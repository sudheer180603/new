@echo off
echo Running Tests...
python -m pytest tests/
if %errorlevel% neq 0 exit /b %errorlevel%
echo Tests Passed!
