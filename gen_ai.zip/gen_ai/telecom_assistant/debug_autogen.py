try:
    import autogen
    print("AutoGen imported successfully")
    print(f"Version: {autogen.__version__}")
except ImportError as e:
    print(f"ImportError: {e}")
except Exception as e:
    print(f"Exception: {e}")
    import traceback
    traceback.print_exc()
