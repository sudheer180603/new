# This file is largely deprecated as logic has moved to views/ and app.py
# Keeping it for any potential shared UI utilities in the future or legacy imports.

import streamlit as st
import os
from config.config import config

def load_css():
    with open(os.path.join(os.path.dirname(__file__), "style.css")) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)
