"""
Test script for Telecom Assistant sample queries
Tests all agents: Billing (CrewAI), Network (AutoGen), Service (LangChain), Knowledge (LlamaIndex)
"""
import os
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from orchestration.graph import app as graph
from dotenv import load_dotenv

load_dotenv()

# Sample queries organized by category
test_queries = {
    "Billing Queries (CrewAI)": [
        "Why did my bill increase by ₹200 this month?",
        "I see a charge for international roaming but I haven't traveled recently",
        "Can you explain the 'Value Added Services' charge on my bill?",
        "What's the early termination fee if I cancel my contract?"
    ],
    "Network Issues (AutoGen)": [
        "I can't make calls from my home in Mumbai West",
        "My data connection keeps dropping when I'm on the train",
        "Why is my 5G connection slower than my friend's?",
        "I get a 'No Service' error in my basement apartment"
    ],
    "Plan Recommendations (LangChain)": [
        "What's the best plan for a family of four who watches a lot of videos?",
        "I need a plan with good international calling to the US",
        "Which plan is best for someone who works from home and needs reliable data?",
        "I'm a light user who mostly just calls and texts. What's my cheapest option?"
    ],
    "Technical Information (LlamaIndex)": [
        "How do I set up VoLTE on my Samsung phone?",
        "What are the APN settings for Android devices?",
        "How can I activate international roaming before traveling?",
        "What areas in Mumbai have 5G coverage?"
    ],
    "Edge Cases": [
        "Tell me a joke about telecom",
        "I need help with both my bill and network issues"
    ]
}

def test_query(query, customer_id="CUST001"):
    """Test a single query through the orchestration graph"""
    print(f"\n{'='*80}")
    print(f"Query: {query}")
    print(f"{'='*80}")
    
    try:
        initial_state = {
            "query": query,
            "customer_id": customer_id,
            "history": [],
            "metadata": {}
        }
        
        result = graph.invoke(initial_state)
        response = result.get("response", "No response")
        category = result.get("category", "Unknown")
        
        print(f"Category: {category}")
        print(f"Response: {response[:500]}...")  # First 500 chars
        return True
    except Exception as e:
        print(f"ERROR: {str(e)}")
        return False

def main():
    print("="*80)
    print("TELECOM ASSISTANT - SAMPLE QUERY TESTING")
    print("="*80)
    
    total_tests = 0
    passed_tests = 0
    
    for category, queries in test_queries.items():
        print(f"\n\n{'#'*80}")
        print(f"# {category}")
        print(f"{'#'*80}")
        
        for query in queries:
            total_tests += 1
            if test_query(query):
                passed_tests += 1
    
    print(f"\n\n{'='*80}")
    print(f"TEST SUMMARY")
    print(f"{'='*80}")
    print(f"Total Tests: {total_tests}")
    print(f"Passed: {passed_tests}")
    print(f"Failed: {total_tests - passed_tests}")
    print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")

if __name__ == "__main__":
    main()
