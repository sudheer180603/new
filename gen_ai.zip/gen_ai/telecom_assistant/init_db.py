import sqlite3
import os

DB_PATH = os.path.join("data", "telecom.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Create usage_stats table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS usage_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id TEXT,
        data_used_gb REAL,
        total_data_gb REAL,
        voice_minutes_used INTEGER,
        sms_used INTEGER,
        period_start DATE,
        period_end DATE
    )
    """)
    
    # Create plans table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS plans (
        id TEXT PRIMARY KEY,
        name TEXT,
        data_limit_gb REAL,
        voice_limit_minutes INTEGER,
        sms_limit INTEGER,
        price REAL
    )
    """)
    
    # Create billing_history table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS billing_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id TEXT,
        billing_date DATE,
        amount REAL,
        status TEXT
    )
    """)
    
    # Create network_stats table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS network_stats (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        city TEXT,
        coverage_percent REAL,
        active_users INTEGER,
        status TEXT,
        avg_latency_ms INTEGER
    )
    """)

    # Create support_tickets table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS support_tickets (
        id TEXT PRIMARY KEY,
        customer_id TEXT,
        issue_type TEXT,
        description TEXT,
        status TEXT,
        created_at DATE,
        priority TEXT
    )
    """)
    
    # Populate usage_stats if empty
    cursor.execute("SELECT count(*) FROM usage_stats")
    if cursor.fetchone()[0] == 0:
        usage_data = [
            ('CUST001', 45.5, 150.0, 120, 50, '2023-11-01', '2023-11-30'),
            ('CUST002', 120.5, 150.0, 500, 150, '2023-11-01', '2023-11-30'),
            ('CUST003', 10.2, 20.0, 50, 10, '2023-11-01', '2023-11-30'),
            ('CUST004', 85.0, 100.0, 300, 80, '2023-11-01', '2023-11-30'),
            ('CUST005', 2.5, 5.0, 20, 5, '2023-11-01', '2023-11-30')
        ]
        cursor.executemany("""
        INSERT INTO usage_stats (customer_id, data_used_gb, total_data_gb, voice_minutes_used, sms_used, period_start, period_end)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, usage_data)
        print("Populated usage_stats")

    # Populate network_stats if empty
    cursor.execute("SELECT count(*) FROM network_stats")
    if cursor.fetchone()[0] == 0:
        network_data = [
            ('Mumbai', 98.5, 25000, 'Operational', 25),
            ('Delhi', 97.2, 22000, 'Operational', 30),
            ('Bangalore', 99.1, 18000, 'Operational', 20),
            ('Hyderabad', 96.5, 15000, 'Operational', 28),
            ('Chennai', 97.8, 14000, 'Operational', 26),
            ('Kolkata', 95.5, 12000, 'Maintenance', 45),
            ('Pune', 98.0, 11000, 'Operational', 22),
            ('Ahmedabad', 94.5, 9500, 'Degraded', 120),
            ('Jaipur', 96.0, 7000, 'Operational', 35),
            ('Lucknow', 93.5, 6500, 'Maintenance', 50)
        ]
        cursor.executemany("""
        INSERT INTO network_stats (city, coverage_percent, active_users, status, avg_latency_ms)
        VALUES (?, ?, ?, ?, ?)
        """, network_data)
        print("Populated network_stats")

    # Populate support_tickets if empty
    cursor.execute("SELECT count(*) FROM support_tickets")
    if cursor.fetchone()[0] == 0:
        tickets = [
            ('TKT-001', 'CUST001', 'Network', 'Slow internet speed in downtown area', 'Open', '2023-11-25', 'High'),
            ('TKT-002', 'CUST002', 'Billing', 'Incorrect charge on last invoice', 'In Progress', '2023-11-26', 'Medium'),
            ('TKT-003', 'CUST005', 'Technical', 'Cannot activate roaming services', 'Closed', '2023-11-20', 'Low'),
            ('TKT-004', 'CUST003', 'Network', 'No signal in subway', 'Open', '2023-11-27', 'Medium'),
            ('TKT-005', 'CUST004', 'Account', 'Request to change plan', 'Resolved', '2023-11-22', 'Low')
        ]
        cursor.executemany("""
        INSERT INTO support_tickets (id, customer_id, issue_type, description, status, created_at, priority)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        """, tickets)
        print("Populated support_tickets")

    # Populate plans if empty (or update)
    # First clear existing plans to ensure sync
    cursor.execute("DELETE FROM plans")
    
    plans = [
        ('BASIC_100', 'Basic Plan', 1.0, 100, 100, 499.0),
        ('STD_500', 'Standard Plan', 5.0, 9999, 9999, 799.0), # 9999 for unlimited
        ('PREM_UNL', 'Premium Unlimited Plan', 150.0, 9999, 9999, 1299.0),
        ('FAMILY_S', 'Family Share Plan', 20.0, 9999, 9999, 1799.0),
        ('BIZ_ESSEN', 'Business Essential Plan', 10.0, 9999, 9999, 1999.0)
    ]
    cursor.executemany("INSERT INTO plans VALUES (?, ?, ?, ?, ?, ?)", plans)
    print("Populated plans from Guide")
        
    # Populate billing_history if empty
    cursor.execute("SELECT count(*) FROM billing_history")
    if cursor.fetchone()[0] == 0:
        cursor.execute("""
        INSERT INTO billing_history (customer_id, billing_date, amount, status)
        VALUES ('CUST001', '2023-10-01', 59.99, 'Paid')
        """)
        print("Populated billing_history")

    conn.commit()
    conn.close()
    print("Database initialized successfully.")

if __name__ == "__main__":
    init_db()
