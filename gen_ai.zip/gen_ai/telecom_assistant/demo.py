"""
Simple demo script to test the Telecom Assistant functionality
without relying on complex test frameworks.
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from orchestration.graph import app as graph

def test_billing_query():
    print("\n" + "="*60)
    print("TEST 1: Billing Query")
    print("="*60)
    query = "Why is my bill so high this month?"
    state = {
        "query": query,
        "customer_id": "CUST_001",
        "history": [],
        "metadata": {}
    }
    
    try:
        result = graph.invoke(state)
        print(f"Query: {query}")
        print(f"Category: {result.get('category', 'N/A')}")
        print(f"Response: {result.get('response', 'No response')[:200]}...")
        print("✓ PASSED")
    except Exception as e:
        print(f"✗ FAILED: {e}")
        import traceback
        traceback.print_exc()

def test_network_query():
    print("\n" + "="*60)
    print("TEST 2: Network Query")
    print("="*60)
    query = "My internet is very slow"
    state = {
        "query": query,
        "customer_id": "CUST_001",
        "history": [],
        "metadata": {}
    }
    
    try:
        result = graph.invoke(state)
        print(f"Query: {query}")
        print(f"Category: {result.get('category', 'N/A')}")
        print(f"Response: {result.get('response', 'No response')[:200]}...")
        print("✓ PASSED")
    except Exception as e:
        print(f"✗ FAILED: {e}")
        import traceback
        traceback.print_exc()

def test_service_query():
    print("\n" + "="*60)
    print("TEST 3: Service Recommendation Query")
    print("="*60)
    query = "I need a plan recommendation"
    state = {
        "query": query,
        "customer_id": "CUST_001",
        "history": [],
        "metadata": {}
    }
    
    try:
        result = graph.invoke(state)
        print(f"Query: {query}")
        print(f"Category: {result.get('category', 'N/A')}")
        print(f"Response: {result.get('response', 'No response')[:200]}...")
        print("✓ PASSED")
    except Exception as e:
        print(f"✗ FAILED: {e}")
        import traceback
        traceback.print_exc()

def test_knowledge_query():
    print("\n" + "="*60)
    print("TEST 4: Knowledge Query")
    print("="*60)
    query = "How do I configure APN settings?"
    state = {
        "query": query,
        "customer_id": "CUST_001",
        "history": [],
        "metadata": {}
    }
    
    try:
        result = graph.invoke(state)
        print(f"Query: {query}")
        print(f"Category: {result.get('category', 'N/A')}")
        print(f"Response: {result.get('response', 'No response')[:200]}...")
        print("✓ PASSED")
    except Exception as e:
        print(f"✗ FAILED: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    print("\n" + "="*60)
    print("TELECOM ASSISTANT DEMO")
    print("="*60)
    
    # Initialize database first
    print("\nInitializing database...")
    try:
        from utils.init_db import create_schema, seed_data
        import sqlite3
        from config.config import config
        conn = sqlite3.connect(config.DB_PATH)
        create_schema(conn)
        seed_data(conn)
        conn.close()
        print("✓ Database initialized")
    except Exception as e:
        print(f"Database initialization: {e}")
    
    # Run tests
    test_billing_query()
    test_network_query()
    test_service_query()
    test_knowledge_query()
    
    print("\n" + "="*60)
    print("DEMO COMPLETE")
    print("="*60)
