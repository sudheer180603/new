import pytest
from unittest.mock import patch, MagicMock
from agents.billing_agents import create_billing_crew, process_billing_query

@patch('agents.billing_agents.Crew')
def test_create_billing_crew(mock_crew):
    crew = create_billing_crew("CUST_001")
    assert mock_crew.called

@patch('agents.billing_agents.create_billing_crew')
def test_process_billing_query(mock_create_crew):
    mock_crew_instance = MagicMock()
    mock_crew_instance.kickoff.return_value = "Billing Analysis Result"
    mock_create_crew.return_value = mock_crew_instance
    
    result = process_billing_query("CUST_001", "Check my bill")
    assert result == "Billing Analysis Result"
