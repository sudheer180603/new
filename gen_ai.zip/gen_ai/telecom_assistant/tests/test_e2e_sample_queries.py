import pytest
from unittest.mock import patch, MagicMock
from orchestration.graph import app as graph

@patch('orchestration.graph.process_billing_query')
@patch('orchestration.graph.process_network_query')
@patch('orchestration.graph.process_recommendation_query')
@patch('orchestration.graph.process_knowledge_query')
def test_e2e_flow(mock_knowledge, mock_service, mock_network, mock_billing):
    # Setup Mocks
    mock_billing.return_value = "Billing Agent Response"
    mock_network.return_value = "Network Agent Response"
    mock_service.return_value = "Service Agent Response"
    mock_knowledge.return_value = "Knowledge Agent Response"
    
    # Test Billing Flow
    state = {"query": "Check my bill", "history": [], "metadata": {}}
    result = graph.invoke(state)
    assert result["response"] == "Billing Agent Response"
    
    # Test Network Flow
    state = {"query": "Internet is slow", "history": [], "metadata": {}}
    result = graph.invoke(state)
    assert result["response"] == "Network Agent Response"
    
    # Test Service Flow
    state = {"query": "Recommend a plan", "history": [], "metadata": {}}
    result = graph.invoke(state)
    assert result["response"] == "Service Agent Response"
    
    # Test Knowledge Flow
    state = {"query": "How to setup APN", "history": [], "metadata": {}}
    result = graph.invoke(state)
    assert result["response"] == "Knowledge Agent Response"
