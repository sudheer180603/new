import pytest
from unittest.mock import patch, MagicMock
from agents.knowledge_agents import process_knowledge_query

@patch('agents.knowledge_agents.create_knowledge_engine')
def test_process_knowledge_query(mock_create):
    mock_engine = MagicMock()
    mock_response = MagicMock()
    mock_response.__str__.return_value = "To configure APN..."
    mock_response.source_nodes = []
    mock_engine.query.return_value = mock_response
    mock_create.return_value = mock_engine
    
    result = process_knowledge_query("How to set APN?")
    assert "To configure APN..." in result
