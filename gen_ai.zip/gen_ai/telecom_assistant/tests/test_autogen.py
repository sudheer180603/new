import pytest
from unittest.mock import patch, MagicMock
from agents.network_agents import create_network_agents, process_network_query

@patch('agents.network_agents.autogen.UserProxyAgent')
@patch('agents.network_agents.autogen.AssistantAgent')
def test_create_network_agents(mock_assistant, mock_user):
    agents = create_network_agents()
    assert len(agents) == 4

@patch('agents.network_agents.autogen.GroupChat')
@patch('agents.network_agents.autogen.GroupChatManager')
@patch('agents.network_agents.create_network_agents')
def test_process_network_query(mock_create, mock_manager, mock_chat):
    mock_user = MagicMock()
    mock_create.return_value = (mock_user, MagicMock(), MagicMock(), MagicMock())
    
    # Mock the chat history
    mock_chat_instance = MagicMock()
    mock_chat_instance.messages = [{'content': 'Troubleshooting Plan'}]
    mock_chat.return_value = mock_chat_instance
    
    result = process_network_query("My internet is down")
    # Note: In our implementation we return the last message content
    # The mock setup here is a bit simplified
    assert result == 'Troubleshooting Plan'
