import pytest
from unittest.mock import patch, MagicMock
from agents.service_agents import estimate_data_usage, process_recommendation_query

def test_estimate_data_usage():
    desc = "I watch Netflix and listen to Spotify"
    result = estimate_data_usage(desc)
    assert "65.0 GB" in result

@patch('agents.service_agents.create_service_agent')
def test_process_recommendation_query(mock_create):
    mock_executor = MagicMock()
    mock_executor.invoke.return_value = {"output": "Recommended Plan: Pro Unlimited"}
    mock_create.return_value = mock_executor
    
    result = process_recommendation_query("I need a better plan")
    assert result == "Recommended Plan: Pro Unlimited"
