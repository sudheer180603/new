import pytest
from unittest.mock import MagicMock
import sys
import os

# Add project root to path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

@pytest.fixture
def mock_llm():
    mock = MagicMock()
    mock.invoke.return_value.content = "billing"
    return mock
