import pytest
from orchestration.graph import classify_query

def test_classify_billing_keyword():
    state = {"query": "I have a question about my bill"}
    result = classify_query(state)
    assert result["category"] == "billing"

def test_classify_network_keyword():
    state = {"query": "My internet is slow"}
    result = classify_query(state)
    assert result["category"] == "network"

def test_classify_service_keyword():
    state = {"query": "Recommend a new plan"}
    result = classify_query(state)
    assert result["category"] == "service"

def test_classify_knowledge_keyword():
    state = {"query": "How to configure APN"}
    result = classify_query(state)
    assert result["category"] == "knowledge"
