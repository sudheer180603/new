import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
    OPENAI_API_MODEL = os.getenv("OPENAI_API_MODEL", "gpt-3.5-turbo")
    VECTOR_STORE_TYPE = os.getenv("VECTOR_STORE_TYPE", "chroma")
    CHROMA_DB_PATH = os.getenv("CHROMA_DB_PATH", "./data/chroma_db")
    DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "telecom.db")
    DOCS_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "documents")

config = Config()
