"""
Comprehensive test to verify all sample queries work correctly
"""
import os
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from orchestration.graph import app as graph
from dotenv import load_dotenv

load_dotenv()

# Test queries with expected categories
test_cases = [
    # Billing Queries (CrewAI)
    ("Why did my bill increase by ₹200 this month?", "billing"),
    ("I see a charge for international roaming but I haven't traveled recently", "billing"),
    ("Can you explain the 'Value Added Services' charge on my bill?", "billing"),
    ("What's the early termination fee if I cancel my contract?", "billing"),
    
    # Network Issues (AutoGen)
    ("I can't make calls from my home in Mumbai West", "network"),
    ("My data connection keeps dropping when I'm on the train", "network"),
    ("Why is my 5G connection slower than my friend's?", "network"),
    ("I get a 'No Service' error in my basement apartment", "network"),
    
    # Plan Recommendations (LangChain)
    ("What's the best plan for a family of four who watches a lot of videos?", "service"),
    ("I need a plan with good international calling to the US", "service"),
    ("Which plan is best for someone who works from home and needs reliable data?", "service"),
    ("I'm a light user who mostly just calls and texts. What's my cheapest option?", "service"),
    
    # Technical Information (LlamaIndex)
    ("How do I set up VoLTE on my Samsung phone?", "knowledge"),
    ("What are the APN settings for Android devices?", "knowledge"),
    ("How can I activate international roaming before traveling?", "knowledge"),
    ("What areas in Mumbai have 5G coverage?", "knowledge"),
]

def test_query(query, expected_category, customer_id="CUST001"):
    """Test a single query"""
    print(f"\n{'='*80}")
    print(f"Query: {query}")
    print(f"Expected Category: {expected_category}")
    print(f"{'='*80}")
    
    try:
        initial_state = {
            "query": query,
            "customer_id": customer_id,
            "history": [],
            "metadata": {}
        }
        
        result = graph.invoke(initial_state)
        actual_category = result.get("category", "Unknown")
        response = result.get("response", "No response")
        
        # Check if category matches
        category_match = "✅" if actual_category == expected_category else "❌"
        
        print(f"{category_match} Actual Category: {actual_category}")
        print(f"\nResponse Preview: {response[:200]}...")
        
        return actual_category == expected_category
    except Exception as e:
        print(f"❌ ERROR: {str(e)}")
        return False

def main():
    print("="*80)
    print("TELECOM ASSISTANT - COMPREHENSIVE QUERY TEST")
    print("="*80)
    
    total_tests = len(test_cases)
    passed_tests = 0
    category_results = {"billing": [], "network": [], "service": [], "knowledge": []}
    
    for query, expected_category in test_cases:
        if test_query(query, expected_category):
            passed_tests += 1
            category_results[expected_category].append("✅")
        else:
            category_results[expected_category].append("❌")
    
    # Summary
    print(f"\n\n{'='*80}")
    print(f"TEST SUMMARY")
    print(f"{'='*80}")
    print(f"Total Tests: {total_tests}")
    print(f"Passed: {passed_tests}")
    print(f"Failed: {total_tests - passed_tests}")
    print(f"Success Rate: {(passed_tests/total_tests)*100:.1f}%")
    
    print(f"\n{'='*80}")
    print(f"CATEGORY BREAKDOWN")
    print(f"{'='*80}")
    for category, results in category_results.items():
        passed = results.count("✅")
        total = len(results)
        print(f"{category.upper()}: {passed}/{total} passed - {''.join(results)}")

if __name__ == "__main__":
    main()
