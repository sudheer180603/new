import sqlite3
import os

DB_PATH = os.path.join("data", "telecom.db")

def migrate_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Get current table structure
    cursor.execute("PRAGMA table_info(customers)")
    columns = [col[1] for col in cursor.fetchall()]
    print(f"Current columns: {columns}")
    
    # Check if we need to add plan column
    if 'plan' not in columns and 'current_plan_id' not in columns:
        print("Adding plan column...")
        try:
            cursor.execute("ALTER TABLE customers ADD COLUMN plan TEXT DEFAULT 'PREM_UNL'")
            conn.commit()
            print("Added plan column successfully")
        except Exception as e:
            print(f"Error adding column: {e}")
    
    # Update customer plan
    try:
        cursor.execute("UPDATE customers SET plan = 'PREM_UNL' WHERE customer_id = 'CUST001'")
        conn.commit()
        print("Updated customer plan")
    except Exception as e:
        print(f"Could not update: {e}")
    
    # Verify
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM customers WHERE customer_id = 'CUST001'")
    row = cursor.fetchone()
    print(f"Customer data: {dict(row)}")
    
    conn.close()
    print("Migration complete")

if __name__ == "__main__":
    migrate_db()
