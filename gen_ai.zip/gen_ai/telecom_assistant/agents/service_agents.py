from langchain.agents import AgentExecutor, create_react_agent
from langchain_community.tools import QuerySQLDataBaseTool, InfoSQLDatabaseTool, ListSQLDatabaseTool
from langchain_community.utilities import SQLDatabase
from langchain_core.tools import Tool
from langchain_core.prompts import PromptTemplate
from langchain_openai import ChatOpenAI
from config.config import config

# Initialize Database
db = SQLDatabase.from_uri(f"sqlite:///{config.DB_PATH}")

def estimate_data_usage(description: str) -> str:
    """
    Estimates monthly data usage in GB based on user description.
    Example input: "I watch 2 hours of Netflix daily and listen to Spotify on my commute."
    """
    # Simple heuristic for demo purposes
    usage = 0.0
    description = description.lower()
    
    if "netflix" in description or "video" in description or "streaming" in description:
        usage += 60.0 # 2GB/day * 30
    if "spotify" in description or "music" in description:
        usage += 5.0
    if "social media" in description or "instagram" in description:
        usage += 10.0
    if "email" in description or "browsing" in description:
        usage += 2.0
        
    return f"Estimated monthly data usage: {usage} GB"

def create_service_agent():
    """
    Creates a LangChain ReAct agent for service recommendations.
    """
    llm = ChatOpenAI(model=config.OPENAI_API_MODEL, temperature=0)
    
    tools = [
        QuerySQLDataBaseTool(db=db),
        InfoSQLDatabaseTool(db=db),
        ListSQLDatabaseTool(db=db),
        Tool(
            name="EstimateDataUsage",
            func=estimate_data_usage,
            description="Useful for estimating data usage based on user activities. Input should be a description of daily habits."
        )
    ]
    
    # Define the ReAct prompt template
    template = """Answer the following questions as best you can. You have access to the following tools:

{tools}

Use the following format:

Question: the input question you must answer
Thought: you should always think about what to do
Action: the action to take, should be one of [{tool_names}]
Action Input: the input to the action
Observation: the result of the action
... (this Thought/Action/Action Input/Observation can repeat N times)
Thought: I now know the final answer
Final Answer: the final answer to the original input question

Begin!

Question: {input}
Thought:{agent_scratchpad}"""
    
    prompt = PromptTemplate.from_template(template)
    
    agent = create_react_agent(llm, tools, prompt)
    agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True, handle_parsing_errors=True)
    
    return agent_executor

def process_recommendation_query(query: str) -> str:
    """
    Process a service recommendation query.
    """
    agent_executor = create_service_agent()
    
    # Add context to the query to ensure the agent checks plans
    enhanced_query = f"""
    User Query: {query}
    
    Instructions:
    1. Carefully analyze what the user needs:
       - If they mention "international calling" or specific countries (like "US"), they need a plan with good international calling features
       - If they mention "family" or multiple people, they likely need high data limits (50GB+)
       - If they mention "videos", "streaming", or "Netflix", they need high data (50GB+)
       - If they mention "light user", "just calls and texts", they need minimal data (1-5GB)
       - If they mention "work from home" or "reliable data", they need stable high-speed data (20GB+)
    
    2. If the user describes their usage patterns, use the EstimateDataUsage tool to get an estimated data requirement.
    
    3. Query the 'plans' table to see all available plans with their features:
       - Check data_limit_gb for data allowances
       - Check voice_minutes for calling limits
       - Check price for cost
       - Note: For international calling needs, Premium plans typically offer better international rates
    
    4. Recommend the BEST plan based on:
       - User's estimated or stated data needs
       - User's calling needs (especially international)
       - Cost-effectiveness
       - Special features they mentioned
    
    5. Provide a clear explanation:
       - Why this plan fits their needs
       - What features match their requirements
       - Cost comparison if relevant
       - Any limitations they should be aware of
    
    IMPORTANT: 
    - For international calling queries, recommend Premium Unlimited or Family Share plans as they typically have better international rates
    - For light users, recommend Basic Plan
    - For heavy video/streaming users, recommend Premium Unlimited
    - For families, recommend Family Share or Premium Unlimited
    - Always explain your reasoning clearly
    """
    
    result = agent_executor.invoke({"input": enhanced_query})
    return result["output"]
