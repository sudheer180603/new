from llama_index.core import (
    VectorStoreIndex,
    Settings,
    SQLDatabase,
    StorageContext
)
from llama_index.core.query_engine import NLSQLTableQueryEngine, RouterQueryEngine
from llama_index.core.selectors import LLMSingleSelector
from llama_index.core.tools import QueryEngineTool
# Note: OpenAI might need llama-index-llms-openai
try:
    from llama_index.llms.openai import OpenAI
except ImportError:
    from llama_index.llms import OpenAI
from sqlalchemy import create_engine
from config.config import config
from utils.document_loader import load_documents
import warnings

# Suppress SQLAlchemy deprecation warnings
warnings.filterwarnings('ignore', category=DeprecationWarning)

def create_knowledge_engine():
    """
    Creates a LlamaIndex engine that can route between SQL and Vector Store.
    """
    # 1. Setup Global Settings (replaces ServiceContext)
    llm = OpenAI(model=config.OPENAI_API_MODEL, temperature=0)
    Settings.llm = llm

    # 2. Setup Vector Store (for Documents)
    documents = load_documents()
    vector_index = VectorStoreIndex.from_documents(documents)
    vector_query_engine = vector_index.as_query_engine()
    
    vector_tool = QueryEngineTool.from_defaults(
        query_engine=vector_query_engine,
        description=(
            "Use this tool for general knowledge questions about TeleServe services, including: "
            "network coverage areas (5G/4G coverage locations), service plans and features, "
            "technical guides (APN settings, VoLTE setup, device configuration), "
            "troubleshooting guides, FAQs, how-to questions, and general telecom information. "
            "Examples: 'What areas have 5G coverage?', 'How to set up VoLTE?', 'What are APN settings?', "
            "'How to activate international roaming?'"
        ),
    )

    # 3. Setup SQL Engine (for Database)
    engine = create_engine(f"sqlite:///{config.DB_PATH}", future=True)
    try:
        # Try newer API first
        sql_database = SQLDatabase(engine, view_names=["customers", "plans", "network_incidents"])
    except TypeError:
        # Fallback to older API
        sql_database = SQLDatabase(engine, include_tables=["customers", "plans", "network_incidents"])
    
    sql_query_engine = NLSQLTableQueryEngine(sql_database=sql_database)
    
    sql_tool = QueryEngineTool.from_defaults(
        query_engine=sql_query_engine,
        description=(
            "Use this tool ONLY for specific customer data queries, including: "
            "individual customer account information, billing history and charges, "
            "usage statistics for specific customers, active network incident records, "
            "and plan pricing details. "
            "Examples: 'What is customer CUST001's current plan?', 'Show my billing history', "
            "'Are there any active network incidents?', 'What does the Premium plan cost?'"
        ),
    )

    # 4. Setup Router
    query_engine = RouterQueryEngine(
        selector=LLMSingleSelector.from_defaults(),
        query_engine_tools=[
            vector_tool,
            sql_tool,
        ],
    )
    
    return query_engine

def process_knowledge_query(query: str) -> str:
    """
    Process a knowledge query using LlamaIndex.
    """
    query_engine = create_knowledge_engine()
    response = query_engine.query(query)
    
    # Format response with sources if available
    result = str(response)
    if response.source_nodes:
        result += "\n\n**Sources:**\n"
        for node in response.source_nodes:
            # Try to get file_name from metadata, fallback to "Document"
            file_name = node.metadata.get("file_name", "Document")
            result += f"- {file_name}\n"
            
    return result
