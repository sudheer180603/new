import os
os.environ["OTEL_SDK_DISABLED"] = "true"  # Disable CrewAI telemetry

from typing import Dict, Any
from langchain_community.utilities import SQLDatabase
from crewai import Agent, Task, Crew, Process
from crewai.tools import tool
from config.config import config

# Initialize Database
db = SQLDatabase.from_uri(f"sqlite:///{config.DB_PATH}")

@tool("Query Database")
def query_database(query: str) -> str:
    """Execute a SQL query against the telecom database and return results."""
    try:
        result = db.run(query)
        return str(result)
    except Exception as e:
        return f"Error executing query: {str(e)}"

def create_billing_crew(customer_id: str, query: str) -> Crew:
    """
    Creates a CrewAI crew for handling billing inquiries.
    """
    
    # Define Agent focused on answering the specific question
    billing_analyst = Agent(
        role='Billing Analyst',
        goal=f'Answer the customer\'s specific billing question: "{query}"',
        backstory=f'''You are a billing expert who answers specific customer questions about their bills.
        The customer asked: "{query}"
        
        Your job is to:
        1. Query the database to get relevant billing and usage data
        2. Answer their SPECIFIC question directly
        3. Only provide information relevant to their question
        4. Be concise and helpful
        
        IMPORTANT: Answer the question they asked, not what you think they should know.''',
        tools=[query_database],
        verbose=True,
        allow_delegation=False
    )
    
    # Create a single task focused on answering the query
    answer_task = Task(
        description=f"""
        The customer (ID: {customer_id}) asked: "{query}"
        
        Your task is to answer this SPECIFIC question. Follow these steps:
        
        1. Identify what the customer is asking:
           - "Why did my bill increase?" → Compare recent bills, find the difference
           - "What is this charge?" → Look for that specific charge in billing_history
           - "Early termination fee?" → Look up contract terms or provide standard info
           - "Roaming charge but didn't travel?" → Check billing_history for roaming charges
        
        2. Query the database for relevant information:
           - SELECT * FROM billing_history WHERE customer_id = '{customer_id}' ORDER BY billing_date DESC LIMIT 3
           - SELECT * FROM customers WHERE customer_id = '{customer_id}'
           - SELECT * FROM usage_stats WHERE customer_id = '{customer_id}'
        
        3. Answer the question directly:
           - If asking about bill increase: Compare the amounts and explain what changed
           - If asking about a specific charge: Look for that charge and explain it
           - If asking about fees: Provide the specific fee information
           - Be specific with numbers and dates from the database
        
        4. Keep your answer focused on their question. Don't provide plan recommendations unless they asked for them.
        
        CRITICAL: Answer ONLY what they asked. Don't go off-topic.
        """,
        agent=billing_analyst,
        expected_output=f"A direct, specific answer to the customer's question: '{query}'"
    )
    
    # Create Crew with single focused task
    billing_crew = Crew(
        agents=[billing_analyst],
        tasks=[answer_task],
        process=Process.sequential,
        verbose=True
    )
    
    return billing_crew

def process_billing_query(customer_id: str, query: str) -> str:
    """
    Process a billing query using the CrewAI crew.
    """
    try:
        crew = create_billing_crew(customer_id, query)
        result = crew.kickoff()
        return str(result)
    except Exception as e:
        # Fallback response if CrewAI fails
        return f"""Billing Analysis for Customer {customer_id}

I apologize, but I encountered an issue processing your billing query with the full analysis system.

Here's a basic summary:
- Your current plan and recent charges are available in your account dashboard
- For detailed billing analysis, please contact customer support
- You can also check your usage statistics in the sidebar

Error details: {str(e)}
"""
