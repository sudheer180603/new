from typing import TypedDict, Optional, List, Dict, Any

class TelecomAssistantState(TypedDict):
    query: str
    customer_id: Optional[str]
    category: Optional[str] # 'billing', 'network', 'service', 'knowledge', 'general'
    history: List[str]
    response: Optional[str]
    metadata: Dict[str, Any]
