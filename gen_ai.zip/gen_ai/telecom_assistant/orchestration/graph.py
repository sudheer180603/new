from langgraph.graph import StateGraph, END
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from config.config import config
from orchestration.state import TelecomAssistantState
from agents.billing_agents import process_billing_query
from agents.network_agents import process_network_query
from agents.service_agents import process_recommendation_query
from agents.knowledge_agents import process_knowledge_query

# Initialize LLM for classification
llm = ChatOpenAI(model=config.OPENAI_API_MODEL, temperature=0)

def classify_query(state: TelecomAssistantState):
    """
    Classifies the user query into one of the known categories.
    """
    query = state["query"]
    
    # Fallback/Keyword logic for offline testing/determinism
    query_lower = query.lower()
    
    # Knowledge queries (technical, how-to, guides) - check first
    if any(word in query_lower for word in ["how to", "how do", "how can", "guide", "setup", "set up", "configure", "activate", "apn", "volte", "settings", "roaming", "coverage", "areas"]):
        return {"category": "knowledge"}
    
    # Billing queries
    if any(word in query_lower for word in ["bill", "charge", "payment", "invoice", "fee", "cost"]):
        return {"category": "billing"}
    
    # Network queries
    if any(word in query_lower for word in ["network", "internet", "slow", "signal", "connection", "dropping", "can't make calls", "no service"]):
        return {"category": "network"}
    
    # Service/Plan queries
    if any(word in query_lower for word in ["plan", "recommend", "upgrade", "best plan", "cheapest", "family"]):
        return {"category": "service"}
        
    # LLM Classification as fallback
    prompt = ChatPromptTemplate.from_template(
        """
        Classify the following telecom user query into one of these categories:
        - billing (for bill analysis, charges, payments)
        - network (for troubleshooting, outages, technical issues)
        - service (for plan recommendations, upgrades, new services)
        - knowledge (for general questions, how-to guides, documentation, technical setup)
        - general (if it doesn't fit others)
        
        Query: {query}
        
        Category:
        """
    )
    chain = prompt | llm
    response = chain.invoke({"query": query})
    category = response.content.strip().lower()
    
    return {"category": category}

def route_query(state: TelecomAssistantState):
    """
    Determines the next node based on the category.
    """
    category = state["category"]
    if category == "billing":
        return "billing_node"
    elif category == "network":
        return "network_node"
    elif category == "service":
        return "service_node"
    elif category == "knowledge":
        return "knowledge_node"
    else:
        return "fallback_handler"

def billing_node(state: TelecomAssistantState):
    customer_id = state.get("customer_id", "CUST_001") # Default for demo
    response = process_billing_query(customer_id, state["query"])
    return {"response": response}

def network_node(state: TelecomAssistantState):
    response = process_network_query(state["query"])
    return {"response": response}

def service_node(state: TelecomAssistantState):
    response = process_recommendation_query(state["query"])
    return {"response": response}

def knowledge_node(state: TelecomAssistantState):
    response = process_knowledge_query(state["query"])
    return {"response": response}

def fallback_handler(state: TelecomAssistantState):
    return {"response": "I'm sorry, I couldn't understand your request. Please try asking about billing, network issues, plans, or general support."}

# Build the Graph
workflow = StateGraph(TelecomAssistantState)

workflow.add_node("classify_query", classify_query)
workflow.add_node("billing_node", billing_node)
workflow.add_node("network_node", network_node)
workflow.add_node("service_node", service_node)
workflow.add_node("knowledge_node", knowledge_node)
workflow.add_node("fallback_handler", fallback_handler)

workflow.set_entry_point("classify_query")

workflow.add_conditional_edges(
    "classify_query",
    route_query,
    {
        "billing_node": "billing_node",
        "network_node": "network_node",
        "service_node": "service_node",
        "knowledge_node": "knowledge_node",
        "fallback_handler": "fallback_handler"
    }
)

workflow.add_edge("billing_node", END)
workflow.add_edge("network_node", END)
workflow.add_edge("service_node", END)
workflow.add_edge("knowledge_node", END)
workflow.add_edge("fallback_handler", END)

app = workflow.compile()
