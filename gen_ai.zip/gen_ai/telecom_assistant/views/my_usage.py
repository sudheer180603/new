import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import os
from utils.database import DatabaseManager

# Initialize DB
db = DatabaseManager()

st.set_page_config(page_title="My Usage", page_icon="📊", layout="wide")

def load_css():
    with open("ui/style.css") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

load_css()

# Check Login
if 'user' not in st.session_state or not st.session_state['logged_in']:
    st.warning("Please login to view your usage.")
    st.stop()

user = st.session_state['user']
customer_id = user['customer_id']

st.title(f"📊 Usage Analytics: {user['name']}")

# Fetch Data
usage_stats = db.get_usage_stats(customer_id)
customer = db.get_customer(customer_id)

if not usage_stats or not customer:
    st.error("Could not load usage data.")
    st.stop()

current_usage = usage_stats[0]

# Usage Alerts
usage_pct = db.get_customer_usage_percentage(customer_id)
if usage_pct['data'] >= 80:
    overage_gb = max(0, current_usage['data_used_gb'] - current_usage['total_data_gb'])
    if overage_gb > 0:
        st.error(f"⚠️ **Data Limit Exceeded!** You've used {current_usage['data_used_gb']:.1f} GB of {current_usage['total_data_gb']:.1f} GB. Overage: {overage_gb:.1f} GB. Consider upgrading your plan.")
    else:
        st.warning(f"⚠️ **High Usage Alert!** You've used {usage_pct['data']:.1f}% of your data limit. Consider monitoring your usage or upgrading your plan.")
elif usage_pct['data'] >= 50:
    st.info(f"💡 You've used {usage_pct['data']:.1f}% of your data limit. You're on track!")


# Plan Overview
st.markdown("### 📱 Current Plan Overview")
col1, col2, col3 = st.columns(3)

with col1:
    # Data Gauge
    fig_data = go.Figure(go.Indicator(
        mode = "gauge+number+delta",
        value = current_usage['data_used_gb'],
        domain = {'x': [0, 1], 'y': [0, 1]},
        title = {'text': "Data (GB)"},
        delta = {'reference': current_usage['total_data_gb'], 'increasing': {'color': "red"}},
        gauge = {
            'axis': {'range': [None, current_usage['total_data_gb']], 'tickwidth': 1, 'tickcolor': "white"},
            'bar': {'color': "#3B82F6"},
            'bgcolor': "rgba(0,0,0,0)",
            'borderwidth': 2,
            'bordercolor': "#333",
            'steps': [
                {'range': [0, current_usage['total_data_gb']*0.8], 'color': 'rgba(59, 130, 246, 0.3)'},
                {'range': [current_usage['total_data_gb']*0.8, current_usage['total_data_gb']], 'color': 'rgba(239, 68, 68, 0.3)'}],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': current_usage['total_data_gb']}}))
    fig_data.update_layout(paper_bgcolor = "rgba(0,0,0,0)", font = {'color': "white", 'family': "Inter"})
    st.plotly_chart(fig_data, use_container_width=True)

with col2:
    st.metric("Voice Minutes Used", f"{current_usage['voice_minutes_used']} mins", "Unlimited Plan")
    st.progress(min(current_usage['voice_minutes_used'] / 5000, 1.0)) # Mock limit
    
    st.markdown("---")
    
    st.metric("SMS Used", f"{current_usage['sms_used']}", "Unlimited Plan")
    st.progress(min(current_usage['sms_used'] / 5000, 1.0)) # Mock limit

with col3:
    st.markdown(f"""
    <div style='background-color: var(--bg-tertiary); padding: 1.5rem; border-radius: 1rem; border: 1px solid var(--border-medium);'>
        <h3>{customer.get('plan', 'Standard Plan')}</h3>
        <p style='color: var(--text-secondary)'>Billing Cycle: 1st - 30th</p>
        <h2 style='color: var(--accent-primary)'>$59.99/mo</h2>
        <br>
        <button style='background-color: var(--bg-quaternary); color: white; border: 1px solid var(--border-medium); padding: 0.5rem 1rem; border-radius: 0.5rem; width: 100%; cursor: pointer;'>Change Plan</button>
    </div>
    """, unsafe_allow_html=True)

st.markdown("---")

# Historical Usage (Mocked for now as we only have one record in usage_stats usually, but let's pretend)
st.subheader("📅 Daily Usage History")

# Mocking daily data for the chart
dates = pd.date_range(start='2023-11-01', periods=30)
import numpy as np
daily_data = pd.DataFrame({
    'Date': dates,
    'Data (GB)': np.random.uniform(0.5, 2.5, 30).cumsum() # Cumulative to match total
})
# Reset to match total roughly
daily_data['Data (GB)'] = daily_data['Data (GB)'] * (current_usage['data_used_gb'] / daily_data['Data (GB)'].max())

fig_hist = px.area(
    daily_data, 
    x='Date', 
    y='Data (GB)',
    title='Data Consumption Trend',
    color_discrete_sequence=['#3B82F6']
)
fig_hist.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
st.plotly_chart(fig_hist, use_container_width=True)
