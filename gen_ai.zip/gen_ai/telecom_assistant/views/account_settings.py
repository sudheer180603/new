import streamlit as st
from utils.database import DatabaseManager

db = DatabaseManager()

st.title("⚙️ Account Settings")

# Check Login
if 'user' not in st.session_state or not st.session_state['logged_in']:
    st.warning("Please login to view account settings.")
    st.stop()

user = st.session_state['user']
customer_id = user['customer_id']

# Fetch customer data
customer = db.get_customer(customer_id)

if not customer:
    st.error("Could not load account information.")
    st.stop()

# Profile Information
st.subheader("👤 Profile Information")

with st.form("profile_form"):
    new_name = st.text_input("Full Name", value=customer.get('name', ''))
    
    # Mock email field (not in DB, but for demo)
    email = st.text_input("Email", value=f"{customer_id.lower()}@example.com", disabled=True)
    
    st.info("💡 Email cannot be changed. Contact support for assistance.")
    
    submitted = st.form_submit_button("Update Profile")
    if submitted:
        updates = {'name': new_name}
        if db.update_customer(customer_id, updates):
            st.success("✅ Profile updated successfully!")
            # Update session state
            st.session_state['user']['name'] = new_name
            st.rerun()
        else:
            st.error("❌ Failed to update profile.")

st.markdown("---")

# Current Plan
st.subheader("📱 Current Plan")

plan = db.get_plan_details(customer.get('plan', 'BASIC_100'))
if plan:
    col1, col2 = st.columns([2, 1])
    with col1:
        st.markdown(f"""
        <div style='background-color: var(--bg-tertiary); padding: 1.5rem; border-radius: 1rem; border: 1px solid var(--border-medium);'>
            <h3>{plan['name']}</h3>
            <p style='color: var(--text-secondary)'>Plan ID: {plan['id']}</p>
            <ul>
                <li>Data: {plan['data_limit_gb']} GB</li>
                <li>Voice: {'Unlimited' if plan['voice_limit_minutes'] >= 9999 else f"{plan['voice_limit_minutes']} minutes"}</li>
                <li>SMS: {'Unlimited' if plan['sms_limit'] >= 9999 else f"{plan['sms_limit']} messages"}</li>
            </ul>
            <h2 style='color: var(--accent-primary)'>${plan['price']}/month</h2>
        </div>
        """, unsafe_allow_html=True)
    with col2:
        if st.button("Compare Plans", use_container_width=True):
            st.info("Navigate to 'Plan Comparison' to explore other plans.")

st.markdown("---")

# Account Status
st.subheader("📊 Account Status")

col_a, col_b = st.columns(2)
with col_a:
    status = customer.get('account_status', 'Active')
    status_color = 'green' if status == 'Active' else 'orange' if status == 'Inactive' else 'red'
    st.markdown(f"**Status:** <span style='color: {status_color}; font-weight: bold;'>{status}</span>", unsafe_allow_html=True)
with col_b:
    st.markdown(f"**Customer ID:** {customer_id}")

st.markdown("---")

# Security
st.subheader("🔒 Security")

with st.expander("Change Password"):
    with st.form("password_form"):
        current_password = st.text_input("Current Password", type="password")
        new_password = st.text_input("New Password", type="password")
        confirm_password = st.text_input("Confirm New Password", type="password")
        
        change_password = st.form_submit_button("Change Password")
        if change_password:
            if new_password != confirm_password:
                st.error("❌ Passwords do not match.")
            elif len(new_password) < 6:
                st.error("❌ Password must be at least 6 characters.")
            else:
                st.success("✅ Password changed successfully! (Simulated)")
