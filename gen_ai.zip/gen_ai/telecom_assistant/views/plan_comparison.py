import streamlit as st
import pandas as pd
from utils.database import DatabaseManager

db = DatabaseManager()

st.title("📊 Plan Comparison")

# Check Login
if 'user' not in st.session_state or not st.session_state['logged_in']:
    st.warning("Please login to compare plans.")
    st.stop()

user = st.session_state['user']
customer_id = user['customer_id']
customer = db.get_customer(customer_id)
current_plan_id = customer.get('plan', 'BASIC_100') if customer else 'BASIC_100'

# Fetch all plans
plans = db.get_all_plans()

if plans:
    st.markdown("### Compare All Available Plans")
    
    # Create comparison table
    df_plans = pd.DataFrame(plans)
    
    # Add a column to highlight current plan
    df_plans['Current'] = df_plans['id'].apply(lambda x: '✅' if x == current_plan_id else '')
    
    # Reorder columns
    df_plans = df_plans[['Current', 'name', 'data_limit_gb', 'voice_limit_minutes', 'sms_limit', 'price']]
    
    # Format display
    df_plans['voice_limit_minutes'] = df_plans['voice_limit_minutes'].apply(
        lambda x: 'Unlimited' if x >= 9999 else f"{x} min"
    )
    df_plans['sms_limit'] = df_plans['sms_limit'].apply(
        lambda x: 'Unlimited' if x >= 9999 else f"{x} SMS"
    )
    
    st.dataframe(
        df_plans,
        use_container_width=True,
        column_config={
            "Current": st.column_config.TextColumn("Current Plan", width="small"),
            "name": st.column_config.TextColumn("Plan Name"),
            "data_limit_gb": st.column_config.NumberColumn("Data (GB)", format="%.1f GB"),
            "voice_limit_minutes": st.column_config.TextColumn("Voice"),
            "sms_limit": st.column_config.TextColumn("SMS"),
            "price": st.column_config.NumberColumn("Price", format="$%.2f/mo")
        },
        hide_index=True
    )
    
    st.markdown("---")
    
    # Detailed comparison
    st.subheader("🔍 Detailed Comparison")
    
    selected_plans = st.multiselect(
        "Select plans to compare (max 3)",
        options=[p['id'] for p in plans],
        default=[current_plan_id],
        max_selections=3,
        format_func=lambda x: next((p['name'] for p in plans if p['id'] == x), x)
    )
    
    if selected_plans:
        cols = st.columns(len(selected_plans))
        for idx, plan_id in enumerate(selected_plans):
            plan = next((p for p in plans if p['id'] == plan_id), None)
            if plan:
                with cols[idx]:
                    is_current = plan_id == current_plan_id
                    border_color = 'var(--accent-primary)' if is_current else 'var(--border-medium)'
                    
                    st.markdown(f"""
                    <div style='background-color: var(--bg-tertiary); padding: 1.5rem; border-radius: 1rem; border: 2px solid {border_color};'>
                        <h3>{plan['name']}</h3>
                        {'<span style="color: var(--accent-primary); font-weight: bold;">✅ Current Plan</span>' if is_current else ''}
                        <hr>
                        <h2 style='color: var(--accent-primary)'>${plan['price']}/mo</h2>
                        <ul>
                            <li><strong>Data:</strong> {plan['data_limit_gb']} GB</li>
                            <li><strong>Voice:</strong> {'Unlimited' if plan['voice_limit_minutes'] >= 9999 else f"{plan['voice_limit_minutes']} min"}</li>
                            <li><strong>SMS:</strong> {'Unlimited' if plan['sms_limit'] >= 9999 else f"{plan['sms_limit']} messages"}</li>
                        </ul>
                    </div>
                    """, unsafe_allow_html=True)
                    
                    if not is_current:
                        if st.button(f"Switch to {plan['name']}", key=f"switch_{plan_id}", use_container_width=True):
                            st.info("💡 Plan switching is simulated. In production, this would initiate a plan change request.")
    
    st.markdown("---")
    
    # Savings calculator
    st.subheader("💰 Savings Calculator")
    
    current_plan = next((p for p in plans if p['id'] == current_plan_id), None)
    compare_plan_id = st.selectbox(
        "Compare with:",
        options=[p['id'] for p in plans if p['id'] != current_plan_id],
        format_func=lambda x: next((p['name'] for p in plans if p['id'] == x), x)
    )
    
    if compare_plan_id and current_plan:
        compare_plan = next((p for p in plans if p['id'] == compare_plan_id), None)
        if compare_plan:
            diff = compare_plan['price'] - current_plan['price']
            annual_diff = diff * 12
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Monthly Difference", f"${abs(diff):.2f}", 
                         delta=f"${diff:.2f}" if diff != 0 else "Same price",
                         delta_color="inverse" if diff > 0 else "normal")
            with col2:
                st.metric("Annual Difference", f"${abs(annual_diff):.2f}",
                         delta=f"${annual_diff:.2f}" if annual_diff != 0 else "Same price",
                         delta_color="inverse" if annual_diff > 0 else "normal")
            
            if diff < 0:
                st.success(f"💡 You could save ${abs(annual_diff):.2f} per year by switching to {compare_plan['name']}!")
            elif diff > 0:
                st.info(f"💡 Switching to {compare_plan['name']} would cost ${annual_diff:.2f} more per year, but may offer better benefits.")
else:
    st.error("No plans available.")
