import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import os
from utils.database import DatabaseManager

# Initialize DB
db = DatabaseManager()

st.set_page_config(page_title="Admin Dashboard", page_icon="📈", layout="wide")

def load_css():
    with open("ui/style.css") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

load_css()

# Check Admin Access
if 'user' not in st.session_state or st.session_state['user'].get('role') != 'admin':
    st.error("⛔ Access Denied: Admin privileges required.")
    st.stop()

st.title("📈 Admin Dashboard")
st.markdown("Monitor network performance, user analytics, and system health.")

# Top KPIs
kpis = db.get_admin_kpis()

col1, col2, col3, col4 = st.columns(4)
with col1:
    st.metric("Total Customers", kpis['total_customers'], "+12%")
with col2:
    st.metric("Total Revenue", f"${kpis['total_revenue']:,.2f}", "+5.4%")
with col3:
    st.metric("Active Incidents", kpis['active_incidents'], "-2", delta_color="inverse")
with col4:
    st.metric("Network Uptime", f"{kpis['network_uptime']}%", "+0.1%")

st.markdown("---")

# Tabs for different sections
tab1, tab2, tab3 = st.tabs(["📡 Network Status", "📊 Usage Analytics", "🎫 Support Tickets"])

with tab1:
    st.subheader("Network Coverage & Status")
    
    network_stats = db.get_network_stats()
    if network_stats:
        df_network = pd.DataFrame(network_stats)
        
        # Map Visualization (Mocked with Scatter Mapbox if we had lat/lon, for now Bar/Table)
        # Let's do a nice colored table and a coverage chart
        
        c1, c2 = st.columns([2, 1])
        with c1:
            st.markdown("### City Status Overview")
            # Custom styling for status
            def color_status(val):
                color = 'green' if val == 'Operational' else 'orange' if val == 'Maintenance' else 'red'
                return f'color: {color}; font-weight: bold'
            
            st.dataframe(
                df_network.style.map(color_status, subset=['status']),
                use_container_width=True,
                column_config={
                    "coverage_percent": st.column_config.ProgressColumn(
                        "Coverage",
                        format="%.1f%%",
                        min_value=0,
                        max_value=100,
                    ),
                    "active_users": st.column_config.NumberColumn(
                        "Active Users",
                        format="%d 👤"
                    )
                }
            )
        
        with c2:
            st.markdown("### Coverage Distribution")
            fig_cov = px.bar(
                df_network, 
                x='city', 
                y='coverage_percent',
                color='status',
                color_discrete_map={'Operational': '#10B981', 'Maintenance': '#F59E0B', 'Degraded': '#EF4444'},
                title="Coverage by City"
            )
            fig_cov.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
            st.plotly_chart(fig_cov, use_container_width=True)

with tab2:
    st.subheader("Global Usage Analytics")
    
    col_a, col_b = st.columns(2)
    
    with col_a:
        # Plan Distribution
        plans_dist = kpis['plans_distribution']
        if plans_dist:
            df_plans = pd.DataFrame(plans_dist)
            fig_pie = px.pie(
                df_plans, 
                values='count', 
                names='plan', 
                title='Customer Distribution by Plan',
                hole=0.4,
                color_discrete_sequence=px.colors.qualitative.Pastel
            )
            fig_pie.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
            st.plotly_chart(fig_pie, use_container_width=True)
            
    with col_b:
        # Revenue by Plan
        revenue_data = db.get_revenue_by_plan()
        if revenue_data:
            df_rev = pd.DataFrame(revenue_data)
            fig_bar = px.bar(
                df_rev,
                x='plan',
                y='revenue',
                title='Revenue by Plan Type',
                color='revenue',
                color_continuous_scale='Viridis'
            )
            fig_bar.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
            st.plotly_chart(fig_bar, use_container_width=True)
            
    # Aggregated Usage Stats
    st.markdown("### Total Network Consumption")
    agg_usage = db.get_aggregated_usage_stats()
    
    m1, m2, m3 = st.columns(3)
    m1.metric("Total Data Consumed", f"{agg_usage['total_data']:,.1f} GB")
    m2.metric("Total Voice Minutes", f"{agg_usage['total_voice']:,} mins")
    m3.metric("Total SMS Sent", f"{agg_usage['total_sms']:,}")

with tab3:
    st.subheader("Support Ticket Management")
    
    filter_status = st.selectbox("Filter by Status", ["All", "Open", "In Progress", "Resolved", "Closed"])
    
    if filter_status == "All":
        tickets = db.get_support_tickets()
    else:
        tickets = db.get_support_tickets(filter_status)
        
    if tickets:
        df_tickets = pd.DataFrame(tickets)
        st.dataframe(
            df_tickets,
            use_container_width=True,
            column_config={
                "created_at": st.column_config.DateColumn("Date"),
                "priority": st.column_config.TextColumn("Priority"),
                "status": st.column_config.SelectboxColumn(
                    "Status",
                    options=["Open", "In Progress", "Resolved", "Closed"],
                    required=True
                )
            },
            hide_index=True
        )
    else:
        st.info("No tickets found.")
