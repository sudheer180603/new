import streamlit as st
from orchestration.graph import app as graph
from utils.database import DatabaseManager

db = DatabaseManager()

st.title("Service Assistant")

# Network Status Banner
incidents = db.get_active_incidents()
if incidents:
    st.warning(f"⚠️ Active Network Incident: {incidents[0]['description']} in {incidents[0]['location']}")
else:
    st.success("✅ Network Status: All Systems Operational")

# Chat Interface
if "messages" not in st.session_state:
    st.session_state.messages = []

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

if prompt := st.chat_input("How can I help you today?"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            user = st.session_state.get('user', {'customer_id': 'UNKNOWN'})
            initial_state = {
                "query": prompt,
                "customer_id": user['customer_id'],
                "history": [m["content"] for m in st.session_state.messages],
                "metadata": {}
            }
            
            try:
                result = graph.invoke(initial_state)
                response = result.get("response", "I'm sorry, something went wrong.")
            except Exception as e:
                response = f"An error occurred: {str(e)}"
            
            st.markdown(response)
            st.session_state.messages.append({"role": "assistant", "content": response})
