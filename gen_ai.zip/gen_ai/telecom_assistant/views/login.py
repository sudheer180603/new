import streamlit as st
import time
from utils.database import DatabaseManager

db = DatabaseManager()

def login_view():
    # st.markdown("<div class='login-container'>", unsafe_allow_html=True)
    st.markdown("<h1 class='login-header'>Telecom Assistant</h1>", unsafe_allow_html=True)
    st.markdown("<p class='login-subheader'>Your AI-powered service companion</p>", unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        with st.container():
            st.markdown("""
            <style>
            div[data-testid="stForm"] {
                background-color: var(--bg-tertiary);
                padding: 2rem;
                border-radius: var(--radius-lg);
                border: 1px solid var(--border-medium);
                box-shadow: var(--shadow-lg);
            }
            </style>
            """, unsafe_allow_html=True)
            
            with st.form("login_form"):
                role = st.selectbox("Login As", ["Customer", "Admin"])
                username = st.text_input("Username", placeholder="Enter your ID (e.g., CUST001)")
                password = st.text_input("Password", type="password", placeholder="Enter password")
                submit = st.form_submit_button("Login", use_container_width=True)
                
                if submit:
                    if role == "Admin":
                        if username == "admin" and password == "admin":
                            st.session_state['logged_in'] = True
                            st.session_state['user'] = {'name': 'Administrator', 'role': 'admin', 'customer_id': 'ADMIN'}
                            st.success("Login successful! Redirecting...")
                            time.sleep(1)
                            st.rerun()
                        else:
                            st.error("Invalid Admin credentials")
                    else:
                        # Customer Login
                        user = db.authenticate_user(username, password)
                        if user:
                            st.session_state['logged_in'] = True
                            st.session_state['user'] = user
                            st.success("Login successful! Redirecting...")
                            time.sleep(1)
                            st.rerun()
                        else:
                            st.error("Invalid credentials")
    
    st.markdown("</div>", unsafe_allow_html=True)

login_view()
