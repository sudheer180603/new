import streamlit as st
import pandas as pd
from utils.database import DatabaseManager

db = DatabaseManager()

st.title("👥 Customer Management")

# Check Admin Access
if 'user' not in st.session_state or st.session_state['user'].get('role') != 'admin':
    st.error("⛔ Access Denied: Admin privileges required.")
    st.stop()

# Fetch all customers
customers = db.get_all_customers()

if customers:
    df_customers = pd.DataFrame(customers)
    
    # Summary metrics
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Customers", len(df_customers))
    with col2:
        active_count = len(df_customers[df_customers['account_status'] == 'Active'])
        st.metric("Active Customers", active_count)
    with col3:
        inactive_count = len(df_customers) - active_count
        st.metric("Inactive Customers", inactive_count)
    
    st.markdown("---")
    
    # Search and filter
    col_a, col_b = st.columns([2, 1])
    with col_a:
        search = st.text_input("🔍 Search by Customer ID or Name", "")
    with col_b:
        status_filter = st.selectbox("Filter by Status", ["All", "Active", "Inactive", "Suspended"])
    
    # Apply filters
    filtered_df = df_customers.copy()
    if search:
        filtered_df = filtered_df[
            filtered_df['customer_id'].str.contains(search, case=False, na=False) |
            filtered_df['name'].str.contains(search, case=False, na=False)
        ]
    if status_filter != "All":
        filtered_df = filtered_df[filtered_df['account_status'] == status_filter]
    
    # Display table
    st.markdown("### Customer List")
    st.dataframe(
        filtered_df,
        use_container_width=True,
        column_config={
            "customer_id": st.column_config.TextColumn("Customer ID"),
            "name": st.column_config.TextColumn("Name"),
            "plan": st.column_config.TextColumn("Plan"),
            "account_status": st.column_config.SelectboxColumn(
                "Status",
                options=["Active", "Inactive", "Suspended"]
            )
        },
        hide_index=True
    )
    
    # Edit customer
    st.markdown("---")
    st.subheader("✏️ Edit Customer")
    
    selected_id = st.selectbox("Select Customer to Edit", df_customers['customer_id'].tolist())
    
    if selected_id:
        customer = db.get_customer(selected_id)
        if customer:
            with st.form("edit_customer_form"):
                new_name = st.text_input("Name", value=customer.get('name', ''))
                new_plan = st.selectbox("Plan", 
                    options=['BASIC_100', 'STD_500', 'PREM_UNL', 'FAMILY_S', 'BIZ_ESSEN'],
                    index=['BASIC_100', 'STD_500', 'PREM_UNL', 'FAMILY_S', 'BIZ_ESSEN'].index(customer.get('plan', 'BASIC_100'))
                )
                new_status = st.selectbox("Account Status",
                    options=['Active', 'Inactive', 'Suspended'],
                    index=['Active', 'Inactive', 'Suspended'].index(customer.get('account_status', 'Active'))
                )
                
                submitted = st.form_submit_button("Update Customer")
                if submitted:
                    updates = {
                        'name': new_name,
                        'plan': new_plan,
                        'account_status': new_status
                    }
                    if db.update_customer(selected_id, updates):
                        st.success(f"✅ Customer {selected_id} updated successfully!")
                        st.rerun()
                    else:
                        st.error("❌ Failed to update customer.")
else:
    st.info("No customers found in the database.")
