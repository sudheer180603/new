import streamlit as st
import pandas as pd
import plotly.express as px
from utils.database import DatabaseManager

db = DatabaseManager()

st.title("🚨 Network Incidents Dashboard")

# Check Admin Access
if 'user' not in st.session_state or st.session_state['user'].get('role') != 'admin':
    st.error("⛔ Access Denied: Admin privileges required.")
    st.stop()

# Fetch incidents
incidents = db.get_all_network_incidents()

if incidents:
    df_incidents = pd.DataFrame(incidents)
    
    # Summary metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Incidents", len(df_incidents))
    with col2:
        active = len(df_incidents[df_incidents['status'] == 'Active'])
        st.metric("Active", active, delta_color="inverse")
    with col3:
        resolved = len(df_incidents[df_incidents['status'] == 'Resolved'])
        st.metric("Resolved", resolved)
    with col4:
        investigating = len(df_incidents[df_incidents['status'] == 'Investigating'])
        st.metric("Investigating", investigating)
    
    st.markdown("---")
    
    # Filter
    status_filter = st.selectbox("Filter by Status", ["All", "Active", "Investigating", "Resolved"])
    
    if status_filter != "All":
        filtered_df = df_incidents[df_incidents['status'] == status_filter]
    else:
        filtered_df = df_incidents
    
    # Incidents table
    st.markdown("### Incident Timeline")
    st.dataframe(
        filtered_df,
        use_container_width=True,
        column_config={
            "start_time": st.column_config.DatetimeColumn("Start Time"),
            "end_time": st.column_config.DatetimeColumn("End Time"),
            "location": st.column_config.TextColumn("Location"),
            "description": st.column_config.TextColumn("Description"),
            "status": st.column_config.SelectboxColumn(
                "Status",
                options=["Active", "Investigating", "Resolved"]
            ),
            "severity": st.column_config.TextColumn("Severity")
        },
        hide_index=True
    )
    
    # Analytics
    st.markdown("---")
    st.subheader("📊 Incident Analytics")
    
    col_a, col_b = st.columns(2)
    
    with col_a:
        # Status distribution
        status_counts = df_incidents['status'].value_counts()
        fig_status = px.pie(
            values=status_counts.values,
            names=status_counts.index,
            title='Incidents by Status',
            color_discrete_sequence=px.colors.qualitative.Set3
        )
        fig_status.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
        st.plotly_chart(fig_status, use_container_width=True)
    
    with col_b:
        # Location distribution
        location_counts = df_incidents['location'].value_counts().head(10)
        fig_location = px.bar(
            x=location_counts.index,
            y=location_counts.values,
            title='Top 10 Incident Locations',
            labels={'x': 'Location', 'y': 'Count'},
            color=location_counts.values,
            color_continuous_scale='Reds'
        )
        fig_location.update_layout(plot_bgcolor='rgba(0,0,0,0)', paper_bgcolor='rgba(0,0,0,0)', font_color='white')
        st.plotly_chart(fig_location, use_container_width=True)
else:
    st.info("No network incidents found.")
