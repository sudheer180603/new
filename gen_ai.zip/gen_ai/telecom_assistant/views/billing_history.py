import streamlit as st
import pandas as pd
from utils.database import DatabaseManager

# Initialize DB
db = DatabaseManager()

st.set_page_config(page_title="Billing History", page_icon="💳", layout="wide")

def load_css():
    with open("ui/style.css") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

load_css()

# Check Login
if 'user' not in st.session_state or not st.session_state['logged_in']:
    st.warning("Please login to view billing history.")
    st.stop()

user = st.session_state['user']
customer_id = user['customer_id']

st.title("💳 Billing History")

# Fetch Data
billing_history = db.get_billing_history(customer_id)

if billing_history:
    df_bills = pd.DataFrame(billing_history)
    
    # Summary Cards
    col1, col2 = st.columns(2)
    with col1:
        last_bill = df_bills.iloc[0]
        st.metric("Last Bill Amount", f"${last_bill['amount']}", f"Date: {last_bill['billing_date']}")
    with col2:
        st.metric("Payment Status", last_bill['status'], delta_color="normal" if last_bill['status']=='Paid' else "inverse")
    
    st.markdown("### Invoice List")
    
    # Custom Table
    st.dataframe(
        df_bills,
        use_container_width=True,
        column_config={
            "billing_date": st.column_config.DateColumn("Billing Date"),
            "amount": st.column_config.NumberColumn("Amount", format="$%.2f"),
            "status": st.column_config.SelectboxColumn("Status", options=["Paid", "Pending", "Overdue"]),
            "id": st.column_config.TextColumn("Invoice ID")
        },
        hide_index=True
    )
    
    st.download_button(
        label="Download Statement (PDF)",
        data="Mock PDF Content",
        file_name=f"Statement_{customer_id}.pdf",
        mime="application/pdf"
    )
else:
    st.info("No billing history found.")
