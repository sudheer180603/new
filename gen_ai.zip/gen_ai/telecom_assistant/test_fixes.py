"""
Quick test script to verify the fixes for specific problematic queries
"""
import os
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from orchestration.graph import app as graph
from dotenv import load_dotenv

load_dotenv()

# Test the specific queries that were reported as incorrect
test_queries = [
    "What areas in Mumbai have 5G coverage?",
    "How can I activate international roaming before traveling?",
    "I need a plan with good international calling to the US",
    "I can't make calls from my home in Mumbai West",
]

def test_query(query, customer_id="CUST001"):
    """Test a single query"""
    print(f"\n{'='*80}")
    print(f"Query: {query}")
    print(f"{'='*80}")
    
    try:
        initial_state = {
            "query": query,
            "customer_id": customer_id,
            "history": [],
            "metadata": {}
        }
        
        result = graph.invoke(initial_state)
        response = result.get("response", "No response")
        category = result.get("category", "Unknown")
        
        print(f"Category: {category}")
        print(f"Response:\n{response}")
        return True
    except Exception as e:
        print(f"ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("="*80)
    print("TESTING FIXES FOR PROBLEMATIC QUERIES")
    print("="*80)
    
    for query in test_queries:
        test_query(query)
        print("\n")
