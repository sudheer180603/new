"""
Test billing agent with specific queries
"""
import os
import sys
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from orchestration.graph import app as graph
from dotenv import load_dotenv

load_dotenv()

# Test the specific billing queries that were reported as incorrect
billing_queries = [
    "Why did my bill increase by ₹200 this month?",
    "I see a charge for international roaming but I haven't traveled recently",
    "Can you explain the 'Value Added Services' charge on my bill?",
    "What's the early termination fee if I cancel my contract?",
]

def test_query(query, customer_id="CUST001"):
    """Test a single query"""
    print(f"\n{'='*80}")
    print(f"Query: {query}")
    print(f"{'='*80}")
    
    try:
        initial_state = {
            "query": query,
            "customer_id": customer_id,
            "history": [],
            "metadata": {}
        }
        
        result = graph.invoke(initial_state)
        response = result.get("response", "No response")
        category = result.get("category", "Unknown")
        
        print(f"Category: {category}")
        print(f"Response:\n{response}")
        print("\n")
        return True
    except Exception as e:
        print(f"ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("="*80)
    print("TESTING BILLING AGENT FIXES")
    print("="*80)
    
    for query in billing_queries:
        test_query(query)
