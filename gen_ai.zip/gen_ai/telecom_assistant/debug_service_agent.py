import os
import sys

# Add current directory to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from agents.service_agents import process_recommendation_query
from dotenv import load_dotenv

load_dotenv()

if __name__ == "__main__":
    query = "I watch a lot of Netflix, about 2 hours a day. What plan do you recommend?"
    print(f"Query: {query}")
    try:
        response = process_recommendation_query(query)
        print(f"Response: {response}")
    except Exception as e:
        print(f"Error: {e}")
