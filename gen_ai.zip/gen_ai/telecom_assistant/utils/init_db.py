import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data", "telecom.db")

def create_schema(conn):
    cursor = conn.cursor()
    
    # Customers
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS customers (
        id TEXT PRIMARY KEY,
        name TEXT,
        email TEXT,
        phone TEXT,
        current_plan_id TEXT,
        account_status TEXT
    )
    ''')
    
    # Plans
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS plans (
        id TEXT PRIMARY KEY,
        name TEXT,
        data_limit_gb INTEGER,
        voice_minutes INTEGER,
        price_monthly REAL,
        description TEXT
    )
    ''')
    
    # Billing History
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS billing_history (
        id TEXT PRIMARY KEY,
        customer_id TEXT,
        billing_date TEXT,
        amount REAL,
        status TEXT,
        details TEXT,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    )
    ''')
    
    # Usage Stats
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS usage_stats (
        id TEXT PRIMARY KEY,
        customer_id TEXT,
        month TEXT,
        data_used_gb REAL,
        voice_minutes_used INTEGER,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    )
    ''')
    
    # Network Incidents
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS network_incidents (
        id TEXT PRIMARY KEY,
        location TEXT,
        status TEXT,
        description TEXT,
        affected_services TEXT,
        start_time TEXT,
        estimated_resolution TEXT
    )
    ''')
    
    conn.commit()

def seed_data(conn):
    cursor = conn.cursor()
    
    # Seed Plans
    plans = [
        ('PLAN_BASIC', 'Basic Saver', 5, 100, 20.0, 'Essential connectivity for light users.'),
        ('PLAN_STD', 'Standard Streamer', 50, 500, 45.0, 'Great for streaming and social media.'),
        ('PLAN_PRO', 'Pro Unlimited', 9999, 9999, 80.0, 'Unlimited data and calls for power users.')
    ]
    cursor.executemany('INSERT OR IGNORE INTO plans VALUES (?,?,?,?,?,?)', plans)
    
    # Seed Customers
    customers = [
        ('CUST_001', 'Alice Smith', 'alice@example.com', '555-0101', 'PLAN_STD', 'Active'),
        ('CUST_002', 'Bob Jones', 'bob@example.com', '555-0102', 'PLAN_BASIC', 'Active'),
        ('CUST_003', 'Charlie Day', 'charlie@example.com', '555-0103', 'PLAN_PRO', 'Active')
    ]
    cursor.executemany('INSERT OR IGNORE INTO customers VALUES (?,?,?,?,?,?)', customers)
    
    # Seed Billing
    billing = [
        ('BILL_001_JAN', 'CUST_001', '2024-01-01', 45.0, 'Paid', 'Standard Plan Monthly'),
        ('BILL_001_FEB', 'CUST_001', '2024-02-01', 45.0, 'Paid', 'Standard Plan Monthly'),
        ('BILL_002_JAN', 'CUST_002', '2024-01-15', 20.0, 'Paid', 'Basic Plan Monthly'),
        ('BILL_003_JAN', 'CUST_003', '2024-01-20', 80.0, 'Pending', 'Pro Plan Monthly')
    ]
    cursor.executemany('INSERT OR IGNORE INTO billing_history VALUES (?,?,?,?,?,?)', billing)
    
    # Seed Usage
    usage = [
        ('USE_001_JAN', 'CUST_001', '2024-01', 45.5, 120),
        ('USE_002_JAN', 'CUST_002', '2024-01', 4.8, 90),
        ('USE_003_JAN', 'CUST_003', '2024-01', 150.2, 400)
    ]
    cursor.executemany('INSERT OR IGNORE INTO usage_stats VALUES (?,?,?,?,?)', usage)
    
    # Seed Incidents
    incidents = [
        ('INC_001', 'Downtown Metro', 'Resolved', 'Fiber cut causing outage', 'Internet, Voice', '2024-02-10 09:00', '2024-02-10 14:00'),
        ('INC_002', 'North Suburbs', 'Active', 'Tower maintenance', '5G Data', '2024-02-28 08:00', '2024-02-28 18:00')
    ]
    cursor.executemany('INSERT OR IGNORE INTO network_incidents VALUES (?,?,?,?,?,?,?)', incidents)
    
    conn.commit()

if __name__ == "__main__":
    if not os.path.exists(os.path.dirname(DB_PATH)):
        os.makedirs(os.path.dirname(DB_PATH))
    
    conn = sqlite3.connect(DB_PATH)
    create_schema(conn)
    seed_data(conn)
    conn.close()
    print(f"Database initialized at {DB_PATH}")
