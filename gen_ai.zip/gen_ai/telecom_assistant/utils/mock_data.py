import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Any
import random

def generate_usage_history(customer_id: str, months: int = 6) -> pd.DataFrame:
    """Generate realistic usage history data for charts."""
    end_date = datetime.now()
    dates = []
    data_used = []
    voice_minutes = []
    sms_count = []
    
    # Base usage with some variation
    base_data = 45.0
    base_voice = 120
    base_sms = 50
    
    for i in range(months * 30):
        date = end_date - timedelta(days=months * 30 - i)
        dates.append(date)
        
        # Add realistic variation
        daily_data = base_data / 30 + np.random.normal(0, 0.5)
        daily_voice = base_voice / 30 + np.random.normal(0, 5)
        daily_sms = base_sms / 30 + np.random.normal(0, 2)
        
        data_used.append(max(0, daily_data))
        voice_minutes.append(max(0, int(daily_voice)))
        sms_count.append(max(0, int(daily_sms)))
    
    return pd.DataFrame({
        'date': dates,
        'data_used_gb': data_used,
        'voice_minutes': voice_minutes,
        'sms_count': sms_count,
        'customer_id': customer_id
    })

def generate_billing_history(customer_id: str, months: int = 12) -> List[Dict[str, Any]]:
    """Generate billing history for the last N months."""
    billing_data = []
    end_date = datetime.now()
    base_amount = 1299.0  # PREM_UNL plan price
    
    for i in range(months):
        billing_date = end_date - timedelta(days=30 * (months - i))
        
        # Add some variation (overages, taxes, etc.)
        base = base_amount
        overages = random.uniform(0, 200) if random.random() > 0.7 else 0
        taxes = (base + overages) * 0.18  # 18% tax
        total = base + overages + taxes
        
        billing_data.append({
            'id': f'BILL_{customer_id}_{billing_date.strftime("%Y%m")}',
            'customer_id': customer_id,
            'billing_date': billing_date.strftime('%Y-%m-%d'),
            'base_amount': round(base, 2),
            'overages': round(overages, 2),
            'taxes': round(taxes, 2),
            'total_amount': round(total, 2),
            'status': 'Paid' if i > 0 else 'Pending',
            'due_date': (billing_date + timedelta(days=15)).strftime('%Y-%m-%d')
        })
    
    return billing_data

def generate_support_tickets(count: int = 50) -> List[Dict[str, Any]]:
    """Generate mock support tickets for admin dashboard."""
    categories = ['Billing', 'Network', 'Plan Change', 'Technical', 'General']
    priorities = ['Low', 'Medium', 'High', 'Critical']
    statuses = ['Open', 'In Progress', 'Resolved', 'Closed']
    
    tickets = []
    for i in range(count):
        created_date = datetime.now() - timedelta(days=random.randint(0, 90))
        category = random.choice(categories)
        priority = random.choice(priorities)
        status = random.choice(statuses)
        
        # Resolution time based on priority
        if status in ['Resolved', 'Closed']:
            if priority == 'Critical':
                resolution_hours = random.randint(1, 4)
            elif priority == 'High':
                resolution_hours = random.randint(4, 24)
            else:
                resolution_hours = random.randint(24, 72)
            resolved_date = created_date + timedelta(hours=resolution_hours)
        else:
            resolved_date = None
            resolution_hours = None
        
        tickets.append({
            'id': f'TICKET_{i+1:04d}',
            'customer_id': f'CUST{random.randint(1, 100):03d}',
            'category': category,
            'priority': priority,
            'status': status,
            'subject': f'{category} issue - {random.choice(["Urgent", "Help needed", "Question", "Problem"])}',
            'created_date': created_date.strftime('%Y-%m-%d %H:%M'),
            'resolved_date': resolved_date.strftime('%Y-%m-%d %H:%M') if resolved_date else None,
            'resolution_hours': resolution_hours,
            'ai_predicted_category': category if random.random() > 0.2 else random.choice(categories)
        })
    
    return tickets

def generate_network_incidents(count: int = 20) -> List[Dict[str, Any]]:
    """Generate network incident data."""
    regions = ['North Zone', 'South Zone', 'East Zone', 'West Zone', 'Central']
    severities = ['Low', 'Medium', 'High', 'Critical']
    statuses = ['Active', 'Investigating', 'Resolved']
    incident_types = ['Fiber Cut', 'Tower Maintenance', 'Power Outage', 'Equipment Failure', 'Planned Maintenance']
    
    incidents = []
    for i in range(count):
        start_time = datetime.now() - timedelta(hours=random.randint(1, 720))
        severity = random.choice(severities)
        status = random.choice(statuses)
        incident_type = random.choice(incident_types)
        
        if status == 'Resolved':
            duration_hours = random.randint(1, 48)
            end_time = start_time + timedelta(hours=duration_hours)
        else:
            duration_hours = None
            end_time = None
        
        affected_users = random.randint(10, 5000) if severity in ['High', 'Critical'] else random.randint(1, 100)
        
        incidents.append({
            'id': f'INC_{i+1:04d}',
            'region': random.choice(regions),
            'severity': severity,
            'status': status,
            'incident_type': incident_type,
            'description': f'{incident_type} in {random.choice(regions)}',
            'start_time': start_time.strftime('%Y-%m-%d %H:%M'),
            'end_time': end_time.strftime('%Y-%m-%d %H:%M') if end_time else None,
            'duration_hours': duration_hours,
            'affected_users': affected_users,
            'affected_services': random.choice(['Internet', 'Voice', 'SMS', 'All Services'])
        })
    
    return incidents

def generate_user_analytics() -> Dict[str, Any]:
    """Generate user analytics data for admin dashboard."""
    total_users = 15000
    
    # Daily active users for last 30 days
    dau_data = []
    for i in range(30):
        date = datetime.now() - timedelta(days=30 - i)
        dau = int(total_users * random.uniform(0.4, 0.6))
        dau_data.append({
            'date': date.strftime('%Y-%m-%d'),
            'active_users': dau
        })
    
    # Users by plan
    plan_distribution = {
        'BASIC_100': int(total_users * 0.25),
        'STD_500': int(total_users * 0.35),
        'PREM_UNL': int(total_users * 0.20),
        'FAMILY_S': int(total_users * 0.15),
        'BIZ_ESSEN': int(total_users * 0.05)
    }
    
    # New signups trend
    signup_data = []
    for i in range(12):
        month = (datetime.now() - timedelta(days=30 * (12 - i))).strftime('%Y-%m')
        signups = random.randint(200, 500)
        signup_data.append({
            'month': month,
            'signups': signups
        })
    
    return {
        'total_users': total_users,
        'active_users_30d': int(total_users * 0.75),
        'new_users_this_month': random.randint(300, 500),
        'churn_rate': round(random.uniform(1.5, 3.5), 2),
        'dau_data': dau_data,
        'plan_distribution': plan_distribution,
        'signup_trend': signup_data
    }

def generate_revenue_data(months: int = 12) -> pd.DataFrame:
    """Generate revenue data for admin dashboard."""
    revenue_data = []
    base_revenue = 5000000  # 5M base
    
    for i in range(months):
        month = (datetime.now() - timedelta(days=30 * (months - i))).strftime('%Y-%m')
        
        # Revenue by plan
        basic_rev = random.randint(800000, 1200000)
        std_rev = random.randint(1500000, 2000000)
        prem_rev = random.randint(1200000, 1800000)
        family_rev = random.randint(800000, 1200000)
        biz_rev = random.randint(400000, 800000)
        
        total_rev = basic_rev + std_rev + prem_rev + family_rev + biz_rev
        
        revenue_data.append({
            'month': month,
            'BASIC_100': basic_rev,
            'STD_500': std_rev,
            'PREM_UNL': prem_rev,
            'FAMILY_S': family_rev,
            'BIZ_ESSEN': biz_rev,
            'total': total_rev
        })
    
    return pd.DataFrame(revenue_data)

def generate_peak_usage_heatmap() -> pd.DataFrame:
    """Generate heatmap data for peak usage hours."""
    days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
    hours = list(range(24))
    
    data = []
    for day in days:
        for hour in hours:
            # Simulate peak hours (evening 6pm-11pm)
            if 18 <= hour <= 23:
                usage = random.randint(70, 100)
            elif 9 <= hour <= 17:
                usage = random.randint(40, 70)
            else:
                usage = random.randint(10, 40)
            
            data.append({
                'day': day,
                'hour': f'{hour:02d}:00',
                'usage_percent': usage
            })
    
    return pd.DataFrame(data)
