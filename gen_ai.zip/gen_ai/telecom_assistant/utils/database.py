import sqlite3
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from config.config import config

class DatabaseManager:
    def __init__(self, db_path: str = config.DB_PATH):
        self.db_path = db_path

    def get_connection(self):
        return sqlite3.connect(self.db_path)

    def query(self, query: str, params: tuple = ()) -> List[Dict[str, Any]]:
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
        finally:
            conn.close()

    def execute(self, query: str, params: tuple = ()) -> None:
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute(query, params)
            conn.commit()
        finally:
            conn.close()

    def get_customer(self, customer_id: str) -> Optional[Dict[str, Any]]:
        results = self.query("SELECT * FROM customers WHERE customer_id = ?", (customer_id,))
        return results[0] if results else None

    def get_billing_history(self, customer_id: str) -> List[Dict[str, Any]]:
        return self.query("SELECT * FROM billing_history WHERE customer_id = ? ORDER BY billing_date DESC", (customer_id,))

    def get_usage_stats(self, customer_id: str) -> List[Dict[str, Any]]:
        return self.query("SELECT * FROM usage_stats WHERE customer_id = ?", (customer_id,))

    def get_active_incidents(self) -> List[Dict[str, Any]]:
        return self.query("SELECT * FROM network_incidents WHERE status = 'Active'")

    def get_all_plans(self) -> List[Dict[str, Any]]:
        return self.query("SELECT * FROM plans")

    def authenticate_user(self, username: str, password: str) -> Optional[Dict[str, Any]]:
        # In a real app, passwords should be hashed. 
        # For this demo, we'll check against the customers table (assuming username=id for simplicity or adding a username field)
        # Let's assume for this demo that 'id' is the username and we have a hardcoded password or a simple check.
        # To make it "fullstack-like", let's actually add a simple user check.
        
        # Check if it's an admin
        if username == "admin" and password == "admin123":
            return {"customer_id": "admin", "name": "Administrator", "role": "admin"}
            
        # Check if it's a customer
        user = self.get_customer(username)
        if user:
            # For demo, password is same as ID or "password"
            if password == "password" or password == username:
                return {**user, "role": "customer"}
        
        return None

    def create_user(self, username: str, name: str, email: str) -> bool:
        # Simple mock creation for the "Register" flow
        try:
            # Check if exists
            if self.get_customer(username):
                return False
            
            # Insert into customers (adapting to existing schema)
            # Actual schema: customer_id, name, account_status, last_billing_date, plan
            self.execute(
                "INSERT INTO customers (customer_id, name, plan, account_status) VALUES (?, ?, ?, ?)",
                (username, name, "BASIC_100", "Active")
            )
            return True
        except Exception as e:
            print(f"Error creating user: {e}")
            return False
    
    # ========== Chart Data Methods ==========
    
    def get_usage_history(self, customer_id: str, days: int = 180) -> List[Dict[str, Any]]:
        """Get usage history for charts. Returns all usage_stats records."""
        return self.query(
            "SELECT * FROM usage_stats WHERE customer_id = ? ORDER BY period_start DESC LIMIT ?",
            (customer_id, days)
        )
    
    def get_billing_chart_data(self, customer_id: str, months: int = 12) -> List[Dict[str, Any]]:
        """Get billing data for charts."""
        return self.query(
            "SELECT * FROM billing_history WHERE customer_id = ? ORDER BY billing_date DESC LIMIT ?",
            (customer_id, months)
        )
    
    def get_all_customers(self) -> List[Dict[str, Any]]:
        """Get all customers for admin views."""
        return self.query("SELECT * FROM customers ORDER BY customer_id")
    
    def get_all_incidents(self) -> List[Dict[str, Any]]:
        """Get all network incidents."""
        return self.query("SELECT * FROM network_incidents ORDER BY start_time DESC")
    
    def get_customer_count_by_plan(self) -> List[Dict[str, Any]]:
        """Get customer distribution by plan."""
        return self.query(
            "SELECT plan, COUNT(*) as count FROM customers GROUP BY plan"
        )
    
    def get_admin_kpis(self) -> Dict[str, Any]:
        """Get KPIs for admin dashboard."""
        # Total customers
        total_customers = self.query("SELECT COUNT(*) as count FROM customers")[0]['count']
        
        # Active customers
        active_customers = self.query(
            "SELECT COUNT(*) as count FROM customers WHERE account_status = 'Active'"
        )[0]['count']
        
        # Total revenue (sum of recent billing)
        revenue_result = self.query(
            "SELECT SUM(amount) as total FROM billing_history WHERE status = 'Paid'"
        )
        total_revenue = revenue_result[0]['total'] if revenue_result and revenue_result[0]['total'] else 0
        
        # Active incidents
        active_incidents = self.query(
            "SELECT COUNT(*) as count FROM network_incidents WHERE status = 'Active'"
        )[0]['count']
        
        # Plans distribution
        plans_dist = self.get_customer_count_by_plan()
        
        return {
            'total_customers': total_customers,
            'active_customers': active_customers,
            'total_revenue': total_revenue,
            'active_incidents': active_incidents,
            'plans_distribution': plans_dist,
            'network_uptime': 99.8  # Mock value
        }
    
    def get_incidents_by_severity(self) -> List[Dict[str, Any]]:
        """Get incident count by severity for charts."""
        # Since we don't have severity in the schema, return empty or mock
        # You can extend the schema if needed
        return []
    
    def get_revenue_by_plan(self) -> List[Dict[str, Any]]:
        """Calculate revenue by plan type."""
        query = """
        SELECT c.plan, SUM(b.amount) as revenue
        FROM billing_history b
        JOIN customers c ON b.customer_id = c.customer_id
        WHERE b.status = 'Paid'
        GROUP BY c.plan
        """
        return self.query(query)

    def get_network_stats(self) -> List[Dict[str, Any]]:
        """Get all network stats."""
        return self.query("SELECT * FROM network_stats")

    def get_support_tickets(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get support tickets, optionally filtered by status."""
        if status:
            return self.query("SELECT * FROM support_tickets WHERE status = ?", (status,))
        return self.query("SELECT * FROM support_tickets")

    def get_aggregated_usage_stats(self) -> Dict[str, Any]:
        """Get aggregated usage stats for all customers."""
        query = """
        SELECT 
            SUM(data_used_gb) as total_data,
            SUM(voice_minutes_used) as total_voice,
            SUM(sms_used) as total_sms
        FROM usage_stats
        """
        result = self.query(query)
        return result[0] if result else {'total_data': 0, 'total_voice': 0, 'total_sms': 0}

    # ========== Customer Management ==========
    
    def update_customer(self, customer_id: str, updates: Dict[str, Any]) -> bool:
        """Update customer information."""
        try:
            fields = ', '.join([f"{k} = ?" for k in updates.keys()])
            values = list(updates.values()) + [customer_id]
            query = f"UPDATE customers SET {fields} WHERE customer_id = ?"
            self.execute(query, tuple(values))
            return True
        except Exception as e:
            print(f"Error updating customer: {e}")
            return False

    def get_all_network_incidents(self) -> List[Dict[str, Any]]:
        """Get all network incidents with details."""
        return self.query("SELECT * FROM network_incidents ORDER BY start_time DESC")

    def get_incidents_by_status(self, status: str) -> List[Dict[str, Any]]:
        """Get network incidents filtered by status."""
        return self.query("SELECT * FROM network_incidents WHERE status = ? ORDER BY start_time DESC", (status,))

    def get_revenue_trend(self, months: int = 12) -> List[Dict[str, Any]]:
        """Get monthly revenue trend."""
        query = """
        SELECT 
            strftime('%Y-%m', billing_date) as month,
            SUM(amount) as revenue,
            COUNT(*) as transaction_count
        FROM billing_history
        WHERE status = 'Paid'
        GROUP BY month
        ORDER BY month DESC
        LIMIT ?
        """
        return self.query(query, (months,))

    def get_plan_details(self, plan_id: str) -> Optional[Dict[str, Any]]:
        """Get details for a specific plan."""
        results = self.query("SELECT * FROM plans WHERE id = ?", (plan_id,))
        return results[0] if results else None

    def get_customer_usage_percentage(self, customer_id: str) -> Dict[str, float]:
        """Calculate usage percentage for a customer."""
        usage = self.get_usage_stats(customer_id)
        if not usage:
            return {'data': 0, 'voice': 0, 'sms': 0}
        
        u = usage[0]
        return {
            'data': (u['data_used_gb'] / u['total_data_gb'] * 100) if u['total_data_gb'] > 0 else 0,
            'voice': (u['voice_minutes_used'] / 5000 * 100),  # Mock limit
            'sms': (u['sms_used'] / 5000 * 100)  # Mock limit
        }
