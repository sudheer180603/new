import os
from typing import List
from llama_index.core import Document, SimpleDirectoryReader
from config.config import config

def load_documents() -> List[Document]:
    """
    Load documents from the data/documents directory.
    Supports .md, .txt files.
    """
    if not os.path.exists(config.DOCS_PATH):
        os.makedirs(config.DOCS_PATH)
        return []

    # Using SimpleDirectoryReader from LlamaIndex
    # It handles various file types automatically
    reader = SimpleDirectoryReader(
        input_dir=config.DOCS_PATH,
        recursive=True,
        required_exts=[".md", ".txt", ".pdf"]
    )
    
    documents = reader.load_data()
    print(f"Loaded {len(documents)} documents from {config.DOCS_PATH}")
    return documents

def get_document_nodes():
    """
    Load documents and parse them into nodes (chunks).
    This is useful if we want more granular control over indexing.
    """
    from llama_index.node_parser import SimpleNodeParser
    
    documents = load_documents()
    parser = SimpleNodeParser.from_defaults()
    nodes = parser.get_nodes_from_documents(documents)
    return nodes
