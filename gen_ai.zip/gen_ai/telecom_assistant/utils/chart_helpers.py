import plotly.graph_objects as go
import plotly.express as px
from typing import Dict, List, Any
import pandas as pd

# Dark theme configuration for Plotly charts
DARK_THEME = {
    'paper_bgcolor': '#111827',
    'plot_bgcolor': '#0a0f1e',
    'font': {'color': '#F9FAFB', 'family': 'Inter'},
    'xaxis': {
        'gridcolor': 'rgba(255, 255, 255, 0.08)',
        'zerolinecolor': 'rgba(255, 255, 255, 0.12)'
    },
    'yaxis': {
        'gridcolor': 'rgba(255, 255, 255, 0.08)',
        'zerolinecolor': 'rgba(255, 255, 255, 0.12)'
    }
}

def create_usage_line_chart(data: pd.DataFrame, title: str = "Data Usage Over Time") -> go.Figure:
    """Create a line chart for usage data over time."""
    fig = go.Figure()
    
    fig.add_trace(go.Scatter(
        x=data['date'],
        y=data['data_used_gb'],
        mode='lines+markers',
        name='Data Used (GB)',
        line=dict(color='#3B82F6', width=3),
        marker=dict(size=8, color='#3B82F6'),
        fill='tozeroy',
        fillcolor='rgba(59, 130, 246, 0.1)'
    ))
    
    fig.update_layout(
        title=title,
        **DARK_THEME,
        hovermode='x unified',
        showlegend=True,
        margin=dict(l=40, r=40, t=60, b=40)
    )
    
    return fig

def create_gauge_chart(current: float, limit: float, title: str = "Usage") -> go.Figure:
    """Create a gauge chart for current usage vs limit."""
    percentage = (current / limit * 100) if limit > 0 else 0
    
    # Determine color based on usage
    if percentage < 50:
        color = '#10B981'  # Green
    elif percentage < 80:
        color = '#F59E0B'  # Amber
    else:
        color = '#EF4444'  # Red
    
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=current,
        domain={'x': [0, 1], 'y': [0, 1]},
        title={'text': title, 'font': {'color': '#F9FAFB'}},
        delta={'reference': limit, 'increasing': {'color': '#EF4444'}},
        gauge={
            'axis': {'range': [None, limit], 'tickcolor': '#9CA3AF'},
            'bar': {'color': color},
            'bgcolor': '#1f2937',
            'borderwidth': 2,
            'bordercolor': 'rgba(255, 255, 255, 0.12)',
            'steps': [
                {'range': [0, limit * 0.5], 'color': 'rgba(16, 185, 129, 0.15)'},
                {'range': [limit * 0.5, limit * 0.8], 'color': 'rgba(245, 158, 11, 0.15)'},
                {'range': [limit * 0.8, limit], 'color': 'rgba(239, 68, 68, 0.15)'}
            ],
            'threshold': {
                'line': {'color': '#F9FAFB', 'width': 4},
                'thickness': 0.75,
                'value': limit
            }
        }
    ))
    
    fig.update_layout(
        **DARK_THEME,
        height=300,
        margin=dict(l=20, r=20, t=60, b=20)
    )
    
    return fig

def create_bar_chart(data: pd.DataFrame, x_col: str, y_col: str, title: str, color: str = '#3B82F6') -> go.Figure:
    """Create a bar chart."""
    fig = go.Figure(go.Bar(
        x=data[x_col],
        y=data[y_col],
        marker=dict(
            color=color,
            line=dict(color='rgba(255, 255, 255, 0.12)', width=1)
        ),
        text=data[y_col],
        textposition='auto',
    ))
    
    fig.update_layout(
        title=title,
        **DARK_THEME,
        showlegend=False,
        margin=dict(l=40, r=40, t=60, b=40)
    )
    
    return fig

def create_pie_chart(labels: List[str], values: List[float], title: str) -> go.Figure:
    """Create a pie chart with dark theme."""
    colors = ['#3B82F6', '#22D3EE', '#8B5CF6', '#10B981', '#F59E0B']
    
    fig = go.Figure(go.Pie(
        labels=labels,
        values=values,
        marker=dict(colors=colors, line=dict(color='#111827', width=2)),
        textfont=dict(color='#F9FAFB'),
        hole=0.4
    ))
    
    fig.update_layout(
        title=title,
        **DARK_THEME,
        showlegend=True,
        legend=dict(font=dict(color='#F9FAFB')),
        margin=dict(l=20, r=20, t=60, b=20)
    ))
    
    return fig

def create_stacked_area_chart(data: pd.DataFrame, x_col: str, y_cols: List[str], title: str) -> go.Figure:
    """Create a stacked area chart."""
    fig = go.Figure()
    
    colors = ['#3B82F6', '#22D3EE', '#8B5CF6', '#10B981']
    
    for i, col in enumerate(y_cols):
        fig.add_trace(go.Scatter(
            x=data[x_col],
            y=data[col],
            mode='lines',
            name=col,
            stackgroup='one',
            fillcolor=f'rgba({int(colors[i % len(colors)][1:3], 16)}, {int(colors[i % len(colors)][3:5], 16)}, {int(colors[i % len(colors)][5:7], 16)}, 0.6)',
            line=dict(width=0.5, color=colors[i % len(colors)])
        ))
    
    fig.update_layout(
        title=title,
        **DARK_THEME,
        hovermode='x unified',
        showlegend=True,
        margin=dict(l=40, r=40, t=60, b=40)
    )
    
    return fig

def create_kpi_card_html(title: str, value: str, delta: str = None, delta_color: str = 'green') -> str:
    """Create HTML for a KPI card (for use in st.markdown)."""
    delta_html = ''
    if delta:
        color = '#10B981' if delta_color == 'green' else '#EF4444'
        arrow = '▲' if delta_color == 'green' else '▼'
        delta_html = f'<div style="color: {color}; font-size: 0.875rem; margin-top: 0.5rem;">{arrow} {delta}</div>'
    
    return f"""
    <div style="
        background: #111827;
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: 0.75rem;
        padding: 1.5rem;
        margin: 0.5rem 0;
    ">
        <div style="color: #9CA3AF; font-size: 0.875rem; margin-bottom: 0.5rem;">{title}</div>
        <div style="color: #F9FAFB; font-size: 2rem; font-weight: 700;">{value}</div>
        {delta_html}
    </div>
    """

def create_heatmap(data: pd.DataFrame, x_col: str, y_col: str, z_col: str, title: str) -> go.Figure:
    """Create a heatmap."""
    fig = go.Figure(go.Heatmap(
        x=data[x_col],
        y=data[y_col],
        z=data[z_col],
        colorscale='Blues',
        text=data[z_col],
        texttemplate='%{text}',
        textfont={"size": 10},
        colorbar=dict(
            title="Value",
            titlefont=dict(color='#F9FAFB'),
            tickfont=dict(color='#F9FAFB')
        )
    ))
    
    fig.update_layout(
        title=title,
        **DARK_THEME,
        margin=dict(l=80, r=40, t=60, b=80)
    )
    
    return fig
