# Sample Input and Output - Telecom Service Assistant

This document shows example queries and the expected responses from each agent type.

---

## Sample 1: Billing Query (CrewAI Agent)

### Input
```
Customer ID: CUST_001
Query: "Why is my bill so high this month?"
```

### Expected Output
```
Bill Analysis for Customer CUST_001

**Billing Specialist Analysis:**

I've analyzed your recent billing history for the past 3 months:
- January 2024: $45.00 (Paid)
- February 2024: $45.00 (Paid)
- Current Month: $45.00

Your monthly charges are consistent at $45.00, which is the standard rate 
for your "Standard Streamer" plan.

**Usage Analysis:**
- Data Used: 45.5 GB (out of 50 GB limit)
- Voice Minutes: 120 (out of 500 minutes)
- No overage charges detected

**Service Advisor Recommendation:**

Your usage is well within your plan limits. Your bill is not unusually high - 
it's the standard monthly charge. However, I notice you're using about 90% of 
your data allowance consistently.

**Recommendations:**
1. Continue with current plan (good value for your usage)
2. Monitor data usage to avoid potential overages
3. Consider upgrading to "Pro Unlimited" ($80/month) only if you frequently 
   exceed 50GB

**Cost Comparison:**
- Current Plan: $45/month (50GB data, 500 minutes)
- Pro Unlimited: $80/month (Unlimited data, unlimited minutes)
- Potential Savings: Stay on current plan unless usage increases
```

---

## Sample 2: Network Troubleshooting (AutoGen Agent)

### Input
```
Query: "My internet is very slow in the downtown area"
```

### Expected Output
```
Network Troubleshooting Analysis:

**1. Incident Check:**
Active Network Incident Detected:
- Location: Downtown Metro
- Status: Active
- Issue: Tower maintenance
- Affected Services: 5G Data
- Started: 2024-02-28 08:00
- Estimated Resolution: 2024-02-28 18:00

**2. Diagnostic Steps:**
Since there's an active maintenance in your area, the slow speeds are expected. 
However, here are steps to optimize your connection:

   a) Restart your device (30 seconds off, then on)
   b) Check signal strength - ensure at least 2 bars
   c) Toggle airplane mode to reset network connection
   d) Verify APN settings are correct:
      - Name: TelecomNet
      - APN: internet.telecom.com

**3. Device-Specific Recommendations:**
   - Ensure device firmware is up to date (Settings > System > Updates)
   - Temporarily disable 5G and use 4G LTE until maintenance completes
     (Settings > Network > Preferred Network Type > LTE)
   - Clear network settings cache if issues persist

**4. Expected Timeline:**
The tower maintenance should complete by 6:00 PM today. If you continue 
experiencing slow speeds after this time, please contact support.

**5. Estimated Success:** 
High likelihood of resolution once maintenance completes. Temporary 4G 
fallback should provide adequate speeds in the meantime.
```

---

## Sample 3: Service Recommendation (LangChain ReAct Agent)

### Input
```
Query: "I watch Netflix 2 hours daily and listen to Spotify during my commute. 
What plan should I get?"
```

### Expected Output
```
**Plan Recommendation Analysis**

**Step 1: Usage Estimation**
Based on your described activities:
- Netflix streaming (2 hours/day): ~60 GB/month
- Spotify music streaming: ~5 GB/month
- General browsing/social media: ~10 GB/month
**Estimated Total: 75 GB/month**

**Step 2: Available Plans Review**
I've queried our database for available plans:

1. **Basic Saver** - $20/month
   - 5GB data (throttled after)
   - 100 voice minutes
   - ❌ Not suitable - insufficient data

2. **Standard Streamer** - $45/month
   - 50GB data
   - 500 voice minutes
   - ❌ Not suitable - you'd exceed limit by 25GB

3. **Pro Unlimited** - $80/month
   - Unlimited data (priority access)
   - Unlimited voice minutes
   - 20GB mobile hotspot
   - ✅ **RECOMMENDED**

**Step 3: Recommendation**

**Best Plan: Pro Unlimited ($80/month)**

**Why this plan fits:**
- Your estimated 75GB usage requires unlimited data
- No risk of overage charges or throttling
- Priority network access ensures smooth Netflix streaming
- Includes international calling if needed
- Bonus: 20GB hotspot for laptop/tablet

**Cost Comparison:**
- Pro Unlimited: $80/month (unlimited)
- Standard Streamer + Overages: $45 + (25GB × $10/GB) = $295/month ❌
- **Savings with Pro Unlimited: $215/month!**

**Alternative Option:**
If you can reduce Netflix quality to SD or limit to 1 hour/day, the 
Standard Streamer ($45/month) could work, saving you $35/month.

**Next Steps:**
Would you like me to help you upgrade to Pro Unlimited?
```

---

## Sample 4: Knowledge Base Query (LlamaIndex Agent)

### Input
```
Query: "How do I configure APN settings on my phone?"
```

### Expected Output
```
**APN Configuration Guide**

To configure APN (Access Point Name) settings on your device:

**Settings:**
1. **Name**: TelecomNet
2. **APN**: internet.telecom.com
3. **MMSC**: http://mms.telecom.com
4. **MCC**: 310
5. **MNC**: 410

**Step-by-Step Instructions:**

**For Android:**
1. Go to Settings > Network & Internet > Mobile Network
2. Tap "Access Point Names"
3. Tap the "+" icon to add new APN
4. Enter the settings listed above
5. Save and select the new APN
6. Restart your device

**For iPhone:**
1. Go to Settings > Cellular > Cellular Data Network
2. Scroll to "Cellular Data" section
3. Enter the APN settings
4. Leave other fields blank unless specified
5. Restart your device

**Troubleshooting:**
- If you don't see APN settings, they may be carrier-locked
- Contact support for automatic configuration
- Ensure you're on the latest iOS/Android version

**Additional Information:**
For eSIM activation or VoLTE setup, please refer to our Technical Support 
documentation or contact customer service.

**Sources:**
- technical_support.md
- network_guide.md
```

---

## Sample 5: General/Fallback Query

### Input
```
Query: "What's the weather like today?"
```

### Expected Output
```
I'm sorry, I couldn't understand your request. I'm a Telecom Service Assistant 
specialized in helping with:

- **Billing questions** (charges, payments, bill analysis)
- **Network issues** (troubleshooting, outages, connectivity)
- **Plan recommendations** (upgrades, new services)
- **General support** (how-to guides, FAQs, technical documentation)

Please try asking about one of these topics, and I'll be happy to help!
```

---

## UI Interaction Flow

### Customer Dashboard (Sidebar)
```
Login As: Customer
Customer ID: CUST_001

─────────────────────
Account Dashboard
─────────────────────
Name: Alice Smith
Plan: PLAN_STD
Status: Active
Data Used: 45.5 GB
```

### Admin View (Sidebar)
```
Login As: Admin

─────────────────────
Knowledge Base Management
─────────────────────
Upload New Document: [Choose File]
                     [Re-index Knowledge Base]
```

### Network Status Banner
```
✅ Network Status: All Systems Operational

OR (when incident active):

⚠️ Active Network Incident: Tower maintenance in Downtown Metro
```

---

## Testing Without API Key

If you want to test without an OpenAI API key, use the demo script:

```bash
python demo.py
```

This will show the routing logic and basic responses without requiring LLM calls.

---

## Notes

- All responses are generated by the respective AI agents
- Actual responses may vary based on:
  - Current database state
  - LLM model used (GPT-4 vs GPT-3.5)
  - Real-time data in knowledge base
- The examples above show the expected format and quality of responses
