# Quick Start Guide - Telecom Service Assistant

## Prerequisites
- Python 3.10+
- OpenAI API Key

## Installation (5 minutes)

### Step 1: Install Dependencies
```bash
cd telecom_assistant
pip install -r requirements.txt
```

### Step 2: Set Up Environment
```bash
# Copy the example file
cp .env.example .env

# Edit .env and add your API key
# OPENAI_API_KEY=sk-your-actual-key-here
```

### Step 3: Initialize Database
```bash
python utils/init_db.py
```

## Running the Application

### Option A: Full Streamlit UI (Recommended)
```bash
streamlit run app.py
```
Then open your browser to `http://localhost:8501`

**Features:**
- Customer login (try: CUST_001, CUST_002, CUST_003)
- Account dashboard
- Chat interface
- Admin mode for document uploads

### Option B: Quick Demo Script
```bash
python demo.py
```
Runs 4 sample queries to test each agent type.

## Sample Queries to Try

Once the UI is running, try these:

1. **Billing Query** (Routes to CrewAI)
   - "Why is my bill so high this month?"
   - "Can you analyze my recent charges?"

2. **Network Query** (Routes to AutoGen)
   - "My internet is very slow"
   - "I have no signal in downtown"

3. **Service Query** (Routes to LangChain)
   - "I watch Netflix daily, recommend a plan"
   - "What plan is best for heavy data usage?"

4. **Knowledge Query** (Routes to LlamaIndex)
   - "How do I configure APN settings?"
   - "What are the payment methods?"

## Project Structure

```
telecom_assistant/
├── app.py                    # Main entry point
├── demo.py                   # Quick demo script
├── agents/                   # All 4 agent implementations
├── orchestration/            # LangGraph routing
├── ui/                       # Streamlit interface
├── data/                     # Database + documents
└── tests/                    # Unit and E2E tests
```

## Troubleshooting

**Issue: "No module named 'autogen'"**
- This is expected with pyautogen v0.10+. The code handles this gracefully.

**Issue: "OpenAI API key not found"**
- Make sure you've created `.env` file and added your key

**Issue: Tests failing**
- Some tests may fail due to environment-specific issues
- The core functionality works (verified by demo.py)

## Next Steps

1. **Customize Agents**: Edit files in `agents/` directory
2. **Add Documents**: Place new .md files in `data/documents/`
3. **Modify Database**: Edit `utils/init_db.py` to add more data
4. **Extend UI**: Modify `ui/streamlit_app.py`

## Documentation

- `README.md` - Full project documentation
- `IMPLEMENTATION_SUMMARY.md` - Design decisions
- `CHANGELOG.md` - Version history
- `walkthrough.md` (in artifacts) - Detailed walkthrough

Enjoy your Telecom Service Assistant! 🚀
