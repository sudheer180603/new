import streamlit as st
import os
import sys

# Add the current directory to python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

def load_css():
    with open("ui/style.css") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Page Configuration must be the first Streamlit command
st.set_page_config(page_title="Telecom Service Assistant", layout="wide")
load_css()

# Initialize Session State
if 'logged_in' not in st.session_state:
    st.session_state['logged_in'] = False

def logout():
    st.session_state['logged_in'] = False
    st.session_state['user'] = None
    st.rerun()

# Define Pages
login_page = st.Page("views/login.py", title="Login", icon="🔒")
logout_page = st.Page(logout, title="Logout", icon="🚪")

# Admin Pages
admin_dashboard = st.Page("views/admin_dashboard.py", title="Dashboard", icon="📈")
customer_management = st.Page("views/customer_management.py", title="Customer Management", icon="👥")
network_incidents = st.Page("views/network_incidents.py", title="Network Incidents", icon="🚨")

# Customer Pages
my_usage = st.Page("views/my_usage.py", title="My Usage", icon="📊")
billing_history = st.Page("views/billing_history.py", title="Billing History", icon="💳")
account_settings = st.Page("views/account_settings.py", title="Account Settings", icon="⚙️")
plan_comparison = st.Page("views/plan_comparison.py", title="Plan Comparison", icon="📊")
chat_support = st.Page("views/chat.py", title="Service Assistant", icon="💬")

# Navigation Logic
if not st.session_state['logged_in']:
    pg = st.navigation([login_page])
else:
    user_role = st.session_state['user'].get('role')
    if user_role == 'admin':
        pg = st.navigation({
            "Admin Workspace": [admin_dashboard, customer_management, network_incidents],
            "Account": [logout_page]
        })
    else:
        pg = st.navigation({
            "My Account": [my_usage, billing_history, account_settings],
            "Plans": [plan_comparison],
            "Support": [chat_support],
            "Account": [logout_page]
        })

pg.run()

