import sqlite3
import pandas as pd

try:
    conn = sqlite3.connect('data/telecom.db')
    
    print("=== PLANS ===")
    df = pd.read_sql("SELECT * FROM plans", conn)
    print(df.to_string())
    
    print("\n\n=== CUSTOMERS (CUST001) ===")
    df = pd.read_sql("SELECT * FROM customers WHERE customer_id='CUST001'", conn)
    print(df.to_string())
    
    print("\n\n=== BILLING HISTORY (CUST001) ===")
    df = pd.read_sql("SELECT * FROM billing_history WHERE customer_id='CUST001'", conn)
    print(df.to_string())
    
    print("\n\n=== USAGE STATS (CUST001) ===")
    df = pd.read_sql("SELECT * FROM usage_stats WHERE customer_id='CUST001'", conn)
    print(df.to_string())
    
    print("\n\n=== NETWORK INCIDENTS ===")
    df = pd.read_sql("SELECT * FROM network_incidents", conn)
    print(df.to_string())
    
    conn.close()
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
