# Telecom Service Assistant

A modular AI-powered assistant for telecom services, integrating **LangGraph**, **CrewAI**, **AutoGen**, **LangChain**, and **LlamaIndex**.

## Features

- **Billing Assistant**: Uses CrewAI to analyze bills and recommend plans.
- **Network Troubleshooting**: Uses AutoGen multi-agent group chat to diagnose issues.
- **Service Recommendations**: Uses LangChain ReAct agent to suggest plans based on usage.
- **Knowledge Base**: Uses LlamaIndex to answer general questions from documents and database.
- **Orchestration**: LangGraph routes queries to the appropriate agent.
- **UI**: Streamlit interface for easy interaction.

## Prerequisites

- Python 3.10+
- OpenAI API Key

## Setup

1. **Clone/Download the repository**
2. **Create a virtual environment**:
   ```bash
   python -m venv .venv
   source .venv/bin/activate  # On Windows: .venv\Scripts\activate
   ```
3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```
4. **Configure Environment**:
   - Copy `.env.example` to `.env`
   - Edit `.env` and add your `OPENAI_API_KEY`.
   ```bash
   cp .env.example .env
   ```
5. **Initialize Database**:
   ```bash
   python utils/init_db.py
   ```

## Running the Application

```bash
streamlit run app.py
```

## Running Tests

```bash
# Run all tests
run_tests.bat
# OR
python -m pytest tests/
```

## Architecture

- **Orchestrator**: LangGraph (`orchestration/graph.py`) classifies and routes queries.
- **Agents**:
  - `agents/billing_agents.py`: CrewAI (Billing Specialist, Service Advisor)
  - `agents/network_agents.py`: AutoGen (Diagnostics, Device Expert, Integrator)
  - `agents/service_agents.py`: LangChain (ReAct Agent)
  - `agents/knowledge_agents.py`: LlamaIndex (Router Query Engine)
- **Data**: SQLite (`data/telecom.db`) and Markdown Docs (`data/documents/`).

## Sample Queries

- **Billing**: "Why is my bill so high this month?"
- **Network**: "My internet is very slow in the downtown area."
- **Service**: "I watch a lot of Netflix, what plan should I get?"
- **Knowledge**: "How do I configure APN settings?"
