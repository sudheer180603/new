# Sample Queries Reference Guide

## Query Categories and Agent Routing

### 1. Billing Queries → **CrewAI Billing Agent**
Tests billing analysis, charge explanations, and contract terms.

- "Why did my bill increase by ₹200 this month?"
- "I see a charge for international roaming but I haven't traveled recently"
- "Can you explain the 'Value Added Services' charge on my bill?"
- "What's the early termination fee if I cancel my contract?"

**Expected**: CrewAI crew analyzes billing history and provides detailed explanations.

---

### 2. Network Issues → **AutoGen Network Agent**
Tests troubleshooting, diagnostics, and network problem resolution.

- "I can't make calls from my home in Mumbai West"
- "My data connection keeps dropping when I'm on the train"
- "Why is my 5G connection slower than my friend's?"
- "I get a 'No Service' error in my basement apartment"

**Expected**: AutoGen agents diagnose issues and provide solutions.

---

### 3. Plan Recommendations → **LangChain Service Agent**
Tests plan analysis, usage estimation, and recommendations.

- "What's the best plan for a family of four who watches a lot of videos?"
- "I need a plan with good international calling to the US"
- "Which plan is best for someone who works from home and needs reliable data?"
- "I'm a light user who mostly just calls and texts. What's my cheapest option?"

**Expected**: LangChain agent queries database, estimates usage, recommends plans.

---

### 4. Technical Information → **LlamaIndex Knowledge Agent**
Tests document retrieval and technical guidance.

- "How do I set up VoLTE on my Samsung phone?"
- "What are the APN settings for Android devices?"
- "How can I activate international roaming before traveling?"
- "What areas in Mumbai have 5G coverage?"

**Expected**: LlamaIndex retrieves relevant documentation.

---

### 5. Edge Cases → **Fallback Handler**
Tests error handling and complex query routing.

- "Tell me a joke about telecom" (fallback/general)
- "I need help with both my bill and network issues" (complex multi-category)

**Expected**: Graceful handling or routing to appropriate agent.

---

## Testing the Queries

### Via Chat Interface (Recommended)
1. Login as customer (CUST001 / password)
2. Go to "Service Assistant" page
3. Type queries one by one
4. Verify correct agent handles each query

### Via Test Script
```bash
python test_sample_queries.py
```

This will test all queries programmatically and show success rate.

---

## Query Classification Logic

The orchestration layer (`orchestration/graph.py`) uses:
1. **Keyword matching** (fast, deterministic)
2. **LLM classification** (fallback for ambiguous queries)

Keywords:
- "bill", "charge", "payment" → Billing
- "network", "internet", "slow", "signal" → Network
- "plan", "recommend", "upgrade" → Service
- "how to", "guide", "support" → Knowledge
