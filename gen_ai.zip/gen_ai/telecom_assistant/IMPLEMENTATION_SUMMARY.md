# Implementation Summary

## Design Choices

### Orchestration (LangGraph)
We used **LangGraph** for the central orchestration because it provides a clean state machine architecture. The `TelecomAssistantState` tracks the query, customer context, and conversation history. A classifier node (LLM-based with keyword fallback) determines the intent and routes to the specific agent node.

### Agent Frameworks
- **CrewAI** was chosen for **Billing** because of its strong role-playing capabilities, allowing us to simulate a "Billing Specialist" and "Service Advisor" working together sequentially.
- **AutoGen** was used for **Network Troubleshooting** to demonstrate a multi-agent group chat where different experts (Diagnostics, Device) collaborate to solve a complex problem.
- **LangChain ReAct** was selected for **Service Recommendations** as it requires tool usage (calculating data usage, querying plans) and reasoning.
- **LlamaIndex** was used for **Knowledge Retrieval** due to its superior RAG capabilities and easy integration of structured (SQL) and unstructured (Vector) data.

### Data Layer
We used **SQLite** for simplicity and portability, pre-seeded with realistic telecom data. **ChromaDB** (via LlamaIndex) is used for vector storage.

## Tradeoffs & Constraints
- **Dependency Management**: Integrating multiple heavy frameworks (CrewAI, AutoGen, LlamaIndex) can lead to version conflicts. We pinned versions in `requirements.txt` to mitigate this.
- **Latency**: The multi-agent approaches (especially AutoGen and CrewAI) can be slower due to multiple LLM roundtrips.
- **Testing**: End-to-end testing of agents is non-deterministic. We used extensive mocking in our test suite to ensure reliability and speed during development.

## Future Improvements
- Persistent vector store (currently rebuilds on restart for simplicity).
- Async support for better UI responsiveness.
- More granular permissions for the Admin role.
