# Changelog

## [1.0.0] - 2024-05-22

### Added
- Initial release of Telecom Service Assistant.
- **Orchestration**: LangGraph implementation with classification and routing.
- **Billing**: CrewAI agents for bill analysis and plan review.
- **Network**: AutoGen group chat for network troubleshooting.
- **Service**: LangChain ReAct agent for plan recommendations.
- **Knowledge**: LlamaIndex RAG engine for documents and database.
- **UI**: Streamlit application with dashboard and chat interface.
- **Data**: SQLite database schema and seed data.
- **Tests**: Unit tests and E2E sample query tests.
