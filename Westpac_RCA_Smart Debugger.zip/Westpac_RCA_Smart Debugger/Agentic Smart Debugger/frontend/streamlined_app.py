import streamlit as st
import requests
import json
import pandas as pd

API_BASE_URL = "http://localhost:8000"

st.set_page_config(
    page_title="Smart Debugger", 
    layout="wide", 
    initial_sidebar_state="collapsed"
)

# Professional dark theme
st.markdown("""
<style>
    /* Professional color palette */
    :root {
        --primary: #3b82f6;
        --primary-hover: #2563eb;
        --surface: #1e293b;
        --surface-alt: #162032;
        --bg: #0f172a;
        --border: rgba(148, 163, 184, 0.12);
        --border-hover: rgba(148, 163, 184, 0.25);
        --text-primary: #f1f5f9;
        --text-secondary: #94a3b8;
        --success: #22c55e;
        --warning: #f59e0b;
        --error: #ef4444;
        --info: #3b82f6;
    }
    
    /* Base background */
    .stApp {
        background-color: #0f172a;
    }
    
    /* Header */
    .main-header {
        background: #1e293b;
        padding: 2rem 2.5rem;
        border-radius: 12px;
        margin-bottom: 2rem;
        border: 1px solid rgba(148, 163, 184, 0.12);
        box-shadow: 0 4px 24px rgba(0, 0, 0, 0.3);
    }
    
    .main-header h1 {
        color: #f1f5f9;
        font-size: 2rem;
        margin: 0;
        font-weight: 700;
        letter-spacing: -0.02em;
    }
    
    .main-header p {
        color: #94a3b8;
        font-size: 1rem;
        margin: 0.5rem 0 0 0;
    }
    
    /* Project info banner */
    .project-banner {
        background: rgba(37, 99, 235, 0.12);
        padding: 1rem 1.5rem;
        border-radius: 8px;
        color: #bfdbfe;
        font-weight: 500;
        margin-bottom: 1.5rem;
        border: 1px solid rgba(59, 130, 246, 0.25);
    }
    
    /* Buttons */
    .stButton>button {
        border-radius: 8px;
        font-weight: 500;
        transition: all 0.2s ease;
        border: 1px solid rgba(148, 163, 184, 0.2);
        background: #1e293b !important;
        color: #e2e8f0 !important;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2);
    }
    
    .stButton>button:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
        border-color: rgba(59, 130, 246, 0.4);
        background: #263548 !important;
    }
    
    .stButton>button[kind="primary"] {
        background: #2563eb !important;
        border: 1px solid rgba(59, 130, 246, 0.5);
        color: white !important;
    }
    
    .stButton>button[kind="primary"]:hover {
        background: #1d4ed8 !important;
        box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        transform: translateY(-1px);
    }
    
    /* Metrics */
    [data-testid="stMetricValue"] {
        font-size: 1.8rem;
        font-weight: 700;
        color: #60a5fa;
    }
    
    [data-testid="stMetricLabel"] {
        color: #94a3b8 !important;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        font-size: 0.78rem;
    }
    
    [data-testid="stMetric"] {
        background: #1e293b;
        padding: 1rem;
        border-radius: 10px;
        border: 1px solid rgba(148, 163, 184, 0.12);
    }
    
    /* Sidebar */
    [data-testid="stSidebar"] {
        background: #0f172a !important;
        border-right: 1px solid rgba(148, 163, 184, 0.12);
    }
    
    [data-testid="stSidebar"] .stButton>button {
        width: 100%;
        text-align: left;
        background: rgba(30, 41, 59, 0.6) !important;
        color: #cbd5e1 !important;
        border: 1px solid rgba(148, 163, 184, 0.15);
        border-radius: 8px;
        margin: 3px 0;
    }
    
    [data-testid="stSidebar"] .stButton>button:hover {
        background: rgba(30, 41, 59, 0.9) !important;
        border-color: rgba(59, 130, 246, 0.3);
    }
    
    /* Progress items */
    .progress-item {
        padding: 0.6rem 1rem;
        margin: 0.3rem 0;
        border-radius: 8px;
        background: rgba(34, 197, 94, 0.08);
        border-left: 3px solid #22c55e;
    }
    
    /* Expander */
    .streamlit-expanderHeader {
        background: rgba(30, 41, 59, 0.8) !important;
        border-radius: 8px !important;
        font-weight: 600;
        border: 1px solid rgba(148, 163, 184, 0.15);
    }
    
    .streamlit-expanderHeader:hover {
        background: rgba(30, 41, 59, 1) !important;
    }
    
    /* Tables */
    .dataframe {
        border-radius: 8px !important;
        overflow: hidden;
        border: 1px solid rgba(148, 163, 184, 0.15) !important;
    }
    
    .dataframe th {
        background: #1e293b !important;
        color: #94a3b8 !important;
        font-weight: 600 !important;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        border-bottom: 1px solid rgba(148, 163, 184, 0.2) !important;
    }
    
    .dataframe td {
        background: rgba(15, 23, 42, 0.8) !important;
        color: #e2e8f0 !important;
        border-color: rgba(148, 163, 184, 0.1) !important;
    }
    
    .dataframe tr:hover td {
        background: rgba(30, 41, 59, 0.9) !important;
    }
    
    /* Alert messages */
    .stSuccess {
        background: rgba(34, 197, 94, 0.1) !important;
        border-left: 3px solid #22c55e !important;
        border-radius: 8px !important;
    }
    
    .stError {
        background: rgba(239, 68, 68, 0.1) !important;
        border-left: 3px solid #ef4444 !important;
        border-radius: 8px !important;
    }
    
    .stWarning {
        background: rgba(245, 158, 11, 0.1) !important;
        border-left: 3px solid #f59e0b !important;
        border-radius: 8px !important;
    }
    
    .stInfo {
        background: rgba(59, 130, 246, 0.1) !important;
        border-left: 3px solid #3b82f6 !important;
        border-radius: 8px !important;
    }
    
    /* Inputs */
    .stTextInput>div>div>input, .stTextArea>div>div>textarea {
        background: #1e293b !important;
        border: 1px solid rgba(148, 163, 184, 0.2) !important;
        border-radius: 8px !important;
        color: #f1f5f9 !important;
        transition: all 0.2s ease;
    }
    
    .stTextInput>div>div>input:focus, .stTextArea>div>div>textarea:focus {
        border-color: #3b82f6 !important;
        box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1) !important;
    }
    
    .stTextInput>div>div>input::placeholder, .stTextArea>div>div>textarea::placeholder {
        color: #475569 !important;
    }
    
    /* Selectbox */
    .stSelectbox>div>div {
        background: #1e293b !important;
        border-radius: 8px !important;
        border: 1px solid rgba(148, 163, 184, 0.2) !important;
    }
    
    .stSelectbox>div>div:hover {
        border-color: rgba(59, 130, 246, 0.4) !important;
    }
    
    /* File uploader */
    [data-testid="stFileUploader"] {
        background: rgba(30, 41, 59, 0.6) !important;
        border: 2px dashed rgba(148, 163, 184, 0.25) !important;
        border-radius: 10px !important;
        padding: 1.5rem !important;
        transition: all 0.2s ease;
    }
    
    [data-testid="stFileUploader"]:hover {
        border-color: rgba(59, 130, 246, 0.4) !important;
        background: rgba(30, 41, 59, 0.8) !important;
    }
    
    /* Checkbox */
    .stCheckbox {
        background: rgba(30, 41, 59, 0.5);
        padding: 0.5rem 0.8rem;
        border-radius: 8px;
        border: 1px solid rgba(148, 163, 184, 0.12);
        transition: all 0.2s ease;
    }
    
    .stCheckbox:hover {
        background: rgba(30, 41, 59, 0.8);
        border-color: rgba(59, 130, 246, 0.3);
    }
    
    /* Dividers */
    hr {
        border: none;
        height: 1px;
        background: rgba(148, 163, 184, 0.12);
        margin: 1.5rem 0;
    }
    
    /* Headings */
    h1, h2, h3 {
        color: #f1f5f9 !important;
    }
    
    h2 {
        color: #cbd5e1 !important;
        font-weight: 600;
    }
    
    h3 {
        color: #94a3b8 !important;
        font-weight: 600;
    }
    
    .stCaption {
        color: #64748b !important;
    }
    
    /* Download button */
    .stDownloadButton>button {
        background: #16a34a !important;
        border: 1px solid rgba(34, 197, 94, 0.4);
        color: white !important;
        font-weight: 600;
    }
    
    .stDownloadButton>button:hover {
        background: #15803d !important;
        box-shadow: 0 4px 12px rgba(22, 163, 74, 0.3);
        transform: translateY(-1px);
    }
    
    /* Spinner */
    .stSpinner>div {
        border-color: #3b82f6 !important;
    }
    
    /* Markdown text */
    .stMarkdown {
        color: #cbd5e1;
    }
    
    /* Code blocks */
    code {
        background: rgba(59, 130, 246, 0.1) !important;
        color: #93c5fd !important;
        border-radius: 4px;
        padding: 2px 5px;
    }
    
    /* Scrollbar */
    ::-webkit-scrollbar {
        width: 8px;
        height: 8px;
    }
    
    ::-webkit-scrollbar-track {
        background: #0f172a;
    }
    
    ::-webkit-scrollbar-thumb {
        background: #334155;
        border-radius: 4px;
    }
    
    ::-webkit-scrollbar-thumb:hover {
        background: #475569;
    }
    
    /* Status badges */
    .status-badge {
        display: inline-block;
        padding: 3px 10px;
        border-radius: 6px;
        font-size: 0.82rem;
        font-weight: 500;
    }
    
    .status-badge.success {
        background: rgba(34, 197, 94, 0.15);
        border: 1px solid rgba(34, 197, 94, 0.3);
        color: #4ade80;
    }
    
    .status-badge.pending {
        background: rgba(245, 158, 11, 0.15);
        border: 1px solid rgba(245, 158, 11, 0.3);
        color: #fbbf24;
    }
</style>
""", unsafe_allow_html=True)

# Initialize session state
if 'workflow_stage' not in st.session_state:
    st.session_state.workflow_stage = 0
if 'project_name' not in st.session_state:
    st.session_state.project_name = None
if 'project_mode' not in st.session_state:
    st.session_state.project_mode = None  # 'new' or 'existing'
if 'results' not in st.session_state:
    st.session_state.results = {}

# Header
st.markdown("""
<div class="main-header">
    <h1>Smart Debugger</h1>
    <p>Enterprise AI-Powered Root Cause Analysis Platform</p>
</div>
""", unsafe_allow_html=True)

# Check backend health
try:
    health = requests.get(f"{API_BASE_URL}/api/health", timeout=2)
    if health.status_code == 200:
        st.sidebar.markdown("### System Status")
        st.sidebar.success("Backend Connected")
    else:
        st.sidebar.markdown("### System Status")
        st.sidebar.error("Backend Error")
except:
    st.sidebar.markdown("### System Status")
    st.sidebar.error("Backend Offline")
    st.error("Cannot connect to backend. Please start the backend with `run_backend.bat`")
    st.stop()

st.sidebar.markdown("---")
st.sidebar.markdown("### Workflow Progress")

# Workflow stages
stages = [
    "Project Selection",
    "Repository Ingestion",
    "Business Documents",
    "Context Building",
    "Jira Tickets",
    "RCA Analysis"
]

# Show progress with navigation
for i, stage in enumerate(stages):
    if i < st.session_state.workflow_stage:
        if st.sidebar.button(f"{stage}", key=f"nav_{i}", use_container_width=True):
            st.session_state.workflow_stage = i
            st.rerun()
    elif i == st.session_state.workflow_stage:
        st.sidebar.markdown(f"**> {stage}**")
    else:
        # Allow navigation to next steps if project exists
        if st.session_state.project_name and st.sidebar.button(f"{stage}", key=f"nav_{i}", use_container_width=True):
            st.session_state.workflow_stage = i
            st.rerun()

st.sidebar.markdown("---")
if st.sidebar.button("Reset Workflow", use_container_width=True):
    st.session_state.workflow_stage = 0
    st.session_state.project_name = None
    st.session_state.project_mode = None
    st.session_state.results = {}
    st.rerun()

# Main workflow
st.markdown("---")

# ============================================================================
# STAGE 0: Project Selection
# ============================================================================
if st.session_state.workflow_stage == 0:
    # st.markdown('<div class="stage-card">', unsafe_allow_html=True)
    st.header("Step 1: Project Selection")
    st.markdown("Choose to create a **new project** or continue with an **existing** one.")
    st.markdown('</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("### New Project")
        st.markdown("Start a fresh analysis with a new repository")
        
        new_project_name = st.text_input(
            "Project Name",
            placeholder="e.g., LOS-Analysis",
            key="new_project_input"
        )
        
        if st.button("Create New Project", type="primary", use_container_width=True):
            if new_project_name:
                try:
                    response = requests.post(
                        f"{API_BASE_URL}/api/projects/create",
                        json={"name": new_project_name}
                    )
                    if response.status_code == 200:
                        st.session_state.project_name = new_project_name
                        st.session_state.project_mode = 'new'
                        st.session_state.workflow_stage = 1
                        st.success(f"Project created: {new_project_name}")
                        st.rerun()
                    else:
                        st.error(f"Error: {response.json().get('detail', 'Unknown error')}")
                except Exception as e:
                    st.error(f"Error: {str(e)}")
            else:
                st.warning("Please enter a project name")
    
    with col2:
        st.markdown("### Existing Project")
        st.markdown("Continue with an existing project from where you left off")
        
        try:
            response = requests.get(f"{API_BASE_URL}/api/projects/list")
            if response.status_code == 200:
                projects = response.json().get('projects', [])
                
                if projects:
                    # Show all projects in dropdown
                    project_names = [p['name'] for p in projects]
                    selected_project = st.selectbox(
                        "Select Project",
                        options=project_names,
                        key="existing_project_select"
                    )
                    
                    # Show project info
                    project_info = next(p for p in projects if p['name'] == selected_project)
                    
                    # Determine project status and next step
                    if not project_info.get('code_indexed', False):
                        next_step = 1
                        status_msg = "Next: Repository Ingestion"
                    elif not project_info.get('business_docs_processed', False):
                        next_step = 2
                        status_msg = "Next: Business Documents"
                    elif not project_info.get('context_built', False):
                        next_step = 3
                        status_msg = "Next: Context Building"
                    else:
                        next_step = 4
                        status_msg = "Ready for Jira Tickets"
                    
                    # Show project statistics
                    st.markdown(f"**Status:** {status_msg}")
                    
                    stats = project_info.get('stats', {})
                    if stats:
                        col_a, col_b, col_c = st.columns(3)
                        with col_a:
                            st.metric("Files", stats.get('files_parsed', 0))
                        with col_b:
                            st.metric("Rules", stats.get('business_rules', 0))
                        with col_c:
                            st.metric("Embeddings", stats.get('embeddings', 0))
                    
                    # Show completion status
                    st.markdown("**Progress:**")
                    progress_items = [
                        ("Repository", project_info.get('code_indexed', False)),
                        ("Business Docs", project_info.get('business_docs_processed', False)),
                        ("Context Built", project_info.get('context_built', False))
                    ]
                    for item, completed in progress_items:
                        icon = "[done]" if completed else "[pending]"
                        st.markdown(f"{icon} {item}")
                    
                    if st.button("Continue This Project", type="primary", use_container_width=True):
                        st.session_state.project_name = selected_project
                        st.session_state.project_mode = 'existing'
                        st.session_state.workflow_stage = next_step
                        st.success(f"Continuing project: {selected_project}")
                        st.rerun()
                else:
                    st.info("No existing projects. Create a new one to get started.")
        except Exception as e:
            st.error(f"Error loading projects: {str(e)}")

# ============================================================================
# STAGE 1: Repository Ingestion (New Projects Only)
# ============================================================================
elif st.session_state.workflow_stage == 1:
    # st.markdown('<div class="stage-card">', unsafe_allow_html=True)
    st.header("Step 2: Repository Ingestion")
    
    # Show project info banner
    st.markdown(f'<div class="project-banner">Project: <strong>{st.session_state.project_name}</strong> | Mode: New Project</div>', unsafe_allow_html=True)
    
    st.markdown("Provide a **GitHub repository URL** or **local folder path** to analyze.")
    st.markdown('</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        repo_input = st.text_input(
            "GitHub URL or Local Path",
            placeholder="https://github.com/user/repo or C:\\projects\\myapp",
            key="repo_input"
        )
    
    with col2:
        st.markdown("<br>", unsafe_allow_html=True)
        process_btn = st.button("Ingest Repository", type="primary", use_container_width=True)
    
    if process_btn:
        if repo_input:
            with st.spinner("Cloning and parsing repository..."):
                try:
                    response = requests.post(
                        f"{API_BASE_URL}/api/projects/{st.session_state.project_name}/ingest/github",
                        json={"repo_url_or_path": repo_input}
                    )
                    if response.status_code == 200:
                        result = response.json()
                        st.session_state.results['github'] = result
                        
                        st.success(f"Successfully parsed {result['files_parsed']} files")
                        
                        # Show results
                        st.markdown("### Ingestion Results")
                        col1, col2 = st.columns(2)
                        with col1:
                            st.metric("Files Parsed", result['files_parsed'])
                        with col2:
                            st.metric("Languages", len(result.get('languages', {})))
                        
                        if result.get('languages'):
                            st.markdown("**Languages Breakdown:**")
                            lang_df = pd.DataFrame([
                                {"Language": lang, "Files": count}
                                for lang, count in result['languages'].items()
                            ])
                            st.dataframe(lang_df, use_container_width=True, hide_index=True)
                        
                        # Auto-advance
                        st.session_state.workflow_stage = 2
                        st.success("Repository ingested. Ready for next step.")
                        if st.button("Continue to Business Documents", use_container_width=True):
                            st.rerun()
                    else:
                        st.error(f"Error: {response.json().get('detail', 'Unknown error')}")
                except Exception as e:
                    st.error(f"Error: {str(e)}")
        else:
            st.warning("Please enter a repository URL or path")

# ============================================================================
# STAGE 2: Business Documents (New Projects Only)
# ============================================================================
elif st.session_state.workflow_stage == 2:
    # st.markdown('<div class="stage-card">', unsafe_allow_html=True)
    st.header("Step 3: Business Documents")
    
    # Show project info banner
    st.markdown(f'<div class="project-banner">Project: <strong>{st.session_state.project_name}</strong> | Status: Repository Ingested</div>', unsafe_allow_html=True)
    
    st.markdown("Upload business documentation **(PDF, DOCX, TXT, MD)** to understand requirements.")
    st.markdown('</div>', unsafe_allow_html=True)
    
    uploaded_files = st.file_uploader(
        "Upload Documents",
        accept_multiple_files=True,
        type=['pdf', 'docx', 'txt', 'md'],
        key="business_docs"
    )
    
    col1, col2 = st.columns([3, 1])
    with col1:
        if uploaded_files:
            st.info(f"**{len(uploaded_files)}** file(s) selected")
    with col2:
        process_btn = st.button("Process Documents", type="primary", use_container_width=True)
        skip_btn = st.button("Skip", use_container_width=True)
    
    if process_btn and uploaded_files:
        with st.spinner("Processing documents..."):
            try:
                files = [("files", (f.name, f, f.type)) for f in uploaded_files]
                response = requests.post(
                    f"{API_BASE_URL}/api/projects/{st.session_state.project_name}/ingest/business-docs",
                    files=files
                )
                if response.status_code == 200:
                    result = response.json()
                    st.session_state.results['business_docs'] = result
                    
                    st.success(f"Extracted {result['rules_extracted']} business rules")
                    
                    # Show results
                    st.markdown("### Processing Results")
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Documents", result['documents_processed'])
                    with col2:
                        st.metric("Rules Extracted", result['rules_extracted'])
                    
                    # Auto-advance
                    st.session_state.workflow_stage = 3
                    st.success("Documents processed. Ready for next step.")
                    if st.button("Continue to Context Building", use_container_width=True):
                        st.rerun()
                else:
                    st.error(f"Error: {response.text}")
            except Exception as e:
                st.error(f"Error: {str(e)}")
    
    if skip_btn:
        st.session_state.workflow_stage = 3
        st.rerun()

# ============================================================================
# STAGE 3: Context Building (New Projects Only)
# ============================================================================
elif st.session_state.workflow_stage == 3:
    # st.markdown('<div class="stage-card">', unsafe_allow_html=True)
    st.header("Step 4: Context Building")
    
    # Show project info banner
    st.markdown(f'<div class="project-banner">Project: <strong>{st.session_state.project_name}</strong> | Status: Documents Processed</div>', unsafe_allow_html=True)
    
    st.markdown("Generate **embeddings** and build **unified context** for AI analysis.")
    st.markdown('</div>', unsafe_allow_html=True)
    
    if st.button("Build Context", type="primary", use_container_width=True):
        with st.spinner("Building context... This may take a few minutes."):
            try:
                response = requests.post(
                    f"{API_BASE_URL}/api/projects/{st.session_state.project_name}/context/build"
                )
                if response.status_code == 200:
                    result = response.json()
                    st.session_state.results['context'] = result
                    
                    st.success("Context built successfully.")
                    
                    # Show results
                    st.subheader("Context Statistics")
                    col1, col2, col3 = st.columns(3)
                    col1.metric("Code Blocks", result['code_blocks'])
                    col2.metric("Business Rules", result['business_rules'])
                    col3.metric("Embeddings", result['embeddings_generated'])
                    
                    # Auto-advance
                    st.session_state.workflow_stage = 4
                    st.info("Context is ready. You can now process Jira tickets.")
                    if st.button("Continue to Jira Tickets"):
                        st.rerun()
                else:
                    st.error(f"Error: {response.text}")
            except Exception as e:
                st.error(f"Error: {str(e)}")

# ============================================================================
# STAGE 4: Jira Tickets
# ============================================================================
elif st.session_state.workflow_stage == 4:
    # st.markdown('<div class="stage-card">', unsafe_allow_html=True)
    st.header("Step 5: Jira Tickets")
    
    # Show project info banner with mode
    mode_text = "Existing Project - Context Ready" if st.session_state.project_mode == 'existing' else "Context Built"
    st.markdown(f'<div class="project-banner">Project: <strong>{st.session_state.project_name}</strong> | {mode_text}</div>', unsafe_allow_html=True)
    
    st.markdown("Paste your Jira tickets in **JSON format** for analysis.")
    st.markdown("**Required:** `ticket_id` or `jira_id` | **Optional:** summary, description, priority, module, etc.")
    st.markdown('</div>', unsafe_allow_html=True)
    
    ticket_json = st.text_area(
        "Jira Tickets JSON",
        height=250,
        placeholder='''[
  {
    "ticket_id": "LOS-105",
    "summary": "KYC file upload has no file size validation",
    "description": "Large files cause memory issues",
    "priority": "Critical",
    "module": "kyc"
  }
]''',
        key="jira_tickets"
    )
    
    if st.button("Process Tickets", type="primary", use_container_width=True):
        if ticket_json:
            try:
                tickets = json.loads(ticket_json)
                
                with st.spinner("Processing tickets..."):
                    response = requests.post(
                        f"{API_BASE_URL}/api/projects/{st.session_state.project_name}/jira/process",
                        json=tickets
                    )
                    if response.status_code == 200:
                        result = response.json()
                        st.session_state.results['jira'] = result
                        
                        st.success(f"Processed {result['tickets_processed']} ticket(s)")
                        
                        # Auto-advance
                        st.session_state.workflow_stage = 5
                        st.info("Tickets processed. Ready for RCA analysis.")
                        if st.button("Continue to RCA Analysis"):
                            st.rerun()
                    else:
                        error_detail = response.json().get('detail', response.text)
                        st.error(f"Error: {error_detail}")
            except json.JSONDecodeError:
                st.error("Invalid JSON format. Please check your syntax.")
            except Exception as e:
                st.error(f"Error: {str(e)}")
        else:
            st.warning("Please enter ticket JSON")

# ============================================================================
# STAGE 5: RCA Analysis
# ============================================================================
elif st.session_state.workflow_stage == 5:
    # st.markdown('<div class="stage-card">', unsafe_allow_html=True)
    st.header("Step 6: Root Cause Analysis")
    
    # Show project info banner
    st.markdown(f'<div class="project-banner">Project: <strong>{st.session_state.project_name}</strong> | Status: Tickets Processed</div>', unsafe_allow_html=True)
    
    st.markdown("Select specific tickets to analyze or analyze **all tickets**.")
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Fetch available tickets
    try:
        response = requests.get(f"{API_BASE_URL}/api/projects/{st.session_state.project_name}/tickets/list")
        if response.status_code == 200:
            ticket_data = response.json()
            available_tickets = ticket_data.get('tickets', [])
            
            if available_tickets:
                st.subheader(f"Available Tickets ({len(available_tickets)})")
                
                # Create ticket selection UI
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    # Show tickets as checkboxes
                    st.markdown("**Select tickets to analyze:**")
                    
                    # Initialize session state for ticket selection
                    if 'selected_tickets' not in st.session_state:
                        st.session_state.selected_tickets = []
                    
                    # Select All / Deselect All buttons
                    col_a, col_b = st.columns(2)
                    with col_a:
                        if st.button("Select All", use_container_width=True):
                            st.session_state.selected_tickets = [t['ticket_id'] for t in available_tickets]
                            st.rerun()
                    with col_b:
                        if st.button("Deselect All", use_container_width=True):
                            st.session_state.selected_tickets = []
                            st.rerun()
                    
                    st.markdown("---")
                    
                    # Show each ticket with checkbox
                    for ticket in available_tickets:
                        ticket_id = ticket['ticket_id']
                        is_selected = ticket_id in st.session_state.selected_tickets
                        
                        col_check, col_info = st.columns([1, 9])
                        
                        with col_check:
                            if st.checkbox("", value=is_selected, key=f"ticket_{ticket_id}"):
                                if ticket_id not in st.session_state.selected_tickets:
                                    st.session_state.selected_tickets.append(ticket_id)
                            else:
                                if ticket_id in st.session_state.selected_tickets:
                                    st.session_state.selected_tickets.remove(ticket_id)
                        
                        with col_info:
                            priority_color = {
                                "Critical": "[Critical]",
                                "High": "[High]",
                                "Medium": "[Medium]",
                                "Low": "[Low]"
                            }.get(ticket.get('priority', ''), "")
                            
                            st.markdown(f"{priority_color} **{ticket_id}** - {ticket.get('summary', 'No summary')[:80]}")
                            if ticket.get('module'):
                                st.caption(f"Module: {ticket['module']}")
                
                with col2:
                    st.metric("Selected", len(st.session_state.selected_tickets))
                    st.metric("Total", len(available_tickets))
                
                st.markdown("---")
                
                # Analysis buttons
                col1, col2 = st.columns(2)
                
                with col1:
                    analyze_selected = st.button(
                        f"Analyze Selected ({len(st.session_state.selected_tickets)})",
                        type="primary",
                        use_container_width=True,
                        disabled=len(st.session_state.selected_tickets) == 0
                    )
                
                with col2:
                    analyze_all = st.button(
                        f"Analyze All ({len(available_tickets)})",
                        use_container_width=True
                    )
                
                # Run analysis
                if analyze_selected or analyze_all:
                    ticket_ids_to_analyze = None
                    
                    if analyze_selected:
                        ticket_ids_to_analyze = st.session_state.selected_tickets
                        st.info(f"Analyzing {len(ticket_ids_to_analyze)} selected ticket(s)...")
                    else:
                        st.info(f"Analyzing all {len(available_tickets)} ticket(s)...")
                    
                    with st.spinner("Analyzing for Root Cause... This may take a minute."):
                        try:
                            # Prepare request body
                            request_body = {}
                            if ticket_ids_to_analyze:
                                request_body = {"ticket_ids": ticket_ids_to_analyze}
                            
                            response = requests.post(
                                f"{API_BASE_URL}/api/projects/{st.session_state.project_name}/rca/analyze",
                                json=request_body if request_body else None
                            )
                            if response.status_code == 200:
                                result = response.json()
                                st.session_state.results['rca'] = result
                                
                                st.success("RCA Analysis Complete.")
                                
                                tickets = result.get('tickets', [])
                                
                                if tickets:
                                    st.subheader(f"Analysis Results ({len(tickets)} Tickets)")
                                    
                                    # Show each ticket
                                    for idx, ticket in enumerate(tickets, 1):
                                        with st.expander(f"Ticket {idx}: {ticket.get('ticket_id', 'Unknown')}", expanded=True):
                                            # Summary metrics
                                            col1, col2, col3 = st.columns(3)
                                            col1.metric("Root Cause", ticket.get('root_cause_type', 'N/A'))
                                            col2.metric("Fix Type", ticket.get('fix_type', 'N/A'))
                                            col3.metric("Confidence", f"{ticket.get('confidence_score', 0):.0%}")
                                            
                                            st.markdown("---")
                                            
                                            # Affected Code Section - Table Format
                                            st.markdown("### Affected Code Section")
                                            
                                            # Parse code pointer to extract line range
                                            code_pointer = ticket.get('code_pointer', 'N/A')
                                            impacted_file = ticket.get('impacted_file', 'N/A')
                                            impacted_method = ticket.get('impacted_method', 'N/A')
                                            
                                            # Create table data
                                            affected_data = {
                                                "Property": ["File", "Class/Method", "Line Range", "Root Cause Type"],
                                                "Value": [
                                                    impacted_file,
                                                    impacted_method,
                                                    code_pointer.split(':')[-1] if ':' in code_pointer else 'N/A',
                                                    ticket.get('root_cause_type', 'N/A')
                                                ]
                                            }
                                            
                                            affected_df = pd.DataFrame(affected_data)
                                            st.table(affected_df)
                                            
                                            # Show affected components if available
                                            if ticket.get('affected_components'):
                                                st.markdown("**Related Components:**")
                                                components_text = ", ".join(ticket['affected_components'][:5])
                                                st.info(components_text)
                                            
                                            st.markdown("---")
                                            
                                            # Analysis Details
                                            st.markdown("### Root Cause Analysis")
                                            
                                            # Create analysis table
                                            analysis_data = {
                                                "Aspect": ["Current Logic", "Expected Logic", "Resolution"],
                                                "Details": [
                                                    ticket.get('current_logic', 'N/A')[:200] + "..." if len(ticket.get('current_logic', '')) > 200 else ticket.get('current_logic', 'N/A'),
                                                    ticket.get('business_expected_logic', 'N/A')[:200] + "..." if len(ticket.get('business_expected_logic', '')) > 200 else ticket.get('business_expected_logic', 'N/A'),
                                                    ticket.get('resolution_logic', 'N/A')[:200] + "..." if len(ticket.get('resolution_logic', '')) > 200 else ticket.get('resolution_logic', 'N/A')
                                                ]
                                            }
                                            
                                            analysis_df = pd.DataFrame(analysis_data)
                                            st.table(analysis_df)
                                            
                                            # Expandable full details
                                            with st.expander("View Full Analysis Details"):
                                                st.markdown("**Current Logic:**")
                                                st.info(ticket.get('current_logic', 'N/A'))
                                                
                                                st.markdown("**Expected Business Logic:**")
                                                st.warning(ticket.get('business_expected_logic', 'N/A'))
                                                
                                                st.markdown("**Resolution:**")
                                                st.success(ticket.get('resolution_logic', 'N/A'))
                                            
                                            # Code Snippet Section
                                            if ticket.get('suggested_code_snippet'):
                                                st.markdown("---")
                                                st.markdown("### Suggested Code Implementation")
                                                st.markdown("**AI-generated code snippet based on the resolution logic:**")
                                                
                                                # Detect language from file extension
                                                impacted_file = ticket.get('impacted_file', '')
                                                language = 'python'  # default
                                                if impacted_file:
                                                    if impacted_file.endswith(('.js', '.jsx')):
                                                        language = 'javascript'
                                                    elif impacted_file.endswith(('.ts', '.tsx')):
                                                        language = 'typescript'
                                                    elif impacted_file.endswith('.java'):
                                                        language = 'java'
                                                    elif impacted_file.endswith('.py'):
                                                        language = 'python'
                                                    elif impacted_file.endswith(('.cpp', '.cc', '.cxx')):
                                                        language = 'cpp'
                                                    elif impacted_file.endswith('.c'):
                                                        language = 'c'
                                                    elif impacted_file.endswith('.cs'):
                                                        language = 'csharp'
                                                    elif impacted_file.endswith('.go'):
                                                        language = 'go'
                                                    elif impacted_file.endswith('.rb'):
                                                        language = 'ruby'
                                                
                                                # Display code snippet with syntax highlighting
                                                st.code(ticket['suggested_code_snippet'], language=language)
                                                
                                                # Download button for code snippet
                                                file_ext = {
                                                    'python': '.py',
                                                    'javascript': '.js',
                                                    'typescript': '.ts',
                                                    'java': '.java',
                                                    'cpp': '.cpp',
                                                    'c': '.c',
                                                    'csharp': '.cs',
                                                    'go': '.go',
                                                    'ruby': '.rb'
                                                }.get(language, '.txt')
                                                
                                                st.download_button(
                                                    label="Download Code Snippet",
                                                    data=ticket['suggested_code_snippet'],
                                                    file_name=f"{ticket.get('ticket_id', 'snippet')}_fix{file_ext}",
                                                    mime="text/plain",
                                                    use_container_width=True
                                                )
                                            else:
                                                st.markdown("---")
                                                st.info("No code snippet generated for this ticket.")
                                    
                                    # Download
                                    st.markdown("---")
                                    st.download_button(
                                        label="Download Full Report (JSON)",
                                        data=json.dumps(result, indent=2),
                                        file_name=f"rca_report_{st.session_state.project_name}.json",
                                        mime="application/json",
                                        use_container_width=True
                                    )
                                    
                                    # Option to analyze more tickets
                                    st.markdown("---")
                                    col1, col2 = st.columns(2)
                                    with col1:
                                        if st.button("Analyze More Tickets", use_container_width=True):
                                            st.session_state.selected_tickets = []
                                            st.rerun()
                                    with col2:
                                        if st.button("Add More Tickets", use_container_width=True):
                                            st.session_state.workflow_stage = 4
                                            st.rerun()
                                else:
                                    st.warning("No tickets found to analyze.")
                            else:
                                st.error(f"Error: {response.text}")
                        except Exception as e:
                            st.error(f"Error: {str(e)}")
            else:
                st.warning("No tickets found. Please process tickets first.")
                if st.button("Go to Jira Tickets"):
                    st.session_state.workflow_stage = 4
                    st.rerun()
        else:
            st.error(f"Error loading tickets: {response.text}")
    except Exception as e:
        st.error(f"Error: {str(e)}")
