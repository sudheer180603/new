import streamlit as st
import requests
import json
import pandas as pd

API_BASE_URL = "http://localhost:8000"

st.set_page_config(page_title="Agentic Smart Debugger", layout="wide")

st.title("🔍 Agentic Smart Debugger")
st.markdown("Enterprise-grade AI-powered debugging intelligence platform")

tab1, tab2, tab3, tab4, tab5 = st.tabs([
    "📦 GitHub Ingestion",
    "📄 Business Docs",
    "🧠 Build Context",
    "🎫 Jira Tickets",
    "🔬 RCA Analysis"
])

with tab1:
    st.header("GitHub Repository / Local Folder Ingestion")
    
    st.markdown("**Option 1: GitHub Repository**")
    repo_url = st.text_input(
        "Enter GitHub Repository URL", 
        placeholder="https://github.com/user/repo",
        key="repo_url_input"
    )
    
    st.markdown("**Option 2: Local Folder**")
    local_path = st.text_input(
        "Enter Local Folder Path",
        placeholder="C:\\projects\\myapp",
        key="local_path_input"
    )
    
    if st.button("Clone & Parse Repository / Folder"):
        # Prioritize repo_url if both are provided
        input_path = repo_url.strip() if repo_url and repo_url.strip() else (local_path.strip() if local_path else None)
        
        if input_path:
            with st.spinner("Processing..."):
                try:
                    response = requests.post(
                        f"{API_BASE_URL}/api/ingest/github", 
                        params={"repo_url_or_path": input_path}
                    )
                    if response.status_code == 200:
                        result = response.json()
                        st.success(f"✅ Successfully parsed {result['files_parsed']} files")
                        
                        # Show detailed output
                        st.subheader("📊 Ingestion Results")
                        
                        col1, col2 = st.columns(2)
                        col1.metric("Files Parsed", result['files_parsed'])
                        col2.metric("Languages Detected", len(result.get('languages', {})))
                        
                        st.markdown("**Repository Path:**")
                        st.code(result['repo_path'], language="text")
                        
                        if result.get('languages'):
                            st.markdown("**Languages Breakdown:**")
                            lang_df = pd.DataFrame([
                                {"Language": lang, "Files": count} 
                                for lang, count in result['languages'].items()
                            ])
                            st.dataframe(lang_df, use_container_width=True, hide_index=True)
                    else:
                        error_detail = response.json().get('detail', response.text)
                        st.error(f"❌ Error: {error_detail}")
                except requests.exceptions.ConnectionError:
                    st.error("❌ Cannot connect to backend. Make sure run_backend.bat is running.")
                except Exception as e:
                    st.error(f"❌ Error: {str(e)}")
        else:
            st.warning("⚠️ Please enter either a GitHub URL or a local folder path")

with tab2:
    st.header("Business Documentation Upload")
    uploaded_files = st.file_uploader(
        "Upload business documents (PDF, DOCX, TXT, MD)",
        accept_multiple_files=True,
        type=['pdf', 'docx', 'txt', 'md']
    )
    
    if st.button("Process Documents"):
        if uploaded_files:
            with st.spinner("Processing documents..."):
                try:
                    files = [("files", (f.name, f, f.type)) for f in uploaded_files]
                    response = requests.post(f"{API_BASE_URL}/api/ingest/business-docs", files=files)
                    if response.status_code == 200:
                        result = response.json()
                        st.success(f"✅ Extracted {result['rules_extracted']} business rules")
                        
                        # Show detailed output
                        st.subheader("📄 Document Processing Results")
                        
                        col1, col2 = st.columns(2)
                        col1.metric("Documents Processed", result['documents_processed'])
                        col2.metric("Rules Extracted", result['rules_extracted'])
                        
                        st.markdown("**Processed Files:**")
                        for f in uploaded_files:
                            st.write(f"- {f.name} ({f.type})")
                    else:
                        st.error(f"Error: {response.text}")
                except Exception as e:
                    st.error(f"Error: {str(e)}")
        else:
            st.warning("Please upload at least one document")

with tab3:
    st.header("Build Unified Context")
    st.markdown("Merge code CST, business knowledge, and generate embeddings")
    
    if st.button("Build Context"):
        with st.spinner("Building unified context..."):
            try:
                response = requests.post(f"{API_BASE_URL}/api/context/build")
                if response.status_code == 200:
                    result = response.json()
                    st.success("✅ Context built successfully")
                    
                    # Show detailed output
                    st.subheader("🧠 Context Building Results")
                    
                    col1, col2, col3 = st.columns(3)
                    col1.metric("Code Blocks", result['code_blocks'])
                    col2.metric("Business Rules", result['business_rules'])
                    col3.metric("Embeddings Generated", result['embeddings_generated'])
                    
                    st.info("✨ Unified context is ready for RCA analysis")
                else:
                    st.error(f"Error: {response.text}")
            except Exception as e:
                st.error(f"Error: {str(e)}")

with tab4:
    st.header("Jira Ticket Processing")
    
    st.markdown("**Required fields:** `ticket_id` or `jira_id` (all other fields are optional)")
    st.markdown("**Supported fields:** `summary`, `description`, `priority`, `module`, `severity`, `affected_module`, `error_message`, `stack_trace`, `endpoint`, `reproduction_steps`")
    
    ticket_json = st.text_area(
        "Paste Jira tickets JSON",
        height=200,
        placeholder='''[
  {
    "ticket_id": "PROJ-123",
    "summary": "Login fails for users",
    "description": "Users cannot login with valid credentials",
    "priority": "High",
    "module": "Authentication"
  }
]'''
    )
    
    if st.button("Process Tickets"):
        if ticket_json:
            try:
                tickets = json.loads(ticket_json)
                
                # Validate tickets
                if not isinstance(tickets, list):
                    st.error("❌ JSON must be an array of ticket objects")
                elif len(tickets) == 0:
                    st.error("❌ Please provide at least one ticket")
                else:
                    # Check for required fields (accept both ticket_id and jira_id)
                    missing_ids = []
                    for i, ticket in enumerate(tickets):
                        if not isinstance(ticket, dict):
                            st.error(f"❌ Ticket at index {i} is not a valid object")
                            break
                        if "ticket_id" not in ticket and "jira_id" not in ticket:
                            missing_ids.append(i)
                    
                    if missing_ids:
                        st.error(f"❌ Missing 'ticket_id' or 'jira_id' field in tickets at indices: {missing_ids}")
                    else:
                        with st.spinner("Processing tickets..."):
                            response = requests.post(
                                f"{API_BASE_URL}/api/jira/process",
                                json=tickets
                            )
                            if response.status_code == 200:
                                result = response.json()
                                st.success(f"✅ Processed {result['tickets_processed']} tickets")
                            else:
                                error_detail = response.json().get('detail', response.text) if response.headers.get('content-type') == 'application/json' else response.text
                                st.error(f"❌ Error: {error_detail}")
            except json.JSONDecodeError:
                st.error("❌ Invalid JSON format. Please check your JSON syntax.")
            except Exception as e:
                st.error(f"❌ Error: {str(e)}")
        else:
            st.warning("⚠️ Please enter ticket JSON")

with tab5:
    st.header("Root Cause Analysis")
    
    if st.button("Run RCA Analysis", type="primary"):
        with st.spinner("Analyzing tickets with Azure GPT-4..."):
            try:
                response = requests.post(f"{API_BASE_URL}/api/rca/analyze")
                if response.status_code == 200:
                    result = response.json()
                    st.success("✅ RCA Analysis Complete")
                    
                    tickets = result.get('tickets', [])
                    
                    if tickets:
                        st.subheader(f"📊 Analysis Results ({len(tickets)} Tickets)")
                        
                        # Show each ticket individually with better formatting
                        for idx, ticket in enumerate(tickets, 1):
                            with st.expander(f"🎫 Ticket {idx}: {ticket.get('ticket_id', 'Unknown')}", expanded=True):
                                # Ticket Summary
                                st.markdown(f"**Root Cause Type:** `{ticket.get('root_cause_type', 'N/A')}`")
                                st.markdown(f"**Fix Type:** `{ticket.get('fix_type', 'N/A')}`")
                                st.markdown(f"**Confidence Score:** `{ticket.get('confidence_score', 0):.2f}`")
                                
                                st.markdown("---")
                                
                                # Code Location
                                st.markdown("### 📍 Impacted Location")
                                col1, col2 = st.columns(2)
                                col1.markdown(f"**File:** `{ticket.get('impacted_file', 'N/A')}`")
                                col2.markdown(f"**Method:** `{ticket.get('impacted_method', 'N/A')}`")
                                st.markdown(f"**Code Pointer:** `{ticket.get('code_pointer', 'N/A')}`")
                                
                                st.markdown("---")
                                
                                # Analysis Details
                                st.markdown("### 🔍 Analysis")
                                
                                st.markdown("**Current Logic:**")
                                st.info(ticket.get('current_logic', 'N/A'))
                                
                                st.markdown("**Expected Business Logic:**")
                                st.warning(ticket.get('business_expected_logic', 'N/A'))
                                
                                st.markdown("**Resolution Logic:**")
                                st.success(ticket.get('resolution_logic', 'N/A'))
                        
                        # Download button
                        st.markdown("---")
                        st.download_button(
                            label="📥 Download Full RCA Report (JSON)",
                            data=json.dumps(result, indent=2),
                            file_name="rca_report.json",
                            mime="application/json"
                        )
                    else:
                        st.warning("⚠️ No tickets found to analyze. Please process Jira tickets first.")
                    
                    # Show consolidation if available
                    if result.get('consolidation'):
                        st.markdown("---")
                        st.subheader("🔗 Issue Consolidation")
                        for cluster in result['consolidation']:
                            with st.expander(f"Cluster {cluster['cluster_id']} - {cluster['ticket_count']} tickets"):
                                st.write(f"**Primary Ticket:** {cluster['primary_ticket']}")
                                st.write(f"**Related Tickets:** {', '.join(cluster['related_tickets'])}")
                                st.write(f"**Root Cause:** {cluster['shared_root_cause']}")
                                st.write(f"**Impacted Files:** {', '.join(cluster['impacted_files'])}")
                else:
                    st.error(f"Error: {response.text}")
            except Exception as e:
                st.error(f"Error: {str(e)}")

st.sidebar.title("System Status")
try:
    health = requests.get(f"{API_BASE_URL}/api/health")
    if health.status_code == 200:
        st.sidebar.success("✅ Backend Connected")
    else:
        st.sidebar.error("❌ Backend Error")
except:
    st.sidebar.error("❌ Backend Offline")

st.sidebar.markdown("---")
st.sidebar.info("""
**Workflow:**
1. Ingest GitHub repo
2. Upload business docs
3. Build unified context
4. Process Jira tickets
5. Run RCA analysis
""")
