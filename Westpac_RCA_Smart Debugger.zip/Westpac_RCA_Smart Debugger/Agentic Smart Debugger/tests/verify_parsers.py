"""
Final verification script for parser fixes
Run this to verify all parsers are working correctly
"""
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

print("=" * 60)
print("AGENTIC SMART DEBUGGER - PARSER VERIFICATION")
print("=" * 60)

# Test 1: Import all modules
print("\n[1/5] Testing imports...")
try:
    from app.parsers.python_parser import PythonParser
    from app.parsers.js_parser import JSParser
    from app.parsers.orchestrator import ParserOrchestrator
    from app.database.models import init_db, CodeMetadata
    print("✅ All modules imported successfully")
except Exception as e:
    print(f"❌ Import failed: {e}")
    sys.exit(1)

# Test 2: Initialize database
print("\n[2/5] Initializing database...")
try:
    init_db()
    print("✅ Database initialized with new schema")
except Exception as e:
    print(f"❌ Database initialization failed: {e}")
    sys.exit(1)

# Test 3: Test Python parser
print("\n[3/5] Testing Python parser...")
try:
    python_parser = PythonParser()
    python_code = """
class Calculator:
    def add(self, a, b):
        return a + b
    
    def subtract(self, a, b):
        return a - b

def multiply(x, y):
    return x * y
"""
    result = python_parser.parse_file("test.py", python_code)
    assert len(result) > 0, "No code blocks parsed"
    assert all('node_type' in block for block in result), "Missing node_type field"
    print(f"✅ Python parser working - found {len(result)} code blocks")
except Exception as e:
    print(f"❌ Python parser failed: {e}")
    sys.exit(1)

# Test 4: Test JS parser
print("\n[4/5] Testing JavaScript parser...")
try:
    js_parser = JSParser()
    js_code = """
class ApiClient {
    constructor(baseUrl) {
        this.baseUrl = baseUrl;
    }
    
    async get(endpoint) {
        return fetch(this.baseUrl + endpoint);
    }
}

function handleResponse(response) {
    return response.json();
}

const logError = (error) => console.error(error);
"""
    result = js_parser.parse_file("test.js", js_code, is_typescript=False)
    assert len(result) > 0, "No code blocks parsed"
    assert all('node_type' in block for block in result), "Missing node_type field"
    print(f"✅ JS parser working - found {len(result)} code blocks")
except Exception as e:
    print(f"❌ JS parser failed: {e}")
    sys.exit(1)

# Test 5: Verify database schema
print("\n[5/5] Verifying database schema...")
try:
    from sqlalchemy import inspect
    from app.database.models import engine, CodeMetadata
    
    inspector = inspect(engine)
    columns = [col['name'] for col in inspector.get_columns('code_metadata')]
    
    required_fields = ['id', 'file_path', 'node_type', 'class_name', 'method_name', 
                      'start_line', 'end_line', 'raw_code', 'cst_tree', 
                      'dependencies', 'related_business_rules', 'embedding_id']
    
    for field in required_fields:
        assert field in columns, f"Missing field: {field}"
    
    assert 'node_type' in columns, "Field 'node_type' not found (should not be 'type')"
    assert 'type' not in columns, "Old field 'type' still exists (should be 'node_type')"
    
    print("✅ Database schema correct - using 'node_type' field")
except Exception as e:
    print(f"❌ Schema verification failed: {e}")
    sys.exit(1)

print("\n" + "=" * 60)
print("✅ ALL TESTS PASSED!")
print("=" * 60)
print("\nThe parsers are working correctly. You can now:")
print("  1. Start backend: .\\run_backend.bat")
print("  2. Start frontend: .\\run_frontend.bat")
print("  3. Access UI: http://localhost:8501")
print("\nFor more details, see: docs/FIXES_APPLIED.md")
