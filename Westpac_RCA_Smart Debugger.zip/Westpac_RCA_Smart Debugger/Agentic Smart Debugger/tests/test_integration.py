"""
Integration test for enhanced extraction and advanced RCA
Tests the complete workflow with enrichment
"""
import sys
import asyncio
from app.parsers.enhanced_extractor import EnhancedExtractor
from app.rca_engine.advanced_analyzer import AdvancedRCAAnalyzer

def test_enhanced_extractor():
    """Test enhanced extractor on sample code"""
    print("\n=== Testing Enhanced Extractor ===")
    
    sample_code = """
def validate_user_input(data):
    '''Validate user input data'''
    # Check if data is not None
    if data is None:
        raise ValueError("Data cannot be None")
    
    # Validate email format
    if not validate_email(data.get('email')):
        return False
    
    try:
        # Save to database
        db.save(data)
    except DatabaseError as e:
        logger.error(f"Database error: {e}")
        return False
    
    return True
"""
    
    code_block = {
        'raw_code': sample_code,
        'file_path': 'test.py',
        'method_name': 'validate_user_input'
    }
    
    # Enrich the code block
    enriched = EnhancedExtractor.enrich_code_block(code_block, 'python')
    
    print(f"✓ Comments found: {len(enriched['enrichment']['comments'])}")
    print(f"✓ Docstrings found: {len(enriched['enrichment']['docstrings'])}")
    print(f"✓ Error handling blocks: {len(enriched['enrichment']['error_handling'])}")
    print(f"✓ Validations found: {len(enriched['enrichment']['validations'])}")
    print(f"✓ Database operations: {len(enriched['enrichment']['database_ops'])}")
    
    if enriched.get('enhanced_description'):
        print(f"✓ Enhanced description: {enriched['enhanced_description'][:100]}...")
    
    # Verify enrichment data
    assert len(enriched['enrichment']['comments']) > 0, "Should find comments"
    assert len(enriched['enrichment']['docstrings']) > 0, "Should find docstrings"
    assert len(enriched['enrichment']['error_handling']) > 0, "Should find error handling"
    assert len(enriched['enrichment']['validations']) > 0, "Should find validations"
    
    print("✅ Enhanced Extractor test PASSED")
    return True

def test_pattern_matching():
    """Test pattern matching boost"""
    print("\n=== Testing Pattern Matching ===")
    
    from app.database.models import Ticket
    
    # Create mock ticket
    ticket = Ticket(
        ticket_id="TEST-001",
        summary="Validation error in user registration",
        description="User registration fails with validation error when email is invalid",
        priority="High",
        module="auth"
    )
    
    # Mock AI result
    ai_result = {
        'impacted_file': 'auth/validators.py',
        'impacted_method': 'UserValidator.validate_email',
        'code_pointer': 'auth/validators.py:45-60',
        'resolution_logic': 'Update the email validation regex to handle edge cases properly',
        'gap_analysis': 'Current validation does not handle international email formats',
        'confidence_score': 0.65
    }
    
    # Mock relevant code
    relevant_code = [
        ({'id': 1}, 0.85),
        ({'id': 2}, 0.75)
    ]
    
    analyzer = AdvancedRCAAnalyzer()
    boost_factors = analyzer._pattern_matching_boost(ticket, relevant_code, ai_result)
    
    print(f"✓ Boost factors: {boost_factors}")
    print(f"✓ Total boost: {sum(boost_factors.values()):.2f}")
    
    # Calculate confidence
    confidence = analyzer._calculate_confidence(ai_result, boost_factors, relevant_code, [])
    
    print(f"✓ Base confidence: {ai_result['confidence_score']:.2f}")
    print(f"✓ Final confidence: {confidence:.2f}")
    
    assert confidence > ai_result['confidence_score'], "Confidence should be boosted"
    
    print("✅ Pattern Matching test PASSED")
    return True

def test_imports():
    """Test that all imports work correctly"""
    print("\n=== Testing Imports ===")
    
    try:
        from app.parsers.enhanced_extractor import EnhancedExtractor
        print("✓ EnhancedExtractor imported")
        
        from app.rca_engine.advanced_analyzer import AdvancedRCAAnalyzer
        print("✓ AdvancedRCAAnalyzer imported")
        
        from app.parsers.orchestrator import ParserOrchestrator
        print("✓ ParserOrchestrator imported (with EnhancedExtractor)")
        
        from app.rca_engine.analyzer import analyze_tickets
        print("✓ analyze_tickets imported (with AdvancedRCAAnalyzer)")
        
        print("✅ All imports successful")
        return True
        
    except Exception as e:
        print(f"❌ Import failed: {e}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("INTEGRATION TEST - Enhanced Extraction & Advanced RCA")
    print("=" * 60)
    
    results = []
    
    # Test 1: Imports
    results.append(("Imports", test_imports()))
    
    # Test 2: Enhanced Extractor
    results.append(("Enhanced Extractor", test_enhanced_extractor()))
    
    # Test 3: Pattern Matching
    results.append(("Pattern Matching", test_pattern_matching()))
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{test_name}: {status}")
    
    all_passed = all(result[1] for result in results)
    
    if all_passed:
        print("\n🎉 ALL TESTS PASSED!")
        return 0
    else:
        print("\n⚠️ SOME TESTS FAILED")
        return 1

if __name__ == "__main__":
    sys.exit(main())
