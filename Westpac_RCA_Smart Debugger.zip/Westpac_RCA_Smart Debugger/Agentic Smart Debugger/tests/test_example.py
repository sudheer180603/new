"""
Example test script to verify the system is working
"""
import requests
import json

API_BASE_URL = "http://localhost:8000"

def test_health():
    print("Testing health endpoint...")
    response = requests.get(f"{API_BASE_URL}/api/health")
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
    print()

def test_github_ingestion():
    print("Testing GitHub ingestion...")
    repo_url = "https://github.com/pallets/flask"
    response = requests.post(
        f"{API_BASE_URL}/api/ingest/github",
        params={"repo_url": repo_url}
    )
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
    print()

def test_jira_processing():
    print("Testing Jira ticket processing...")
    tickets = [
        {
            "ticket_id": "TEST-001",
            "summary": "Login authentication fails",
            "description": "Users cannot authenticate with valid credentials",
            "priority": "High",
            "module": "Authentication"
        },
        {
            "ticket_id": "TEST-002",
            "summary": "Database connection timeout",
            "description": "Application loses database connection after 5 minutes",
            "priority": "Critical",
            "module": "Database"
        }
    ]
    
    response = requests.post(
        f"{API_BASE_URL}/api/jira/process",
        json=tickets
    )
    print(f"Status: {response.status_code}")
    print(f"Response: {response.json()}")
    print()

if __name__ == "__main__":
    print("=== Agentic Smart Debugger Test Suite ===\n")
    
    try:
        test_health()
        # Uncomment to test other endpoints
        # test_github_ingestion()
        # test_jira_processing()
    except Exception as e:
        print(f"Error: {str(e)}")
        print("Make sure the backend is running on port 8000")
