#!/usr/bin/env python3
"""
Setup verification script for Agentic Smart Debugger
Checks if all required components are in place
"""

import os
import sys
from pathlib import Path

def check_file(path, description):
    """Check if a file exists"""
    if os.path.exists(path):
        print(f"✅ {description}: {path}")
        return True
    else:
        print(f"❌ {description}: {path} - MISSING")
        return False

def check_directory(path, description):
    """Check if a directory exists"""
    if os.path.isdir(path):
        print(f"✅ {description}: {path}")
        return True
    else:
        print(f"❌ {description}: {path} - MISSING")
        return False

def main():
    print("=" * 60)
    print("Agentic Smart Debugger - Setup Verification")
    print("=" * 60)
    print()
    
    all_good = True
    
    # Check core files
    print("📄 Core Files:")
    all_good &= check_file("requirements.txt", "Requirements")
    all_good &= check_file(".env.example", "Environment template")
    all_good &= check_file("README.md", "README")
    all_good &= check_directory("docs", "Documentation folder")
    all_good &= check_file("docs/START_HERE.md", "Start guide")
    print()
    
    # Check app structure
    print("📁 Backend Structure:")
    all_good &= check_directory("app", "App directory")
    all_good &= check_file("app/main.py", "Main FastAPI app")
    all_good &= check_file("app/config.py", "Configuration")
    print()
    
    # Check modules
    print("🔧 Backend Modules:")
    modules = [
        "github", "parsers", "business_docs", "context_engine",
        "embeddings", "vector_store", "jira", "rca_engine",
        "consolidation", "database", "services", "utils"
    ]
    for module in modules:
        all_good &= check_directory(f"app/{module}", f"{module.title()} module")
    print()
    
    # Check frontend
    print("🎨 Frontend:")
    all_good &= check_directory("frontend", "Frontend directory")
    all_good &= check_file("frontend/app.py", "Streamlit app")
    print()
    
    # Check scripts
    print("🚀 Launch Scripts:")
    all_good &= check_file("run_backend.bat", "Backend launcher (Windows)")
    all_good &= check_file("run_backend.sh", "Backend launcher (Linux/Mac)")
    all_good &= check_file("run_frontend.bat", "Frontend launcher (Windows)")
    all_good &= check_file("run_frontend.sh", "Frontend launcher (Linux/Mac)")
    all_good &= check_file("quickstart.bat", "Quick setup (Windows)")
    all_good &= check_file("quickstart.sh", "Quick setup (Linux/Mac)")
    print()
    
    # Check environment
    print("⚙️  Environment:")
    if os.path.exists(".env"):
        print("✅ .env file exists")
        with open(".env", "r") as f:
            content = f.read()
            if "AZURE_OPENAI_ENDPOINT" in content:
                print("✅ Azure OpenAI endpoint configured")
            else:
                print("⚠️  Azure OpenAI endpoint not configured")
                all_good = False
    else:
        print("⚠️  .env file not found - copy .env.example and configure")
        all_good = False
    print()
    
    # Check Python version
    print("🐍 Python Environment:")
    version = sys.version_info
    if version.major == 3 and version.minor >= 9:
        print(f"✅ Python version: {version.major}.{version.minor}.{version.micro}")
    else:
        print(f"❌ Python version: {version.major}.{version.minor}.{version.micro} - Need 3.9+")
        all_good = False
    print()
    
    # Summary
    print("=" * 60)
    if all_good:
        print("✅ All checks passed! System is ready.")
        print()
        print("Next steps:")
        print("1. Configure Azure OpenAI in .env file (if not done)")
        print("   copy .env.example .env")
        print("   notepad .env")
        print("2. Run: run_backend.bat")
        print("3. Run: run_frontend.bat")
        print("4. Open: http://localhost:8501")
        print("5. Read: docs\\START_HERE.md")
    else:
        print("❌ Some checks failed. Please review the output above.")
        print()
        print("Run quickstart.bat (or .sh) to set up the environment.")
    print("=" * 60)
    
    return 0 if all_good else 1

if __name__ == "__main__":
    sys.exit(main())
