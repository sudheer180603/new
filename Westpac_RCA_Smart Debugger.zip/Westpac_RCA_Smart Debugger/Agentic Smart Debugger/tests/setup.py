from setuptools import setup, find_packages

setup(
    name="agentic-smart-debugger",
    version="1.0.0",
    packages=find_packages(),
    install_requires=[
        "fastapi>=0.109.0",
        "uvicorn>=0.27.0",
        "streamlit>=1.31.0",
        "openai>=1.12.0",
        "sentence-transformers>=2.3.1",
        "faiss-cpu>=1.7.4",
        "libcst>=1.1.0",
        "tree-sitter>=0.20.4",
        "gitpython>=3.1.41",
        "PyPDF2>=3.0.1",
        "python-docx>=1.1.0",
        "sqlalchemy>=2.0.25",
        "pydantic>=2.6.0",
        "pydantic-settings>=2.1.0",
    ],
    python_requires=">=3.9",
)
