"""
Test script for new features:
1. Dependency graph population
2. Code snippet generation in RCA
"""
import asyncio
import logging
from app.database.project_db import project_db
from app.database.models import DependencyGraph, RCAResult, CodeMetadata, Ticket
from app.project_manager import project_manager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_dependency_graph(project_name: str):
    """Test if dependency graph is populated"""
    logger.info(f"\n{'='*60}")
    logger.info(f"Testing Dependency Graph for project: {project_name}")
    logger.info(f"{'='*60}")
    
    try:
        db = project_db.get_session(project_name)
        
        # Count dependencies
        dep_count = db.query(DependencyGraph).count()
        logger.info(f"✓ Total dependencies in graph: {dep_count}")
        
        if dep_count == 0:
            logger.warning("⚠ No dependencies found. Make sure to parse repository first.")
            db.close()
            return False
        
        # Get sample dependencies
        sample_deps = db.query(DependencyGraph).limit(10).all()
        
        logger.info(f"\nSample Dependencies:")
        logger.info(f"{'-'*60}")
        for dep in sample_deps:
            logger.info(f"  {dep.source_file}")
            logger.info(f"    → {dep.target_file}")
            logger.info(f"    Type: {dep.dependency_type}")
            logger.info(f"")
        
        # Get dependency statistics
        dep_types = db.query(
            DependencyGraph.dependency_type,
            db.func.count(DependencyGraph.id)
        ).group_by(DependencyGraph.dependency_type).all()
        
        logger.info(f"Dependency Types Distribution:")
        logger.info(f"{'-'*60}")
        for dep_type, count in dep_types:
            logger.info(f"  {dep_type}: {count}")
        
        # Get files with most dependencies
        top_sources = db.query(
            DependencyGraph.source_file,
            db.func.count(DependencyGraph.id).label('dep_count')
        ).group_by(DependencyGraph.source_file).order_by(
            db.text('dep_count DESC')
        ).limit(5).all()
        
        logger.info(f"\nTop 5 Files with Most Dependencies:")
        logger.info(f"{'-'*60}")
        for file, count in top_sources:
            logger.info(f"  {file}: {count} dependencies")
        
        db.close()
        logger.info(f"\n✓ Dependency graph test PASSED")
        return True
        
    except Exception as e:
        logger.error(f"✗ Dependency graph test FAILED: {e}")
        return False

def test_code_snippets(project_name: str):
    """Test if code snippets are generated in RCA results"""
    logger.info(f"\n{'='*60}")
    logger.info(f"Testing Code Snippet Generation for project: {project_name}")
    logger.info(f"{'='*60}")
    
    try:
        db = project_db.get_session(project_name)
        
        # Count RCA results
        rca_count = db.query(RCAResult).count()
        logger.info(f"✓ Total RCA results: {rca_count}")
        
        if rca_count == 0:
            logger.warning("⚠ No RCA results found. Run RCA analysis first.")
            db.close()
            return False
        
        # Check for code snippets
        with_snippets = db.query(RCAResult).filter(
            RCAResult.suggested_code_snippet.isnot(None)
        ).count()
        
        without_snippets = rca_count - with_snippets
        
        logger.info(f"\nCode Snippet Statistics:")
        logger.info(f"{'-'*60}")
        logger.info(f"  With code snippets: {with_snippets}")
        logger.info(f"  Without code snippets: {without_snippets}")
        logger.info(f"  Coverage: {(with_snippets/rca_count*100):.1f}%")
        
        # Get sample RCA with code snippet
        sample_rca = db.query(RCAResult).filter(
            RCAResult.suggested_code_snippet.isnot(None)
        ).first()
        
        if sample_rca:
            logger.info(f"\nSample RCA Result with Code Snippet:")
            logger.info(f"{'-'*60}")
            logger.info(f"  Ticket ID: {sample_rca.ticket_id}")
            logger.info(f"  Root Cause: {sample_rca.root_cause_type}")
            logger.info(f"  Impacted File: {sample_rca.impacted_file}")
            logger.info(f"  Impacted Method: {sample_rca.impacted_method}")
            logger.info(f"  Fix Type: {sample_rca.fix_type}")
            logger.info(f"  Confidence: {sample_rca.confidence_score:.2f}")
            logger.info(f"\n  Resolution Logic:")
            logger.info(f"  {sample_rca.resolution_logic[:200]}...")
            logger.info(f"\n  Code Snippet Preview:")
            logger.info(f"  {'-'*60}")
            snippet_preview = sample_rca.suggested_code_snippet[:500] if sample_rca.suggested_code_snippet else "None"
            logger.info(f"  {snippet_preview}...")
        
        db.close()
        
        if with_snippets > 0:
            logger.info(f"\n✓ Code snippet generation test PASSED")
            return True
        else:
            logger.warning(f"\n⚠ Code snippet generation test INCOMPLETE - no snippets found")
            return False
        
    except Exception as e:
        logger.error(f"✗ Code snippet generation test FAILED: {e}")
        return False

def test_code_metadata_dependencies(project_name: str):
    """Test if CodeMetadata has dependencies populated"""
    logger.info(f"\n{'='*60}")
    logger.info(f"Testing CodeMetadata Dependencies for project: {project_name}")
    logger.info(f"{'='*60}")
    
    try:
        db = project_db.get_session(project_name)
        
        # Count code blocks
        code_count = db.query(CodeMetadata).count()
        logger.info(f"✓ Total code blocks: {code_count}")
        
        if code_count == 0:
            logger.warning("⚠ No code blocks found. Parse repository first.")
            db.close()
            return False
        
        # Check for dependencies in CodeMetadata
        with_deps = db.query(CodeMetadata).filter(
            CodeMetadata.dependencies.isnot(None)
        ).count()
        
        logger.info(f"\nCodeMetadata Dependency Statistics:")
        logger.info(f"{'-'*60}")
        logger.info(f"  Code blocks with dependencies: {with_deps}")
        logger.info(f"  Code blocks without dependencies: {code_count - with_deps}")
        logger.info(f"  Coverage: {(with_deps/code_count*100):.1f}%")
        
        # Get sample code blocks with dependencies
        sample_blocks = db.query(CodeMetadata).filter(
            CodeMetadata.dependencies.isnot(None)
        ).limit(5).all()
        
        logger.info(f"\nSample Code Blocks with Dependencies:")
        logger.info(f"{'-'*60}")
        for block in sample_blocks:
            logger.info(f"  File: {block.file_path}")
            logger.info(f"  Method: {block.class_name}.{block.method_name}" if block.class_name else f"  Function: {block.method_name}")
            logger.info(f"  Dependencies: {block.dependencies[:5]}")  # Show first 5
            logger.info(f"")
        
        db.close()
        logger.info(f"\n✓ CodeMetadata dependencies test PASSED")
        return True
        
    except Exception as e:
        logger.error(f"✗ CodeMetadata dependencies test FAILED: {e}")
        return False

def main():
    """Run all tests"""
    logger.info(f"\n{'#'*60}")
    logger.info(f"# NEW FEATURES TEST SUITE")
    logger.info(f"{'#'*60}")
    
    # Get available projects
    projects = project_manager.list_projects()
    
    if not projects:
        logger.error("No projects found. Create a project first.")
        return
    
    logger.info(f"\nAvailable projects: {projects}")
    
    # Test each project
    results = {}
    for project_name in projects:
        logger.info(f"\n\nTesting project: {project_name}")
        logger.info(f"{'='*60}")
        
        results[project_name] = {
            "code_metadata_deps": test_code_metadata_dependencies(project_name),
            "dependency_graph": test_dependency_graph(project_name),
            "code_snippets": test_code_snippets(project_name)
        }
    
    # Summary
    logger.info(f"\n\n{'#'*60}")
    logger.info(f"# TEST SUMMARY")
    logger.info(f"{'#'*60}")
    
    for project_name, tests in results.items():
        logger.info(f"\nProject: {project_name}")
        logger.info(f"{'-'*60}")
        for test_name, passed in tests.items():
            status = "✓ PASSED" if passed else "✗ FAILED"
            logger.info(f"  {test_name}: {status}")
    
    # Overall result
    all_passed = all(all(tests.values()) for tests in results.values())
    
    if all_passed:
        logger.info(f"\n{'='*60}")
        logger.info(f"✓ ALL TESTS PASSED")
        logger.info(f"{'='*60}")
    else:
        logger.info(f"\n{'='*60}")
        logger.info(f"⚠ SOME TESTS FAILED OR INCOMPLETE")
        logger.info(f"{'='*60}")

if __name__ == "__main__":
    main()
