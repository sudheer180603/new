"""
Fix for multiprocess ResourceTracker warning in Python 3.12+
This script patches the multiprocess library to prevent cleanup warnings
"""
import sys
import warnings

def fix_multiprocess_warning():
    """
    Suppress multiprocess ResourceTracker warnings in Python 3.12+
    This is a known compatibility issue that doesn't affect functionality
    """
    # Suppress the specific warning
    warnings.filterwarnings("ignore", category=UserWarning, module="multiprocess.resource_tracker")
    warnings.filterwarnings("ignore", message=".*_recursion_count.*")
    
    # Patch the ResourceTracker if multiprocess is already imported
    try:
        import multiprocess.resource_tracker as resource_tracker
        
        # Store original __del__ method
        original_del = resource_tracker.ResourceTracker.__del__
        
        # Create patched version that catches the AttributeError
        def patched_del(self):
            try:
                original_del(self)
            except AttributeError as e:
                if '_recursion_count' in str(e):
                    # Silently ignore this specific error
                    pass
                else:
                    raise
        
        # Apply patch
        resource_tracker.ResourceTracker.__del__ = patched_del
        print("✅ Multiprocess warning fix applied")
        
    except ImportError:
        # multiprocess not installed or not imported yet
        pass
    except Exception as e:
        print(f"⚠️ Could not apply multiprocess fix: {e}")

if __name__ == "__main__":
    fix_multiprocess_warning()
    print("✅ Fix applied. You can now import modules without warnings.")
