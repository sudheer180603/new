"""
Migration script to add suggested_code_snippet column to rca_results table
Run this script to update existing databases
"""
import sqlite3
import os
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def migrate_database(db_path: str):
    """Add suggested_code_snippet column to rca_results table"""
    if not os.path.exists(db_path):
        logger.warning(f"Database not found: {db_path}")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check if column already exists
        cursor.execute("PRAGMA table_info(rca_results)")
        columns = [col[1] for col in cursor.fetchall()]
        
        if 'suggested_code_snippet' in columns:
            logger.info(f"Column already exists in {db_path}")
            conn.close()
            return True
        
        # Add the new column
        cursor.execute("""
            ALTER TABLE rca_results 
            ADD COLUMN suggested_code_snippet TEXT
        """)
        
        conn.commit()
        conn.close()
        
        logger.info(f"Successfully migrated {db_path}")
        return True
        
    except Exception as e:
        logger.error(f"Error migrating {db_path}: {e}")
        return False

def main():
    """Migrate all databases"""
    migrated = 0
    failed = 0
    
    # Migrate global database
    if os.path.exists("debugger.db"):
        if migrate_database("debugger.db"):
            migrated += 1
        else:
            failed += 1
    
    # Migrate project databases
    projects_dir = "./projects"
    if os.path.exists(projects_dir):
        for project_name in os.listdir(projects_dir):
            project_path = os.path.join(projects_dir, project_name)
            if os.path.isdir(project_path):
                db_path = os.path.join(project_path, "database", "project.db")
                if os.path.exists(db_path):
                    if migrate_database(db_path):
                        migrated += 1
                    else:
                        failed += 1
    
    logger.info(f"\nMigration complete: {migrated} databases migrated, {failed} failed")

if __name__ == "__main__":
    main()
