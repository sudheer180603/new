@echo off
echo Starting Streamlined Frontend...
echo.
cd frontend
streamlit run streamlined_app.py --server.port 8501
