# Agentic Smart Debugger - Clear Data Script
# PowerShell version with more options

param(
    [switch]$All,
    [switch]$Database,
    [switch]$Indexes,
    [switch]$Projects,
    [switch]$Repos,
    [switch]$Force
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Agentic Smart Debugger - Clear Data" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Show help if no parameters
if (-not ($All -or $Database -or $Indexes -or $Projects -or $Repos)) {
    Write-Host "Usage:" -ForegroundColor Yellow
    Write-Host "  .\clear_data.ps1 -All          # Clear everything"
    Write-Host "  .\clear_data.ps1 -Database     # Clear only database"
    Write-Host "  .\clear_data.ps1 -Indexes      # Clear only FAISS indexes"
    Write-Host "  .\clear_data.ps1 -Projects     # Clear only projects"
    Write-Host "  .\clear_data.ps1 -Repos        # Clear only cloned repos"
    Write-Host "  .\clear_data.ps1 -All -Force   # Clear without confirmation"
    Write-Host ""
    exit
}

# Confirm unless -Force is used
if (-not $Force) {
    Write-Host "This will delete:" -ForegroundColor Yellow
    if ($All -or $Database) { Write-Host "  - debugger.db" }
    if ($All -or $Indexes) { Write-Host "  - faiss_index/" }
    if ($All -or $Projects) { Write-Host "  - projects/" }
    if ($All -or $Repos) { Write-Host "  - cloned_repos/" }
    Write-Host ""
    
    $confirm = Read-Host "Are you sure? (y/n)"
    if ($confirm -ne 'y') {
        Write-Host "Operation cancelled." -ForegroundColor Yellow
        exit
    }
}

Write-Host ""
Write-Host "Clearing data..." -ForegroundColor Green
Write-Host ""

$cleared = 0

# Clear database
if ($All -or $Database) {
    if (Test-Path "debugger.db") {
        Remove-Item "debugger.db" -Force
        Write-Host "[OK] debugger.db deleted" -ForegroundColor Green
        $cleared++
    } else {
        Write-Host "[--] debugger.db not found" -ForegroundColor Gray
    }
}

# Clear FAISS indexes
if ($All -or $Indexes) {
    if (Test-Path "faiss_index") {
        Remove-Item -Recurse -Force "faiss_index"
        Write-Host "[OK] faiss_index/ deleted" -ForegroundColor Green
        $cleared++
    } else {
        Write-Host "[--] faiss_index/ not found" -ForegroundColor Gray
    }
}

# Clear projects
if ($All -or $Projects) {
    if (Test-Path "projects") {
        Remove-Item -Recurse -Force "projects"
        Write-Host "[OK] projects/ deleted" -ForegroundColor Green
        $cleared++
    } else {
        Write-Host "[--] projects/ not found" -ForegroundColor Gray
    }
}

# Clear cloned repos
if ($All -or $Repos) {
    if (Test-Path "cloned_repos") {
        Remove-Item -Recurse -Force "cloned_repos"
        Write-Host "[OK] cloned_repos/ deleted" -ForegroundColor Green
        $cleared++
    } else {
        Write-Host "[--] cloned_repos/ not found" -ForegroundColor Gray
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
if ($cleared -gt 0) {
    Write-Host "  $cleared item(s) cleared successfully!" -ForegroundColor Green
} else {
    Write-Host "  No items found to clear" -ForegroundColor Yellow
}
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "The system will recreate databases automatically" -ForegroundColor Gray
Write-Host "when you restart the backend." -ForegroundColor Gray
Write-Host ""
