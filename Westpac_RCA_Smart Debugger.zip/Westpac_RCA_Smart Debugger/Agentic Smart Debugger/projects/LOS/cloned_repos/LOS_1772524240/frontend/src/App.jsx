import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import Sidebar from './components/Sidebar';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import CustomerDashboard from './pages/CustomerDashboard';
import CreateCustomer from './pages/CreateCustomer';
import VerifyKYC from './pages/VerifyKYC';
import SubmitKYC from './pages/SubmitKYC';
import GenerateCreditScore from './pages/GenerateCreditScore';
import ApplyLoan from './pages/ApplyLoan';
import MyLoans from './pages/MyLoans';
import LoanDetails from './pages/LoanDetails';
import LoanApproval from './pages/LoanApproval';
import PaymentProcessing from './pages/PaymentProcessing';
import PaymentHistory from './pages/PaymentHistory';
import Profile from './pages/Profile';
import EMICalculator from './pages/EMICalculator';
import Reports from './pages/Reports';

function PrivateRoute({ children }) {
    const { user, loading } = useAuth();
    if (loading) return <div className="loading"><div className="spinner" /> Loading...</div>;
    return user ? children : <Navigate to="/login" />;
}

function RoleRoute({ children, roles }) {
    const { user, loading } = useAuth();
    if (loading) return <div className="loading"><div className="spinner" /> Loading...</div>;
    if (!user) return <Navigate to="/login" />;
    if (!roles.includes(user.role)) {
        return (
            <AppLayout>
                <div className="card" style={{ textAlign: 'center', padding: '60px 20px' }}>
                    <h2 style={{ color: 'var(--danger)', marginBottom: '12px' }}>🚫 Access Denied</h2>
                    <p style={{ color: 'var(--text-secondary)' }}>
                        Your role <strong>({user.role})</strong> does not have permission to access this page.
                    </p>
                    <button className="btn btn-primary" style={{ marginTop: '20px' }}
                        onClick={() => window.location.href = '/'}>
                        ← Back to Dashboard
                    </button>
                </div>
            </AppLayout>
        );
    }
    return children;
}

function AppLayout({ children }) {
    return (
        <div className="app-layout">
            <Sidebar />
            <main className="main-content">{children}</main>
        </div>
    );
}

// Smart dashboard route that renders role-specific dashboard
function SmartDashboard() {
    const { user } = useAuth();
    if (user?.role === 'ADMIN') return <Dashboard />;
    return <CustomerDashboard />;
}

function AppRoutes() {
    const { user } = useAuth();

    return (
        <Routes>
            <Route path="/login" element={user ? <Navigate to="/" /> : <Login />} />
            <Route path="/register" element={user ? <Navigate to="/" /> : <Register />} />

            {/* Dashboard — role-aware */}
            <Route path="/" element={<PrivateRoute><AppLayout><SmartDashboard /></AppLayout></PrivateRoute>} />

            {/* Customer pages — any authenticated user */}
            <Route path="/profile" element={<PrivateRoute><AppLayout><Profile /></AppLayout></PrivateRoute>} />
            <Route path="/kyc/submit" element={<PrivateRoute><AppLayout><SubmitKYC /></AppLayout></PrivateRoute>} />
            <Route path="/loans/apply" element={<PrivateRoute><AppLayout><ApplyLoan /></AppLayout></PrivateRoute>} />
            <Route path="/loans/my" element={<PrivateRoute><AppLayout><MyLoans /></AppLayout></PrivateRoute>} />
            <Route path="/loans/:id" element={<PrivateRoute><AppLayout><LoanDetails /></AppLayout></PrivateRoute>} />
            <Route path="/payments" element={<PrivateRoute><AppLayout><PaymentProcessing /></AppLayout></PrivateRoute>} />
            <Route path="/emi-calculator" element={<PrivateRoute><AppLayout><EMICalculator /></AppLayout></PrivateRoute>} />

            {/* Admin only */}
            <Route path="/kyc" element={<RoleRoute roles={['ADMIN']}><AppLayout><VerifyKYC /></AppLayout></RoleRoute>} />
            <Route path="/credit" element={<RoleRoute roles={['ADMIN']}><AppLayout><GenerateCreditScore /></AppLayout></RoleRoute>} />
            <Route path="/loans/approval" element={<RoleRoute roles={['ADMIN']}><AppLayout><LoanApproval /></AppLayout></RoleRoute>} />
            <Route path="/reports" element={<RoleRoute roles={['ADMIN']}><AppLayout><Reports /></AppLayout></RoleRoute>} />

            <Route path="*" element={<Navigate to="/" />} />
        </Routes>
    );
}

export default function App() {
    return (
        <BrowserRouter>
            <AuthProvider>
                <AppRoutes />
            </AuthProvider>
        </BrowserRouter>
    );
}
