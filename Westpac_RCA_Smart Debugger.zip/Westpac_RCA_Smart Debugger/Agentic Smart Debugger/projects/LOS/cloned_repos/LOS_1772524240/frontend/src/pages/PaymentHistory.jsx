import { useState, useEffect } from 'react';
import { paymentAPI } from '../services/api';

export default function PaymentHistory() {
    const [payments, setPayments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState('ALL');

    useEffect(() => {
        const fetchPayments = async () => {
            try {
                const res = await paymentAPI.getMy();
                setPayments(res.data);
            } catch { }
            setLoading(false);
        };
        fetchPayments();
    }, []);

    const filteredPayments = filter === 'ALL' ? payments : payments.filter(p => p.status === filter);
    const totalPaid = payments.filter(p => p.status === 'SUCCESS').reduce((sum, p) => sum + p.total_amount, 0);
    const totalLateFees = payments.reduce((sum, p) => sum + (p.late_fee || 0), 0);

    if (loading) return <div className="loading"><div className="spinner" /> Loading payment history...</div>;

    return (
        <>
            <div className="page-header">
                <h1>Payment History</h1>
                <p>View all your past EMI payments</p>
            </div>

            {/* Summary Stats */}
            <div className="stats-grid" style={{ marginBottom: '20px' }}>
                <div className="stat-card" style={{ borderLeft: '4px solid var(--success)' }}>
                    <div className="label">Total Payments</div>
                    <div className="value">{payments.length}</div>
                </div>
                <div className="stat-card" style={{ borderLeft: '4px solid var(--primary)' }}>
                    <div className="label">Total Paid</div>
                    <div className="value">₹{totalPaid.toLocaleString()}</div>
                </div>
                <div className="stat-card" style={{ borderLeft: '4px solid var(--warning)' }}>
                    <div className="label">Late Fees</div>
                    <div className="value">₹{totalLateFees.toLocaleString()}</div>
                </div>
            </div>

            {/* Filters */}
            <div style={{ display: 'flex', gap: '8px', marginBottom: '16px' }}>
                {['ALL', 'SUCCESS', 'FAILED'].map(f => (
                    <button key={f} className={`btn ${filter === f ? 'btn-primary' : 'btn-outline'}`}
                        style={{ padding: '6px 16px', fontSize: '13px' }}
                        onClick={() => setFilter(f)}>
                        {f === 'ALL' ? `All (${payments.length})` : `${f} (${payments.filter(p => p.status === f).length})`}
                    </button>
                ))}
            </div>

            {filteredPayments.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: '60px 20px' }}>
                    <div style={{ fontSize: '48px', marginBottom: '16px' }}>💳</div>
                    <h3>No Payments Found</h3>
                    <p style={{ color: 'var(--text-secondary)' }}>
                        {filter === 'ALL' ? "You haven't made any payments yet." : `No ${filter.toLowerCase()} payments.`}
                    </p>
                </div>
            ) : (
                <div className="card">
                    <div className="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Loan</th>
                                    <th>EMI #</th>
                                    <th>Amount</th>
                                    <th>Late Fee</th>
                                    <th>Total</th>
                                    <th>Method</th>
                                    <th>Status</th>
                                    <th>Ref</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredPayments.map(p => (
                                    <tr key={p.id}>
                                        <td>#{p.loan_id}</td>
                                        <td>{p.emi_number}</td>
                                        <td>₹{p.amount?.toLocaleString()}</td>
                                        <td>₹{p.late_fee || 0}</td>
                                        <td style={{ fontWeight: 600 }}>₹{p.total_amount?.toLocaleString()}</td>
                                        <td>{p.payment_method}</td>
                                        <td><span className={`badge badge-${p.status.toLowerCase()}`}>{p.status}</span></td>
                                        <td style={{ fontSize: '12px' }}>{p.transaction_ref}</td>
                                        <td style={{ fontSize: '13px' }}>{p.paid_at ? new Date(p.paid_at).toLocaleDateString() : '—'}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </>
    );
}
