import axios from 'axios';

const API_BASE = 'http://localhost:8000';

const api = axios.create({
    baseURL: API_BASE,
    headers: { 'Content-Type': 'application/json' },
});

// Attach JWT token to every request
api.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});

// Handle 401 errors globally
api.interceptors.response.use(
    (res) => res,
    (err) => {
        if (err.response?.status === 401) {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            window.location.href = '/login';
        }
        return Promise.reject(err);
    }
);

// Auth
export const authAPI = {
    register: (data) => api.post('/auth/register', data),
    login: (data) => api.post('/auth/login', data),
};

// Customers
export const customerAPI = {
    create: (data) => api.post('/customers', data),
    getAll: () => api.get('/customers'),
    getById: (id) => api.get(`/customers/${id}`),
    getMe: () => api.get('/customers/me'),
    updateMe: (data) => api.put('/customers/me', data),
};

// KYC
export const kycAPI = {
    submitFiles: (formData) => api.post('/kyc/submit', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
    }),
    getMe: () => api.get('/kyc/me'),
    getAll: () => api.get('/kyc/all'),
    approve: (customerId, data) => api.post(`/kyc/approve/${customerId}`, data),
    get: (customerId) => api.get(`/kyc/${customerId}`),
    downloadFile: (customerId, fileType) =>
        api.get(`/kyc/file/${customerId}/${fileType}`, { responseType: 'blob' }),
};

// Credit
export const creditAPI = {
    generate: (customerId) => api.post(`/credit/generate/${customerId}`),
    get: (customerId) => api.get(`/credit/${customerId}`),
};

// Loans
export const loanAPI = {
    apply: (data) => api.post('/loans/apply', data),
    getMy: () => api.get('/loans/my'),
    getPending: () => api.get('/loans/pending'),
    getAll: () => api.get('/loans/all'),
    approve: (loanId, data) => api.post(`/loans/approve/${loanId}`, data),
    getById: (id) => api.get(`/loans/${id}`),
    getByCustomer: (customerId) => api.get(`/loans/customer/${customerId}`),
};

// Payments
export const paymentAPI = {
    process: (loanId, data) => api.post(`/payments/process/${loanId}`, data),
    getByLoan: (loanId) => api.get(`/payments/${loanId}`),
    getMy: () => api.get('/payments/my'),
};

// Reports
export const reportAPI = {
    monthly: () => api.get('/reports/monthly'),
    portfolio: () => api.get('/reports/portfolio'),
};

export default api;
