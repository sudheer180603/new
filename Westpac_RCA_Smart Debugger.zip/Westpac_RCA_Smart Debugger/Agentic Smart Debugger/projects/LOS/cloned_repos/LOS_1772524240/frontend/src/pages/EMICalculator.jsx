import { useState } from 'react';

export default function EMICalculator() {
    const [form, setForm] = useState({ amount: '', rate: '10.5', tenure: '' });

    const calculate = () => {
        const P = parseFloat(form.amount);
        const R = parseFloat(form.rate) / 12 / 100;
        const N = parseInt(form.tenure);
        if (!P || !R || !N || N < 1) return null;
        const power = Math.pow(1 + R, N);
        const emi = (P * R * power) / (power - 1);
        const total = emi * N;
        const interest = total - P;
        return { emi, total, interest };
    };

    const result = calculate();
    const principalPercent = result ? (parseFloat(form.amount) / result.total * 100).toFixed(1) : 0;

    return (
        <>
            <div className="page-header">
                <h1>🧮 EMI Calculator</h1>
                <p>Plan your finances — calculate EMI before applying for a loan</p>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', alignItems: 'start' }}>
                <div className="card">
                    <h3 style={{ marginBottom: '20px' }}>Loan Parameters</h3>
                    <div className="form-group">
                        <label>Loan Amount (₹)</label>
                        <input type="number" value={form.amount}
                            onChange={(e) => setForm({ ...form, amount: e.target.value })}
                            placeholder="e.g. 500000" />
                        {form.amount && (
                            <input type="range" min="10000" max="5000000" step="10000" value={form.amount}
                                onChange={(e) => setForm({ ...form, amount: e.target.value })}
                                style={{ width: '100%', marginTop: '8px', accentColor: 'var(--primary)' }} />
                        )}
                    </div>
                    <div className="form-group">
                        <label>Interest Rate (% per annum)</label>
                        <input type="number" step="0.1" value={form.rate}
                            onChange={(e) => setForm({ ...form, rate: e.target.value })}
                            placeholder="e.g. 10.5" />
                        <input type="range" min="1" max="30" step="0.5" value={form.rate}
                            onChange={(e) => setForm({ ...form, rate: e.target.value })}
                            style={{ width: '100%', marginTop: '8px', accentColor: 'var(--primary)' }} />
                    </div>
                    <div className="form-group">
                        <label>Tenure (months)</label>
                        <input type="number" value={form.tenure}
                            onChange={(e) => setForm({ ...form, tenure: e.target.value })}
                            placeholder="6 to 60" />
                        {form.tenure && (
                            <input type="range" min="6" max="60" step="1" value={form.tenure}
                                onChange={(e) => setForm({ ...form, tenure: e.target.value })}
                                style={{ width: '100%', marginTop: '8px', accentColor: 'var(--primary)' }} />
                        )}
                    </div>
                </div>

                <div className="card" style={{ position: 'sticky', top: '28px' }}>
                    <h3 style={{ marginBottom: '20px' }}>EMI Breakdown</h3>
                    {result ? (
                        <>
                            <div style={{
                                textAlign: 'center', padding: '28px', marginBottom: '20px',
                                background: 'linear-gradient(135deg, var(--primary), var(--secondary))',
                                borderRadius: 'var(--radius)', color: '#fff',
                            }}>
                                <div style={{ fontSize: '13px', opacity: 0.85, textTransform: 'uppercase', letterSpacing: '1px' }}>Monthly EMI</div>
                                <div style={{ fontSize: '40px', fontWeight: 700, marginTop: '4px' }}>₹{result.emi.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</div>
                            </div>

                            {/* Visual Breakdown */}
                            <div style={{ marginBottom: '20px' }}>
                                <div style={{ display: 'flex', height: '10px', borderRadius: '5px', overflow: 'hidden', marginBottom: '8px' }}>
                                    <div style={{ width: `${principalPercent}%`, background: 'var(--primary)' }} />
                                    <div style={{ flex: 1, background: 'var(--warning)' }} />
                                </div>
                                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '12px' }}>
                                    <span style={{ color: 'var(--primary)', fontWeight: 600 }}>Principal ({principalPercent}%)</span>
                                    <span style={{ color: 'var(--warning)', fontWeight: 600 }}>Interest ({(100 - principalPercent).toFixed(1)}%)</span>
                                </div>
                            </div>

                            <div style={{ display: 'grid', gap: '14px' }}>
                                <div style={{
                                    display: 'flex', justifyContent: 'space-between', padding: '12px 16px',
                                    background: 'var(--bg)', borderRadius: 'var(--radius-sm)',
                                }}>
                                    <span style={{ color: 'var(--text-secondary)' }}>Principal Amount</span>
                                    <span style={{ fontWeight: 700 }}>₹{parseFloat(form.amount).toLocaleString()}</span>
                                </div>
                                <div style={{
                                    display: 'flex', justifyContent: 'space-between', padding: '12px 16px',
                                    background: 'var(--bg)', borderRadius: 'var(--radius-sm)',
                                }}>
                                    <span style={{ color: 'var(--text-secondary)' }}>Total Interest</span>
                                    <span style={{ fontWeight: 700, color: 'var(--warning)' }}>₹{result.interest.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</span>
                                </div>
                                <div style={{
                                    display: 'flex', justifyContent: 'space-between', padding: '12px 16px',
                                    background: 'var(--primary-light)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--primary)',
                                }}>
                                    <span style={{ color: 'var(--primary)', fontWeight: 600 }}>Total Payable</span>
                                    <span style={{ fontWeight: 700, color: 'var(--primary)' }}>₹{result.total.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ",")}</span>
                                </div>
                            </div>
                        </>
                    ) : (
                        <div style={{ textAlign: 'center', padding: '40px 20px', color: 'var(--text-secondary)' }}>
                            <div style={{ fontSize: '48px', marginBottom: '12px' }}>📊</div>
                            <p>Enter loan details to see EMI breakdown</p>
                        </div>
                    )}
                </div>
            </div>
        </>
    );
}
