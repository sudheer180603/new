import { useState, useEffect } from 'react';
import { loanAPI, customerAPI } from '../services/api';

export default function LoanApproval() {
    const [loans, setLoans] = useState([]);
    const [loading, setLoading] = useState(true);
    const [actionLoading, setActionLoading] = useState(null);
    const [remarks, setRemarks] = useState({});
    const [customers, setCustomers] = useState({});

    useEffect(() => {
        fetchPending();
    }, []);

    const fetchPending = async () => {
        setLoading(true);
        try {
            const res = await loanAPI.getPending();
            setLoans(res.data);
            // Fetch customer names for each unique customer_id
            const customerIds = [...new Set(res.data.map(l => l.customer_id))];
            const custMap = {};
            for (const id of customerIds) {
                try {
                    const custRes = await customerAPI.getById(id);
                    custMap[id] = custRes.data;
                } catch { }
            }
            setCustomers(custMap);
        } catch { }
        setLoading(false);
    };

    const handleAction = async (loanId, approved) => {
        setActionLoading(loanId);
        try {
            await loanAPI.approve(loanId, {
                approved,
                remarks: remarks[loanId] || null,
            });
            // Remove from list
            setLoans(prev => prev.filter(l => l.id !== loanId));
        } catch { }
        setActionLoading(null);
    };

    if (loading) return <div className="loading"><div className="spinner" /> Loading pending loans...</div>;

    return (
        <>
            <div className="page-header">
                <h1>Loan Approvals</h1>
                <p>Review and approve or reject pending loan applications</p>
            </div>

            {loans.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: '60px 20px' }}>
                    <div style={{ fontSize: '48px', marginBottom: '16px' }}>✅</div>
                    <h3>All Caught Up!</h3>
                    <p style={{ color: 'var(--text-secondary)' }}>No pending loan applications to review.</p>
                </div>
            ) : (
                <div style={{ display: 'grid', gap: '16px' }}>
                    {loans.map(loan => {
                        const cust = customers[loan.customer_id];
                        return (
                            <div key={loan.id} className="card" style={{ borderLeft: '4px solid var(--warning)' }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                                    <div>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
                                            <h3 style={{ fontSize: '18px' }}>Loan #{loan.id}</h3>
                                            <span className="badge badge-pending">PENDING</span>
                                        </div>
                                        <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                                            Customer: <strong>{cust ? `${cust.first_name} ${cust.last_name}` : `#${loan.customer_id}`}</strong>
                                            {cust && ` • Income: ₹${cust.monthly_income?.toLocaleString()}/mo`}
                                        </div>
                                    </div>
                                    <div style={{ textAlign: 'right' }}>
                                        <div style={{ fontSize: '22px', fontWeight: 700 }}>₹{loan.loan_amount?.toLocaleString()}</div>
                                        <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>
                                            {new Date(loan.created_at).toLocaleDateString()}
                                        </div>
                                    </div>
                                </div>

                                {/* Loan Details */}
                                <div style={{
                                    display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))',
                                    gap: '12px', padding: '14px', background: 'var(--bg)', borderRadius: 'var(--radius-sm)', marginBottom: '16px',
                                }}>
                                    <div>
                                        <div style={{ fontSize: '11px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '.5px', fontWeight: 600 }}>EMI</div>
                                        <div style={{ fontWeight: 600, marginTop: '2px' }}>₹{loan.emi_amount?.toLocaleString()}/mo</div>
                                    </div>
                                    <div>
                                        <div style={{ fontSize: '11px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '.5px', fontWeight: 600 }}>Rate</div>
                                        <div style={{ fontWeight: 600, marginTop: '2px' }}>{loan.interest_rate}% p.a.</div>
                                    </div>
                                    <div>
                                        <div style={{ fontSize: '11px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '.5px', fontWeight: 600 }}>Tenure</div>
                                        <div style={{ fontWeight: 600, marginTop: '2px' }}>{loan.tenure_months} months</div>
                                    </div>
                                    <div>
                                        <div style={{ fontSize: '11px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '.5px', fontWeight: 600 }}>Purpose</div>
                                        <div style={{ fontWeight: 600, marginTop: '2px' }}>{loan.purpose || '—'}</div>
                                    </div>
                                    <div>
                                        <div style={{ fontSize: '11px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '.5px', fontWeight: 600 }}>Total Payable</div>
                                        <div style={{ fontWeight: 600, marginTop: '2px' }}>₹{loan.total_payable?.toLocaleString()}</div>
                                    </div>
                                    <div>
                                        <div style={{ fontSize: '11px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '.5px', fontWeight: 600 }}>Total Interest</div>
                                        <div style={{ fontWeight: 600, marginTop: '2px' }}>₹{loan.total_interest?.toLocaleString()}</div>
                                    </div>
                                </div>

                                {/* Action */}
                                <div style={{ display: 'flex', gap: '12px', alignItems: 'end' }}>
                                    <div className="form-group" style={{ flex: 1, marginBottom: 0 }}>
                                        <label>Remarks (optional)</label>
                                        <input value={remarks[loan.id] || ''}
                                            onChange={(e) => setRemarks(prev => ({ ...prev, [loan.id]: e.target.value }))}
                                            placeholder="Add a note..." />
                                    </div>
                                    <button className="btn btn-success" disabled={actionLoading === loan.id}
                                        onClick={() => handleAction(loan.id, true)}>
                                        {actionLoading === loan.id ? '...' : '✅ Approve'}
                                    </button>
                                    <button className="btn btn-danger" disabled={actionLoading === loan.id}
                                        onClick={() => handleAction(loan.id, false)}>
                                        {actionLoading === loan.id ? '...' : '❌ Reject'}
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </>
    );
}
