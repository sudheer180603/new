import { useState, useEffect } from 'react';
import { reportAPI } from '../services/api';

export default function Reports() {
    const [monthly, setMonthly] = useState(null);
    const [portfolio, setPortfolio] = useState(null);
    const [loading, setLoading] = useState(true);
    const [activeTab, setActiveTab] = useState('monthly');

    useEffect(() => {
        const fetchReports = async () => {
            try {
                const [mRes, pRes] = await Promise.all([
                    reportAPI.monthly(),
                    reportAPI.portfolio(),
                ]);
                setMonthly(mRes.data);
                setPortfolio(pRes.data);
            } catch (err) {
                console.error('Reports load error:', err);
            } finally {
                setLoading(false);
            }
        };
        fetchReports();
    }, []);

    if (loading) return <div className="loading"><div className="spinner" /> Loading reports...</div>;

    return (
        <>
            <div className="page-header">
                <h1>Reports</h1>
                <p>Regulatory and portfolio reports</p>
            </div>

            <div style={{ display: 'flex', gap: '8px', marginBottom: '20px' }}>
                <button className={`btn ${activeTab === 'monthly' ? 'btn-primary' : 'btn-outline'}`}
                    onClick={() => setActiveTab('monthly')}>Monthly Report</button>
                <button className={`btn ${activeTab === 'portfolio' ? 'btn-primary' : 'btn-outline'}`}
                    onClick={() => setActiveTab('portfolio')}>Portfolio Report</button>
            </div>

            {activeTab === 'monthly' && monthly && (
                <div className="card">
                    <div className="card-header">
                        <h3>Monthly Report — {monthly.report_period}</h3>
                        <span style={{ fontSize: '12px', color: 'var(--text-light)' }}>
                            Generated: {new Date(monthly.generated_at).toLocaleString()}
                        </span>
                    </div>
                    <div className="stats-grid">
                        <div className="stat-card">
                            <div className="label">Total Loans Issued</div>
                            <div className="value">{monthly.total_loans_issued}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Amount Disbursed</div>
                            <div className="value">₹{monthly.total_amount_disbursed?.toLocaleString()}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Collections</div>
                            <div className="value">₹{monthly.total_collections?.toLocaleString()}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Active Loans</div>
                            <div className="value">{monthly.active_loans}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Closed Loans</div>
                            <div className="value">{monthly.closed_loans}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Rejected</div>
                            <div className="value">{monthly.rejected_loans}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Defaults</div>
                            <div className="value">{monthly.default_loans}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Avg Loan Amount</div>
                            <div className="value">₹{monthly.average_loan_amount?.toLocaleString()}</div>
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'portfolio' && portfolio && (
                <div className="card">
                    <div className="card-header">
                        <h3>Portfolio Overview</h3>
                        <span style={{ fontSize: '12px', color: 'var(--text-light)' }}>
                            Generated: {new Date(portfolio.generated_at).toLocaleString()}
                        </span>
                    </div>
                    <div className="stats-grid">
                        <div className="stat-card">
                            <div className="label">Total Customers</div>
                            <div className="value">{portfolio.total_customers}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Total Loans</div>
                            <div className="value">{portfolio.total_loans}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Total Disbursed</div>
                            <div className="value">₹{portfolio.total_disbursed?.toLocaleString()}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Outstanding</div>
                            <div className="value">₹{portfolio.total_outstanding?.toLocaleString()}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Collections</div>
                            <div className="value">₹{portfolio.total_collections?.toLocaleString()}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Active Loans</div>
                            <div className="value">{portfolio.active_loans}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Closed Loans</div>
                            <div className="value">{portfolio.closed_loans}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">NPA Count</div>
                            <div className="value">{portfolio.npa_count}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">NPA Amount</div>
                            <div className="value">₹{portfolio.npa_amount?.toLocaleString()}</div>
                        </div>
                        <div className="stat-card">
                            <div className="label">Avg Credit Score</div>
                            <div className="value">{portfolio.average_credit_score}</div>
                        </div>
                    </div>

                    {portfolio.loan_by_status && Object.keys(portfolio.loan_by_status).length > 0 && (
                        <div style={{ marginTop: '20px' }}>
                            <h4 style={{ marginBottom: '12px', fontSize: '13px', textTransform: 'uppercase', letterSpacing: '.5px', color: 'var(--text-secondary)' }}>
                                Loan Status Breakdown
                            </h4>
                            <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                                {Object.entries(portfolio.loan_by_status).map(([status, count]) => (
                                    <div key={status} style={{
                                        padding: '12px 20px', borderRadius: '8px', background: '#f8fafc',
                                        border: '1px solid var(--border)', textAlign: 'center',
                                    }}>
                                        <div style={{ fontSize: '24px', fontWeight: '700' }}>{count}</div>
                                        <div><span className={`badge badge-${status.toLowerCase()}`}>{status}</span></div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            )}
        </>
    );
}
