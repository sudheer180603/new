import { useState } from 'react';
import { loanAPI } from '../services/api';

export default function ApplyLoan() {
    const [form, setForm] = useState({
        loan_amount: '', tenure_months: '', interest_rate: '10.5', purpose: '',
    });
    const [result, setResult] = useState(null);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    // Live EMI calculation
    const calculateEMI = () => {
        const P = parseFloat(form.loan_amount);
        const R = parseFloat(form.interest_rate) / 12 / 100;
        const N = parseInt(form.tenure_months);
        if (!P || !R || !N || N < 6) return null;
        const power = Math.pow(1 + R, N);
        const emi = (P * R * power) / (power - 1);
        return { emi: emi.toFixed(2), total: (emi * N).toFixed(2), interest: (emi * N - P).toFixed(2) };
    };

    const emiPreview = calculateEMI();

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setResult(null);
        setLoading(true);
        try {
            const payload = {
                loan_amount: parseFloat(form.loan_amount),
                tenure_months: parseInt(form.tenure_months),
                interest_rate: parseFloat(form.interest_rate),
                purpose: form.purpose || null,
            };
            const res = await loanAPI.apply(payload);
            setResult(res.data);
        } catch (err) {
            setError(err.response?.data?.detail || 'Loan application failed. Please ensure your KYC is approved and credit score is generated.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <div className="page-header">
                <h1>Apply for a Loan</h1>
                <p>Fill in the details below to submit your loan application</p>
            </div>

            {error && <div className="alert alert-error">{error}</div>}

            {result ? (
                <div className="card">
                    <div style={{ textAlign: 'center', padding: '20px 0' }}>
                        {result.status === 'PENDING' ? (
                            <>
                                <div style={{ fontSize: '64px', marginBottom: '12px' }}>🎉</div>
                                <h2 style={{ marginBottom: '8px', color: 'var(--success)' }}>Application Submitted!</h2>
                                <p style={{ color: 'var(--text-secondary)', marginBottom: '24px' }}>
                                    Your loan application is being reviewed by our team.
                                </p>
                            </>
                        ) : (
                            <>
                                <div style={{ fontSize: '64px', marginBottom: '12px' }}>❌</div>
                                <h2 style={{ marginBottom: '8px', color: 'var(--danger)' }}>Application Rejected</h2>
                                <p style={{ color: 'var(--text-secondary)', marginBottom: '24px' }}>
                                    {result.rejection_reason}
                                </p>
                            </>
                        )}
                    </div>

                    <div className="detail-grid" style={{ background: 'var(--bg)', padding: '20px', borderRadius: 'var(--radius-sm)' }}>
                        <div className="detail-item"><div className="label">Loan ID</div><div className="value">#{result.id}</div></div>
                        <div className="detail-item"><div className="label">Amount</div><div className="value">₹{result.loan_amount?.toLocaleString()}</div></div>
                        <div className="detail-item"><div className="label">EMI</div><div className="value">₹{result.emi_amount?.toLocaleString()}/mo</div></div>
                        <div className="detail-item"><div className="label">Status</div><div className="value"><span className={`badge badge-${result.status.toLowerCase()}`}>{result.status}</span></div></div>
                    </div>

                    <button className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', marginTop: '20px' }}
                        onClick={() => { setResult(null); setForm({ loan_amount: '', tenure_months: '', interest_rate: '10.5', purpose: '' }); }}>
                        📝 Apply for Another Loan
                    </button>
                </div>
            ) : (
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: '20px', alignItems: 'start' }}>
                    <div className="card">
                        <h3 style={{ marginBottom: '16px' }}>Loan Details</h3>
                        <form onSubmit={handleSubmit}>
                            <div className="form-grid">
                                <div className="form-group">
                                    <label>Loan Amount (₹)</label>
                                    <input type="number" value={form.loan_amount}
                                        onChange={(e) => setForm({ ...form, loan_amount: e.target.value })}
                                        placeholder="e.g. 500000" min="10000" required />
                                </div>
                                <div className="form-group">
                                    <label>Tenure (months)</label>
                                    <input type="number" value={form.tenure_months}
                                        onChange={(e) => setForm({ ...form, tenure_months: e.target.value })}
                                        placeholder="6 to 60" min="6" max="60" required />
                                </div>
                                <div className="form-group">
                                    <label>Interest Rate (% p.a.)</label>
                                    <input type="number" step="0.1" value={form.interest_rate}
                                        onChange={(e) => setForm({ ...form, interest_rate: e.target.value })}
                                        min="1" max="30" required />
                                </div>
                                <div className="form-group">
                                    <label>Purpose</label>
                                    <select value={form.purpose} onChange={(e) => setForm({ ...form, purpose: e.target.value })}>
                                        <option value="">Select purpose</option>
                                        <option value="Home">Home</option>
                                        <option value="Education">Education</option>
                                        <option value="Vehicle">Vehicle</option>
                                        <option value="Personal">Personal</option>
                                        <option value="Business">Business</option>
                                        <option value="Medical">Medical</option>
                                        <option value="Other">Other</option>
                                    </select>
                                </div>
                            </div>
                            <button type="submit" className="btn btn-primary" disabled={loading}
                                style={{ width: '100%', justifyContent: 'center', padding: '14px', fontSize: '15px' }}>
                                {loading ? '⏳ Submitting...' : '📝 Submit Application'}
                            </button>
                        </form>
                    </div>

                    {/* EMI Preview */}
                    <div className="card" style={{ position: 'sticky', top: '28px' }}>
                        <h3 style={{ marginBottom: '16px' }}>💡 EMI Preview</h3>
                        {emiPreview ? (
                            <>
                                <div style={{ textAlign: 'center', padding: '20px 0', borderBottom: '1px solid var(--border)', marginBottom: '16px' }}>
                                    <div style={{ fontSize: '12px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '.5px', fontWeight: 600 }}>Monthly EMI</div>
                                    <div style={{ fontSize: '32px', fontWeight: 700, color: 'var(--primary)', marginTop: '4px' }}>₹{parseFloat(emiPreview.emi).toLocaleString()}</div>
                                </div>
                                <div style={{ display: 'grid', gap: '12px' }}>
                                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                        <span style={{ color: 'var(--text-secondary)', fontSize: '14px' }}>Total Payable</span>
                                        <span style={{ fontWeight: 600 }}>₹{parseFloat(emiPreview.total).toLocaleString()}</span>
                                    </div>
                                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                        <span style={{ color: 'var(--text-secondary)', fontSize: '14px' }}>Total Interest</span>
                                        <span style={{ fontWeight: 600, color: 'var(--warning)' }}>₹{parseFloat(emiPreview.interest).toLocaleString()}</span>
                                    </div>
                                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                        <span style={{ color: 'var(--text-secondary)', fontSize: '14px' }}>Principal</span>
                                        <span style={{ fontWeight: 600 }}>₹{parseFloat(form.loan_amount).toLocaleString()}</span>
                                    </div>
                                </div>
                            </>
                        ) : (
                            <p style={{ color: 'var(--text-secondary)', fontSize: '14px', textAlign: 'center', padding: '20px 0' }}>
                                Enter loan amount and tenure to see EMI preview
                            </p>
                        )}
                    </div>
                </div>
            )}
        </>
    );
}
