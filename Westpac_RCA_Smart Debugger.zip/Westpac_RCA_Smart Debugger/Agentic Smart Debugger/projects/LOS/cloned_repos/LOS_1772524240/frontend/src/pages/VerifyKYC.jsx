import { useState, useEffect } from 'react';
import { kycAPI, customerAPI } from '../services/api';

export default function VerifyKYC() {
    const [kycRecords, setKycRecords] = useState([]);
    const [customers, setCustomers] = useState({});
    const [loading, setLoading] = useState(true);
    const [actionLoading, setActionLoading] = useState(null);
    const [remarks, setRemarks] = useState({});

    useEffect(() => {
        fetchData();
    }, []);

    const fetchData = async () => {
        setLoading(true);
        try {
            const res = await kycAPI.getAll();
            setKycRecords(res.data);

            // Fetch customer details for each record
            const custIds = [...new Set(res.data.map(k => k.customer_id))];
            const custMap = {};
            for (const id of custIds) {
                try {
                    const cRes = await customerAPI.getById(id);
                    custMap[id] = cRes.data;
                } catch { }
            }
            setCustomers(custMap);
        } catch { }
        setLoading(false);
    };

    const handleAction = async (customerId, approved) => {
        setActionLoading(customerId);
        try {
            await kycAPI.approve(customerId, {
                approved,
                remarks: remarks[customerId] || null,
            });
            // Refresh list
            fetchData();
        } catch { }
        setActionLoading(null);
    };

    const downloadFile = async (customerId, type) => {
        try {
            const response = await kycAPI.downloadFile(customerId, type);
            // Create blob link to download
            const url = window.URL.createObjectURL(new Blob([response.data]));
            const link = document.createElement('a');
            link.href = url;
            link.setAttribute('download', `${type}_${customerId}.pdf`);
            document.body.appendChild(link);
            link.click();
            link.remove();
        } catch (error) {
            alert('Failed to download file');
        }
    };

    if (loading) return <div className="loading"><div className="spinner" /> Loading KYC records...</div>;

    return (
        <>
            <div className="page-header">
                <h1>KYC Verification</h1>
                <p>Review and verify customer documents</p>
            </div>

            {kycRecords.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: '60px 20px' }}>
                    <div style={{ fontSize: '48px', marginBottom: '16px' }}>✅</div>
                    <h3>All Caught Up!</h3>
                    <p style={{ color: 'var(--text-secondary)' }}>No pending KYC verifications.</p>
                </div>
            ) : (
                <div style={{ display: 'grid', gap: '16px' }}>
                    {kycRecords.map(record => {
                        const cust = customers[record.customer_id];
                        return (
                            <div key={record.id} className="card" style={{
                                borderLeft: `4px solid ${record.status === 'PENDING' ? 'var(--warning)' :
                                    record.status === 'APPROVED' ? 'var(--success)' : 'var(--danger)'}`
                            }}>
                                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '16px' }}>
                                    <div>
                                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '4px' }}>
                                            <h3 style={{ fontSize: '18px' }}>
                                                {cust ? `${cust.first_name} ${cust.last_name}` : `Customer #${record.customer_id}`}
                                            </h3>
                                            <span className={`badge badge-${record.status.toLowerCase()}`}>{record.status}</span>
                                        </div>
                                        <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                                            Submitted: {new Date(record.created_at).toLocaleDateString()}
                                            {record.verified_at && ` • Verified: ${new Date(record.verified_at).toLocaleDateString()}`}
                                        </div>
                                    </div>

                                    {/* Download Actions */}
                                    <div style={{ display: 'flex', gap: '8px' }}>
                                        <button className="btn btn-outline" onClick={() => downloadFile(record.customer_id, 'pan')}>
                                            📄 PAN
                                        </button>
                                        <button className="btn btn-outline" onClick={() => downloadFile(record.customer_id, 'aadhaar')}>
                                            📄 Aadhaar
                                        </button>
                                    </div>
                                </div>

                                {/* Current Remarks if any */}
                                {record.remarks && (
                                    <div className="alert alert-info" style={{ marginBottom: '16px', padding: '10px' }}>
                                        <strong>Note:</strong> {record.remarks}
                                    </div>
                                )}

                                {/* Admin Actions - Only for PENDING */}
                                {record.status === 'PENDING' && (
                                    <div style={{ display: 'flex', gap: '12px', alignItems: 'end', marginTop: '12px', borderTop: '1px solid var(--border)', paddingTop: '16px' }}>
                                        <div className="form-group" style={{ flex: 1, marginBottom: 0 }}>
                                            <input
                                                value={remarks[record.customer_id] || ''}
                                                onChange={(e) => setRemarks(prev => ({ ...prev, [record.customer_id]: e.target.value }))}
                                                placeholder="Add verification remarks..."
                                            />
                                        </div>
                                        <button className="btn btn-success" disabled={actionLoading === record.customer_id}
                                            onClick={() => handleAction(record.customer_id, true)}>
                                            {actionLoading === record.customer_id ? '...' : '✅ Approve'}
                                        </button>
                                        <button className="btn btn-danger" disabled={actionLoading === record.customer_id}
                                            onClick={() => handleAction(record.customer_id, false)}>
                                            {actionLoading === record.customer_id ? '...' : '❌ Reject'}
                                        </button>
                                    </div>
                                )}
                            </div>
                        );
                    })}
                </div>
            )}
        </>
    );
}
