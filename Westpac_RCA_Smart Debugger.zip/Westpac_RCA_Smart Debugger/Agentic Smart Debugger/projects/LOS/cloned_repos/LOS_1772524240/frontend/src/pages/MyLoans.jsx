import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { loanAPI } from '../services/api';

export default function MyLoans() {
    const [loans, setLoans] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [expandedLoan, setExpandedLoan] = useState(null);
    const [emiSchedule, setEmiSchedule] = useState({});
    const [filter, setFilter] = useState('ALL');

    useEffect(() => {
        const fetchLoans = async () => {
            try {
                const res = await loanAPI.getMy();
                setLoans(res.data);
            } catch (err) {
                setError(err.response?.data?.detail || 'Failed to load loans');
            } finally {
                setLoading(false);
            }
        };
        fetchLoans();
    }, []);

    const toggleExpand = async (loanId) => {
        if (expandedLoan === loanId) {
            setExpandedLoan(null);
            return;
        }
        setExpandedLoan(loanId);
        if (!emiSchedule[loanId]) {
            try {
                const res = await loanAPI.getById(loanId);
                setEmiSchedule(prev => ({ ...prev, [loanId]: res.data.emi_schedule }));
            } catch { }
        }
    };

    const filteredLoans = filter === 'ALL' ? loans : loans.filter(l => l.status === filter);

    const getStatusColor = (status) => {
        const colors = {
            PENDING: 'var(--warning)', APPROVED: 'var(--success)', DISBURSED: 'var(--success)',
            REJECTED: 'var(--danger)', CLOSED: 'var(--info)', DEFAULT: 'var(--danger)',
        };
        return colors[status] || 'var(--text-secondary)';
    };

    if (loading) return <div className="loading"><div className="spinner" /> Loading loans...</div>;

    return (
        <>
            <div className="page-header">
                <h1>My Loans</h1>
                <p>View and manage all your loan applications</p>
            </div>

            {error && <div className="alert alert-error">{error}</div>}

            {/* Filters */}
            <div style={{ display: 'flex', gap: '8px', marginBottom: '20px', flexWrap: 'wrap' }}>
                {['ALL', 'PENDING', 'DISBURSED', 'CLOSED', 'REJECTED'].map(f => (
                    <button key={f} className={`btn ${filter === f ? 'btn-primary' : 'btn-outline'}`}
                        style={{ padding: '6px 16px', fontSize: '13px' }}
                        onClick={() => setFilter(f)}>
                        {f === 'ALL' ? `All (${loans.length})` : `${f} (${loans.filter(l => l.status === f).length})`}
                    </button>
                ))}
            </div>

            {filteredLoans.length === 0 ? (
                <div className="card" style={{ textAlign: 'center', padding: '60px 20px' }}>
                    <div style={{ fontSize: '48px', marginBottom: '16px' }}>💰</div>
                    <h3 style={{ marginBottom: '8px' }}>No Loans Found</h3>
                    <p style={{ color: 'var(--text-secondary)', marginBottom: '20px' }}>
                        {filter === 'ALL' ? "You haven't applied for any loans yet." : `No ${filter.toLowerCase()} loans.`}
                    </p>
                    <Link to="/loans/apply" className="btn btn-primary">📝 Apply for a Loan</Link>
                </div>
            ) : (
                <div style={{ display: 'grid', gap: '16px' }}>
                    {filteredLoans.map(loan => (
                        <div key={loan.id} className="card" style={{
                            borderLeft: `4px solid ${getStatusColor(loan.status)}`,
                            cursor: 'pointer', transition: 'var(--transition)',
                        }}>
                            {/* Card Header */}
                            <div onClick={() => toggleExpand(loan.id)} style={{
                                display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start',
                            }}>
                                <div>
                                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
                                        <h3 style={{ fontSize: '18px' }}>₹{loan.loan_amount.toLocaleString()}</h3>
                                        <span className={`badge badge-${loan.status.toLowerCase()}`}>{loan.status}</span>
                                    </div>
                                    <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                                        {loan.purpose || 'General Purpose'} • Applied on {new Date(loan.created_at).toLocaleDateString()}
                                    </div>
                                </div>
                                <div style={{ textAlign: 'right' }}>
                                    <div style={{ fontSize: '20px', fontWeight: 700 }}>₹{loan.emi_amount.toLocaleString()}</div>
                                    <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>per month</div>
                                </div>
                            </div>

                            {/* Card Stats Row */}
                            <div style={{
                                display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))',
                                gap: '12px', marginTop: '16px', padding: '14px',
                                background: 'var(--bg)', borderRadius: 'var(--radius-sm)',
                            }}>
                                <div>
                                    <div style={{ fontSize: '11px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '.5px', fontWeight: 600 }}>Interest Rate</div>
                                    <div style={{ fontWeight: 600, marginTop: '2px' }}>{loan.interest_rate}% p.a.</div>
                                </div>
                                <div>
                                    <div style={{ fontSize: '11px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '.5px', fontWeight: 600 }}>Tenure</div>
                                    <div style={{ fontWeight: 600, marginTop: '2px' }}>{loan.tenure_months} months</div>
                                </div>
                                <div>
                                    <div style={{ fontSize: '11px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '.5px', fontWeight: 600 }}>Total Payable</div>
                                    <div style={{ fontWeight: 600, marginTop: '2px' }}>₹{loan.total_payable.toLocaleString()}</div>
                                </div>
                                <div>
                                    <div style={{ fontSize: '11px', color: 'var(--text-secondary)', textTransform: 'uppercase', letterSpacing: '.5px', fontWeight: 600 }}>Total Interest</div>
                                    <div style={{ fontWeight: 600, marginTop: '2px' }}>₹{loan.total_interest.toLocaleString()}</div>
                                </div>
                            </div>

                            {/* Rejection reason */}
                            {loan.rejection_reason && (
                                <div className="alert alert-error" style={{ marginTop: '12px', marginBottom: 0 }}>
                                    <strong>Reason:</strong> {loan.rejection_reason}
                                </div>
                            )}

                            {/* Expanded EMI Schedule */}
                            {expandedLoan === loan.id && emiSchedule[loan.id] && (
                                <div style={{ marginTop: '16px' }}>
                                    <h4 style={{ marginBottom: '12px', fontSize: '14px' }}>📅 EMI Schedule ({emiSchedule[loan.id].length} installments)</h4>
                                    <div className="table-container">
                                        <table>
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Due Date</th>
                                                    <th>EMI</th>
                                                    <th>Principal</th>
                                                    <th>Interest</th>
                                                    <th>Balance</th>
                                                    <th>Status</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {emiSchedule[loan.id].map(emi => (
                                                    <tr key={emi.id}>
                                                        <td>{emi.emi_number}</td>
                                                        <td>{emi.due_date}</td>
                                                        <td>₹{emi.emi_amount?.toLocaleString()}</td>
                                                        <td>₹{emi.principal_component?.toLocaleString()}</td>
                                                        <td>₹{emi.interest_component?.toLocaleString()}</td>
                                                        <td>₹{emi.outstanding_balance?.toLocaleString()}</td>
                                                        <td><span className={`badge badge-${emi.status.toLowerCase()}`}>{emi.status}</span></td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            )}

                            {/* Expand indicator */}
                            <div onClick={() => toggleExpand(loan.id)} style={{
                                textAlign: 'center', marginTop: '12px', fontSize: '13px',
                                color: 'var(--primary)', fontWeight: 600, cursor: 'pointer',
                            }}>
                                {expandedLoan === loan.id ? '▲ Hide Details' : '▼ View EMI Schedule'}
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </>
    );
}
