import { useState, useEffect } from 'react';
import { customerAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function Profile() {
    const { user } = useAuth();
    const [customer, setCustomer] = useState(null);
    const [editing, setEditing] = useState(false);
    const [form, setForm] = useState({});
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [isNewProfile, setIsNewProfile] = useState(false);
    const [newForm, setNewForm] = useState({
        first_name: '', last_name: '', email: user?.username ? '' : '',
        phone: '', date_of_birth: '', address: '', city: '', state: '',
        pincode: '', monthly_income: '', employment_type: 'SALARIED', company_name: '',
    });

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const res = await customerAPI.getMe();
                setCustomer(res.data);
                setForm(res.data);
            } catch {
                setIsNewProfile(true);
            }
            setLoading(false);
        };
        fetchProfile();
    }, []);

    const handleUpdate = async (e) => {
        e.preventDefault();
        setSaving(true);
        setError('');
        setSuccess('');
        try {
            const res = await customerAPI.updateMe({
                first_name: form.first_name,
                last_name: form.last_name,
                phone: form.phone,
                address: form.address,
                city: form.city,
                state: form.state,
                pincode: form.pincode,
                monthly_income: parseFloat(form.monthly_income),
                employment_type: form.employment_type,
                company_name: form.company_name || null,
            });
            setCustomer(res.data);
            setForm(res.data);
            setEditing(false);
            setSuccess('Profile updated successfully!');
        } catch (err) {
            setError(err.response?.data?.detail || 'Failed to update profile');
        } finally {
            setSaving(false);
        }
    };

    const handleCreate = async (e) => {
        e.preventDefault();
        setSaving(true);
        setError('');
        try {
            const payload = {
                ...newForm,
                email: newForm.email || user?.username + '@example.com',
                monthly_income: parseFloat(newForm.monthly_income),
                user_id: user?.id,
            };
            const res = await customerAPI.create(payload);
            setCustomer(res.data);
            setForm(res.data);
            setIsNewProfile(false);
            setSuccess('Profile created successfully!');
        } catch (err) {
            setError(err.response?.data?.detail || 'Failed to create profile');
        } finally {
            setSaving(false);
        }
    };

    if (loading) return <div className="loading"><div className="spinner" /> Loading profile...</div>;

    if (isNewProfile) {
        return (
            <>
                <div className="page-header">
                    <h1>Complete Your Profile</h1>
                    <p>Please fill in your details to get started</p>
                </div>

                {error && <div className="alert alert-error">{error}</div>}

                <div className="card">
                    <form onSubmit={handleCreate}>
                        <div className="form-grid">
                            <div className="form-group">
                                <label>First Name</label>
                                <input value={newForm.first_name} onChange={(e) => setNewForm({ ...newForm, first_name: e.target.value })} required />
                            </div>
                            <div className="form-group">
                                <label>Last Name</label>
                                <input value={newForm.last_name} onChange={(e) => setNewForm({ ...newForm, last_name: e.target.value })} required />
                            </div>
                            <div className="form-group">
                                <label>Email</label>
                                <input type="email" value={newForm.email} onChange={(e) => setNewForm({ ...newForm, email: e.target.value })} required />
                            </div>
                            <div className="form-group">
                                <label>Phone</label>
                                <input value={newForm.phone} onChange={(e) => setNewForm({ ...newForm, phone: e.target.value })} placeholder="e.g. 9876543210" required />
                            </div>
                            <div className="form-group">
                                <label>Date of Birth</label>
                                <input type="date" value={newForm.date_of_birth} onChange={(e) => setNewForm({ ...newForm, date_of_birth: e.target.value })} required />
                            </div>
                            <div className="form-group">
                                <label>Monthly Income (₹)</label>
                                <input type="number" value={newForm.monthly_income} onChange={(e) => setNewForm({ ...newForm, monthly_income: e.target.value })} placeholder="e.g. 50000" required />
                            </div>
                            <div className="form-group full-width">
                                <label>Address</label>
                                <input value={newForm.address} onChange={(e) => setNewForm({ ...newForm, address: e.target.value })} required />
                            </div>
                            <div className="form-group">
                                <label>City</label>
                                <input value={newForm.city} onChange={(e) => setNewForm({ ...newForm, city: e.target.value })} required />
                            </div>
                            <div className="form-group">
                                <label>State</label>
                                <input value={newForm.state} onChange={(e) => setNewForm({ ...newForm, state: e.target.value })} required />
                            </div>
                            <div className="form-group">
                                <label>Pincode</label>
                                <input value={newForm.pincode} onChange={(e) => setNewForm({ ...newForm, pincode: e.target.value })} maxLength={6} required />
                            </div>
                            <div className="form-group">
                                <label>Employment Type</label>
                                <select value={newForm.employment_type} onChange={(e) => setNewForm({ ...newForm, employment_type: e.target.value })}>
                                    <option value="SALARIED">Salaried</option>
                                    <option value="SELF_EMPLOYED">Self Employed</option>
                                    <option value="BUSINESS">Business</option>
                                </select>
                            </div>
                            <div className="form-group full-width">
                                <label>Company Name (optional)</label>
                                <input value={newForm.company_name} onChange={(e) => setNewForm({ ...newForm, company_name: e.target.value })} />
                            </div>
                        </div>
                        <button type="submit" className="btn btn-primary" disabled={saving}
                            style={{ width: '100%', justifyContent: 'center', padding: '14px', fontSize: '15px' }}>
                            {saving ? '⏳ Saving...' : '✅ Create Profile'}
                        </button>
                    </form>
                </div>
            </>
        );
    }

    return (
        <>
            <div className="page-header">
                <h1>My Profile</h1>
                <p>View and manage your personal information</p>
            </div>

            {error && <div className="alert alert-error">{error}</div>}
            {success && <div className="alert alert-success">{success}</div>}

            <div className="card">
                <div className="card-header">
                    <h3>Personal Information</h3>
                    {!editing ? (
                        <button className="btn btn-outline" onClick={() => setEditing(true)}>✏️ Edit</button>
                    ) : (
                        <div style={{ display: 'flex', gap: '8px' }}>
                            <button className="btn btn-outline" onClick={() => { setEditing(false); setForm(customer); }}>Cancel</button>
                            <button className="btn btn-primary" onClick={handleUpdate} disabled={saving}>
                                {saving ? 'Saving...' : '💾 Save'}
                            </button>
                        </div>
                    )}
                </div>

                {editing ? (
                    <div className="form-grid">
                        <div className="form-group">
                            <label>First Name</label>
                            <input value={form.first_name} onChange={(e) => setForm({ ...form, first_name: e.target.value })} />
                        </div>
                        <div className="form-group">
                            <label>Last Name</label>
                            <input value={form.last_name} onChange={(e) => setForm({ ...form, last_name: e.target.value })} />
                        </div>
                        <div className="form-group">
                            <label>Phone</label>
                            <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                        </div>
                        <div className="form-group">
                            <label>Monthly Income (₹)</label>
                            <input type="number" value={form.monthly_income} onChange={(e) => setForm({ ...form, monthly_income: e.target.value })} />
                        </div>
                        <div className="form-group full-width">
                            <label>Address</label>
                            <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
                        </div>
                        <div className="form-group">
                            <label>City</label>
                            <input value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
                        </div>
                        <div className="form-group">
                            <label>State</label>
                            <input value={form.state} onChange={(e) => setForm({ ...form, state: e.target.value })} />
                        </div>
                        <div className="form-group">
                            <label>Pincode</label>
                            <input value={form.pincode} onChange={(e) => setForm({ ...form, pincode: e.target.value })} />
                        </div>
                        <div className="form-group">
                            <label>Employment Type</label>
                            <select value={form.employment_type} onChange={(e) => setForm({ ...form, employment_type: e.target.value })}>
                                <option value="SALARIED">Salaried</option>
                                <option value="SELF_EMPLOYED">Self Employed</option>
                                <option value="BUSINESS">Business</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <label>Company</label>
                            <input value={form.company_name || ''} onChange={(e) => setForm({ ...form, company_name: e.target.value })} />
                        </div>
                    </div>
                ) : (
                    <div className="detail-grid">
                        <div className="detail-item"><div className="label">Name</div><div className="value">{customer.first_name} {customer.last_name}</div></div>
                        <div className="detail-item"><div className="label">Email</div><div className="value">{customer.email}</div></div>
                        <div className="detail-item"><div className="label">Phone</div><div className="value">{customer.phone}</div></div>
                        <div className="detail-item"><div className="label">Date of Birth</div><div className="value">{customer.date_of_birth}</div></div>
                        <div className="detail-item"><div className="label">Address</div><div className="value">{customer.address}</div></div>
                        <div className="detail-item"><div className="label">City</div><div className="value">{customer.city}, {customer.state} - {customer.pincode}</div></div>
                        <div className="detail-item"><div className="label">Monthly Income</div><div className="value">₹{customer.monthly_income?.toLocaleString()}</div></div>
                        <div className="detail-item"><div className="label">Employment</div><div className="value"><span className="badge badge-pending">{customer.employment_type}</span></div></div>
                        {customer.company_name && <div className="detail-item"><div className="label">Company</div><div className="value">{customer.company_name}</div></div>}
                        <div className="detail-item"><div className="label">Customer ID</div><div className="value">#{customer.id}</div></div>
                    </div>
                )}
            </div>
        </>
    );
}
