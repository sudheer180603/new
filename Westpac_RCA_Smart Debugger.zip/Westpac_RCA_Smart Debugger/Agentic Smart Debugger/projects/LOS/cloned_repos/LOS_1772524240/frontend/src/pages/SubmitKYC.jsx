import { useState, useEffect, useRef } from 'react';
import { kycAPI } from '../services/api';

export default function SubmitKYC() {
    const [kyc, setKyc] = useState(null);
    const [panFile, setPanFile] = useState(null);
    const [aadhaarFile, setAadhaarFile] = useState(null);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [checking, setChecking] = useState(true);
    const [success, setSuccess] = useState('');
    const panRef = useRef(null);
    const aadhaarRef = useRef(null);

    useEffect(() => {
        const checkStatus = async () => {
            try {
                const res = await kycAPI.getMe();
                setKyc(res.data);
            } catch { }
            setChecking(false);
        };
        checkStatus();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!panFile || !aadhaarFile) {
            setError('Please upload both PAN and Aadhaar PDF documents');
            return;
        }

        setError('');
        setSuccess('');
        setLoading(true);

        const formData = new FormData();
        formData.append('pan_file', panFile);
        formData.append('aadhaar_file', aadhaarFile);

        try {
            const res = await kycAPI.submitFiles(formData);
            setKyc(res.data);
            setSuccess('Documents uploaded successfully! Your KYC is now under review.');
            setPanFile(null);
            setAadhaarFile(null);
        } catch (err) {
            setError(err.response?.data?.detail || 'KYC submission failed. Make sure your profile is complete.');
        } finally {
            setLoading(false);
        }
    };

    const FileDropZone = ({ label, file, setFile, inputRef, icon }) => (
        <div
            onClick={() => inputRef.current.click()}
            onDragOver={(e) => { e.preventDefault(); e.currentTarget.style.borderColor = 'var(--primary)'; }}
            onDragLeave={(e) => { e.currentTarget.style.borderColor = 'var(--border)'; }}
            onDrop={(e) => {
                e.preventDefault();
                e.currentTarget.style.borderColor = 'var(--border)';
                const dropped = e.dataTransfer.files[0];
                if (dropped?.type === 'application/pdf') setFile(dropped);
                else setError('Only PDF files are accepted');
            }}
            style={{
                border: `2px dashed ${file ? 'var(--success)' : 'var(--border)'}`,
                borderRadius: 'var(--radius)',
                padding: '40px 20px',
                textAlign: 'center',
                cursor: 'pointer',
                background: file ? 'var(--success-light)' : '#fafafa',
                transition: 'var(--transition)',
            }}
        >
            <input ref={inputRef} type="file" accept=".pdf" style={{ display: 'none' }}
                onChange={(e) => { if (e.target.files[0]) setFile(e.target.files[0]); }} />

            {file ? (
                <>
                    <div style={{ fontSize: '36px', marginBottom: '8px' }}>✅</div>
                    <div style={{ fontWeight: 600, color: 'var(--success)' }}>{file.name}</div>
                    <div style={{ fontSize: '12px', color: 'var(--text-secondary)', marginTop: '4px' }}>
                        {(file.size / 1024).toFixed(1)} KB • Click to change
                    </div>
                </>
            ) : (
                <>
                    <div style={{ fontSize: '36px', marginBottom: '8px' }}>{icon}</div>
                    <div style={{ fontWeight: 600, marginBottom: '4px' }}>{label}</div>
                    <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                        Drag & drop or click to browse • PDF only
                    </div>
                </>
            )}
        </div>
    );

    if (checking) return <div className="loading"><div className="spinner" /> Checking KYC status...</div>;

    return (
        <>
            <div className="page-header">
                <h1>KYC Verification</h1>
                <p>Upload your identity documents for verification</p>
            </div>

            {/* Current Status */}
            {kyc && (
                <div className="card" style={{ marginBottom: '20px' }}>
                    <h3 style={{ marginBottom: '16px' }}>Current KYC Status</h3>
                    <div className="detail-grid">
                        <div className="detail-item">
                            <div className="label">Status</div>
                            <div className="value">
                                <span className={`badge badge-${kyc.status.toLowerCase()}`}>{kyc.status}</span>
                            </div>
                        </div>
                        <div className="detail-item">
                            <div className="label">Submitted On</div>
                            <div className="value">{kyc.created_at ? new Date(kyc.created_at).toLocaleDateString() : '—'}</div>
                        </div>
                        <div className="detail-item" style={{ gridColumn: '1 / -1' }}>
                            <div className="label">Remarks</div>
                            <div className="value">{kyc.remarks || '—'}</div>
                        </div>
                    </div>
                    {kyc.status === 'APPROVED' && (
                        <div className="alert alert-success" style={{ marginTop: '16px', marginBottom: 0 }}>
                            ✅ Your KYC is approved! You are eligible for loan applications.
                        </div>
                    )}
                    {kyc.status === 'REJECTED' && (
                        <div className="alert alert-error" style={{ marginTop: '16px', marginBottom: 0 }}>
                            ❌ Your KYC was rejected. Please re-upload your documents below.
                        </div>
                    )}
                    {kyc.status === 'PENDING' && (
                        <div className="alert" style={{ marginTop: '16px', marginBottom: 0, background: '#fef3c7', color: '#92400e', border: '1px solid #fcd34d' }}>
                            ⏳ Your KYC is pending admin review. You will be notified once verified.
                        </div>
                    )}
                </div>
            )}

            {/* Upload Form */}
            {(!kyc || kyc.status !== 'APPROVED') && (
                <div className="card">
                    <h3 style={{ marginBottom: '16px' }}>
                        {kyc?.status === 'REJECTED' ? '🔄 Re-upload Documents' : '📤 Upload Documents'}
                    </h3>

                    {error && <div className="alert alert-error">{error}</div>}
                    {success && <div className="alert alert-success">{success}</div>}

                    <form onSubmit={handleSubmit}>
                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '20px' }}>
                            <FileDropZone label="PAN Card (PDF)" file={panFile} setFile={setPanFile}
                                inputRef={panRef} icon="🪪" />
                            <FileDropZone label="Aadhaar Card (PDF)" file={aadhaarFile} setFile={setAadhaarFile}
                                inputRef={aadhaarRef} icon="🆔" />
                        </div>

                        <button type="submit" className="btn btn-primary" disabled={loading || !panFile || !aadhaarFile}
                            style={{ width: '100%', justifyContent: 'center', padding: '14px', fontSize: '15px' }}>
                            {loading ? '⏳ Uploading...' : '📄 Submit for Verification'}
                        </button>
                    </form>
                </div>
            )}
        </>
    );
}
