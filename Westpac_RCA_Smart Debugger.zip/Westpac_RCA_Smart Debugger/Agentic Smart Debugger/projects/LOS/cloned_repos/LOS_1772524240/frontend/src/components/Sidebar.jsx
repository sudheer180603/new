import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ROLE_NAV = {
    ADMIN: ['dashboard', 'kyc_manage', 'credit', 'loan_approval', 'reports'],
    CUSTOMER: ['dashboard', 'profile', 'kyc_submit', 'my_loans', 'apply_loan', 'payments', 'emi_calc'],
};

const NAV_ITEMS = [
    // Customer items
    { key: 'dashboard', to: '/', icon: '📊', label: 'Dashboard', section: 'Main' },
    { key: 'profile', to: '/profile', icon: '👤', label: 'My Profile', section: 'My Account' },
    { key: 'kyc_submit', to: '/kyc/submit', icon: '📄', label: 'KYC Verification', section: 'My Account' },
    { key: 'my_loans', to: '/loans/my', icon: '💰', label: 'My Loans', section: 'Services' },
    { key: 'apply_loan', to: '/loans/apply', icon: '📝', label: 'Apply for Loan', section: 'Services' },
    { key: 'payments', to: '/payments', icon: '💳', label: 'Make Payment', section: 'Services' },
    { key: 'emi_calc', to: '/emi-calculator', icon: '🧮', label: 'EMI Calculator', section: 'Tools' },

    // Admin items
    { key: 'kyc_manage', to: '/kyc', icon: '🔍', label: 'KYC Management', section: 'Admin Operations' },
    { key: 'credit', to: '/credit', icon: '📈', label: 'Credit Score', section: 'Admin Operations' },
    { key: 'loan_approval', to: '/loans/approval', icon: '✅', label: 'Loan Approvals', section: 'Admin Operations' },
    { key: 'reports', to: '/reports', icon: '📋', label: 'Reports', section: 'Analytics' },
];

export default function Sidebar() {
    const { user, logout } = useAuth();
    const role = user?.role || 'CUSTOMER';
    const allowed = ROLE_NAV[role] || ROLE_NAV.CUSTOMER;

    const visibleItems = NAV_ITEMS.filter((item) => allowed.includes(item.key));

    // Group by section
    const sections = {};
    visibleItems.forEach((item) => {
        if (!sections[item.section]) sections[item.section] = [];
        sections[item.section].push(item);
    });

    return (
        <aside className="sidebar">
            <div className="sidebar-brand">
                <h2>🏦 LOS</h2>
                <span>Loan Origination System</span>
            </div>

            <nav className="sidebar-nav">
                {Object.entries(sections).map(([section, items]) => (
                    <div key={section}>
                        <div className="sidebar-section">{section}</div>
                        {items.map((item) => (
                            <NavLink key={item.key} to={item.to} className={({ isActive }) => isActive ? 'active' : ''}>
                                <span className="icon">{item.icon}</span> {item.label}
                            </NavLink>
                        ))}
                    </div>
                ))}
            </nav>

            <div className="sidebar-footer">
                <div style={{ fontSize: '13px', marginBottom: '10px', color: '#94a3b8' }}>
                    Signed in as <strong style={{ color: '#fff' }}>{user?.username}</strong>
                    <br />
                    <span style={{ fontSize: '11px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>
                        {role === 'ADMIN' ? '🛡️ Administrator' : '👤 Customer'}
                    </span>
                </div>
                <button onClick={logout}>Sign Out</button>
            </div>
        </aside>
    );
}
