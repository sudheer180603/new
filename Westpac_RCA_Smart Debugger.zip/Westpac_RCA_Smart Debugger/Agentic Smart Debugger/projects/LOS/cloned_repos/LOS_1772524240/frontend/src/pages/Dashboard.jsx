import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { customerAPI, reportAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function Dashboard() {
    const { user } = useAuth();
    const [customers, setCustomers] = useState([]);
    const [portfolio, setPortfolio] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const [custRes, portRes] = await Promise.all([
                    customerAPI.getAll(),
                    reportAPI.portfolio(),
                ]);
                setCustomers(custRes.data);
                setPortfolio(portRes.data);
            } catch (err) {
                console.error('Dashboard load error:', err);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    if (loading) return <div className="loading"><div className="spinner" /> Loading dashboard...</div>;

    return (
        <>
            <div className="page-header">
                <h1>Dashboard</h1>
                <p>Welcome back, {user?.username}. Here's your LOS overview.</p>
            </div>

            <div className="stats-grid">
                <div className="stat-card">
                    <div className="label">Total Customers</div>
                    <div className="value">{portfolio?.total_customers || 0}</div>
                </div>
                <div className="stat-card">
                    <div className="label">Total Loans</div>
                    <div className="value">{portfolio?.total_loans || 0}</div>
                </div>
                <div className="stat-card">
                    <div className="label">Total Disbursed</div>
                    <div className="value">₹{(portfolio?.total_disbursed || 0).toLocaleString()}</div>
                </div>
                <div className="stat-card">
                    <div className="label">Active Loans</div>
                    <div className="value">{portfolio?.active_loans || 0}</div>
                </div>
                <div className="stat-card">
                    <div className="label">Collections</div>
                    <div className="value">₹{(portfolio?.total_collections || 0).toLocaleString()}</div>
                </div>
                <div className="stat-card">
                    <div className="label">Avg Credit Score</div>
                    <div className="value">{portfolio?.average_credit_score || '—'}</div>
                </div>
            </div>

            <div className="card">
                <div className="card-header">
                    <h3>Recent Customers</h3>
                    <Link to="/customers/new" className="btn btn-primary">+ Add Customer</Link>
                </div>
                {customers.length === 0 ? (
                    <p style={{ color: 'var(--text-secondary)', textAlign: 'center', padding: '20px' }}>
                        No customers yet. Create your first customer to get started.
                    </p>
                ) : (
                    <div className="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Monthly Income</th>
                                    <th>Employment</th>
                                </tr>
                            </thead>
                            <tbody>
                                {customers.slice(0, 10).map((c) => (
                                    <tr key={c.id}>
                                        <td>{c.id}</td>
                                        <td><strong>{c.first_name} {c.last_name}</strong></td>
                                        <td>{c.email}</td>
                                        <td>{c.phone}</td>
                                        <td>₹{c.monthly_income.toLocaleString()}</td>
                                        <td><span className="badge badge-pending">{c.employment_type}</span></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </>
    );
}
