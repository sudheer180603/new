import { useState, useEffect } from 'react';
import { paymentAPI, loanAPI, customerAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function PaymentProcessing() {
    const { user } = useAuth();
    const [loans, setLoans] = useState([]);
    const [selectedLoan, setSelectedLoan] = useState(null);
    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(true);
    const [processing, setProcessing] = useState(false);
    const [success, setSuccess] = useState(null);
    const [error, setError] = useState('');

    // Form state for payment
    const [paymentMethod, setPaymentMethod] = useState('UPI');

    useEffect(() => {
        fetchLoans();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [user.role]); // Reload if role changes, though unlikely without refresh

    const fetchLoans = async () => {
        setLoading(true);
        try {
            // Fetch active loans for the customer
            const res = await loanAPI.getMy();
            // In backend, approved loans are marked DISBURSED, but check APPROVED too just in case
            const active = res.data.filter(l => ['APPROVED', 'DISBURSED'].includes(l.status));
            setLoans(active);
            if (active.length > 0) {
                // Select first loan by default
                handleSelectLoan(active[0]);
            } else {
                setLoading(false);
            }
        } catch (err) {
            console.error("Failed to fetch loans", err);
            setLoading(false);
        }
    };

    const handleSelectLoan = async (loan) => {
        setSelectedLoan(loan);
        setSuccess(null);
        setError('');
        // Fetch payment history for this loan
        try {
            const res = await paymentAPI.getByLoan(loan.id);
            setHistory(res.data);
        } catch {
            setHistory([]);
        }
        setLoading(false);
    };

    const getNextEmi = () => {
        if (!selectedLoan) return 1;
        // Simple logic: last paid emi + 1. 
        // In real app, backend would tell us next due. 
        // For now, let's assume history length is number of paid EMIs.
        // Filter history for SUCCESS
        const paidCount = history.filter(p => p.status === 'SUCCESS').length;
        return paidCount + 1;
    };

    const handlePay = async (e) => {
        e.preventDefault();
        if (!selectedLoan) return;

        setProcessing(true);
        setError('');
        setSuccess(null);

        const emiNo = getNextEmi();
        if (emiNo > selectedLoan.tenure_months) {
            setError('All EMIs for this loan have been paid!');
            setProcessing(false);
            return;
        }

        try {
            const payload = {
                emi_number: emiNo,
                amount: null, // Full EMI
                payment_method: paymentMethod,
                simulate_failure: false
            };

            const res = await paymentAPI.process(selectedLoan.id, payload);
            if (res.data.status === 'SUCCESS') {
                setSuccess(res.data);
                // Refresh history
                const hRes = await paymentAPI.getByLoan(selectedLoan.id);
                setHistory(hRes.data);
            } else {
                setError('Payment Failed! ' + (res.data.remarks || ''));
            }
        } catch (err) {
            setError(err.response?.data?.detail || 'Payment processing failed');
        } finally {
            setProcessing(false);
        }
    };

    if (loading) return <div className="loading"><div className="spinner" /> Loading Payment Details...</div>;

    if (loans.length === 0) {
        return (
            <div className="card" style={{ textAlign: 'center', padding: '60px 20px' }}>
                <div style={{ fontSize: '48px', marginBottom: '16px' }}>💰</div>
                <h3>No Active Loans</h3>
                <p>You don't have any active loans to make payments for.</p>
            </div>
        );
    }

    const nextEmi = getNextEmi();
    const isLoanComplete = selectedLoan && nextEmi > selectedLoan.tenure_months;

    return (
        <div className="payment-page">
            <div className="page-header">
                <h1>Make a Payment</h1>
                <p>Securely pay your loan EMIs</p>
            </div>

            <div className="payment-layout" style={{ display: 'grid', gridTemplateColumns: 'minmax(300px, 1fr) 2fr', gap: '24px' }}>

                {/* Left Col: Loan Selector & Payment Form */}
                <div className="payment-action-col">
                    <div className="card" style={{ position: 'sticky', top: '24px' }}>
                        <h3>Select Loan</h3>
                        <br />
                        <div className="loan-selector" style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                            {loans.map(loan => (
                                <div
                                    key={loan.id}
                                    onClick={() => handleSelectLoan(loan)}
                                    className={`loan-option ${selectedLoan?.id === loan.id ? 'active' : ''}`}
                                    style={{
                                        padding: '12px',
                                        borderRadius: '8px',
                                        border: `2px solid ${selectedLoan?.id === loan.id ? 'var(--primary)' : 'var(--border)'}`,
                                        cursor: 'pointer',
                                        background: selectedLoan?.id === loan.id ? 'var(--bg-light)' : '#fff',
                                        transition: 'all 0.2s'
                                    }}
                                >
                                    <div style={{ fontWeight: '600', color: 'var(--text-primary)' }}>Loan #{loan.id}</div>
                                    <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                                        ₹{loan.loan_amount.toLocaleString()} • {loan.tenure_months} Months
                                    </div>
                                </div>
                            ))}
                        </div>

                        <hr style={{ margin: '24px 0', borderColor: 'var(--border)' }} />

                        {selectedLoan && (
                            <>
                                <h3 style={{ color: 'var(--primary)' }}>
                                    EMI Details
                                </h3>
                                <div style={{ fontSize: '36px', fontWeight: '800', margin: '16px 0' }}>
                                    ₹{selectedLoan.emi_amount.toLocaleString()}
                                </div>
                                <div style={{ marginBottom: '24px', color: 'var(--text-secondary)' }}>
                                    Due for Month {nextEmi} of {selectedLoan.tenure_months}
                                </div>

                                {isLoanComplete ? (
                                    <div className="alert alert-success">🎉 Loan Fully Paid!</div>
                                ) : (
                                    <form onSubmit={handlePay}>
                                        <div className="form-group">
                                            <label>Payment Method</label>
                                            <select
                                                value={paymentMethod}
                                                onChange={(e) => setPaymentMethod(e.target.value)}
                                                style={{ padding: '12px', fontSize: '16px' }}
                                            >
                                                <option value="UPI">📱 UPI / GPay / PhonePe</option>
                                                <option value="NEFT">🏦 Net Banking / NEFT</option>
                                                <option value="DEBIT_CARD">💳 Debit Card</option>
                                            </select>
                                        </div>

                                        {error && <div className="alert alert-error" style={{ marginBottom: '16px' }}>{error}</div>}

                                        <button
                                            type="submit"
                                            className="btn btn-primary"
                                            disabled={processing}
                                            style={{ width: '100%', padding: '14px', fontSize: '16px' }}
                                        >
                                            {processing ? 'Processing...' : 'Pay Now'}
                                        </button>
                                    </form>
                                )}
                            </>
                        )}
                    </div>
                </div>

                {/* Right Col: Success State & History */}
                <div className="payment-history-col">
                    {success && (
                        <div className="card" style={{ marginBottom: '24px', background: '#ecfdf5', border: '1px solid #a7f3d0' }}>
                            <div style={{ textAlign: 'center', padding: '24px' }}>
                                <div style={{ fontSize: '48px', marginBottom: '8px' }}>✅</div>
                                <h2 style={{ color: '#047857' }}>Payment Successful!</h2>
                                <p style={{ color: '#065f46' }}>Transaction Ref: {success.transaction_ref}</p>
                                <div style={{ fontSize: '24px', fontWeight: 'bold', margin: '16px 0', color: '#047857' }}>
                                    ₹{success.total_amount.toLocaleString()}
                                </div>
                            </div>
                        </div>
                    )}

                    <div className="card">
                        <h3>Transaction History</h3>
                        {history.length === 0 ? (
                            <p style={{ color: 'var(--text-secondary)', padding: '20px 0' }}>No past transactions found for this loan.</p>
                        ) : (
                            <div className="table-responsive">
                                <table className="history-table">
                                    <thead>
                                        <tr>
                                            <th>Date</th>
                                            <th>EMI #</th>
                                            <th>Amount</th>
                                            <th>Method</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {history.map(p => (
                                            <tr key={p.id}>
                                                <td>{new Date(p.payment_date).toLocaleDateString()}</td>
                                                <td>{p.emi_number}</td>
                                                <td>₹{p.total_amount?.toLocaleString()}</td>
                                                <td>{p.payment_method}</td>
                                                <td>
                                                    <span className={`badge badge-${p.status.toLowerCase()}`}>
                                                        {p.status}
                                                    </span>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
}
