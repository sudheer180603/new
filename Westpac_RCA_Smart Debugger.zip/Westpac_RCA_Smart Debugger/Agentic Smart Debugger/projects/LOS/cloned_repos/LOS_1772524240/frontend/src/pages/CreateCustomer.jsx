import { useState } from 'react';
import { customerAPI } from '../services/api';

export default function CreateCustomer() {
    const [form, setForm] = useState({
        first_name: '', last_name: '', email: '', phone: '',
        date_of_birth: '', address: '', city: '', state: '',
        pincode: '', monthly_income: '', employment_type: 'SALARIED',
        company_name: '',
    });
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        setForm({ ...form, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccess('');
        setLoading(true);
        try {
            const payload = { ...form, monthly_income: parseFloat(form.monthly_income) };
            const res = await customerAPI.create(payload);
            setSuccess(`Customer created successfully! ID: ${res.data.id}`);
            setForm({
                first_name: '', last_name: '', email: '', phone: '',
                date_of_birth: '', address: '', city: '', state: '',
                pincode: '', monthly_income: '', employment_type: 'SALARIED',
                company_name: '',
            });
        } catch (err) {
            setError(err.response?.data?.detail || 'Failed to create customer');
        } finally {
            setLoading(false);
        }
    };

    return (
        <>
            <div className="page-header">
                <h1>Create Customer</h1>
                <p>Onboard a new bank customer into the system</p>
            </div>

            <div className="card">
                {error && <div className="alert alert-error">{error}</div>}
                {success && <div className="alert alert-success">{success}</div>}

                <form onSubmit={handleSubmit}>
                    <div className="form-grid">
                        <div className="form-group">
                            <label>First Name</label>
                            <input name="first_name" value={form.first_name} onChange={handleChange} required />
                        </div>
                        <div className="form-group">
                            <label>Last Name</label>
                            <input name="last_name" value={form.last_name} onChange={handleChange} required />
                        </div>
                        <div className="form-group">
                            <label>Email</label>
                            <input type="email" name="email" value={form.email} onChange={handleChange} required />
                        </div>
                        <div className="form-group">
                            <label>Phone</label>
                            <input name="phone" value={form.phone} onChange={handleChange} placeholder="e.g. 9876543210" required />
                        </div>
                        <div className="form-group">
                            <label>Date of Birth</label>
                            <input type="date" name="date_of_birth" value={form.date_of_birth} onChange={handleChange} required />
                        </div>
                        <div className="form-group">
                            <label>Monthly Income (₹)</label>
                            <input type="number" name="monthly_income" value={form.monthly_income} onChange={handleChange} placeholder="e.g. 50000" required />
                        </div>
                        <div className="form-group full-width">
                            <label>Address</label>
                            <input name="address" value={form.address} onChange={handleChange} required />
                        </div>
                        <div className="form-group">
                            <label>City</label>
                            <input name="city" value={form.city} onChange={handleChange} required />
                        </div>
                        <div className="form-group">
                            <label>State</label>
                            <input name="state" value={form.state} onChange={handleChange} required />
                        </div>
                        <div className="form-group">
                            <label>Pincode</label>
                            <input name="pincode" value={form.pincode} onChange={handleChange} required />
                        </div>
                        <div className="form-group">
                            <label>Employment Type</label>
                            <select name="employment_type" value={form.employment_type} onChange={handleChange}>
                                <option value="SALARIED">Salaried</option>
                                <option value="SELF_EMPLOYED">Self Employed</option>
                                <option value="BUSINESS">Business</option>
                            </select>
                        </div>
                        <div className="form-group full-width">
                            <label>Company Name (Optional)</label>
                            <input name="company_name" value={form.company_name} onChange={handleChange} />
                        </div>
                    </div>
                    <button type="submit" className="btn btn-primary" disabled={loading} style={{ marginTop: '8px' }}>
                        {loading ? 'Creating...' : 'Create Customer'}
                    </button>
                </form>
            </div>
        </>
    );
}
