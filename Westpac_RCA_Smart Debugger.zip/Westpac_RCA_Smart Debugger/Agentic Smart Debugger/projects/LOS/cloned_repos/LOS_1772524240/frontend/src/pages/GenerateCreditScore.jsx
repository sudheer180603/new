import { useState } from 'react';
import { creditAPI, customerAPI } from '../services/api';

export default function GenerateCreditScore() {
    const [customerId, setCustomerId] = useState('');
    const [customer, setCustomer] = useState(null);
    const [score, setScore] = useState(null);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const fetchCustomer = async () => {
        if (!customerId) return;
        setError('');
        try {
            const res = await customerAPI.getById(customerId);
            setCustomer(res.data);
            setScore(null); // Clear previous score until checked/generated
        } catch {
            setError('Customer not found');
            setCustomer(null);
        }
    };

    const generateScore = async () => {
        setError('');
        setLoading(true);
        try {
            const res = await creditAPI.generate(customerId);
            setScore(res.data);
        } catch (err) {
            setError(err.response?.data?.detail || 'Failed to generate credit score');
        } finally {
            setLoading(false);
        }
    };

    // Helper to calculate color and stroke-dashoffset for circular gauge
    const getGaugeProps = (s) => {
        const radius = 90;
        const circumference = 2 * Math.PI * radius;
        // Score range typically 300 to 900. Normalize to 0-1
        // Let's assume min 300, max 900
        const min = 300;
        const max = 900;
        const normalized = Math.max(0, Math.min((s - min) / (max - min), 1));
        const offset = circumference - (normalized * circumference);

        let color = '#ef4444'; // Red
        if (s >= 650) color = '#f59e0b'; // Orange
        if (s >= 750) color = '#10b981'; // Green

        return { offset, color, circumference };
    };

    return (
        <div className="credit-score-page">
            <div className="page-header">
                <h1>Credit Score Management</h1>
                <p>Evaluate customer creditworthiness</p>
            </div>

            <div className="card" style={{ maxWidth: '800px', margin: '0 auto' }}>
                <div style={{ display: 'flex', gap: '16px', alignItems: 'flex-end', marginBottom: '24px' }}>
                    <div className="form-group" style={{ flex: 1, marginBottom: 0 }}>
                        <label>Customer ID</label>
                        <input
                            type="number"
                            value={customerId}
                            onChange={(e) => setCustomerId(e.target.value)}
                            placeholder="Enter Customer ID"
                            className="input-lg"
                        />
                    </div>
                    <button className="btn btn-primary" onClick={fetchCustomer} style={{ height: '48px' }}>
                        Find Customer
                    </button>
                </div>

                {error && <div className="alert alert-error">{error}</div>}

                {customer && (
                    <div className="customer-profile-preview" style={{
                        padding: '20px',
                        background: 'var(--bg-light)',
                        borderRadius: '12px',
                        marginBottom: '24px',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center'
                    }}>
                        <div>
                            <h3 style={{ margin: 0 }}>{customer.first_name} {customer.last_name}</h3>
                            <p style={{ margin: '4px 0 0', color: 'var(--text-secondary)' }}>
                                {customer.email} • {customer.phone}
                            </p>
                        </div>
                        <div style={{ textAlign: 'right' }}>
                            <div style={{ fontSize: '12px', textTransform: 'uppercase', letterSpacing: '1px', color: 'var(--text-secondary)' }}>Monthly Income</div>
                            <div style={{ fontWeight: 'bold', fontSize: '18px' }}>₹{customer.monthly_income?.toLocaleString()}</div>
                        </div>
                    </div>
                )}

                {customer && !score && (
                    <div style={{ textAlign: 'center', padding: '40px' }}>
                        <button className="btn btn-lg btn-primary" onClick={generateScore} disabled={loading} style={{ padding: '16px 32px', fontSize: '18px' }}>
                            {loading ? <span className="spinner" /> : '🚀 Generate Credit Score'}
                        </button>
                    </div>
                )}

                {score && (() => {
                    const { offset, color, circumference } = getGaugeProps(score.score);
                    return (
                        <div className="score-result fade-in" style={{ textAlign: 'center' }}>
                            <div style={{ position: 'relative', width: '200px', height: '200px', margin: '0 auto 24px' }}>
                                <svg width="200" height="200" style={{ transform: 'rotate(-90deg)' }}>
                                    <circle
                                        cx="100" cy="100" r="90"
                                        fill="none" stroke="#e2e8f0" strokeWidth="12"
                                    />
                                    <circle
                                        cx="100" cy="100" r="90"
                                        fill="none" stroke={color} strokeWidth="12"
                                        strokeDasharray={circumference}
                                        strokeDashoffset={offset}
                                        strokeLinecap="round"
                                        style={{ transition: 'stroke-dashoffset 1s ease-out' }}
                                    />
                                </svg>
                                <div style={{
                                    position: 'absolute', top: '50%', left: '50%',
                                    transform: 'translate(-50%, -50%)', textAlign: 'center'
                                }}>
                                    <div style={{ fontSize: '48px', fontWeight: '800', color: 'var(--text-primary)', lineHeight: 1 }}>
                                        {score.score}
                                    </div>
                                    <div style={{ fontSize: '14px', color: color, fontWeight: 'bold', marginTop: '4px' }}>
                                        {score.risk_category}
                                    </div>
                                </div>
                            </div>

                            <div className="risk-factors" style={{ textAlign: 'left' }}>
                                <h4 style={{ borderBottom: '1px solid var(--border)', paddingBottom: '8px', marginBottom: '16px' }}>Risk Factors Analysis</h4>
                                <div style={{ display: 'grid', gap: '12px' }}>
                                    {JSON.parse(score.factors).map((f, i) => (
                                        <div key={i} style={{
                                            display: 'flex', alignItems: 'center', gap: '12px',
                                            padding: '12px', background: '#fff', borderRadius: '8px',
                                            border: '1px solid var(--border)'
                                        }}>
                                            <div style={{
                                                width: '24px', height: '24px', borderRadius: '50%',
                                                background: f.impact === 'POSITIVE' ? '#d1fae5' : '#fee2e2',
                                                color: f.impact === 'POSITIVE' ? '#059669' : '#dc2626',
                                                display: 'flex', alignItems: 'center', justifyContent: 'center',
                                                fontWeight: 'bold'
                                            }}>
                                                {f.impact === 'POSITIVE' ? '↑' : '↓'}
                                            </div>
                                            <div style={{ flex: 1 }}>
                                                <div style={{ fontWeight: '500' }}>{f.factor}</div>
                                            </div>
                                            <div style={{
                                                fontSize: '12px', fontWeight: 'bold',
                                                color: f.impact === 'POSITIVE' ? 'var(--success)' : 'var(--danger)'
                                            }}>
                                                {f.impact}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    );
                })()}
            </div>
        </div>
    );
}
