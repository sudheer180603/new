import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { customerAPI, kycAPI, loanAPI, paymentAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';

export default function CustomerDashboard() {
    const { user } = useAuth();
    const [customer, setCustomer] = useState(null);
    const [kyc, setKyc] = useState(null);
    const [loans, setLoans] = useState([]);
    const [payments, setPayments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [noProfile, setNoProfile] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const custRes = await customerAPI.getMe();
                setCustomer(custRes.data);

                // Fetch KYC, loans, and payments (ignore errors for each)
                try { const kyRes = await kycAPI.getMe(); setKyc(kyRes.data); } catch { }
                try { const lnRes = await loanAPI.getMy(); setLoans(lnRes.data); } catch { }
                try { const pyRes = await paymentAPI.getMy(); setPayments(pyRes.data); } catch { }
            } catch {
                setNoProfile(true);
            } finally {
                setLoading(false);
            }
        };
        fetchData();
    }, []);

    if (loading) return <div className="loading"><div className="spinner" /> Loading dashboard...</div>;

    if (noProfile) {
        return (
            <>
                <div className="page-header">
                    <h1>Welcome, {user?.username}! 👋</h1>
                    <p>Let's get your account set up</p>
                </div>
                <div className="card" style={{ textAlign: 'center', padding: '60px 20px' }}>
                    <div style={{ fontSize: '64px', marginBottom: '16px' }}>📋</div>
                    <h2 style={{ marginBottom: '8px' }}>Complete Your Profile</h2>
                    <p style={{ color: 'var(--text-secondary)', marginBottom: '24px', maxWidth: '400px', margin: '0 auto 24px' }}>
                        Before you can access loans and services, please complete your customer profile.
                    </p>
                    <Link to="/profile" className="btn btn-primary" style={{ fontSize: '16px', padding: '14px 32px' }}>
                        📝 Set Up Profile
                    </Link>
                </div>
            </>
        );
    }

    const activeLoans = loans.filter(l => l.status === 'DISBURSED');
    const pendingLoans = loans.filter(l => l.status === 'PENDING');
    const totalOutstanding = activeLoans.reduce((sum, l) => sum + l.total_payable, 0);
    const totalPaid = payments.filter(p => p.status === 'SUCCESS').reduce((sum, p) => sum + p.total_amount, 0);

    const getKycBadge = () => {
        if (!kyc) return { text: 'Not Submitted', className: 'badge-pending', icon: '⚠️' };
        if (kyc.status === 'APPROVED') return { text: 'Verified', className: 'badge-approved', icon: '✅' };
        if (kyc.status === 'PENDING') return { text: 'Under Review', className: 'badge-pending', icon: '⏳' };
        return { text: 'Rejected', className: 'badge-rejected', icon: '❌' };
    };
    const kycBadge = getKycBadge();

    return (
        <>
            <div className="page-header">
                <h1>Welcome back, {customer?.first_name}! 👋</h1>
                <p>Here's an overview of your account</p>
            </div>

            {/* Quick Stats */}
            <div className="stats-grid">
                <div className="stat-card" style={{ borderLeft: '4px solid var(--primary)' }}>
                    <div className="label">KYC Status</div>
                    <div className="value" style={{ fontSize: '20px' }}>
                        {kycBadge.icon} <span className={`badge ${kycBadge.className}`}>{kycBadge.text}</span>
                    </div>
                </div>
                <div className="stat-card" style={{ borderLeft: '4px solid var(--success)' }}>
                    <div className="label">Active Loans</div>
                    <div className="value">{activeLoans.length}</div>
                    {pendingLoans.length > 0 && <div className="sub">{pendingLoans.length} pending approval</div>}
                </div>
                <div className="stat-card" style={{ borderLeft: '4px solid var(--warning)' }}>
                    <div className="label">Total Outstanding</div>
                    <div className="value">₹{totalOutstanding.toLocaleString()}</div>
                </div>
                <div className="stat-card" style={{ borderLeft: '4px solid var(--info)' }}>
                    <div className="label">Total Paid</div>
                    <div className="value">₹{totalPaid.toLocaleString()}</div>
                </div>
            </div>

            {/* Action Cards */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px', marginBottom: '24px' }}>
                {/* KYC Action */}
                {(!kyc || kyc.status === 'REJECTED') && (
                    <div className="card" style={{ borderTop: '3px solid var(--warning)' }}>
                        <h3 style={{ marginBottom: '8px' }}>📄 KYC Verification</h3>
                        <p style={{ color: 'var(--text-secondary)', fontSize: '14px', marginBottom: '16px' }}>
                            {kyc?.status === 'REJECTED'
                                ? 'Your KYC was rejected. Please re-upload your documents.'
                                : 'Upload your PAN and Aadhaar documents to get verified.'}
                        </p>
                        <Link to="/kyc/submit" className="btn btn-primary">
                            {kyc?.status === 'REJECTED' ? '🔄 Re-submit KYC' : '📤 Submit KYC'}
                        </Link>
                    </div>
                )}

                {/* Apply for Loan */}
                {kyc?.status === 'APPROVED' && (
                    <div className="card" style={{ borderTop: '3px solid var(--primary)' }}>
                        <h3 style={{ marginBottom: '8px' }}>💰 Apply for a Loan</h3>
                        <p style={{ color: 'var(--text-secondary)', fontSize: '14px', marginBottom: '16px' }}>
                            Your KYC is verified! You can now apply for loans.
                        </p>
                        <Link to="/loans/apply" className="btn btn-primary">📝 Apply Now</Link>
                    </div>
                )}

                {/* EMI Calculator */}
                <div className="card" style={{ borderTop: '3px solid var(--secondary)' }}>
                    <h3 style={{ marginBottom: '8px' }}>🧮 EMI Calculator</h3>
                    <p style={{ color: 'var(--text-secondary)', fontSize: '14px', marginBottom: '16px' }}>
                        Plan your finances — calculate EMI before applying.
                    </p>
                    <Link to="/emi-calculator" className="btn btn-outline">Calculate EMI</Link>
                </div>
            </div>

            {/* Recent Loans */}
            {loans.length > 0 && (
                <div className="card" style={{ marginBottom: '20px' }}>
                    <div className="card-header">
                        <h3>Recent Loans</h3>
                        <Link to="/loans/my" className="btn btn-outline" style={{ fontSize: '13px', padding: '6px 14px' }}>View All →</Link>
                    </div>
                    <div style={{ display: 'grid', gap: '12px' }}>
                        {loans.slice(0, 3).map(loan => (
                            <div key={loan.id} style={{
                                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                                padding: '16px', background: 'var(--bg)', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)',
                            }}>
                                <div>
                                    <div style={{ fontWeight: 600, marginBottom: '4px' }}>
                                        ₹{loan.loan_amount.toLocaleString()}
                                        <span className={`badge badge-${loan.status.toLowerCase()}`} style={{ marginLeft: '8px' }}>{loan.status}</span>
                                    </div>
                                    <div style={{ fontSize: '13px', color: 'var(--text-secondary)' }}>
                                        {loan.purpose || 'General'} • {loan.tenure_months} months • {loan.interest_rate}% p.a.
                                    </div>
                                </div>
                                <div style={{ textAlign: 'right' }}>
                                    <div style={{ fontWeight: 600, fontSize: '14px' }}>₹{loan.emi_amount.toLocaleString()}/mo</div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Recent Payments */}
            {payments.length > 0 && (
                <div className="card">
                    <div className="card-header">
                        <h3>Recent Payments</h3>
                        <Link to="/payments/history" className="btn btn-outline" style={{ fontSize: '13px', padding: '6px 14px' }}>View All →</Link>
                    </div>
                    <div className="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>Loan</th>
                                    <th>EMI #</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                {payments.slice(0, 5).map(p => (
                                    <tr key={p.id}>
                                        <td>Loan #{p.loan_id}</td>
                                        <td>{p.emi_number}</td>
                                        <td>₹{p.total_amount?.toLocaleString()}</td>
                                        <td><span className={`badge badge-${p.status.toLowerCase()}`}>{p.status}</span></td>
                                        <td style={{ fontSize: '13px' }}>{p.paid_at ? new Date(p.paid_at).toLocaleDateString() : '—'}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
        </>
    );
}
