import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { loanAPI } from '../services/api';

export default function LoanDetails() {
    const { id } = useParams();
    const [data, setData] = useState(null);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(true);
    const [searchId, setSearchId] = useState(id || '');

    const fetchLoan = async (loanId) => {
        setError('');
        setLoading(true);
        try {
            const res = await loanAPI.getById(loanId);
            setData(res.data);
        } catch (err) {
            setError(err.response?.data?.detail || 'Loan not found');
            setData(null);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (id) fetchLoan(id);
        else setLoading(false);
    }, [id]);

    const loan = data?.loan;
    const schedule = data?.emi_schedule || [];

    return (
        <>
            <div className="page-header">
                <h1>Loan Details</h1>
                <p>View loan information and EMI schedule</p>
            </div>

            {!id && (
                <div className="card" style={{ marginBottom: '20px' }}>
                    <div style={{ display: 'flex', gap: '12px', alignItems: 'end' }}>
                        <div className="form-group" style={{ flex: 1, marginBottom: 0 }}>
                            <label>Loan ID</label>
                            <input type="number" value={searchId} onChange={(e) => setSearchId(e.target.value)}
                                placeholder="Enter loan ID" />
                        </div>
                        <button className="btn btn-primary" onClick={() => fetchLoan(searchId)}>Search</button>
                    </div>
                </div>
            )}

            {error && <div className="alert alert-error">{error}</div>}
            {loading && <div className="loading"><div className="spinner" /> Loading...</div>}

            {loan && (
                <>
                    <div className="card" style={{ marginBottom: '20px' }}>
                        <div className="card-header">
                            <h3>Loan #{loan.id}</h3>
                            <span className={`badge badge-${loan.status.toLowerCase()}`}>{loan.status}</span>
                        </div>
                        <div className="detail-grid">
                            <div className="detail-item">
                                <div className="label">Customer ID</div>
                                <div className="value">{loan.customer_id}</div>
                            </div>
                            <div className="detail-item">
                                <div className="label">Loan Amount</div>
                                <div className="value">₹{loan.loan_amount?.toLocaleString()}</div>
                            </div>
                            <div className="detail-item">
                                <div className="label">EMI Amount</div>
                                <div className="value">₹{loan.emi_amount?.toLocaleString()}</div>
                            </div>
                            <div className="detail-item">
                                <div className="label">Interest Rate</div>
                                <div className="value">{loan.interest_rate}% p.a.</div>
                            </div>
                            <div className="detail-item">
                                <div className="label">Tenure</div>
                                <div className="value">{loan.tenure_months} months</div>
                            </div>
                            <div className="detail-item">
                                <div className="label">Total Payable</div>
                                <div className="value">₹{loan.total_payable?.toLocaleString()}</div>
                            </div>
                            <div className="detail-item">
                                <div className="label">Total Interest</div>
                                <div className="value">₹{loan.total_interest?.toLocaleString()}</div>
                            </div>
                            <div className="detail-item">
                                <div className="label">Purpose</div>
                                <div className="value">{loan.purpose || '—'}</div>
                            </div>
                        </div>
                    </div>

                    {schedule.length > 0 && (
                        <div className="card">
                            <h3 style={{ marginBottom: '16px' }}>EMI Schedule ({schedule.length} installments)</h3>
                            <div className="table-container">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Due Date</th>
                                            <th>EMI</th>
                                            <th>Principal</th>
                                            <th>Interest</th>
                                            <th>Balance</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {schedule.map((emi) => (
                                            <tr key={emi.id}>
                                                <td>{emi.emi_number}</td>
                                                <td>{emi.due_date}</td>
                                                <td>₹{emi.emi_amount?.toLocaleString()}</td>
                                                <td>₹{emi.principal_component?.toLocaleString()}</td>
                                                <td>₹{emi.interest_component?.toLocaleString()}</td>
                                                <td>₹{emi.outstanding_balance?.toLocaleString()}</td>
                                                <td>
                                                    <span className={`badge badge-${emi.status.toLowerCase()}`}>{emi.status}</span>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}
                </>
            )}
        </>
    );
}
