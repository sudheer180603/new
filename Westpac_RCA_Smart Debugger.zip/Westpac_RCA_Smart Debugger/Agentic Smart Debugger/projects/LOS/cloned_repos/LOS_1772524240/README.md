# Digital Loan Origination System (LOS)

> **Enterprise-grade Loan Origination System for retail banking** — built with
> FastAPI (Python) on the backend and React + Vite on the frontend.

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Backend Modules](#backend-modules)
4. [Database Schema](#database-schema)
5. [API Endpoints](#api-endpoints)
6. [Frontend Pages](#frontend-pages)
7. [Business Rules & Workflow](#business-rules--workflow)
8. [Authentication & Authorisation](#authentication--authorisation)
9. [Event / Notification System](#event--notification-system)
10. [Configuration](#configuration)
11. [Running the Application](#running-the-application)

---

## Overview

The LOS application manages the **complete lifecycle** of a retail bank loan:

1. **Customer onboarding** — register, create profile, capture demographics & income.
2. **KYC (Know Your Customer)** — upload PAN and Aadhaar documents; admin verifies.
3. **Credit scoring** — simulate a credit score (300–900) with risk categorisation.
4. **Loan application** — customer applies; eligibility pre-checks run automatically.
5. **Loan approval / rejection** — admin reviews pending loans.
6. **Disbursement** — on approval the loan is auto-disbursed and an EMI schedule is generated.
7. **Payment processing** — EMI payments, late-fee calculation, overdue tracking.
8. **Reporting** — monthly and portfolio-level regulatory reports.

The system uses **role-based access control** (RBAC) with two roles: `ADMIN` and `CUSTOMER`.

---

## Architecture

```
┌──────────────────────────────────────────────────────┐
│                   React Frontend (Vite)              │
│  Pages: Login, Register, Dashboard, ApplyLoan,       │
│         MyLoans, LoanDetails, LoanApproval,          │
│         CreateCustomer, CustomerDashboard, SubmitKYC, │
│         VerifyKYC, GenerateCreditScore, EMICalculator,│
│         PaymentProcessing, PaymentHistory, Profile,   │
│         Reports                                       │
│  API Client: Axios with JWT interceptor               │
└───────────────────────┬──────────────────────────────┘
                        │ HTTP / JSON
┌───────────────────────▼──────────────────────────────┐
│             FastAPI Backend (Python 3.x)              │
│                                                       │
│  Routers:  /auth  /customers  /kyc  /credit  /loans  │
│            /payments  /reporting                      │
│                                                       │
│  Services: auth.service, customers.service,           │
│            kyc.service, credit.service,               │
│            loans.service, payments.service,           │
│            reporting.service, notifications.service   │
│                                                       │
│  ORM: SQLAlchemy  │  DB: SQLite (los.db)              │
│  Auth: JWT (HS256) via python-jose + passlib[bcrypt]  │
└───────────────────────┬──────────────────────────────┘
                        │
              ┌─────────▼─────────┐
              │    SQLite DB      │
              │   (los.db)        │
              └───────────────────┘
```

---

## Backend Modules

Each module follows a consistent structure:
`models.py` → `schemas.py` → `service.py` → `routes.py`

### `auth/` — Authentication & Authorisation

| File | Purpose |
|------|---------|
| `models.py` | `User` model with fields: `id`, `username`, `email`, `hashed_password`, `full_name`, `role` (ADMIN/CUSTOMER), `is_active`, timestamps. |
| `schemas.py` | Pydantic schemas: `UserCreate`, `UserResponse`, `Token`, `LoginRequest`. |
| `service.py` | Password hashing (bcrypt), JWT creation/verification (`python-jose`), user registration, login, `get_current_user` dependency. |
| `routes.py` | `POST /auth/register`, `POST /auth/login`. |

### `customers/` — Customer Onboarding

| File | Purpose |
|------|---------|
| `models.py` | `Customer` model: `id`, `user_id` (FK→users), `first_name`, `last_name`, `email`, `phone`, `date_of_birth`, `address`, `city`, `state`, `pincode`, `monthly_income`, `employment_type` (SALARIED/SELF_EMPLOYED/BUSINESS), `company_name`, `created_by`, timestamps. |
| `schemas.py` | `CustomerCreate`, `CustomerUpdate`, `CustomerResponse`. |
| `service.py` | CRUD: create, get all, get by ID, get by user_id, update. Admins can create customers for any user; customers can only access their own profile. |
| `routes.py` | `POST /customers`, `GET /customers`, `GET /customers/me`, `PUT /customers/me`, `GET /customers/{id}`. |

### `kyc/` — Know Your Customer

| File | Purpose |
|------|---------|
| `models.py` | `KYCRecord` model: `id`, `customer_id` (FK→customers), `pan_file_path`, `aadhaar_file_path`, `status` (PENDING/APPROVED/REJECTED), `remarks`, `verified_by`, `verified_at`, timestamps. |
| `schemas.py` | `KYCSubmitRequest`, `KYCResponse`. |
| `service.py` | Submit KYC documents (file upload to `uploads/kyc/{customer_id}/`), approve/reject KYC, retrieve KYC status. |
| `routes.py` | `POST /kyc/submit`, `GET /kyc/me`, `GET /kyc/all`, `POST /kyc/approve/{customer_id}`, `GET /kyc/file/{customer_id}/{file_type}`, `GET /kyc/{customer_id}`. |

### `credit/` — Credit Scoring

| File | Purpose |
|------|---------|
| `models.py` | `CreditScore` model: `id`, `customer_id` (FK→customers), `score` (300–900), `risk_category` (LOW/MEDIUM/HIGH/VERY_HIGH), `factors` (JSON string), `generated_at`, timestamps. |
| `schemas.py` | `CreditScoreResponse`. |
| `service.py` | Simulated credit score generation based on: income (40% weight), employment type (20%), age (15%), existing loan history (25%). Maps score → risk category. |
| `routes.py` | `POST /credit/generate/{customer_id}`, `GET /credit/{customer_id}`. |

### `loans/` — Loan Processing (Core Module)

| File | Purpose |
|------|---------|
| `models.py` | `Loan` model: `id`, `customer_id`, `loan_amount`, `interest_rate`, `tenure_months` (6–60), `emi_amount`, `total_payable`, `total_interest`, `status` (PENDING/APPROVED/REJECTED/DISBURSED/CLOSED/DEFAULT), `purpose`, `rejection_reason`, `approved_by`, `disbursed_at`, timestamps.  `EMISchedule` model: `id`, `loan_id`, `emi_number`, `due_date`, `emi_amount`, `principal_component`, `interest_component`, `outstanding_balance`, `status` (PENDING/PAID/OVERDUE). |
| `schemas.py` | `LoanApplyRequest`, `LoanResponse`, `LoanDetailResponse`, `EMIScheduleResponse`. |
| `service.py` | **Key functions:** `calculate_emi(principal, annual_rate, tenure_months)` — standard reducing-balance EMI formula. `generate_emi_schedule(...)` — builds full amortisation table. `apply_loan(...)` — eligibility pre-checks (KYC approved, credit score ≥ 650, loan ≤ 50× monthly income, EMI ≤ 40% income). `approve_loan(...)` — admin approves, auto-disburses, generates EMI schedule. `reject_loan(...)`. Various query helpers. |
| `routes.py` | `POST /loans/apply`, `GET /loans/my`, `GET /loans/pending`, `GET /loans/all`, `POST /loans/approve/{loan_id}`, `GET /loans/{loan_id}`, `GET /loans/customer/{customer_id}`. |

### `payments/` — Payment Management

| File | Purpose |
|------|---------|
| `models.py` | `Payment` model: `id`, `loan_id`, `emi_number`, `amount`, `late_fee`, `total_amount`, `status` (SUCCESS/FAILED/PENDING), `payment_method`, `transaction_ref`, `remarks`, `paid_at`, timestamps. |
| `schemas.py` | `PaymentRequest`, `PaymentResponse`. |
| `service.py` | Process next due EMI, calculate late fees for overdue EMIs, mark EMI schedule as PAID, check for loan closure when all EMIs paid. |
| `routes.py` | `GET /payments/my`, `POST /payments/process/{loan_id}`, `GET /payments/{loan_id}`. |

### `reporting/` — Regulatory Reporting

| File | Purpose |
|------|---------|
| `models.py` | `Report` model: `id`, `report_type` (MONTHLY/PORTFOLIO), `report_period`, aggregate fields (`total_loans`, `total_disbursed`, `total_collections`, `active_loans`, `npa_count`, `npa_amount`, `average_credit_score`), `report_data` (JSON Text), timestamps. |
| `schemas.py` | `MonthlyReportResponse`, `PortfolioReportResponse`. |
| `service.py` | Aggregate queries across loans, payments, credit scores to build monthly and portfolio snapshots. |
| `routes.py` | `GET /reporting/monthly`, `GET /reporting/portfolio`. |

### `notifications/` — Event System

| File | Purpose |
|------|---------|
| `service.py` | In-memory event simulation (replaces Kafka). `emit_event(event_type, payload)` logs and triggers downstream handlers. Supported events: `KYC_SUBMITTED`, `KYC_APPROVED`, `KYC_REJECTED`, `CREDIT_GENERATED`, `LOAN_APPLIED`, `LOAN_APPROVED`, `LOAN_REJECTED`, `LOAN_DISBURSED`, `PAYMENT_SUCCESS`, `PAYMENT_FAILED`, `PAYMENT_OVERDUE`. |

### `database/` — Engine & Session

| File | Purpose |
|------|---------|
| `engine.py` | SQLAlchemy engine (SQLite with `check_same_thread=False`), `SessionLocal`, `Base`, `get_db()` dependency. |

### `core/` — Configuration

| File | Purpose |
|------|---------|
| `config.py` | `Settings(BaseSettings)`: `SECRET_KEY`, `ALGORITHM` (HS256), `ACCESS_TOKEN_EXPIRE_MINUTES` (60), `DATABASE_URL` (`sqlite:///./app/database/los.db`). |

### `shared/` — Cross-cutting Dependencies

| File | Purpose |
|------|---------|
| `deps.py` | Shared FastAPI dependency helpers for current-user injection, admin-only checks, and customer-id resolution. |

---

## Database Schema

```
┌──────────┐     ┌─────────────┐     ┌─────────────┐
│  users   │1───*│  customers  │1───*│  kyc_records │
│          │     │             │     └─────────────┘
│  id (PK) │     │  id (PK)    │1───*┌──────────────┐
│  username│     │  user_id FK │     │ credit_scores│
│  email   │     │  first_name │     │  id (PK)     │
│  hashed_ │     │  last_name  │     │  customer_id │
│  password│     │  email      │     │  score       │
│  role    │     │  phone      │     │  risk_categ. │
│  ...     │     │  monthly_   │     └──────────────┘
└──────────┘     │  income     │1───*┌──────────┐
                 │  employment │     │  loans   │
                 │  _type      │     │  id (PK) │1───*┌──────────────┐
                 └─────────────┘     │  cust_id │     │ emi_schedules│
                                     │  amount  │     │  id (PK)     │
                                     │  rate    │     │  loan_id FK  │
                                     │  tenure  │     │  emi_number  │
                                     │  status  │     │  due_date    │
                                     │  ...     │     │  amount      │
                                     └──────────┘     │  principal   │
                                          │1          │  interest    │
                                          │           │  outstanding │
                                          *           │  status      │
                                     ┌──────────┐    └──────────────┘
                                     │ payments │
                                     │  id (PK) │
                                     │  loan_id │
                                     │  emi_num │
                                     │  amount  │
                                     │  late_fee│
                                     │  status  │
                                     └──────────┘

                 ┌───────────┐
                 │  reports  │  (standalone aggregate table)
                 │  id (PK)  │
                 │  type     │
                 │  period   │
                 │  totals   │
                 └───────────┘
```

### Relationships

| Parent | Child | Cardinality | FK Column |
|--------|-------|-------------|-----------|
| users | customers | 1 : 0..1 | `customers.user_id` |
| customers | kyc_records | 1 : * | `kyc_records.customer_id` |
| customers | credit_scores | 1 : * | `credit_scores.customer_id` |
| customers | loans | 1 : * | `loans.customer_id` |
| loans | emi_schedules | 1 : * | `emi_schedules.loan_id` |
| loans | payments | 1 : * | `payments.loan_id` |

---

## API Endpoints

### Authentication (`/auth`)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/auth/register` | Public | Register a new user (ADMIN or CUSTOMER) |
| POST | `/auth/login` | Public | Login, returns JWT access token |

### Customers (`/customers`)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/customers` | ADMIN | Create a customer profile |
| GET | `/customers` | ADMIN | List all customers |
| GET | `/customers/me` | CUSTOMER | Get own customer profile |
| PUT | `/customers/me` | CUSTOMER | Update own profile |
| GET | `/customers/{id}` | ADMIN | Get customer by ID |

### KYC (`/kyc`)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/kyc/submit` | CUSTOMER | Upload PAN + Aadhaar documents |
| GET | `/kyc/me` | CUSTOMER | Get own KYC status |
| GET | `/kyc/all` | ADMIN | List all KYC records |
| POST | `/kyc/approve/{cid}` | ADMIN | Approve or reject KYC |
| GET | `/kyc/file/{cid}/{type}` | ADMIN | Download KYC document file |
| GET | `/kyc/{cid}` | ADMIN | Get KYC record for a customer |

### Credit Scoring (`/credit`)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/credit/generate/{cid}` | ADMIN | Generate credit score for customer |
| GET | `/credit/{cid}` | Any | Get latest credit score |

### Loans (`/loans`)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| POST | `/loans/apply` | CUSTOMER | Apply for a loan |
| GET | `/loans/my` | CUSTOMER | List own loans |
| GET | `/loans/pending` | ADMIN | List pending loan applications |
| GET | `/loans/all` | ADMIN | List all loans |
| POST | `/loans/approve/{id}` | ADMIN | Approve a pending loan |
| GET | `/loans/{id}` | Any | Loan detail with EMI schedule |
| GET | `/loans/customer/{cid}` | ADMIN | Loans for a specific customer |

### Payments (`/payments`)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/payments/my` | CUSTOMER | List own payment history |
| POST | `/payments/process/{lid}` | Any | Process next EMI payment |
| GET | `/payments/{lid}` | Any | Payment history for a loan |

### Reporting (`/reporting`)
| Method | Path | Auth | Description |
|--------|------|------|-------------|
| GET | `/reporting/monthly` | ADMIN | Monthly aggregate report |
| GET | `/reporting/portfolio` | ADMIN | Portfolio-level report |

---

## Frontend Pages

| Page Component | Route | Role | Description |
|---------------|-------|------|-------------|
| `Login.jsx` | `/login` | Public | JWT login form |
| `Register.jsx` | `/register` | Public | User registration form |
| `Dashboard.jsx` | `/dashboard` | ADMIN | Admin overview: totals, pending items |
| `CustomerDashboard.jsx` | `/customer-dashboard` | CUSTOMER | Customer overview: loans, payments |
| `CreateCustomer.jsx` | `/create-customer` | ADMIN | Create new customer profile |
| `SubmitKYC.jsx` | `/submit-kyc` | CUSTOMER | Upload PAN/Aadhaar documents |
| `VerifyKYC.jsx` | `/verify-kyc` | ADMIN | Review and approve/reject KYC |
| `GenerateCreditScore.jsx` | `/generate-credit-score` | ADMIN | Generate credit score for customers |
| `ApplyLoan.jsx` | `/apply-loan` | CUSTOMER | Loan application form |
| `MyLoans.jsx` | `/my-loans` | CUSTOMER | List of customer's own loans |
| `LoanApproval.jsx` | `/loan-approval` | ADMIN | Approve/reject pending loans |
| `LoanDetails.jsx` | `/loan/:id` | Any | Loan detail view with EMI schedule |
| `EMICalculator.jsx` | `/emi-calculator` | Any | Interactive EMI calculator tool |
| `PaymentProcessing.jsx` | `/payment-processing` | Any | Process EMI payments |
| `PaymentHistory.jsx` | `/payment-history` | Any | View payment transaction history |
| `Profile.jsx` | `/profile` | CUSTOMER | View/edit customer profile |
| `Reports.jsx` | `/reports` | ADMIN | Monthly and portfolio reports |

The frontend uses **React Router v6** for navigation and a sidebar (`Sidebar.jsx`) for the main layout.  Authentication state is managed via `AuthContext.jsx` with JWT stored in `localStorage`.

---

## Business Rules & Workflow

### Loan Eligibility Pre-checks (at application time)

1. **KYC must be APPROVED** — customer cannot apply without verified identity.
2. **Credit score ≥ 650** — minimum credit score (`MIN_CREDIT_SCORE`).
3. **Loan amount ≤ 50× monthly income** — `MAX_LOAN_MULTIPLIER`.
4. **EMI ≤ 40% of monthly income** — `MAX_EMI_INCOME_RATIO`.

### Loan Lifecycle

```
Customer applies           Admin reviews             Auto-disburse
 ┌──────────┐     ┌──────────────┐     ┌────────────────────────────┐
 │  PENDING  │ ──▶ │  APPROVED /  │ ──▶ │  DISBURSED                 │
 └──────────┘     │  REJECTED    │     │  + EMI schedule generated   │
                  └──────────────┘     └────────┬───────────────────┘
                                                │ all EMIs paid
                                       ┌────────▼───────┐
                                       │     CLOSED      │
                                       └────────────────┘
```

### EMI Calculation

Standard reducing-balance formula:

```
EMI = [P × R × (1+R)^N] / [(1+R)^N − 1]
```

Where: P = principal, R = monthly rate (annual_rate / 12 / 100), N = tenure months.

### Credit Score Simulation

Weighted composite:
- **Income factor** (40%): Higher income → higher score.
- **Employment type** (20%): SALARIED > BUSINESS > SELF_EMPLOYED.
- **Age factor** (15%): Sweet spot around 30–50 years.
- **Loan history** (25%): Responsible repayment history boosts score.

Score ranges:
| Range | Risk Category |
|-------|---------------|
| 750–900 | LOW |
| 650–749 | MEDIUM |
| 550–649 | HIGH |
| 300–549 | VERY_HIGH |

### Late Fee Calculation

If an EMI payment is past its due date, a late fee is calculated and added to the payment amount.  Specific logic in `payments/service.py`.

---

## Authentication & Authorisation

- **JWT-based**: Tokens issued on login with HS256 algorithm.
- **Token expiry**: 60 minutes (configurable).
- **Roles**: `ADMIN` and `CUSTOMER`.
- **Password hashing**: bcrypt via `passlib`.
- **Frontend**: Axios interceptor attaches `Authorization: Bearer <token>` header; 401 responses auto-redirect to `/login`.

### Common dependency functions (in `shared/deps.py`)

- `get_current_user(token)` — decode JWT, fetch user from DB.
- Admin-only guards on sensitive endpoints.
- Customer-to-customer-id resolution for self-service endpoints.

---

## Event / Notification System

The `notifications/service.py` module provides an **in-memory event bus** that simulates a production message broker (e.g. Kafka):

| Event | Trigger |
|-------|---------|
| `KYC_SUBMITTED` | Customer uploads KYC documents |
| `KYC_APPROVED` | Admin approves KYC |
| `KYC_REJECTED` | Admin rejects KYC |
| `CREDIT_GENERATED` | Credit score is generated |
| `LOAN_APPLIED` | Customer submits loan application |
| `LOAN_APPROVED` | Admin approves loan |
| `LOAN_REJECTED` | Admin rejects loan |
| `LOAN_DISBURSED` | Loan is disbursed after approval |
| `PAYMENT_SUCCESS` | EMI payment succeeds |
| `PAYMENT_FAILED` | EMI payment fails |
| `PAYMENT_OVERDUE` | EMI payment is past due date |

Events are logged and can trigger downstream handlers (e.g. notifications, auditing).

---

## Configuration

Environment variables loaded from `.env` via `pydantic-settings`:

| Variable | Default | Description |
|----------|---------|-------------|
| `SECRET_KEY` | `los-super-secret-key-...` | JWT signing key |
| `ALGORITHM` | `HS256` | JWT algorithm |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | `60` | Token lifetime |
| `DATABASE_URL` | `sqlite:///./app/database/los.db` | SQLAlchemy DB URL |

---

## Running the Application

### Backend

```bash
cd LOS/backend
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

API docs at: `http://localhost:8000/docs`

### Frontend

```bash
cd LOS/frontend
npm install
npm run dev
```

Frontend at: `http://localhost:5173`

### Seed Data

```bash
cd LOS/backend
python seed_data.py
```

Creates sample admin/customer users, customer profiles, KYC records, credit scores, loans, EMI schedules, and payments for testing.
