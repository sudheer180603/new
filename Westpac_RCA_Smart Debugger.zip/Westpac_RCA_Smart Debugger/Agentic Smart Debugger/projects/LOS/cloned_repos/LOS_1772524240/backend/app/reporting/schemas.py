"""
Reporting schemas for response validation.
"""

from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class LoanSummary(BaseModel):
    """Summary of a loan for reports."""
    loan_id: int
    customer_id: int
    loan_amount: float
    status: str
    emi_amount: float


class MonthlyReportResponse(BaseModel):
    """Monthly report response."""
    report_period: str
    total_loans_issued: int
    total_amount_disbursed: float
    total_collections: float
    active_loans: int
    closed_loans: int
    rejected_loans: int
    default_loans: int
    average_loan_amount: float
    generated_at: datetime


class PortfolioReportResponse(BaseModel):
    """Portfolio report response."""
    total_customers: int
    total_loans: int
    total_disbursed: float
    total_outstanding: float
    total_collections: float
    active_loans: int
    closed_loans: int
    npa_count: int
    npa_amount: float
    average_credit_score: float
    loan_by_status: dict
    generated_at: datetime
