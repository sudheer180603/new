"""
Credit scoring service. Simulates credit score generation.
"""

import logging
import random
import json
from sqlalchemy.orm import Session
from app.credit.models import CreditScore
from app.customers.models import Customer
from app.kyc.models import KYCRecord, KYCStatus
from app.notifications.service import emit_event

logger = logging.getLogger(__name__)

# Credit scoring factors for simulation
CREDIT_FACTORS = [
    "Payment history",
    "Credit utilization ratio",
    "Length of credit history",
    "Credit mix",
    "New credit inquiries",
    "Outstanding debt",
    "Employment stability",
    "Income level",
]


def _classify_risk(score: int) -> str:
    """
    Classify a credit score into a risk category string.

    Uses standard banking risk bands:

    * ``"LOW"``      — score ≥ 750 (prime borrower)
    * ``"MEDIUM"``   — score 650–749 (near-prime)
    * ``"HIGH"``     — score 500–649 (sub-prime)
    * ``"VERY_HIGH"``— score < 500  (deep sub-prime)

    Args:
        score (int): The numeric credit score in the range 300–900.

    Returns:
        str: One of ``"LOW"``, ``"MEDIUM"``, ``"HIGH"``, or
            ``"VERY_HIGH"``.
    """
    if score >= 750:
        return "LOW"
    elif score >= 650:
        return "MEDIUM"
    elif score >= 500:
        return "HIGH"
    else:
        return "VERY_HIGH"


def _generate_factors(score: int) -> str:
    """
    Generate a JSON-encoded list of simulated credit-score factors.

    Randomly selects four factors from the global ``CREDIT_FACTORS`` list
    and assigns each a ``"POSITIVE"`` or ``"NEGATIVE"`` impact label.
    For borrowers with a score ≥ 650 all selected factors are marked
    ``"POSITIVE"`` to reflect a healthy credit profile; below that
    threshold impacts are randomised.

    Args:
        score (int): The numeric credit score used to bias the impact
            assignment.

    Returns:
        str: A JSON string representing a list of dicts, each containing
            ``"factor"`` (str) and ``"impact"`` (``"POSITIVE"`` or
            ``"NEGATIVE"``) keys.

    Example return value::

        '[{"factor": "Payment history", "impact": "POSITIVE"}, ...]'
    """
    selected = random.sample(CREDIT_FACTORS, min(4, len(CREDIT_FACTORS)))
    factor_details = []
    for factor in selected:
        impact = "POSITIVE" if score >= 650 else random.choice(["POSITIVE", "NEGATIVE"])
        factor_details.append({"factor": factor, "impact": impact})
    return json.dumps(factor_details)


def generate_credit_score(db: Session, customer_id: int) -> CreditScore:
    """
    Generate (or refresh) a simulated credit score for a customer.

    The score is computed from a base value of 500 plus three adjustments:

    * **Income factor** — up to +200 points based on monthly income
      (₹10,000 increments contribute +30 each, capped at +200).
    * **Employment factor** — +50 for ``SALARIED`` employees, +20 for all
      other employment types.
    * **Random factor** — a uniform random integer in [-50, +100] to
      simulate market/behavioural variance.

    The final score is clamped to [300, 900].  Requires KYC to be in
    ``APPROVED`` state.  If a ``CreditScore`` record already exists for
    the customer it is updated in place; otherwise a new record is created.
    Emits a ``CREDIT_GENERATED`` event in both cases.

    Args:
        db (Session): Active SQLAlchemy database session.
        customer_id (int): Primary key of the customer to score.

    Returns:
        CreditScore: The created or updated ``CreditScore`` ORM instance
            with the computed ``score``, ``risk_category``, and
            ``factors`` fields populated.

    Raises:
        ValueError: If the customer does not exist.
        ValueError: If the customer's KYC is not in ``APPROVED`` state.
    """
    # Check customer exists
    customer = db.query(Customer).filter(Customer.id == customer_id).first()
    if not customer:
        raise ValueError(f"Customer with ID {customer_id} not found")

    # Check KYC is approved
    kyc = db.query(KYCRecord).filter(
        KYCRecord.customer_id == customer_id,
        KYCRecord.status == KYCStatus.APPROVED,
    ).first()
    if not kyc:
        raise ValueError("KYC must be APPROVED before generating credit score")

    # Generate score based on income (simulation)
    base_score = 500
    income_factor = min(int(customer.monthly_income / 10000) * 30, 200)
    employment_factor = 50 if customer.employment_type == "SALARIED" else 20
    random_factor = random.randint(-50, 100)
    score = max(300, min(900, base_score + income_factor + employment_factor + random_factor))

    # Check for existing score and update
    existing = db.query(CreditScore).filter(CreditScore.customer_id == customer_id).first()
    if existing:
        existing.score = score
        existing.risk_category = _classify_risk(score)
        existing.factors = _generate_factors(score)
        db.commit()
        db.refresh(existing)
        emit_event("CREDIT_GENERATED", {"customer_id": customer_id, "score": score})
        return existing

    credit_score = CreditScore(
        customer_id=customer_id,
        score=score,
        risk_category=_classify_risk(score),
        factors=_generate_factors(score),
    )
    db.add(credit_score)
    db.commit()
    db.refresh(credit_score)
    logger.info(f"Credit score generated for customer {customer_id}: {score}")

    emit_event("CREDIT_GENERATED", {"customer_id": customer_id, "score": score})
    return credit_score


def get_credit_score(db: Session, customer_id: int) -> CreditScore:
    """
    Retrieve the most recent credit score record for a customer.

    Args:
        db (Session): Active SQLAlchemy database session.
        customer_id (int): Primary key of the customer to look up.

    Returns:
        CreditScore: The ``CreditScore`` ORM instance for the customer.

    Raises:
        ValueError: If no credit score has been generated for the given
            ``customer_id``.
    """
    score = db.query(CreditScore).filter(CreditScore.customer_id == customer_id).first()
    if not score:
        raise ValueError(f"Credit score not found for customer {customer_id}")
    return score
