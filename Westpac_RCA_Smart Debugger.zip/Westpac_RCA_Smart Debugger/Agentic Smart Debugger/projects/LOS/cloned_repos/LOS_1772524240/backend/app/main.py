"""
Digital Loan Origination System (LOS) - Main Application

A comprehensive banking loan origination system built with FastAPI.
Supports customer onboarding, KYC, credit scoring, loan processing,
payment management, and regulatory reporting.
"""

import logging
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Import database engine and all models to ensure table creation
from app.database.engine import engine, Base
from app.auth.models import User
from app.customers.models import Customer
from app.kyc.models import KYCRecord
from app.credit.models import CreditScore
from app.loans.models import Loan, EMISchedule
from app.payments.models import Payment
from app.reporting.models import Report

# Import routers
from app.auth.routes import router as auth_router
from app.customers.routes import router as customer_router
from app.kyc.routes import router as kyc_router
from app.credit.routes import router as credit_router
from app.loans.routes import router as loan_router
from app.payments.routes import router as payment_router
from app.reporting.routes import router as reporting_router

# Create FastAPI application
app = FastAPI(
    title="Digital Loan Origination System (LOS)",
    description="Enterprise-grade Loan Origination System for retail banking",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS configuration - allow React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include all routers
app.include_router(auth_router)
app.include_router(customer_router)
app.include_router(kyc_router)
app.include_router(credit_router)
app.include_router(loan_router)
app.include_router(payment_router)
app.include_router(reporting_router)


@app.on_event("startup")
def startup_event():
    """
    Application startup handler — initialise the database schema.

    Invoked automatically by FastAPI when the server starts.  Creates all
    SQLAlchemy ORM tables that do not yet exist in the database (idempotent
    — existing tables are not modified).  Also ensures the database
    directory is present on the filesystem before attempting table creation.

    Logs startup confirmation messages and the URL of the interactive API
    documentation.

    Returns:
        None
    """
    # Ensure database directory exists
    db_dir = os.path.join(os.path.dirname(__file__), "database")
    os.makedirs(db_dir, exist_ok=True)

    Base.metadata.create_all(bind=engine)
    logger.info("✅ Database tables created successfully")
    logger.info("✅ LOS Application started")
    logger.info("📄 API Docs: http://localhost:8000/docs")


@app.get("/", tags=["Root"])
def root():
    """
    Root endpoint — basic health and identity check.

    Returns a JSON object confirming the application name, version, and
    current running status.  Also surfaces the URL of the Swagger UI docs
    for quick discoverability.

    Returns:
        dict: A JSON-serialisable dict with ``app``, ``version``,
            ``status``, and ``docs`` keys.
    """
    return {
        "app": "Digital Loan Origination System",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs",
    }


@app.get("/health", tags=["Root"])
def health_check():
    """
    Health check endpoint for load balancers and monitoring systems.

    Returns a simple ``{"status": "healthy"}`` response with HTTP 200.
    Used by infrastructure components (e.g. Kubernetes liveness probes,
    AWS ALB health checks) to verify the application process is alive and
    accepting connections.

    Returns:
        dict: ``{"status": "healthy"}``
    """
    return {"status": "healthy"}
