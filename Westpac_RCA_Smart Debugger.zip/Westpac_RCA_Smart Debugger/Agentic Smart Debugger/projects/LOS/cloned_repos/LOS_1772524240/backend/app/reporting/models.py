"""
Report model for regulatory reporting.
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, Text
from sqlalchemy.sql import func
from app.database.engine import Base


class Report(Base):
    """Generated reports table."""
    __tablename__ = "reports"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    report_type = Column(String(30), nullable=False)  # MONTHLY, PORTFOLIO
    report_period = Column(String(20), nullable=False)  # e.g. "2024-01"
    total_loans = Column(Integer, default=0)
    total_disbursed = Column(Float, default=0.0)
    total_collections = Column(Float, default=0.0)
    active_loans = Column(Integer, default=0)
    npa_count = Column(Integer, default=0)  # Non-performing assets
    npa_amount = Column(Float, default=0.0)
    average_credit_score = Column(Float, default=0.0)
    report_data = Column(Text, nullable=True)  # JSON string for detailed data
    generated_at = Column(DateTime, server_default=func.now())
    generated_by = Column(Integer, nullable=True)
