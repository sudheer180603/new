"""
Auth API routes for registration and login.
"""

import logging
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.engine import get_db
from app.auth.schemas import UserCreate, UserLogin, Token, UserResponse
from app.auth.service import register_user, authenticate_user, create_access_token

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/auth", tags=["Authentication"])


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(user_data: UserCreate, db: Session = Depends(get_db)):
    """
    Register a new user account.

    Accepts user details in the request body, delegates to
    ``register_user`` in the auth service, and returns the newly created
    user object.  Returns HTTP 400 if the username or email is already
    taken.

    Args:
        user_data (UserCreate): Request body containing ``username``,
            ``email``, ``password``, ``full_name``, and optional ``role``
            (defaults to ``CUSTOMER``).
        db (Session): SQLAlchemy session injected by ``get_db``.

    Returns:
        UserResponse: Serialized representation of the created user,
            including ``id``, ``username``, ``email``, ``full_name``,
            ``role``, ``is_active``, and ``created_at``.

    Raises:
        HTTPException (400 BAD REQUEST): If the username or email address is
            already registered.
    """
    try:
        user = register_user(db, user_data)
        return user
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post("/login", response_model=Token)
def login(login_data: UserLogin, db: Session = Depends(get_db)):
    """
    Authenticate a user and return a JWT access token.

    Validates the supplied credentials via ``authenticate_user``.  On
    success, issues a signed JWT containing the username (``sub`` claim)
    and role, then returns the token together with basic user information
    so the frontend can bootstrap its session without an extra round-trip.

    Args:
        login_data (UserLogin): Request body containing ``username`` and
            ``password``.
        db (Session): SQLAlchemy session injected by ``get_db``.

    Returns:
        Token: Object containing ``access_token``, ``token_type``
            (``"bearer"``), ``user_id``, ``username``, and ``role``.

    Raises:
        HTTPException (401 UNAUTHORIZED): If the username does not exist or
            the password is incorrect.  The ``WWW-Authenticate: Bearer``
            header is included per RFC 6750.
    """
    user = authenticate_user(db, login_data)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    access_token = create_access_token(data={"sub": user.username, "role": user.role.value})
    return Token(
        access_token=access_token,
        user_id=user.id,
        username=user.username,
        role=user.role.value,
    )
