"""
Internal event simulation service (replaces Kafka).
Logs events and triggers downstream actions.
"""

import logging
from typing import Dict, Any

logger = logging.getLogger(__name__)

# In-memory event log for simulation
event_log = []


def emit_event(event_type: str, payload: Dict[str, Any]):
    """
    Emit an application event and trigger any registered downstream handlers.

    In a production environment this function would publish the event to a
    message broker (e.g. Apache Kafka or RabbitMQ).  In this simulation it
    appends the event to the in-memory ``event_log`` list, writes an INFO
    log entry, then synchronously dispatches the event to ``_handle_event``
    to mimic downstream consumer behaviour.

    Args:
        event_type (str): The canonical name of the event.  Supported
            values include:

            * ``"KYC_SUBMITTED"``
            * ``"KYC_APPROVED"``
            * ``"KYC_REJECTED"``
            * ``"CREDIT_GENERATED"``
            * ``"LOAN_APPLIED"``
            * ``"LOAN_APPROVED"``
            * ``"LOAN_REJECTED"``
            * ``"LOAN_DISBURSED"``
            * ``"PAYMENT_SUCCESS"``
            * ``"PAYMENT_FAILED"``
            * ``"PAYMENT_OVERDUE"``

        payload (Dict[str, Any]): Arbitrary key-value data associated with
            the event (e.g. ``{"loan_id": 42, "customer_id": 7}``).

    Returns:
        None
    """
    event = {
        "event_type": event_type,
        "payload": payload,
    }
    event_log.append(event)
    logger.info(f"[EVENT] {event_type}: {payload}")

    # Simulate downstream event handlers
    _handle_event(event_type, payload)


def _handle_event(event_type: str, payload: Dict[str, Any]):
    """
    Internal dispatcher that maps event types to their simulated handlers.

    Mimics the consumer side of an event-driven architecture by looking up
    the ``event_type`` in a handler dictionary and invoking the
    corresponding lambda.  Each handler logs a descriptive message to
    represent the downstream action that would normally be performed by a
    separate microservice (e.g. sending an SMS, updating a ledger, or
    scheduling a job).

    Args:
        event_type (str): The event type string, as passed to
            ``emit_event``.
        payload (Dict[str, Any]): The event payload forwarded from
            ``emit_event``.

    Returns:
        None
    """
    handlers = {
        "KYC_APPROVED": lambda p: logger.info(f"→ Credit generation now available for customer {p.get('customer_id')}"),
        "CREDIT_GENERATED": lambda p: logger.info(f"→ Loan application now available for customer {p.get('customer_id')}"),
        "LOAN_APPROVED": lambda p: logger.info(f"→ EMI schedule created for loan {p.get('loan_id')}"),
        "LOAN_DISBURSED": lambda p: logger.info(f"→ Disbursement notification sent for loan {p.get('loan_id')}"),
        "PAYMENT_SUCCESS": lambda p: logger.info(f"→ Payment confirmation for EMI #{p.get('emi_number')} on loan {p.get('loan_id')}"),
        "PAYMENT_FAILED": lambda p: logger.info(f"→ Late fee applied for EMI #{p.get('emi_number')} on loan {p.get('loan_id')}"),
        "PAYMENT_OVERDUE": lambda p: logger.info(f"→ Overdue notice sent for loan {p.get('loan_id')}"),
    }
    handler = handlers.get(event_type)
    if handler:
        handler(payload)


def get_event_log():
    """
    Return the in-memory event log for the current application session.

    Provides access to the accumulated list of all events emitted since the
    application started.  Useful for debugging, testing, and auditing event
    flows without a real message broker.

    Returns:
        List[dict]: The global ``event_log`` list.  Each entry is a dict
            with ``"event_type"`` (str) and ``"payload"`` (dict) keys.
    """
    return event_log
