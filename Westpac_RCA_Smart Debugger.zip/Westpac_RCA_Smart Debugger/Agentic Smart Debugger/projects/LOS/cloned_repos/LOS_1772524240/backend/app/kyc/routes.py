"""
KYC API routes.
- Submit KYC: CUSTOMER (auto-detect from JWT, file upload)
- Approve/Reject KYC: ADMIN only
- Check KYC status: /me for customer, /{customer_id} for admin
- Download files: ADMIN only
- List all: ADMIN only
"""

import os
import logging
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status, UploadFile, File
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from app.database.engine import get_db
from app.kyc.schemas import KYCApproveRequest, KYCResponse
from app.kyc.service import submit_kyc, approve_kyc, get_kyc_by_customer, get_all_kyc_records
from app.customers.service import get_customer_by_user_id
from app.shared.deps import get_current_user, require_role
from app.auth.models import User, UserRole

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/kyc", tags=["KYC"])

_admin = require_role(UserRole.ADMIN)

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "uploads", "kyc")


@router.post("/submit", response_model=KYCResponse)
async def submit_customer_kyc(
    pan_file: UploadFile = File(...),
    aadhaar_file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Submit KYC documents (PAN card + Aadhaar card) for the authenticated customer.

    Auto-detects the customer profile from the JWT token.  Both files must
    be PDFs.  Uploaded files are saved under
    ``uploads/kyc/<customer_id>/pan.pdf`` and
    ``uploads/kyc/<customer_id>/aadhaar.pdf``, then the KYC record is
    created or updated with status ``PENDING``.

    Args:
        pan_file (UploadFile): Multipart PDF upload for the PAN card
            document.
        aadhaar_file (UploadFile): Multipart PDF upload for the Aadhaar
            card document.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Authenticated user extracted from the JWT token.

    Returns:
        KYCResponse: The newly created or updated KYC record with status
            ``PENDING``.

    Raises:
        HTTPException (404 NOT FOUND): If the authenticated user does not
            have a customer profile.
        HTTPException (400 BAD REQUEST): If either file is not a PDF.
        HTTPException (400 BAD REQUEST): If the KYC is already ``APPROVED``
            and cannot be re-submitted.
    """
    # Auto-detect customer from JWT
    try:
        from app.customers.service import get_customer_by_user_id
        customer = get_customer_by_user_id(db, current_user.id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No customer profile found. Please complete your profile first."
        )

    # Validate file types
    for f, label in [(pan_file, "PAN"), (aadhaar_file, "Aadhaar")]:
        if not f.filename.lower().endswith(".pdf"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"{label} document must be a PDF file"
            )

    # Create upload directory
    customer_dir = os.path.join(UPLOAD_DIR, str(customer.id))
    os.makedirs(customer_dir, exist_ok=True)

    # Save PAN file
    pan_path = os.path.join(customer_dir, "pan.pdf")
    with open(pan_path, "wb") as f:
        content = await pan_file.read()
        f.write(content)

    # Save Aadhaar file
    aadhaar_path = os.path.join(customer_dir, "aadhaar.pdf")
    with open(aadhaar_path, "wb") as f:
        content = await aadhaar_file.read()
        f.write(content)

    try:
        return submit_kyc(db, customer.id, pan_path, aadhaar_path)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get("/me", response_model=KYCResponse)
def get_my_kyc_status(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Get the KYC status for the currently authenticated user's customer profile.

    Resolves the customer from the JWT token and returns their latest KYC
    record.  Accessible by any authenticated user.

    Args:
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Authenticated user extracted from the JWT token.

    Returns:
        KYCResponse: The KYC record for the current user's customer profile,
            including status, remarks, and verification timestamps.

    Raises:
        HTTPException (404 NOT FOUND): If no customer profile or KYC record
            is found for the current user.
    """
    try:
        customer = get_customer_by_user_id(db, current_user.id)
        return get_kyc_by_customer(db, customer.id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get("/all", response_model=List[KYCResponse])
def list_all_kyc(
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin),
):
    """
    List all KYC records across all customers.

    Restricted to ADMIN users.  Returns records ordered by creation date
    (newest first), allowing admins to process the verification queue.

    Args:
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by ``_admin``
            dependency).

    Returns:
        List[KYCResponse]: All KYC records in the system, newest first.

    Raises:
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
    """
    return get_all_kyc_records(db)


@router.post("/approve/{customer_id}", response_model=KYCResponse)
def approve_customer_kyc(
    customer_id: int,
    approval: KYCApproveRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin),
):
    """
    Approve or reject KYC documents for a specific customer.

    Restricted to ADMIN users.  Transitions the KYC record from ``PENDING``
    to either ``APPROVED`` or ``REJECTED`` and stores the admin's ID along
    with a timestamp.

    Args:
        customer_id (int): Primary key of the customer whose KYC is being
            reviewed.
        approval (KYCApproveRequest): Body containing ``approved`` (bool)
            and optional ``remarks`` (str).
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by ``_admin``
            dependency).

    Returns:
        KYCResponse: The updated KYC record with the new status.

    Raises:
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
        HTTPException (400 BAD REQUEST): If no KYC record exists for the
            customer, or if the record is not currently in ``PENDING`` state.
    """
    try:
        return approve_kyc(
            db, customer_id,
            approved=approval.approved,
            remarks=approval.remarks,
            verified_by=current_user.id,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get("/file/{customer_id}/{file_type}")
def download_kyc_file(
    customer_id: int,
    file_type: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin),
):
    """
    Download a KYC document PDF for a specific customer.

    Restricted to ADMIN users.  Serves either the PAN or Aadhaar PDF from
    the server's upload directory as a ``FileResponse``.

    Args:
        customer_id (int): Primary key of the customer whose file is being
            requested.
        file_type (str): Which document to download.  Must be either
            ``"pan"`` or ``"aadhaar"`` (case-sensitive).
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by ``_admin``
            dependency).

    Returns:
        FileResponse: The PDF file served with
            ``Content-Type: application/pdf`` and a filename of
            ``<file_type>_<customer_id>.pdf``.

    Raises:
        HTTPException (400 BAD REQUEST): If ``file_type`` is not ``"pan"``
            or ``"aadhaar"``.
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
        HTTPException (404 NOT FOUND): If the requested PDF file does not
            exist on the server's filesystem.
    """
    if file_type not in ("pan", "aadhaar"):
        raise HTTPException(status_code=400, detail="file_type must be 'pan' or 'aadhaar'")

    file_path = os.path.join(UPLOAD_DIR, str(customer_id), f"{file_type}.pdf")
    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail=f"{file_type.upper()} file not found")

    return FileResponse(file_path, media_type="application/pdf", filename=f"{file_type}_{customer_id}.pdf")


@router.get("/{customer_id}", response_model=KYCResponse)
def get_kyc_status(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Get the KYC status for a specific customer by their customer ID.

    Accessible by any authenticated user.  Admins typically use this to
    check an individual customer's KYC state; customers can use it to
    check their own status by ID.

    Args:
        customer_id (int): Primary key of the customer to look up.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Any authenticated user.

    Returns:
        KYCResponse: The KYC record for the specified customer.

    Raises:
        HTTPException (404 NOT FOUND): If no KYC record exists for the
            given ``customer_id``.
    """
    try:
        return get_kyc_by_customer(db, customer_id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
