"""
KYC schemas for request/response validation.
"""

from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class KYCApproveRequest(BaseModel):
    """Schema for admin to approve/reject KYC."""
    approved: bool
    remarks: Optional[str] = None


class KYCResponse(BaseModel):
    """KYC record response schema."""
    id: int
    customer_id: int
    pan_file_path: str
    aadhaar_file_path: str
    status: str
    remarks: Optional[str] = None
    verified_by: Optional[int] = None
    verified_at: Optional[datetime] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
