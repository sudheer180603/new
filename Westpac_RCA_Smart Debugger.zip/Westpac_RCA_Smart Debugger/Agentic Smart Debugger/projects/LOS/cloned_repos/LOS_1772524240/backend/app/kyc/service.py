"""
KYC service for customer identity verification.
Two-step flow:
  1. Customer uploads KYC documents (PAN + Aadhaar PDFs) → status = PENDING
  2. Admin approves or rejects → status = APPROVED / REJECTED
"""

import logging
from datetime import datetime
from sqlalchemy.orm import Session
from app.kyc.models import KYCRecord, KYCStatus
from app.customers.models import Customer
from app.notifications.service import emit_event

logger = logging.getLogger(__name__)


def submit_kyc(db: Session, customer_id: int, pan_file_path: str, aadhaar_file_path: str) -> KYCRecord:
    """
    Submit or re-submit KYC documents for a customer.

    Verifies that the customer exists and that their KYC is not already in
    an ``APPROVED`` state (approved KYC cannot be overwritten).  If an
    earlier ``PENDING`` or ``REJECTED`` record exists it is updated in place;
    otherwise a brand-new ``KYCRecord`` is created.  In both cases the
    status is set to ``PENDING`` and a ``KYC_SUBMITTED`` event is emitted.

    Args:
        db (Session): Active SQLAlchemy database session.
        customer_id (int): Primary key of the customer submitting KYC.
        pan_file_path (str): Absolute filesystem path where the PAN PDF has
            been saved.
        aadhaar_file_path (str): Absolute filesystem path where the Aadhaar
            PDF has been saved.

    Returns:
        KYCRecord: The created or updated ``KYCRecord`` ORM instance with
            status ``PENDING``.

    Raises:
        ValueError: If the customer does not exist.
        ValueError: If the customer's KYC is already ``APPROVED`` (cannot
            be re-submitted without admin intervention).
    """
    customer = db.query(Customer).filter(Customer.id == customer_id).first()
    if not customer:
        raise ValueError(f"Customer with ID {customer_id} not found")

    existing = db.query(KYCRecord).filter(KYCRecord.customer_id == customer_id).first()
    if existing and existing.status == KYCStatus.APPROVED:
        raise ValueError("KYC is already approved for this customer")

    if existing:
        existing.pan_file_path = pan_file_path
        existing.aadhaar_file_path = aadhaar_file_path
        existing.status = KYCStatus.PENDING
        existing.remarks = "KYC documents re-submitted, awaiting admin verification"
        existing.verified_by = None
        existing.verified_at = None
        db.commit()
        db.refresh(existing)
        logger.info(f"KYC re-submitted for customer {customer_id}")
        emit_event("KYC_SUBMITTED", {"customer_id": customer_id})
        return existing

    kyc_record = KYCRecord(
        customer_id=customer_id,
        pan_file_path=pan_file_path,
        aadhaar_file_path=aadhaar_file_path,
        status=KYCStatus.PENDING,
        remarks="KYC documents submitted, awaiting admin verification",
    )
    db.add(kyc_record)
    db.commit()
    db.refresh(kyc_record)
    logger.info(f"KYC submitted for customer {customer_id}")
    emit_event("KYC_SUBMITTED", {"customer_id": customer_id})
    return kyc_record


def approve_kyc(db: Session, customer_id: int, approved: bool, remarks: str = None, verified_by: int = None) -> KYCRecord:
    """
    Approve or reject a customer's pending KYC submission.

    Looks up the existing ``KYCRecord`` for the customer and transitions its
    status to either ``APPROVED`` or ``REJECTED``.  Only records currently in
    ``PENDING`` state may be actioned.  Records the verifying admin's
    ``user_id`` and the timestamp of the decision.  Emits a
    ``KYC_APPROVED`` or ``KYC_REJECTED`` event accordingly.

    Args:
        db (Session): Active SQLAlchemy database session.
        customer_id (int): Primary key of the customer whose KYC is being
            reviewed.
        approved (bool): ``True`` to approve, ``False`` to reject.
        remarks (str, optional): Human-readable note from the admin
            explaining the decision.  Defaults to a standard message if
            omitted.
        verified_by (int, optional): ``user_id`` of the admin performing
            the action, stored for audit purposes.

    Returns:
        KYCRecord: The updated ``KYCRecord`` ORM instance with the new
            status, remarks, verifier, and verification timestamp.

    Raises:
        ValueError: If no KYC record exists for the given ``customer_id``.
        ValueError: If the existing KYC record is not in ``PENDING`` state.
    """
    record = db.query(KYCRecord).filter(KYCRecord.customer_id == customer_id).first()
    if not record:
        raise ValueError(f"KYC record not found for customer {customer_id}")

    if record.status != KYCStatus.PENDING:
        raise ValueError(f"KYC is not in PENDING state (current: {record.status.value})")

    record.status = KYCStatus.APPROVED if approved else KYCStatus.REJECTED
    record.remarks = remarks or ("KYC approved by admin" if approved else "KYC rejected by admin")
    record.verified_by = verified_by
    record.verified_at = datetime.utcnow()
    db.commit()
    db.refresh(record)
    logger.info(f"KYC {'approved' if approved else 'rejected'} for customer {customer_id}")

    if approved:
        emit_event("KYC_APPROVED", {"customer_id": customer_id})
    else:
        emit_event("KYC_REJECTED", {"customer_id": customer_id})
    return record


def get_kyc_by_customer(db: Session, customer_id: int) -> KYCRecord:
    """
    Retrieve the KYC record for a specific customer.

    Args:
        db (Session): Active SQLAlchemy database session.
        customer_id (int): Primary key of the customer to look up.

    Returns:
        KYCRecord: The ``KYCRecord`` ORM instance for the customer.

    Raises:
        ValueError: If no KYC record is found for the given
            ``customer_id``.
    """
    record = db.query(KYCRecord).filter(KYCRecord.customer_id == customer_id).first()
    if not record:
        raise ValueError(f"KYC record not found for customer {customer_id}")
    return record


def get_all_kyc_records(db: Session):
    """
    Retrieve all KYC records ordered by creation date, newest first.

    Used by admins to view the full queue of pending, approved, and
    rejected KYC submissions.

    Args:
        db (Session): Active SQLAlchemy database session.

    Returns:
        List[KYCRecord]: All ``KYCRecord`` ORM instances ordered by
            ``created_at`` descending.
    """
    return db.query(KYCRecord).order_by(KYCRecord.created_at.desc()).all()
