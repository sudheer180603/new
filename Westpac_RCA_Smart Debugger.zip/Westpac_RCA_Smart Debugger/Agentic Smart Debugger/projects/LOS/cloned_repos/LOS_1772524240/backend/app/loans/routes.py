"""
Loan API routes.
- Apply: CUSTOMER (auto-detect from JWT)
- Approve/Reject: ADMIN only
- View pending: ADMIN only
- View own loans: CUSTOMER (auto-detect)
- View by ID: all authenticated
"""

import logging
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.engine import get_db
from app.loans.schemas import LoanApplyRequest, LoanApproveRequest, LoanResponse, LoanDetailResponse
from app.loans.service import (
    apply_for_loan, approve_loan, get_loan_by_id,
    get_loans_by_customer, get_pending_loans, get_all_loans,
)
from app.customers.service import get_customer_by_user_id
from app.shared.deps import get_current_user, require_role
from app.auth.models import User, UserRole

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/loans", tags=["Loans"])

_admin_only = require_role(UserRole.ADMIN)


@router.post("/apply", response_model=LoanResponse, status_code=status.HTTP_201_CREATED)
def apply_loan(
    loan_data: LoanApplyRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Submit a loan application on behalf of the authenticated user.

    Auto-detects the customer profile from the JWT token so the client does
    not need to supply a ``customer_id``.  Delegates eligibility checks to
    the loan service; returns the resulting loan record whether the outcome
    is ``PENDING`` (eligible) or ``REJECTED`` (ineligible).  Accessible by
    any authenticated user.

    Args:
        loan_data (LoanApplyRequest): Request body containing
            ``loan_amount``, ``tenure_months``, optional
            ``interest_rate``, and optional ``purpose``.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Authenticated user extracted from the JWT
            token.

    Returns:
        LoanResponse: The created loan record with calculated ``emi_amount``,
            ``total_payable``, ``total_interest``, and ``status``.

    Raises:
        HTTPException (400 BAD REQUEST): If no customer profile is linked
            to the user, KYC is not approved, credit score is missing, or
            any eligibility validation fails.
    """
    try:
        customer = get_customer_by_user_id(db, current_user.id)
        return apply_for_loan(db, loan_data, customer_id=customer.id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get("/my", response_model=List[LoanResponse])
def get_my_loans(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Retrieve all loan applications for the currently authenticated user.

    Auto-detects the customer profile from the JWT token.  Returns all
    loans for that customer regardless of their status.  Accessible by any
    authenticated user.

    Args:
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Authenticated user extracted from the JWT
            token.

    Returns:
        List[LoanResponse]: All loans associated with the current user's
            customer profile, ordered by creation date (newest first).

    Raises:
        HTTPException (404 NOT FOUND): If no customer profile is linked to
            the authenticated user.
    """
    try:
        customer = get_customer_by_user_id(db, current_user.id)
        return get_loans_by_customer(db, customer.id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get("/pending", response_model=List[LoanResponse])
def list_pending_loans(
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin_only),
):
    """
    List all loan applications awaiting admin review.

    Restricted to ADMIN users.  Returns only loans with status ``PENDING``,
    ordered newest-first, providing the admin's approval queue.

    Args:
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by
            ``_admin_only`` dependency).

    Returns:
        List[LoanResponse]: All pending loan applications.

    Raises:
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
    """
    return get_pending_loans(db)


@router.get("/all", response_model=List[LoanResponse])
def list_all_loans(
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin_only),
):
    """
    List all loans across all customers and statuses.

    Restricted to ADMIN users.  Provides a complete portfolio view for
    reporting and administration.

    Args:
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by
            ``_admin_only`` dependency).

    Returns:
        List[LoanResponse]: Every loan record in the system, ordered by
            creation date (newest first).

    Raises:
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
    """
    return get_all_loans(db)


@router.post("/approve/{loan_id}", response_model=LoanResponse)
def approve_reject_loan(
    loan_id: int,
    approval: LoanApproveRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin_only),
):
    """
    Approve or reject a specific pending loan application.

    Restricted to ADMIN users.  On approval the loan is immediately
    disbursed and its EMI schedule is auto-generated.  On rejection a
    reason is recorded.

    Args:
        loan_id (int): Primary key of the loan to process.
        approval (LoanApproveRequest): Body containing ``approved`` (bool)
            and optional ``remarks`` (str).
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by
            ``_admin_only`` dependency).

    Returns:
        LoanResponse: The updated loan record reflecting the new status
            (``DISBURSED`` or ``REJECTED``).

    Raises:
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
        HTTPException (400 BAD REQUEST): If the loan does not exist or is
            not in ``PENDING`` state.
    """
    try:
        return approve_loan(
            db, loan_id,
            approved=approval.approved,
            remarks=approval.remarks,
            approved_by=current_user.id,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get("/{loan_id}", response_model=LoanDetailResponse)
def get_loan(
    loan_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Retrieve detailed information for a specific loan including its EMI schedule.

    Returns the loan record together with the full amortisation schedule.
    Accessible by any authenticated user (customers can view their own loan
    details; admins can view any loan).

    Args:
        loan_id (int): Primary key of the loan to retrieve.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Any authenticated user.

    Returns:
        LoanDetailResponse: A composite object with ``loan`` (the loan
            record) and ``emi_schedule`` (list of instalment rows).

    Raises:
        HTTPException (404 NOT FOUND): If no loan with the given
            ``loan_id`` exists.
    """
    try:
        return get_loan_by_id(db, loan_id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.get("/customer/{customer_id}", response_model=List[LoanResponse])
def get_customer_loans(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Retrieve all loans for a specific customer by their customer ID.

    Any authenticated user may call this endpoint.  Typically used by
    admins to inspect a particular customer's lending history.

    Args:
        customer_id (int): Primary key of the customer whose loans are
            being requested.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Any authenticated user.

    Returns:
        List[LoanResponse]: All loans for the specified customer, ordered
            by creation date (newest first).
    """
    return get_loans_by_customer(db, customer_id)
