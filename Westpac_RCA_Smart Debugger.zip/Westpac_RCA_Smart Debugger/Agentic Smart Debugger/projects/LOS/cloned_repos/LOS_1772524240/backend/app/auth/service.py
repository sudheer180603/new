"""
Auth service for user registration, login, and JWT token management.
"""

import logging
from datetime import datetime, timedelta
from typing import Optional

from jose import jwt
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from app.auth.models import User, UserRole
from app.auth.schemas import UserCreate, UserLogin
from app.core.config import settings

logger = logging.getLogger(__name__)
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def _truncate_password(password: str) -> str:
    """
    Truncate a password string to a maximum of 72 bytes (UTF-8 encoded).

    bcrypt silently ignores bytes beyond the 72-byte boundary, which can
    cause two different passwords to hash identically if they share the same
    first 72 bytes.  This helper makes the truncation explicit and consistent.

    Args:
        password (str): The plain-text password supplied by the user.

    Returns:
        str: The password decoded back to a string after being capped at
            72 bytes.  Characters that cannot be decoded are silently ignored.
    """
    return password.encode("utf-8")[:72].decode("utf-8", errors="ignore")


def hash_password(password: str) -> str:
    """
    Hash a plain-text password using bcrypt.

    Passes the password through ``_truncate_password`` first to enforce the
    72-byte bcrypt limit, then uses the configured ``CryptContext`` (bcrypt
    scheme) to produce a salted hash.

    Args:
        password (str): The plain-text password to hash.

    Returns:
        str: The bcrypt-hashed password string suitable for storing in the
            database.
    """
    return pwd_context.hash(_truncate_password(password))


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify a plain-text password against a stored bcrypt hash.

    Applies the same 72-byte truncation used during hashing before calling
    ``CryptContext.verify`` to ensure consistent comparison.

    Args:
        plain_password (str): The raw password provided by the user at login.
        hashed_password (str): The bcrypt hash retrieved from the database.

    Returns:
        bool: ``True`` if the password matches the hash, ``False`` otherwise.
    """
    return pwd_context.verify(_truncate_password(plain_password), hashed_password)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    """
    Create a signed JWT access token.

    Encodes the supplied ``data`` payload with an expiry timestamp and signs
    it using the application's ``SECRET_KEY`` and ``ALGORITHM`` (HS256 by
    default).  If ``expires_delta`` is not provided, the token expires after
    ``ACCESS_TOKEN_EXPIRE_MINUTES`` minutes as configured in settings.

    Args:
        data (dict): Arbitrary claims to embed in the token payload.
            Typically includes ``{"sub": username, "role": role}``.
        expires_delta (Optional[timedelta]): Custom lifetime for the token.
            Defaults to ``None``, which falls back to the settings value.

    Returns:
        str: The encoded JWT string to be returned to the client.
    """
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def register_user(db: Session, user_data: UserCreate) -> User:
    """
    Register a new user account in the database.

    Validates that neither the requested username nor email address is
    already taken, maps the ``role`` string to the ``UserRole`` enum
    (defaulting to ``CUSTOMER`` for unrecognised values), hashes the
    password, persists the record, and returns the refreshed ORM instance.

    Args:
        db (Session): Active SQLAlchemy database session.
        user_data (UserCreate): Validated Pydantic schema containing
            ``username``, ``email``, ``password``, ``full_name``, and
            optional ``role``.

    Returns:
        User: The newly created and committed ``User`` ORM object.

    Raises:
        ValueError: If a user with the same username *or* email already
            exists in the database.
    """
    # Check if username or email already exists
    existing = db.query(User).filter(
        (User.username == user_data.username) | (User.email == user_data.email)
    ).first()
    if existing:
        raise ValueError("Username or email already registered")

    # Validate role
    try:
        role = UserRole(user_data.role)
    except ValueError:
        role = UserRole.CUSTOMER

    user = User(
        username=user_data.username,
        email=user_data.email,
        hashed_password=hash_password(user_data.password),
        full_name=user_data.full_name,
        role=role,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    logger.info(f"User registered: {user.username} with role {user.role}")
    return user


def authenticate_user(db: Session, login_data: UserLogin) -> Optional[User]:
    """
    Authenticate a user by verifying their username and password.

    Looks up the user by username and delegates password verification to
    ``verify_password``.  Returns ``None`` instead of raising an exception
    so that the calling route can return a generic 401 response without
    leaking whether the username or the password was incorrect.

    Args:
        db (Session): Active SQLAlchemy database session.
        login_data (UserLogin): Pydantic schema containing ``username``
            and ``password`` supplied by the client.

    Returns:
        Optional[User]: The matched ``User`` ORM instance if credentials are
            valid, or ``None`` if the username does not exist or the password
            is incorrect.
    """
    user = db.query(User).filter(User.username == login_data.username).first()
    if not user or not verify_password(login_data.password, user.hashed_password):
        return None
    logger.info(f"User authenticated: {user.username}")
    return user
