"""
Credit score schemas for request/response validation.
"""

from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class CreditScoreResponse(BaseModel):
    """Credit score response schema."""
    id: int
    customer_id: int
    score: int
    risk_category: str
    factors: Optional[str] = None
    generated_at: Optional[datetime] = None

    class Config:
        from_attributes = True
