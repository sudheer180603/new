"""
Core configuration module.
Loads settings from environment variables via .env file.
"""

from pydantic_settings import BaseSettings
from pathlib import Path


class Settings(BaseSettings):
    """Application settings loaded from .env file."""

    SECRET_KEY: str = "los-super-secret-key-change-in-production-2024"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    DATABASE_URL: str = "sqlite:///./app/database/los.db"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


settings = Settings()
