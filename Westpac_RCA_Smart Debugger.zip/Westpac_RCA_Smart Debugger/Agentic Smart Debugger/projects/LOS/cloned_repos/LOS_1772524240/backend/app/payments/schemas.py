"""
Payment schemas for request/response validation.
"""

from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class PaymentProcessRequest(BaseModel):
    """Schema for processing a payment."""
    emi_number: int
    amount: Optional[float] = None  # If null, pay the full EMI
    payment_method: str = "AUTO_DEBIT"
    simulate_failure: bool = False  # For testing late fees


class PaymentResponse(BaseModel):
    """Payment response schema."""
    id: int
    loan_id: int
    emi_number: int
    amount: float
    late_fee: float
    total_amount: float
    status: str
    payment_method: str
    transaction_ref: Optional[str] = None
    remarks: Optional[str] = None
    paid_at: Optional[datetime] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
