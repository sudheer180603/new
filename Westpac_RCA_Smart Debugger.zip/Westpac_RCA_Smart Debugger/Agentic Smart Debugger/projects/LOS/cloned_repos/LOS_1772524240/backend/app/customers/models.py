"""
Customer model for customer onboarding.
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, Date, ForeignKey
from sqlalchemy.sql import func
from app.database.engine import Base


class Customer(Base):
    """Customer table for onboarded bank customers."""
    __tablename__ = "customers"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True, unique=True, index=True)
    first_name = Column(String(50), nullable=False)
    last_name = Column(String(50), nullable=False)
    email = Column(String(100), unique=True, nullable=False, index=True)
    phone = Column(String(15), nullable=False)
    date_of_birth = Column(Date, nullable=False)
    address = Column(String(255), nullable=False)
    city = Column(String(50), nullable=False)
    state = Column(String(50), nullable=False)
    pincode = Column(String(10), nullable=False)
    monthly_income = Column(Float, nullable=False)
    employment_type = Column(String(30), nullable=False)  # SALARIED, SELF_EMPLOYED, BUSINESS
    company_name = Column(String(100), nullable=True)
    created_by = Column(Integer, nullable=True)  # user_id of creator
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
