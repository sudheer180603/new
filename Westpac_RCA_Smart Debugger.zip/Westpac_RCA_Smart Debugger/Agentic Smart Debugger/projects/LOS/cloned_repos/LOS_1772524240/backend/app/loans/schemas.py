"""
Loan schemas for request/response validation.
"""

from pydantic import BaseModel, field_validator
from typing import Optional, List
from datetime import datetime, date


class LoanApplyRequest(BaseModel):
    """Schema for loan application. Customer applies themselves; customer_id auto-detected."""
    loan_amount: float
    tenure_months: int
    interest_rate: float = 10.5  # Default annual interest rate
    purpose: Optional[str] = None

    @field_validator("tenure_months")
    @classmethod
    def validate_tenure(cls, v):
        if v < 6 or v > 60:
            raise ValueError("Tenure must be between 6 and 60 months")
        return v

    @field_validator("loan_amount")
    @classmethod
    def validate_amount(cls, v):
        if v <= 0:
            raise ValueError("Loan amount must be positive")
        return v


class LoanApproveRequest(BaseModel):
    """Schema for admin to approve/reject a loan."""
    approved: bool
    remarks: Optional[str] = None


class EMIScheduleResponse(BaseModel):
    """EMI schedule item response."""
    id: int
    loan_id: int
    emi_number: int
    due_date: date
    emi_amount: float
    principal_component: float
    interest_component: float
    outstanding_balance: float
    status: str
    paid_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class LoanResponse(BaseModel):
    """Loan response schema."""
    id: int
    customer_id: int
    loan_amount: float
    interest_rate: float
    tenure_months: int
    emi_amount: float
    total_payable: float
    total_interest: float
    status: str
    purpose: Optional[str] = None
    rejection_reason: Optional[str] = None
    disbursed_at: Optional[datetime] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class LoanDetailResponse(BaseModel):
    """Loan detail with EMI schedule."""
    loan: LoanResponse
    emi_schedule: List[EMIScheduleResponse] = []
