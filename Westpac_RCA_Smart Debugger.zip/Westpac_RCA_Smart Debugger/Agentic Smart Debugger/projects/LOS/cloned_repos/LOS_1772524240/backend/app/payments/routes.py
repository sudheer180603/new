"""
Payment API routes.
"""

import logging
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.engine import get_db
from app.payments.schemas import PaymentProcessRequest, PaymentResponse
from app.payments.service import process_payment, get_payments_by_loan, get_payments_by_customer
from app.customers.service import get_customer_by_user_id
from app.shared.deps import get_current_user
from app.auth.models import User

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/payments", tags=["Payments"])


@router.get("/my", response_model=List[PaymentResponse])
def get_my_payments(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Retrieve the full payment history for the currently authenticated user.

    Auto-detects the customer profile from the JWT token, then fetches all
    payment transactions across all of that customer's loans, ordered by
    payment date (newest first).  Accessible by any authenticated user.

    Args:
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Authenticated user extracted from the JWT
            token.

    Returns:
        List[PaymentResponse]: All payment records for the user's loans,
            newest first.

    Raises:
        HTTPException (404 NOT FOUND): If no customer profile is linked to
            the authenticated user.
    """
    try:
        customer = get_customer_by_user_id(db, current_user.id)
        return get_payments_by_customer(db, customer.id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.post("/process/{loan_id}", response_model=PaymentResponse)
def process_loan_payment(
    loan_id: int,
    payment_data: PaymentProcessRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Process an EMI payment for a specific loan.

    Accepts the EMI number, optional override amount, payment method, and
    an optional failure-simulation flag.  Delegates all business logic
    (validation, status updates, loan closure) to the payment service.
    Accessible by any authenticated user.

    Args:
        loan_id (int): Primary key of the loan for which the payment is
            being made.
        payment_data (PaymentProcessRequest): Body containing
            ``emi_number``, optional ``amount``, ``payment_method``, and
            optional ``simulate_failure`` flag.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Authenticated user extracted from the JWT
            token.

    Returns:
        PaymentResponse: The resulting payment transaction record including
            ``status``, ``transaction_ref``, ``total_amount``, and
            ``late_fee``.

    Raises:
        HTTPException (400 BAD REQUEST): If the loan doesn't exist, is not
            active, the EMI number is invalid, or the EMI is already paid.
    """
    try:
        return process_payment(db, loan_id, payment_data)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get("/{loan_id}", response_model=List[PaymentResponse])
def get_loan_payments(
    loan_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Retrieve all payment transactions for a specific loan.

    Returns the complete payment history for the given loan, ordered by
    EMI number (ascending).  Accessible by any authenticated user.

    Args:
        loan_id (int): Primary key of the loan whose payment history is
            being requested.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Any authenticated user.

    Returns:
        List[PaymentResponse]: All payment records for the loan, ordered
            by ``emi_number`` ascending.
    """
    return get_payments_by_loan(db, loan_id)
