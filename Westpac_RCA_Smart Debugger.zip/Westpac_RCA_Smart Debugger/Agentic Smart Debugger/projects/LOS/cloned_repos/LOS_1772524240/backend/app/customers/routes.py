"""
Customer API routes.
- Create: ADMIN only
- View all: ADMIN only
- /me: CUSTOMER (auto-detect from JWT)
- Profile update: CUSTOMER (own profile only)
"""

import logging
from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.engine import get_db
from app.customers.schemas import CustomerCreate, CustomerUpdate, CustomerResponse
from app.customers.service import (
    create_customer, get_customer_by_id, get_all_customers,
    get_customer_by_user_id, update_customer_profile,
)
from app.shared.deps import get_current_user, require_role
from app.auth.models import User, UserRole
from app.customers.models import Customer

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/customers", tags=["Customers"])

_admin_only = require_role(UserRole.ADMIN)


@router.get("/me", response_model=CustomerResponse)
def get_my_customer_profile(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Retrieve the customer profile linked to the currently authenticated user.

    Auto-detects the customer from the JWT token so the client does not need
    to supply a ``customer_id``.  Accessible by any authenticated user
    (ADMIN or CUSTOMER).

    Args:
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Authenticated user extracted from the JWT token.

    Returns:
        CustomerResponse: The customer profile associated with the current
            user's ``user_id``.

    Raises:
        HTTPException (404 NOT FOUND): If no customer profile is linked to
            the authenticated user's account.
    """
    try:
        return get_customer_by_user_id(db, current_user.id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))


@router.put("/me", response_model=CustomerResponse)
def update_my_profile(
    update_data: CustomerUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Update the customer profile of the currently authenticated user.

    Resolves the customer profile from the JWT token, then applies only the
    fields provided in the request body (partial update).  Any authenticated
    user may update their own profile.

    Args:
        update_data (CustomerUpdate): Partial schema with the fields to
            update.  Only provided fields are written; omitted fields retain
            their current values.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Authenticated user extracted from the JWT token.

    Returns:
        CustomerResponse: The updated customer profile.

    Raises:
        HTTPException (400 BAD REQUEST): If the linked customer profile does
            not exist or an update constraint is violated.
    """
    try:
        customer = get_customer_by_user_id(db, current_user.id)
        return update_customer_profile(db, customer.id, update_data)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.post("", response_model=CustomerResponse, status_code=status.HTTP_201_CREATED)
def create_new_customer(
    customer_data: CustomerCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Create a new customer profile.

    Admins may create a customer profile for any ``user_id``.  Non-admin
    users may only create a profile linked to their own ``user_id`` and are
    blocked from doing so on behalf of another user (HTTP 403).  Also
    prevents creating a second profile for a user who already has one.

    Args:
        customer_data (CustomerCreate): Full customer details including all
            required personal, contact, and financial fields.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Authenticated user extracted from the JWT token.

    Returns:
        CustomerResponse: The newly created customer profile.

    Raises:
        HTTPException (403 FORBIDDEN): If a non-admin user tries to create a
            profile for a different ``user_id``.
        HTTPException (400 BAD REQUEST): If the target user already has a
            customer profile, or if a duplicate email is detected.
    """
    if current_user.role != UserRole.ADMIN:
        if customer_data.user_id != current_user.id:
            raise HTTPException(status_code=403, detail="Cannot create customer profile for another user")
        
    try:
        # Check if user already has a customer profile
        if customer_data.user_id:
            existing = db.query(Customer).filter(Customer.user_id == customer_data.user_id).first()
            if existing:
                raise HTTPException(status_code=400, detail="User already has a customer profile")

        customer = create_customer(db, customer_data, created_by=current_user.id)
        return customer
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get("", response_model=List[CustomerResponse])
def list_customers(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin_only),
):
    """
    List all customer profiles with optional pagination.

    Restricted to users with the ADMIN role.

    Args:
        skip (int): Number of records to skip for pagination.
            Defaults to ``0``.
        limit (int): Maximum number of records to return.
            Defaults to ``100``.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by ``_admin_only``
            dependency).

    Returns:
        List[CustomerResponse]: Paginated list of all customer profiles.

    Raises:
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
    """
    return get_all_customers(db, skip, limit)


@router.get("/{customer_id}", response_model=CustomerResponse)
def get_customer(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin_only),
):
    """
    Retrieve a specific customer profile by its ID.

    Restricted to users with the ADMIN role.

    Args:
        customer_id (int): The primary key of the customer to retrieve.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by ``_admin_only``
            dependency).

    Returns:
        CustomerResponse: The requested customer profile.

    Raises:
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
        HTTPException (404 NOT FOUND): If no customer with the given
            ``customer_id`` exists.
    """
    try:
        return get_customer_by_id(db, customer_id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
