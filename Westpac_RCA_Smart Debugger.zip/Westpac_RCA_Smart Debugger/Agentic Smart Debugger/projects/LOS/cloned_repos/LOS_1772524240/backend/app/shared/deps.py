"""
Shared dependencies and utilities used across modules.
"""

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from sqlalchemy.orm import Session
from app.core.config import settings
from app.database.engine import get_db
from app.auth.models import User, UserRole

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: Session = Depends(get_db),
) -> User:
    """
    FastAPI dependency that decodes the incoming JWT Bearer token and returns
    the authenticated ``User`` ORM object.

    Reads the ``Authorization: Bearer <token>`` header via the OAuth2 scheme,
    verifies the token signature and expiry against ``settings.SECRET_KEY``,
    extracts the ``sub`` claim as the username, then looks up the corresponding
    user row in the database.

    Args:
        token (str): The raw JWT string extracted from the Authorization header.
        db (Session): SQLAlchemy database session provided by ``get_db``.

    Returns:
        User: The authenticated user ORM instance.

    Raises:
        HTTPException (401 UNAUTHORIZED): If the token is missing, expired,
            has an invalid signature, or the username claim is absent.
        HTTPException (401 UNAUTHORIZED): If no user matching the token's
            ``sub`` claim is found in the database.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception

    user = db.query(User).filter(User.username == username).first()
    if user is None:
        raise credentials_exception
    return user


def require_role(*roles: UserRole):
    """
    Dependency factory that enforces role-based access control (RBAC).

    Returns a FastAPI dependency function that checks whether the currently
    authenticated user holds one of the specified ``roles``.  Intended to be
    used with ``Depends()`` on route handlers that should be restricted to
    particular user roles.

    Args:
        *roles (UserRole): One or more ``UserRole`` enum values that are
            allowed to access the protected endpoint.

    Returns:
        Callable: A FastAPI dependency (``role_checker``) that accepts the
            current user via ``get_current_user`` and returns that user if
            their role matches, or raises an HTTP 403 exception otherwise.

    Raises:
        HTTPException (403 FORBIDDEN): If the authenticated user's role is
            not in the provided ``roles`` list.

    Example::

        _admin_only = require_role(UserRole.ADMIN)

        @router.get("/admin-only")
        def admin_endpoint(current_user: User = Depends(_admin_only)):
            ...
    """
    def role_checker(current_user: User = Depends(get_current_user)):
        if current_user.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied. Required roles: {[r.value for r in roles]}",
            )
        return current_user
    return role_checker
