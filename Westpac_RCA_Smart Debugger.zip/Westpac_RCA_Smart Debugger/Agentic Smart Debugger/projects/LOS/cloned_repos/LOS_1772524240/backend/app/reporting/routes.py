"""
Reporting API routes.
Restricted to ADMIN and LOAN_OFFICER roles.
"""

import logging
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database.engine import get_db
from app.reporting.schemas import MonthlyReportResponse, PortfolioReportResponse
from app.reporting.service import generate_monthly_report, generate_portfolio_report
from app.shared.deps import require_role
from app.auth.models import User, UserRole

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/reports", tags=["Reports"])

_admin_only = require_role(UserRole.ADMIN)


@router.get("/monthly", response_model=MonthlyReportResponse)
def get_monthly_report(
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin_only),
):
    """
    Generate and return the monthly summary report for the current period.

    Computes loan issuance counts, disbursement totals, collection figures,
    and status breakdowns for the current UTC calendar month.  Restricted
    to ADMIN users.

    Args:
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by
            ``_admin_only`` dependency).

    Returns:
        MonthlyReportResponse: Aggregated monthly statistics including
            ``report_period``, ``total_loans_issued``,
            ``total_amount_disbursed``, ``total_collections``,
            ``active_loans``, ``closed_loans``, ``rejected_loans``,
            ``default_loans``, ``average_loan_amount``, and
            ``generated_at``.

    Raises:
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
    """
    return generate_monthly_report(db)


@router.get("/portfolio", response_model=PortfolioReportResponse)
def get_portfolio_report(
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin_only),
):
    """
    Generate and return the portfolio overview report.

    Provides a comprehensive snapshot of the institution's entire lending
    book, including outstanding exposure, NPA analysis, average credit
    score, and a per-status loan distribution breakdown.  Restricted to
    ADMIN users.

    Args:
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by
            ``_admin_only`` dependency).

    Returns:
        PortfolioReportResponse: Portfolio-level metrics including
            ``total_customers``, ``total_loans``, ``total_disbursed``,
            ``total_outstanding``, ``total_collections``, ``active_loans``,
            ``closed_loans``, ``npa_count``, ``npa_amount``,
            ``average_credit_score``, ``loan_by_status``, and
            ``generated_at``.

    Raises:
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
    """
    return generate_portfolio_report(db)
