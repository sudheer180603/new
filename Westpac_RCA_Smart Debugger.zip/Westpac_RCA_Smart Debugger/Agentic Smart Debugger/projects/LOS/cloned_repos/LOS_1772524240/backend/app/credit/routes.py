"""
Credit score API routes.
Restricted to ADMIN and LOAN_OFFICER roles.
"""

import logging
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.database.engine import get_db
from app.credit.schemas import CreditScoreResponse
from app.credit.service import generate_credit_score, get_credit_score
from app.shared.deps import require_role
from app.auth.models import User, UserRole

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/credit", tags=["Credit Score"])

_admin_only = require_role(UserRole.ADMIN)


@router.post("/generate/{customer_id}", response_model=CreditScoreResponse)
def generate_score(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin_only),
):
    """
    Generate or refresh the credit score for a specific customer.

    Triggers the credit-scoring simulation in the credit service.  If a
    score already exists for the customer it is overwritten with the newly
    computed value.  Requires KYC to be ``APPROVED`` before a score can be
    generated.  Restricted to ADMIN users.

    Args:
        customer_id (int): Primary key of the customer to score.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by
            ``_admin_only`` dependency).

    Returns:
        CreditScoreResponse: The newly generated credit score record,
            including ``score``, ``risk_category``, and ``factors``.

    Raises:
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
        HTTPException (400 BAD REQUEST): If the customer does not exist or
            their KYC is not yet ``APPROVED``.
    """
    try:
        return generate_credit_score(db, customer_id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))


@router.get("/{customer_id}", response_model=CreditScoreResponse)
def get_score(
    customer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(_admin_only),
):
    """
    Retrieve the existing credit score for a specific customer.

    Returns the most recent credit score record stored for the customer.
    Restricted to ADMIN users.

    Args:
        customer_id (int): Primary key of the customer to look up.
        db (Session): SQLAlchemy session injected by ``get_db``.
        current_user (User): Must be an ADMIN (enforced by
            ``_admin_only`` dependency).

    Returns:
        CreditScoreResponse: The stored credit score record including
            ``score``, ``risk_category``, ``factors``, and
            ``generated_at``.

    Raises:
        HTTPException (403 FORBIDDEN): If the caller is not an ADMIN.
        HTTPException (404 NOT FOUND): If no credit score has been
            generated for the given customer.
    """
    try:
        return get_credit_score(db, customer_id)
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
