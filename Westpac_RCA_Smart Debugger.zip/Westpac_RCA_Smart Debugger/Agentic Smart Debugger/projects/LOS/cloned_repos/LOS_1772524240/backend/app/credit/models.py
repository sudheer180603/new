"""
Credit Score model for credit scoring simulation.
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.sql import func
from app.database.engine import Base


class CreditScore(Base):
    """Credit score records for customers."""
    __tablename__ = "credit_scores"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=False, index=True)
    score = Column(Integer, nullable=False)  # 300-900 range
    risk_category = Column(String(20), nullable=False)  # LOW, MEDIUM, HIGH, VERY_HIGH
    factors = Column(String(500), nullable=True)  # JSON string of factors
    generated_at = Column(DateTime, server_default=func.now())
    created_at = Column(DateTime, server_default=func.now())
