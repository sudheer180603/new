"""
Payment service for processing loan EMI payments.
"""

import logging
import uuid
from datetime import datetime
from sqlalchemy.orm import Session

from app.payments.models import Payment, PaymentStatus
from app.payments.schemas import PaymentProcessRequest
from app.loans.models import Loan, EMISchedule, LoanStatus
from app.notifications.service import emit_event

logger = logging.getLogger(__name__)

LATE_FEE_AMOUNT = 500.0  # Fixed late fee for failed/overdue payments


def process_payment(db: Session, loan_id: int, payment_data: PaymentProcessRequest) -> Payment:
    """
    Process an EMI payment for a specific loan instalment.

    Validates that the loan exists, is in an active state
    (``DISBURSED`` or ``APPROVED``), and that the targeted EMI instalment
    exists and has not already been paid.

    **Happy path (successful payment):**
    The ``EMISchedule`` row is marked ``PAID`` with a timestamp, a
    ``Payment`` record is created with status ``SUCCESS``, and the total
    collected equals the EMI amount.  If this payment clears the final
    outstanding instalment the loan status is automatically set to
    ``CLOSED``.  A ``PAYMENT_SUCCESS`` event is emitted.

    **Simulated failure path (``simulate_failure=True``):**
    A fixed late fee of ₹500 is added to the payment total, the
    ``EMISchedule`` row is marked ``OVERDUE``, and the ``Payment`` record
    is stored with status ``FAILED``.  A ``PAYMENT_FAILED`` event is
    emitted.  This path exists for testing overdue and recovery scenarios.

    Args:
        db (Session): Active SQLAlchemy database session.
        loan_id (int): Primary key of the loan being paid.
        payment_data (PaymentProcessRequest): Request schema containing:

            * ``emi_number`` (int) — the instalment to pay (1-indexed).
            * ``amount`` (float, optional) — override amount; defaults to
              the scheduled EMI amount if ``None``.
            * ``payment_method`` (str) — e.g. ``"UPI"``, ``"NEFT"``,
              ``"AUTO_DEBIT"``.
            * ``simulate_failure`` (bool) — set ``True`` to trigger the
              failure path for testing.

    Returns:
        Payment: The committed ``Payment`` ORM instance representing the
            transaction.

    Raises:
        ValueError: If the loan does not exist.
        ValueError: If the loan is not in an active state.
        ValueError: If the specified EMI number does not exist for the loan.
        ValueError: If the specified EMI has already been paid.
    """
    # Verify loan exists and is active
    loan = db.query(Loan).filter(Loan.id == loan_id).first()
    if not loan:
        raise ValueError(f"Loan with ID {loan_id} not found")
    if loan.status not in [LoanStatus.DISBURSED, LoanStatus.APPROVED]:
        raise ValueError(f"Loan is not active. Current status: {loan.status.value}")

    # Get EMI schedule entry
    emi = db.query(EMISchedule).filter(
        EMISchedule.loan_id == loan_id,
        EMISchedule.emi_number == payment_data.emi_number,
    ).first()
    if not emi:
        raise ValueError(f"EMI #{payment_data.emi_number} not found for loan {loan_id}")
    if emi.status == "PAID":
        raise ValueError(f"EMI #{payment_data.emi_number} is already paid")

    payment_amount = payment_data.amount or emi.emi_amount
    transaction_ref = f"TXN-{uuid.uuid4().hex[:12].upper()}"

    # Simulate payment failure if requested
    if payment_data.simulate_failure:
        late_fee = LATE_FEE_AMOUNT
        total_amount = payment_amount + late_fee
        payment = Payment(
            loan_id=loan_id,
            emi_number=payment_data.emi_number,
            amount=payment_amount,
            late_fee=late_fee,
            total_amount=total_amount,
            status=PaymentStatus.FAILED,
            payment_method=payment_data.payment_method,
            transaction_ref=transaction_ref,
            remarks=f"Payment failed. Late fee of ₹{late_fee} applied.",
        )
        emi.status = "OVERDUE"
        db.add(payment)
        db.commit()
        db.refresh(payment)

        emit_event("PAYMENT_FAILED", {"loan_id": loan_id, "emi_number": payment_data.emi_number})
        logger.warning(f"Payment failed for loan {loan_id}, EMI #{payment_data.emi_number}")
        return payment

    # Successful payment
    payment = Payment(
        loan_id=loan_id,
        emi_number=payment_data.emi_number,
        amount=payment_amount,
        late_fee=0.0,
        total_amount=payment_amount,
        status=PaymentStatus.SUCCESS,
        payment_method=payment_data.payment_method,
        transaction_ref=transaction_ref,
        remarks="Payment successful",
        paid_at=datetime.utcnow(),
    )
    emi.status = "PAID"
    emi.paid_at = datetime.utcnow()

    db.add(payment)
    db.commit()
    db.refresh(payment)

    # Check if all EMIs are paid → close loan
    pending_emis = db.query(EMISchedule).filter(
        EMISchedule.loan_id == loan_id,
        EMISchedule.status != "PAID",
    ).count()
    if pending_emis == 0:
        loan.status = LoanStatus.CLOSED
        db.commit()
        logger.info(f"Loan {loan_id} fully paid and closed")

    emit_event("PAYMENT_SUCCESS", {"loan_id": loan_id, "emi_number": payment_data.emi_number})
    logger.info(f"Payment processed for loan {loan_id}, EMI #{payment_data.emi_number}")
    return payment


def get_payments_by_loan(db: Session, loan_id: int):
    """
    Retrieve all payment transactions for a specific loan.

    Returns payment records ordered by instalment number (ascending), which
    corresponds to chronological payment order for a given loan.

    Args:
        db (Session): Active SQLAlchemy database session.
        loan_id (int): Primary key of the loan whose payment history is
            being requested.

    Returns:
        List[Payment]: All ``Payment`` ORM instances for the loan, ordered
            by ``emi_number`` ascending.
    """
    return db.query(Payment).filter(Payment.loan_id == loan_id).order_by(Payment.emi_number).all()


def get_payments_by_customer(db: Session, customer_id: int):
    """
    Retrieve all payment transactions across all loans belonging to a customer.

    Looks up all loans for the customer, then fetches every payment
    associated with those loan IDs.  Results are ordered by payment date
    (newest first) so the customer sees their most recent transactions at
    the top.

    Args:
        db (Session): Active SQLAlchemy database session.
        customer_id (int): Primary key of the customer whose payment
            history is being requested.

    Returns:
        List[Payment]: All ``Payment`` ORM instances across all the
            customer's loans, ordered by ``paid_at`` descending.  Returns
            an empty list if the customer has no loans.
    """
    from app.loans.models import Loan
    loan_ids = [l.id for l in db.query(Loan).filter(Loan.customer_id == customer_id).all()]
    if not loan_ids:
        return []
    return db.query(Payment).filter(Payment.loan_id.in_(loan_ids)).order_by(Payment.paid_at.desc()).all()
