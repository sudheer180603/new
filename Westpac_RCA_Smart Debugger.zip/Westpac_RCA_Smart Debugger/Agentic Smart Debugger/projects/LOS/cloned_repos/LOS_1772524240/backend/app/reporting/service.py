"""
Reporting service for generating monthly and portfolio reports.
"""

import logging
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.loans.models import Loan, LoanStatus, EMISchedule
from app.payments.models import Payment, PaymentStatus
from app.customers.models import Customer
from app.credit.models import CreditScore

logger = logging.getLogger(__name__)


def generate_monthly_report(db: Session):
    """
    Generate an aggregated monthly summary report for the current calendar month.

    Computes portfolio-level metrics by querying all relevant tables.
    The report period is expressed as ``"YYYY-MM"`` using the current UTC
    date.  All monetary totals are rounded to 2 decimal places.

    Metrics included:

    * **total_loans_issued** — count of all loan records.
    * **total_amount_disbursed** — sum of ``loan_amount`` for all
      ``DISBURSED`` and ``CLOSED`` loans.
    * **total_collections** — sum of successful payment amounts.
    * **active_loans** — count of loans in ``DISBURSED`` state.
    * **closed_loans** — count of fully repaid loans.
    * **rejected_loans** — count of ``REJECTED`` applications.
    * **default_loans** — count of loans in ``DEFAULT`` state.
    * **average_loan_amount** — mean disbursed loan amount.

    Args:
        db (Session): Active SQLAlchemy database session.

    Returns:
        dict: A dictionary matching the ``MonthlyReportResponse`` schema,
            containing all the metrics listed above plus
            ``report_period`` and ``generated_at`` (UTC datetime).
    """
    current_period = datetime.utcnow().strftime("%Y-%m")

    total_loans = db.query(Loan).count()
    disbursed = db.query(Loan).filter(Loan.status.in_([LoanStatus.DISBURSED, LoanStatus.CLOSED])).all()
    total_disbursed_amount = sum(l.loan_amount for l in disbursed)
    active = db.query(Loan).filter(Loan.status == LoanStatus.DISBURSED).count()
    closed = db.query(Loan).filter(Loan.status == LoanStatus.CLOSED).count()
    rejected = db.query(Loan).filter(Loan.status == LoanStatus.REJECTED).count()
    defaults = db.query(Loan).filter(Loan.status == LoanStatus.DEFAULT).count()

    successful_payments = db.query(func.sum(Payment.amount)).filter(
        Payment.status == PaymentStatus.SUCCESS
    ).scalar() or 0.0

    avg_amount = total_disbursed_amount / len(disbursed) if disbursed else 0.0

    return {
        "report_period": current_period,
        "total_loans_issued": total_loans,
        "total_amount_disbursed": round(total_disbursed_amount, 2),
        "total_collections": round(successful_payments, 2),
        "active_loans": active,
        "closed_loans": closed,
        "rejected_loans": rejected,
        "default_loans": defaults,
        "average_loan_amount": round(avg_amount, 2),
        "generated_at": datetime.utcnow(),
    }


def generate_portfolio_report(db: Session):
    """
    Generate a comprehensive portfolio overview report.

    Provides a holistic snapshot of the institution's lending book,
    including outstanding exposure, NPA (Non-Performing Asset) counts,
    average credit quality, and a per-status loan breakdown.

    **NPA definition used here:** a loan is classified as NPA if it has
    3 or more ``OVERDUE`` EMI instalments.

    **Outstanding balance calculation:** for each active loan, the
    ``outstanding_balance`` of its *first pending* EMI instalment is used
    as a proxy for the current outstanding principal.

    Metrics included:

    * **total_customers** — total onboarded customer count.
    * **total_loans** — total loan applications (all statuses).
    * **total_disbursed** — cumulative amount disbursed.
    * **total_outstanding** — estimated outstanding principal across active
      loans.
    * **total_collections** — cumulative successful payment receipts.
    * **active_loans** — loans currently in ``DISBURSED`` state.
    * **closed_loans** — fully repaid loans.
    * **npa_count** — number of loans classified as NPA.
    * **npa_amount** — total loan amount exposed via NPA loans.
    * **average_credit_score** — mean credit score across all scored
      customers.
    * **loan_by_status** — dict mapping each ``LoanStatus`` value to its
      count (zero-count statuses are omitted).

    Args:
        db (Session): Active SQLAlchemy database session.

    Returns:
        dict: A dictionary matching the ``PortfolioReportResponse`` schema,
            containing all the metrics listed above plus
            ``generated_at`` (UTC datetime).
    """
    total_customers = db.query(Customer).count()
    total_loans = db.query(Loan).count()

    disbursed_loans = db.query(Loan).filter(
        Loan.status.in_([LoanStatus.DISBURSED, LoanStatus.CLOSED])
    ).all()
    total_disbursed = sum(l.loan_amount for l in disbursed_loans)

    # Calculate outstanding
    active_loans = db.query(Loan).filter(Loan.status == LoanStatus.DISBURSED).all()
    total_outstanding = 0.0
    for loan in active_loans:
        pending_emis = db.query(EMISchedule).filter(
            EMISchedule.loan_id == loan.id,
            EMISchedule.status != "PAID",
        ).all()
        total_outstanding += sum(e.outstanding_balance for e in pending_emis[:1])  # First pending EMI balance

    total_collections = db.query(func.sum(Payment.amount)).filter(
        Payment.status == PaymentStatus.SUCCESS
    ).scalar() or 0.0

    active_count = len(active_loans)
    closed_count = db.query(Loan).filter(Loan.status == LoanStatus.CLOSED).count()

    # NPA: loans with 3+ overdue EMIs
    npa_count = 0
    npa_amount = 0.0
    for loan in active_loans:
        overdue = db.query(EMISchedule).filter(
            EMISchedule.loan_id == loan.id,
            EMISchedule.status == "OVERDUE",
        ).count()
        if overdue >= 3:
            npa_count += 1
            npa_amount += loan.loan_amount

    avg_score = db.query(func.avg(CreditScore.score)).scalar() or 0.0

    # Loan status breakdown
    status_counts = {}
    for status in LoanStatus:
        count = db.query(Loan).filter(Loan.status == status).count()
        if count > 0:
            status_counts[status.value] = count

    return {
        "total_customers": total_customers,
        "total_loans": total_loans,
        "total_disbursed": round(total_disbursed, 2),
        "total_outstanding": round(total_outstanding, 2),
        "total_collections": round(total_collections, 2),
        "active_loans": active_count,
        "closed_loans": closed_count,
        "npa_count": npa_count,
        "npa_amount": round(npa_amount, 2),
        "average_credit_score": round(avg_score, 2),
        "loan_by_status": status_counts,
        "generated_at": datetime.utcnow(),
    }
