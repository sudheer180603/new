"""
Loan service with EMI calculation, eligibility checks, and loan processing.
Now supports two-step flow:
  1. Customer applies → status = PENDING (with eligibility pre-checks)
  2. Admin approves → status = APPROVED → auto-disburse with EMI schedule
"""

import logging
from datetime import datetime, date, timedelta
from sqlalchemy.orm import Session

from app.loans.models import Loan, EMISchedule, LoanStatus
from app.loans.schemas import LoanApplyRequest
from app.customers.models import Customer
from app.kyc.models import KYCRecord, KYCStatus
from app.credit.models import CreditScore
from app.notifications.service import emit_event

logger = logging.getLogger(__name__)

# Business rule constants
MIN_CREDIT_SCORE = 650
MAX_LOAN_MULTIPLIER = 50  # Max loan = 50x monthly income
MAX_EMI_INCOME_RATIO = 0.40  # EMI should not exceed 40% of monthly income


def calculate_emi(principal: float, annual_rate: float, tenure_months: int) -> float:
    """
    Calculate the fixed monthly EMI (Equated Monthly Instalment) amount.

    Uses the standard reducing-balance formula:

    .. code-block:: text

        EMI = [P × R × (1+R)^N] / [(1+R)^N − 1]

    where:

    * **P** = ``principal`` (loan amount in ₹)
    * **R** = monthly interest rate (``annual_rate / 12 / 100``)
    * **N** = ``tenure_months`` (number of monthly instalments)

    For zero-interest loans the formula degenerates to a simple equal
    division: ``P / N``.

    Args:
        principal (float): The loan amount disbursed to the borrower.
        annual_rate (float): The annual interest rate expressed as a
            percentage (e.g. ``10.5`` for 10.5 % p.a.).
        tenure_months (int): Number of monthly instalments (loan tenure).

    Returns:
        float: The fixed EMI amount rounded to 2 decimal places.
    """
    monthly_rate = annual_rate / 12 / 100
    if monthly_rate == 0:
        return principal / tenure_months

    power = (1 + monthly_rate) ** tenure_months
    emi = (principal * monthly_rate * power) / (power - 1)
    return round(emi, 2)


def generate_emi_schedule(
    db: Session, loan_id: int, principal: float, annual_rate: float,
    tenure_months: int, emi_amount: float, start_date: date = None
):
    """
    Generate and persist the complete EMI amortisation schedule for a loan.

    Calculates each month's principal and interest split using the
    reducing-balance method.  The last instalment is adjusted so that any
    accumulated rounding error is absorbed and the outstanding balance
    reaches exactly zero.  All schedule rows are bulk-inserted in a single
    ``db.add_all`` call for efficiency.

    Args:
        db (Session): Active SQLAlchemy database session.
        loan_id (int): Foreign key of the loan for which the schedule is
            being generated.
        principal (float): Original disbursed loan amount.
        annual_rate (float): Annual interest rate in percent.
        tenure_months (int): Total number of EMI instalments.
        emi_amount (float): Pre-calculated fixed EMI (from
            ``calculate_emi``).
        start_date (date, optional): The date from which the 30-day due-
            date spacing starts.  Defaults to ``date.today()``.

    Returns:
        List[EMISchedule]: The list of ``EMISchedule`` ORM instances that
            were committed to the database.
    """
    if start_date is None:
        start_date = date.today()

    monthly_rate = annual_rate / 12 / 100
    balance = principal
    schedules = []

    for month in range(1, tenure_months + 1):
        interest_component = round(balance * monthly_rate, 2)
        principal_component = round(emi_amount - interest_component, 2)

        if month == tenure_months:
            principal_component = round(balance, 2)
            emi_adjusted = principal_component + interest_component
        else:
            emi_adjusted = emi_amount

        balance = round(balance - principal_component, 2)
        if balance < 0:
            balance = 0

        due_date = start_date + timedelta(days=30 * month)

        schedule = EMISchedule(
            loan_id=loan_id,
            emi_number=month,
            due_date=due_date,
            emi_amount=round(emi_adjusted, 2),
            principal_component=principal_component,
            interest_component=interest_component,
            outstanding_balance=balance,
            status="PENDING",
        )
        schedules.append(schedule)

    db.add_all(schedules)
    db.commit()
    logger.info(f"EMI schedule generated for loan {loan_id}: {tenure_months} installments")
    return schedules


def apply_for_loan(db: Session, loan_data: LoanApplyRequest, customer_id: int) -> Loan:
    """
    Process a customer's loan application with automated eligibility checks.

    Performs the following sequential validations before accepting an
    application:

    1. **Customer exists** — verifies the ``customer_id`` is in the database.
    2. **KYC approved** — the customer must have an ``APPROVED`` KYC record.
    3. **Credit score present** — a credit score must have been generated.
    4. **Minimum credit score** — score must be ≥ ``MIN_CREDIT_SCORE`` (650).
    5. **Maximum loan amount** — loan cannot exceed 50× the customer's
       monthly income.
    6. **EMI affordability** — calculated EMI must not exceed 40 % of
       monthly income.

    If any of the last three checks fails, the loan is immediately persisted
    with status ``REJECTED`` and a ``rejection_reason``.  If all checks pass
    the loan is saved with status ``PENDING`` for admin review, and a
    ``LOAN_APPLIED`` event is emitted.

    Args:
        db (Session): Active SQLAlchemy database session.
        loan_data (LoanApplyRequest): Validated request schema containing
            ``loan_amount``, ``tenure_months``, ``interest_rate``, and
            optional ``purpose``.
        customer_id (int): Primary key of the applying customer.

    Returns:
        Loan: The persisted ``Loan`` ORM instance.  Status will be either
            ``PENDING`` (eligible) or ``REJECTED`` (ineligible).

    Raises:
        ValueError: If the customer does not exist, KYC is not approved, or
            no credit score is found.
    """
    # 1. Check customer exists
    customer = db.query(Customer).filter(Customer.id == customer_id).first()
    if not customer:
        raise ValueError(f"Customer with ID {customer_id} not found")

    # 2. Check KYC approved
    kyc = db.query(KYCRecord).filter(
        KYCRecord.customer_id == customer_id,
        KYCRecord.status == KYCStatus.APPROVED,
    ).first()
    if not kyc:
        raise ValueError("KYC must be APPROVED before applying for a loan")

    # 3. Check credit score
    credit = db.query(CreditScore).filter(CreditScore.customer_id == customer_id).first()
    if not credit:
        raise ValueError("Credit score must be generated before applying for a loan")

    # Calculate EMI
    emi_amount = calculate_emi(loan_data.loan_amount, loan_data.interest_rate, loan_data.tenure_months)
    total_payable = round(emi_amount * loan_data.tenure_months, 2)
    total_interest = round(total_payable - loan_data.loan_amount, 2)

    # Credit score check
    if credit.score < MIN_CREDIT_SCORE:
        loan = Loan(
            customer_id=customer_id,
            loan_amount=loan_data.loan_amount,
            interest_rate=loan_data.interest_rate,
            tenure_months=loan_data.tenure_months,
            emi_amount=emi_amount,
            total_payable=total_payable,
            total_interest=total_interest,
            status=LoanStatus.REJECTED,
            purpose=loan_data.purpose,
            rejection_reason=f"Credit score {credit.score} is below minimum {MIN_CREDIT_SCORE}",
        )
        db.add(loan)
        db.commit()
        db.refresh(loan)
        return loan

    # Max loan amount check
    max_loan = customer.monthly_income * MAX_LOAN_MULTIPLIER
    if loan_data.loan_amount > max_loan:
        loan = Loan(
            customer_id=customer_id,
            loan_amount=loan_data.loan_amount,
            interest_rate=loan_data.interest_rate,
            tenure_months=loan_data.tenure_months,
            emi_amount=emi_amount,
            total_payable=total_payable,
            total_interest=total_interest,
            status=LoanStatus.REJECTED,
            purpose=loan_data.purpose,
            rejection_reason=f"Loan amount ₹{loan_data.loan_amount} exceeds maximum ₹{max_loan} (50x monthly income)",
        )
        db.add(loan)
        db.commit()
        db.refresh(loan)
        return loan

    # EMI affordability check
    max_emi = customer.monthly_income * MAX_EMI_INCOME_RATIO
    if emi_amount > max_emi:
        loan = Loan(
            customer_id=customer_id,
            loan_amount=loan_data.loan_amount,
            interest_rate=loan_data.interest_rate,
            tenure_months=loan_data.tenure_months,
            emi_amount=emi_amount,
            total_payable=total_payable,
            total_interest=total_interest,
            status=LoanStatus.REJECTED,
            purpose=loan_data.purpose,
            rejection_reason=f"EMI ₹{emi_amount} exceeds 40% of monthly income (₹{max_emi})",
        )
        db.add(loan)
        db.commit()
        db.refresh(loan)
        return loan

    # All checks passed — set to PENDING for admin approval
    loan = Loan(
        customer_id=customer_id,
        loan_amount=loan_data.loan_amount,
        interest_rate=loan_data.interest_rate,
        tenure_months=loan_data.tenure_months,
        emi_amount=emi_amount,
        total_payable=total_payable,
        total_interest=total_interest,
        status=LoanStatus.PENDING,
        purpose=loan_data.purpose,
    )
    db.add(loan)
    db.commit()
    db.refresh(loan)

    emit_event("LOAN_APPLIED", {"loan_id": loan.id, "customer_id": customer_id})
    logger.info(f"Loan application submitted: ID={loan.id}, Amount=₹{loan_data.loan_amount}, Status=PENDING")
    return loan


def approve_loan(db: Session, loan_id: int, approved: bool, remarks: str = None, approved_by: int = None) -> Loan:
    """
    Approve or reject a pending loan application.

    Only loans in ``PENDING`` state may be actioned.  When rejected the
    loan status is set to ``REJECTED`` and an optional remarks string is
    stored as the rejection reason.  When approved the loan is immediately
    **disbursed** (status transitions to ``DISBURSED``, and
    ``disbursed_at`` is recorded), after which the full EMI amortisation
    schedule is auto-generated.  Appropriate events (``LOAN_APPROVED``,
    ``LOAN_DISBURSED``, or ``LOAN_REJECTED``) are emitted.

    Args:
        db (Session): Active SQLAlchemy database session.
        loan_id (int): Primary key of the loan to act on.
        approved (bool): ``True`` to approve and disburse, ``False`` to
            reject.
        remarks (str, optional): Human-readable note from the admin.
            Used as the rejection reason when ``approved=False``.
        approved_by (int, optional): ``user_id`` of the admin processing
            the decision, stored for audit purposes.

    Returns:
        Loan: The updated ``Loan`` ORM instance with the new status.

    Raises:
        ValueError: If no loan with the given ``loan_id`` exists.
        ValueError: If the loan is not currently in ``PENDING`` state.
    """
    loan = db.query(Loan).filter(Loan.id == loan_id).first()
    if not loan:
        raise ValueError(f"Loan with ID {loan_id} not found")

    if loan.status != LoanStatus.PENDING:
        raise ValueError(f"Loan is not in PENDING state (current: {loan.status.value})")

    if not approved:
        loan.status = LoanStatus.REJECTED
        loan.rejection_reason = remarks or "Loan rejected by admin"
        loan.approved_by = approved_by
        db.commit()
        db.refresh(loan)
        emit_event("LOAN_REJECTED", {"loan_id": loan.id, "customer_id": loan.customer_id})
        logger.info(f"Loan rejected: ID={loan.id}")
        return loan

    # Approve and disburse
    loan.status = LoanStatus.DISBURSED
    loan.approved_by = approved_by
    loan.disbursed_at = datetime.utcnow()
    loan.rejection_reason = None
    db.commit()
    db.refresh(loan)

    # Generate EMI schedule
    generate_emi_schedule(
        db, loan.id, loan.loan_amount, loan.interest_rate,
        loan.tenure_months, loan.emi_amount,
    )

    emit_event("LOAN_APPROVED", {"loan_id": loan.id, "customer_id": loan.customer_id})
    emit_event("LOAN_DISBURSED", {"loan_id": loan.id, "amount": loan.loan_amount})

    logger.info(f"Loan approved and disbursed: ID={loan.id}, Amount=₹{loan.loan_amount}")
    return loan


def get_pending_loans(db: Session):
    """
    Retrieve all loan applications currently awaiting admin review.

    Returns loans with status ``PENDING`` ordered by creation date
    (newest first) so the admin queue shows the most recent applications at
    the top.

    Args:
        db (Session): Active SQLAlchemy database session.

    Returns:
        List[Loan]: All ``Loan`` ORM instances with status ``PENDING``,
            ordered by ``created_at`` descending.
    """
    return db.query(Loan).filter(Loan.status == LoanStatus.PENDING).order_by(Loan.created_at.desc()).all()


def get_all_loans(db: Session):
    """
    Retrieve all loan records regardless of status.

    Intended for admin dashboards that need a full portfolio view.  Results
    are ordered by creation date (newest first).

    Args:
        db (Session): Active SQLAlchemy database session.

    Returns:
        List[Loan]: All ``Loan`` ORM instances ordered by ``created_at``
            descending.
    """
    return db.query(Loan).order_by(Loan.created_at.desc()).all()


def get_loan_by_id(db: Session, loan_id: int):
    """
    Retrieve a loan together with its full EMI amortisation schedule.

    Fetches the ``Loan`` record and all associated ``EMISchedule`` rows
    sorted by instalment number, then returns them as a dict so the route
    handler can serialise them using ``LoanDetailResponse``.

    Args:
        db (Session): Active SQLAlchemy database session.
        loan_id (int): Primary key of the loan to retrieve.

    Returns:
        dict: A dictionary with two keys:

            * ``"loan"`` — the ``Loan`` ORM instance.
            * ``"emi_schedule"`` — a list of ``EMISchedule`` ORM instances
              ordered by ``emi_number`` ascending.

    Raises:
        ValueError: If no loan with the given ``loan_id`` exists.
    """
    loan = db.query(Loan).filter(Loan.id == loan_id).first()
    if not loan:
        raise ValueError(f"Loan with ID {loan_id} not found")
    emi_schedule = db.query(EMISchedule).filter(EMISchedule.loan_id == loan_id).order_by(EMISchedule.emi_number).all()
    return {"loan": loan, "emi_schedule": emi_schedule}


def get_loans_by_customer(db: Session, customer_id: int):
    """
    Retrieve all loans belonging to a specific customer.

    Returns loans for the given customer ordered by creation date (newest
    first).  Used on both the customer-facing "My Loans" view and the
    admin's per-customer loan history.

    Args:
        db (Session): Active SQLAlchemy database session.
        customer_id (int): Primary key of the customer whose loans are
            being retrieved.

    Returns:
        List[Loan]: All ``Loan`` ORM instances for the customer, ordered
            by ``created_at`` descending.
    """
    return db.query(Loan).filter(Loan.customer_id == customer_id).order_by(Loan.created_at.desc()).all()
