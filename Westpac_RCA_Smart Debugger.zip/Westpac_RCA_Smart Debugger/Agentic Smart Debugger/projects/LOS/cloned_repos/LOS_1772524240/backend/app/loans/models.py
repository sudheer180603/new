"""
Loan and EMI Schedule models.
"""

from sqlalchemy import Column, Integer, String, Float, DateTime, Date, ForeignKey, Enum as SQLEnum
from sqlalchemy.sql import func
from app.database.engine import Base
import enum


class LoanStatus(str, enum.Enum):
    """Loan application status."""
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    DISBURSED = "DISBURSED"
    CLOSED = "CLOSED"
    DEFAULT = "DEFAULT"


class Loan(Base):
    """Loan applications table."""
    __tablename__ = "loans"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=False, index=True)
    loan_amount = Column(Float, nullable=False)
    interest_rate = Column(Float, nullable=False)  # Annual rate in %
    tenure_months = Column(Integer, nullable=False)  # 6-60 months
    emi_amount = Column(Float, nullable=False)
    total_payable = Column(Float, nullable=False)
    total_interest = Column(Float, nullable=False)
    status = Column(SQLEnum(LoanStatus), default=LoanStatus.PENDING, nullable=False)
    purpose = Column(String(100), nullable=True)
    rejection_reason = Column(String(255), nullable=True)
    approved_by = Column(Integer, nullable=True)
    disbursed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())


class EMISchedule(Base):
    """EMI payment schedule for approved loans."""
    __tablename__ = "emi_schedules"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    loan_id = Column(Integer, ForeignKey("loans.id"), nullable=False, index=True)
    emi_number = Column(Integer, nullable=False)
    due_date = Column(Date, nullable=False)
    emi_amount = Column(Float, nullable=False)
    principal_component = Column(Float, nullable=False)
    interest_component = Column(Float, nullable=False)
    outstanding_balance = Column(Float, nullable=False)
    status = Column(String(20), default="PENDING")  # PENDING, PAID, OVERDUE
    paid_at = Column(DateTime, nullable=True)
