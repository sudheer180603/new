"""
Customer schemas for request/response validation.
"""

from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import date, datetime


class CustomerCreate(BaseModel):
    """Schema for creating a new customer."""
    first_name: str
    last_name: str
    email: EmailStr
    phone: str
    date_of_birth: date
    address: str
    city: str
    state: str
    pincode: str
    monthly_income: float
    employment_type: str
    company_name: Optional[str] = None
    user_id: Optional[int] = None


class CustomerUpdate(BaseModel):
    """Schema for updating customer profile."""
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    state: Optional[str] = None
    pincode: Optional[str] = None
    monthly_income: Optional[float] = None
    employment_type: Optional[str] = None
    company_name: Optional[str] = None


class CustomerResponse(BaseModel):
    """Customer response schema."""
    id: int
    user_id: Optional[int] = None
    first_name: str
    last_name: str
    email: str
    phone: str
    date_of_birth: date
    address: str
    city: str
    state: str
    pincode: str
    monthly_income: float
    employment_type: str
    company_name: Optional[str] = None
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
