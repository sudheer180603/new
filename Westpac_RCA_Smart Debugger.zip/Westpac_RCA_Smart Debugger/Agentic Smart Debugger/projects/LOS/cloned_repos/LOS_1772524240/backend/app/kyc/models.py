"""
KYC Record model for Know Your Customer validation.
"""

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Enum as SQLEnum
from sqlalchemy.sql import func
from app.database.engine import Base
import enum


class KYCStatus(str, enum.Enum):
    """KYC verification status."""
    PENDING = "PENDING"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"


class KYCRecord(Base):
    """KYC records for identity verification."""
    __tablename__ = "kyc_records"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=False, index=True)
    pan_file_path = Column(String(255), nullable=False)
    aadhaar_file_path = Column(String(255), nullable=False)
    status = Column(SQLEnum(KYCStatus), default=KYCStatus.PENDING, nullable=False)
    remarks = Column(String(255), nullable=True)
    verified_by = Column(Integer, nullable=True)  # user_id of verifier
    verified_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())
