# Credit module
