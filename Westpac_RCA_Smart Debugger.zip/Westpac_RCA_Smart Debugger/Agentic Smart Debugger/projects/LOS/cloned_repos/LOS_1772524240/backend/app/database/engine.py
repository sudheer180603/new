"""
Database engine and session management.
Uses SQLite for local development.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from app.core.config import settings

# SQLite requires check_same_thread=False for FastAPI
engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False},
    echo=False,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """
    FastAPI dependency that provides a SQLAlchemy database session.

    Yields a ``SessionLocal`` instance for the duration of a single request
    and guarantees that the session is closed afterward, even if an exception
    is raised.  Should be injected via ``Depends(get_db)`` in route handlers.

    Yields:
        Session: An active SQLAlchemy ORM session bound to the configured
            database engine.

    Example::

        @router.get("/items")
        def list_items(db: Session = Depends(get_db)):
            return db.query(Item).all()
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
