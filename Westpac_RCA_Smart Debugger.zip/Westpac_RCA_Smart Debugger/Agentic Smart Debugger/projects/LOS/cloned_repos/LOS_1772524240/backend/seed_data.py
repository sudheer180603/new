"""
Seed script: populates the LOS database with dummy data via the REST API.
Run with:  python seed_data.py
Requires the backend to be running on http://localhost:8000
"""

import requests, json, sys

BASE = "http://localhost:8000"

def p(label, resp):
    """
    Print a labelled result for an HTTP response and return the response.

    Used throughout the seed script to give each API call a human-readable
    label and a pass/fail indicator (✅ / ❌) in the console output.  Also
    prints the first 200 characters of the response body when the request
    fails, to aid debugging.

    Args:
        label (str): A short description of the operation being performed
            (e.g. ``"Register Admin"``).
        resp (requests.Response): The HTTP response object returned by the
            ``requests`` library.

    Returns:
        requests.Response: The same ``resp`` object, unchanged, so callers
            can chain the result (e.g. ``r = p("...", requests.get(...))``)
            and immediately inspect ``r.ok``, ``r.json()``, etc.
    """
    ok = "✅" if resp.ok else "❌"
    print(f"{ok} {label} [{resp.status_code}]")
    if not resp.ok:
        print(f"   Error: {resp.text[:200]}")
    return resp

# ─── 1. Register users ───────────────────────────────────────
print("\n══════ REGISTERING USERS ══════")
admin_reg = p("Register Admin", requests.post(f"{BASE}/auth/register", json={
    "username": "admin1", "email": "admin1@los.com",
    "password": "Admin@123", "full_name": "Raj Malhotra", "role": "ADMIN"
}))
cust_reg = p("Register Customer", requests.post(f"{BASE}/auth/register", json={
    "username": "customer1", "email": "priya@example.com",
    "password": "Cust@123", "full_name": "Priya Sharma", "role": "CUSTOMER"
}))

# ─── 2. Login ─────────────────────────────────────────────────
print("\n══════ LOGGING IN ══════")
admin_login = p("Admin Login", requests.post(f"{BASE}/auth/login", json={
    "username": "admin1", "password": "Admin@123"
}))
admin_token = admin_login.json()["access_token"] if admin_login.ok else None

cust_login = p("Customer Login", requests.post(f"{BASE}/auth/login", json={
    "username": "customer1", "password": "Cust@123"
}))
cust_token = cust_login.json()["access_token"] if cust_login.ok else None

if not admin_token or not cust_token:
    print("❌ Login failed, cannot proceed")
    sys.exit(1)

admin_h = {"Authorization": f"Bearer {admin_token}"}
cust_h  = {"Authorization": f"Bearer {cust_token}"}

# ─── 3. Create customers (Admin only) ────────────────────────
print("\n══════ CREATING CUSTOMERS (Admin) ══════")
customers = [
    {"first_name": "Priya", "last_name": "Sharma", "email": "priya.sharma@example.com",
     "phone": "9876543210", "date_of_birth": "1990-05-15",
     "address": "42 MG Road", "city": "Bangalore", "state": "Karnataka", "pincode": "560001",
     "monthly_income": 75000, "employment_type": "SALARIED", "company_name": "Infosys Ltd"},
    {"first_name": "Vikram", "last_name": "Patel", "email": "vikram.patel@example.com",
     "phone": "9876543211", "date_of_birth": "1985-11-22",
     "address": "101 Park Street", "city": "Mumbai", "state": "Maharashtra", "pincode": "400001",
     "monthly_income": 120000, "employment_type": "SALARIED", "company_name": "TCS"},
    {"first_name": "Ananya", "last_name": "Reddy", "email": "ananya.r@example.com",
     "phone": "9876543212", "date_of_birth": "1993-08-30",
     "address": "7 Jubilee Hills", "city": "Hyderabad", "state": "Telangana", "pincode": "500033",
     "monthly_income": 55000, "employment_type": "SELF_EMPLOYED", "company_name": "Reddy Consulting"},
]
cust_ids = []
for c in customers:
    r = p(f"Create {c['first_name']} {c['last_name']}", requests.post(f"{BASE}/customers", json=c, headers=admin_h))
    if r.ok:
        cust_ids.append(r.json()["id"])

print(f"   Created customer IDs: {cust_ids}")

# ─── 4. RBAC tests ───────────────────────────────────────────
print("\n══════ RBAC TESTS ══════")
r = p("Customer → Create Customer (expect 403)", requests.post(f"{BASE}/customers", json=customers[0], headers=cust_h))
assert r.status_code == 403, f"Expected 403, got {r.status_code}"
r = p("Customer → Reports (expect 403)", requests.get(f"{BASE}/reports/monthly", headers=cust_h))
assert r.status_code == 403, f"Expected 403, got {r.status_code}"
r = p("Customer → Credit (expect 403)", requests.post(f"{BASE}/credit/generate/{cust_ids[0]}", headers=cust_h))
assert r.status_code == 403, f"Expected 403, got {r.status_code}"
print("   ✅ All RBAC checks passed!")

# ─── 5. KYC: Customer submits ────────────────────────────────
print("\n══════ KYC SUBMISSION (Customer) ══════")
kyc_docs = [
    (cust_ids[0], {"pan_number": "ABCDE1234F", "aadhaar_number": "123456789012"}),
    (cust_ids[1], {"pan_number": "FGHIJ5678K", "aadhaar_number": "234567890123"}),
    (cust_ids[2], {"pan_number": "KLMNO9012P", "aadhaar_number": "345678901234"}),
]
for cid, doc in kyc_docs:
    r = p(f"Submit KYC for customer {cid}", requests.post(f"{BASE}/kyc/submit/{cid}", json=doc, headers=cust_h))
    if r.ok:
        print(f"   Status: {r.json()['status']}")

# ─── 6. KYC status check ─────────────────────────────────────
print("\n══════ KYC STATUS CHECK ══════")
for cid in cust_ids:
    r = p(f"KYC status customer {cid}", requests.get(f"{BASE}/kyc/{cid}", headers=cust_h))
    if r.ok:
        print(f"   Status: {r.json()['status']}")

# ─── 7. Admin approves/rejects ───────────────────────────────
print("\n══════ KYC APPROVAL (Admin) ══════")
p(f"Approve customer {cust_ids[0]}", requests.post(f"{BASE}/kyc/approve/{cust_ids[0]}", json={"approved": True, "remarks": "Documents verified"}, headers=admin_h))
p(f"Approve customer {cust_ids[1]}", requests.post(f"{BASE}/kyc/approve/{cust_ids[1]}", json={"approved": True, "remarks": "All clear"}, headers=admin_h))
p(f"Reject customer {cust_ids[2]}", requests.post(f"{BASE}/kyc/approve/{cust_ids[2]}", json={"approved": False, "remarks": "Blurry Aadhaar image"}, headers=admin_h))

# Confirm statuses
for cid in cust_ids:
    r = requests.get(f"{BASE}/kyc/{cid}", headers=admin_h)
    if r.ok:
        print(f"   Customer {cid} KYC → {r.json()['status']}")

# ─── 8. Credit Scoring (Admin) ───────────────────────────────
print("\n══════ CREDIT SCORING (Admin) ══════")
for cid in cust_ids[:2]:  # only approved KYC customers
    r = p(f"Generate credit score customer {cid}", requests.post(f"{BASE}/credit/generate/{cid}", headers=admin_h))
    if r.ok:
        d = r.json()
        print(f"   Score: {d.get('score')}, Risk: {d.get('risk_category')}")

# ─── 9. Loan Application (Admin) ─────────────────────────────
print("\n══════ LOAN APPLICATION (Admin) ══════")
loans = [
    {"customer_id": cust_ids[0], "loan_amount": 500000, "tenure_months": 36, "purpose": "Home Renovation"},
    {"customer_id": cust_ids[1], "loan_amount": 1000000, "tenure_months": 60, "purpose": "Business Expansion"},
]
loan_ids = []
for loan in loans:
    r = p(f"Apply loan for customer {loan['customer_id']}", requests.post(f"{BASE}/loans/apply", json=loan, headers=admin_h))
    if r.ok:
        d = r.json()
        loan_ids.append(d["id"])
        print(f"   Loan #{d['id']}: Status={d.get('status')}, Amount=₹{d.get('loan_amount', 0):,.0f}, EMI=₹{d.get('emi_amount', 0):,.0f}")

# ─── 10. View loan details ───────────────────────────────────
print("\n══════ LOAN DETAILS ══════")
for lid in loan_ids:
    r = p(f"Loan detail #{lid}", requests.get(f"{BASE}/loans/{lid}", headers=admin_h))
    if r.ok:
        d = r.json()
        loan_info = d.get("loan", d)
        emi_schedule = d.get("emi_schedule", [])
        print(f"   EMIs: {len(emi_schedule)}, Monthly: ₹{loan_info.get('emi_amount', 0):,.0f}")

# ─── 11. Payment processing ──────────────────────────────────
print("\n══════ PAYMENTS ══════")
if loan_ids:
    lid = loan_ids[0]
    for emi_num in [1, 2, 3]:
        r = p(f"Pay EMI #{emi_num} for loan {lid}", requests.post(
            f"{BASE}/payments/process/{lid}",
            json={"emi_number": emi_num, "payment_method": "UPI"},
            headers=cust_h
        ))
        if r.ok:
            print(f"   Status: {r.json().get('status')}, Amount: ₹{r.json().get('total_amount', 0):,.0f}")

    r = p("Payment history", requests.get(f"{BASE}/payments/{lid}", headers=cust_h))
    if r.ok:
        print(f"   Total payments: {len(r.json())}")

# ─── 12. Reports (Admin) ─────────────────────────────────────
print("\n══════ REPORTS (Admin) ══════")
r = p("Monthly Report", requests.get(f"{BASE}/reports/monthly", headers=admin_h))
if r.ok:
    d = r.json()
    for k, v in d.items():
        print(f"   {k}: {v}")

r = p("Portfolio Report", requests.get(f"{BASE}/reports/portfolio", headers=admin_h))
if r.ok:
    d = r.json()
    for k, v in d.items():
        print(f"   {k}: {v}")

# ─── 13. List customers ──────────────────────────────────────
print("\n══════ LIST CUSTOMERS (Admin) ══════")
r = p("Get all customers", requests.get(f"{BASE}/customers", headers=admin_h))
if r.ok:
    for c in r.json():
        print(f"   #{c['id']}: {c['first_name']} {c['last_name']} ({c['city']}) — ₹{c.get('monthly_income', 0):,.0f}/mo")

print("\n══════ ALL TESTS COMPLETE ══════\n")
