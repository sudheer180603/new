"""
Customer service for customer onboarding operations.
"""

import logging
from sqlalchemy.orm import Session
from app.customers.models import Customer
from app.customers.schemas import CustomerCreate, CustomerUpdate

logger = logging.getLogger(__name__)


def create_customer(db: Session, customer_data: CustomerCreate, created_by: int = None) -> Customer:
    """
    Create a new customer record in the database.

    Checks for a duplicate email address before inserting the record.
    All fields from ``CustomerCreate`` are mapped directly to the
    ``Customer`` ORM model.  The optional ``created_by`` argument records
    the ``user_id`` of whoever triggered the creation (useful for audit
    trails).

    Args:
        db (Session): Active SQLAlchemy database session.
        customer_data (CustomerCreate): Validated Pydantic schema with all
            required customer fields (``first_name``, ``last_name``,
            ``email``, ``phone``, ``date_of_birth``, ``address``, ``city``,
            ``state``, ``pincode``, ``monthly_income``,
            ``employment_type``).  Optional fields: ``company_name``,
            ``user_id``.
        created_by (int, optional): The ``user_id`` of the admin or user
            who is creating the customer profile.  Defaults to ``None``.

    Returns:
        Customer: The newly persisted ``Customer`` ORM instance.

    Raises:
        ValueError: If a customer with the same email address already
            exists in the database.
    """
    # Check for duplicate email
    existing = db.query(Customer).filter(Customer.email == customer_data.email).first()
    if existing:
        raise ValueError("Customer with this email already exists")

    customer = Customer(
        user_id=customer_data.user_id,
        first_name=customer_data.first_name,
        last_name=customer_data.last_name,
        email=customer_data.email,
        phone=customer_data.phone,
        date_of_birth=customer_data.date_of_birth,
        address=customer_data.address,
        city=customer_data.city,
        state=customer_data.state,
        pincode=customer_data.pincode,
        monthly_income=customer_data.monthly_income,
        employment_type=customer_data.employment_type,
        company_name=customer_data.company_name,
        created_by=created_by,
    )
    db.add(customer)
    db.commit()
    db.refresh(customer)
    logger.info(f"Customer created: {customer.first_name} {customer.last_name} (ID: {customer.id})")
    return customer


def get_customer_by_id(db: Session, customer_id: int) -> Customer:
    """
    Retrieve a single customer record by its primary key.

    Args:
        db (Session): Active SQLAlchemy database session.
        customer_id (int): The primary-key ID of the customer to look up.

    Returns:
        Customer: The matched ``Customer`` ORM instance.

    Raises:
        ValueError: If no customer with the given ``customer_id`` exists.
    """
    customer = db.query(Customer).filter(Customer.id == customer_id).first()
    if not customer:
        raise ValueError(f"Customer with ID {customer_id} not found")
    return customer


def get_customer_by_user_id(db: Session, user_id: int) -> Customer:
    """
    Retrieve the customer profile linked to a specific user account.

    Each user can have at most one associated customer profile (enforced by
    the unique constraint on ``Customer.user_id``).  This function is used
    throughout the application to auto-detect the customer context from a
    JWT-authenticated user.

    Args:
        db (Session): Active SQLAlchemy database session.
        user_id (int): The ``user_id`` foreign key stored on the
            ``Customer`` record.

    Returns:
        Customer: The ``Customer`` ORM instance whose ``user_id`` matches.

    Raises:
        ValueError: If no customer profile is linked to the given
            ``user_id``.
    """
    customer = db.query(Customer).filter(Customer.user_id == user_id).first()
    if not customer:
        raise ValueError(f"No customer profile found for this user")
    return customer


def update_customer_profile(db: Session, customer_id: int, update_data: CustomerUpdate) -> Customer:
    """
    Update selected fields on an existing customer profile.

    Uses Pydantic's ``model_dump(exclude_unset=True)`` so that only the
    fields explicitly provided in the request body are written; omitted
    fields retain their current database values.

    Args:
        db (Session): Active SQLAlchemy database session.
        customer_id (int): Primary key of the customer to update.
        update_data (CustomerUpdate): Partial Pydantic schema.  Any
            combination of ``first_name``, ``last_name``, ``phone``,
            ``address``, ``city``, ``state``, ``pincode``,
            ``monthly_income``, ``employment_type``, and ``company_name``
            may be included.

    Returns:
        Customer: The updated and refreshed ``Customer`` ORM instance.

    Raises:
        ValueError: If no customer with the given ``customer_id`` exists.
    """
    customer = db.query(Customer).filter(Customer.id == customer_id).first()
    if not customer:
        raise ValueError(f"Customer with ID {customer_id} not found")

    update_dict = update_data.model_dump(exclude_unset=True)
    for field, value in update_dict.items():
        setattr(customer, field, value)

    db.commit()
    db.refresh(customer)
    logger.info(f"Customer profile updated: {customer.first_name} {customer.last_name} (ID: {customer.id})")
    return customer


def get_all_customers(db: Session, skip: int = 0, limit: int = 100):
    """
    Retrieve a paginated list of all customer records.

    Args:
        db (Session): Active SQLAlchemy database session.
        skip (int): Number of records to skip (offset).  Defaults to ``0``.
        limit (int): Maximum number of records to return.  Defaults to
            ``100``.

    Returns:
        List[Customer]: A list of ``Customer`` ORM instances ordered by
            their default database insertion order.
    """
    return db.query(Customer).offset(skip).limit(limit).all()
