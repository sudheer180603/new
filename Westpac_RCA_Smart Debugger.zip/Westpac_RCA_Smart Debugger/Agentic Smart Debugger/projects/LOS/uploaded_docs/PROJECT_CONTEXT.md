# Loan Origination System (LOS) - Complete Project Context

## 📋 Project Overview

**Digital Loan Origination System (LOS)** is a comprehensive, enterprise-grade banking application for managing the complete loan lifecycle from customer onboarding to loan disbursement, payment processing, and regulatory reporting.

### Technology Stack
- **Backend**: FastAPI (Python) with SQLAlchemy ORM
- **Frontend**: React 18 with React Router v6
- **Database**: SQLite (development)
- **Authentication**: JWT (JSON Web Tokens) with role-based access control
- **API Communication**: Axios with interceptors

---

## 🏗️ System Architecture

### Backend Architecture (FastAPI)
The backend follows a modular, domain-driven design with clear separation of concerns:

```
backend/
├── app/
│   ├── auth/          # Authentication & Authorization
│   ├── customers/     # Customer Management
│   ├── kyc/          # KYC Verification
│   ├── credit/       # Credit Scoring
│   ├── loans/        # Loan Processing
│   ├── payments/     # Payment Management
│   ├── reporting/    # Reports & Analytics
│   ├── notifications/ # Event System
│   ├── shared/       # Shared Dependencies
│   ├── core/         # Configuration
│   └── database/     # Database Engine
```

### Frontend Architecture (React)
Component-based architecture with context API for state management:

```
frontend/src/
├── components/       # Reusable UI components
├── pages/           # Route-specific pages
├── services/        # API integration layer
├── context/         # Global state (Auth)
└── App.jsx          # Main routing & layout
```

---

## 🔐 Authentication & Authorization

### User Roles
1. **ADMIN**: Full system access (loan approval, KYC verification, reports)
2. **CUSTOMER**: Limited access (profile, loans, payments)

### Authentication Flow
1. User registers via `/auth/register` with username, email, password, full_name, role
2. User logs in via `/auth/login` → receives JWT token
3. Token stored in localStorage and attached to all API requests
4. Backend validates JWT on protected routes using `get_current_user` dependency
5. Role-based access enforced via `require_role` decorator

### JWT Token Structure
```json
{
  "sub": "username",
  "role": "ADMIN|CUSTOMER",
  "exp": 1234567890
}
```

### Security Features
- Password hashing with bcrypt (truncated to 72 bytes)
- JWT expiration (60 minutes default)
- 401 auto-logout on frontend
- CORS protection
- Role-based route protection

---

## 📦 Core Modules

### 1. Authentication Module (`/auth`)

**Purpose**: User registration, login, and JWT token management

**Models**:
- `User`: id, username, email, hashed_password, full_name, role, is_active, created_at, updated_at

**Routes**:
- `POST /auth/register` - Register new user (public)
- `POST /auth/login` - Login and get JWT token (public)

**Business Logic**:
- Password validation and hashing
- Duplicate username/email check
- JWT token generation with role claims
- Token expiration handling

---

### 2. Customer Management Module (`/customers`)

**Purpose**: Customer onboarding and profile management

**Models**:
- `Customer`: id, user_id (FK), first_name, last_name, email, phone, date_of_birth, address, city, state, pincode, monthly_income, employment_type, company_name, created_by, created_at, updated_at

**Routes**:
- `POST /customers` - Create customer (ADMIN or self-registration)
- `GET /customers` - List all customers (ADMIN only)
- `GET /customers/{id}` - Get customer by ID (ADMIN only)
- `GET /customers/me` - Get current user's customer profile (authenticated)
- `PUT /customers/me` - Update own profile (authenticated)

**Business Logic**:
- Email uniqueness validation
- User-customer linking (one-to-one)
- Profile completion workflow
- Employment type validation (SALARIED, SELF_EMPLOYED, BUSINESS)

**Frontend Pages**:
- `CreateCustomer.jsx` - Admin creates customer
- `Profile.jsx` - Customer views/edits own profile

---

### 3. KYC Verification Module (`/kyc`)

**Purpose**: Know Your Customer document verification workflow

**Models**:
- `KYCRecord`: id, customer_id (FK), pan_file_path, aadhaar_file_path, status (PENDING/APPROVED/REJECTED), remarks, verified_by, verified_at, created_at, updated_at

**Routes**:
- `POST /kyc/submit` - Upload KYC documents (authenticated, auto-detects customer)
- `GET /kyc/me` - Get own KYC status (authenticated)
- `GET /kyc/all` - List all KYC records (ADMIN only)
- `POST /kyc/approve/{customer_id}` - Approve/reject KYC (ADMIN only)
- `GET /kyc/file/{customer_id}/{file_type}` - Download KYC file (ADMIN only)
- `GET /kyc/{customer_id}` - Get KYC status (authenticated)

**Business Logic**:
- Two-step workflow: Submit → Admin Review → Approved/Rejected
- File upload handling (PAN and Aadhaar PDFs)
- File storage in `uploads/kyc/{customer_id}/`
- Re-submission allowed for rejected KYC
- KYC approval required before credit score generation

**Frontend Pages**:
- `SubmitKYC.jsx` - Customer uploads documents with drag-and-drop
- `VerifyKYC.jsx` - Admin reviews and approves/rejects

---

### 4. Credit Scoring Module (`/credit`)

**Purpose**: Simulated credit score generation for loan eligibility

**Models**:
- `CreditScore`: id, customer_id (FK), score (300-900), risk_category (LOW/MEDIUM/HIGH/VERY_HIGH), factors (JSON), generated_at, created_at

**Routes**:
- `POST /credit/generate/{customer_id}` - Generate credit score (ADMIN only)
- `GET /credit/{customer_id}` - Get credit score (ADMIN only)

**Business Logic**:
- Requires KYC approval before generation
- Score calculation based on:
  - Base score: 500
  - Income factor: +30 per ₹10,000 monthly income (max +200)
  - Employment factor: +50 for SALARIED, +20 for others
  - Random factor: -50 to +100
- Risk classification:
  - 750+: LOW
  - 650-749: MEDIUM
  - 500-649: HIGH
  - <500: VERY_HIGH
- Generates realistic credit factors (JSON)
- Updates existing score if re-generated

**Frontend Pages**:
- `GenerateCreditScore.jsx` - Admin generates score with circular gauge visualization

---

### 5. Loan Management Module (`/loans`)

**Purpose**: Complete loan application, approval, and disbursement workflow

**Models**:
- `Loan`: id, customer_id (FK), loan_amount, interest_rate, tenure_months, emi_amount, total_payable, total_interest, status (PENDING/APPROVED/REJECTED/DISBURSED/CLOSED/DEFAULT), purpose, rejection_reason, approved_by, disbursed_at, created_at, updated_at
- `EMISchedule`: id, loan_id (FK), emi_number, due_date, emi_amount, principal_component, interest_component, outstanding_balance, status (PENDING/PAID/OVERDUE), paid_at

**Routes**:
- `POST /loans/apply` - Apply for loan (authenticated, auto-detects customer)
- `GET /loans/my` - Get own loans (authenticated)
- `GET /loans/pending` - List pending loans (ADMIN only)
- `GET /loans/all` - List all loans (ADMIN only)
- `POST /loans/approve/{loan_id}` - Approve/reject loan (ADMIN only)
- `GET /loans/{loan_id}` - Get loan details with EMI schedule (authenticated)
- `GET /loans/customer/{customer_id}` - Get customer's loans (authenticated)

**Business Logic**:

**Loan Application (Two-Step Flow)**:
1. Customer applies → Eligibility checks performed
2. If eligible → Status = PENDING (awaits admin approval)
3. If ineligible → Status = REJECTED immediately with reason

**Eligibility Checks**:
- KYC must be APPROVED
- Credit score must exist
- Credit score ≥ 650 (MIN_CREDIT_SCORE)
- Loan amount ≤ 50x monthly income (MAX_LOAN_MULTIPLIER)
- EMI ≤ 40% of monthly income (MAX_EMI_INCOME_RATIO)

**EMI Calculation**:
```
EMI = [P × R × (1+R)^N] / [(1+R)^N - 1]
where:
  P = Principal (loan amount)
  R = Monthly interest rate (annual_rate / 12 / 100)
  N = Tenure in months
```

**Loan Approval**:
- Admin approves → Status = DISBURSED
- Auto-generates EMI amortization schedule
- Calculates principal and interest components for each EMI
- Sets due dates (30-day intervals)

**EMI Schedule Generation**:
- Creates N EMI records (N = tenure_months)
- Each EMI has: emi_number, due_date, emi_amount, principal_component, interest_component, outstanding_balance
- Uses reducing balance method for amortization

**Frontend Pages**:
- `ApplyLoan.jsx` - Customer applies with live EMI preview
- `MyLoans.jsx` - Customer views loans with expandable EMI schedules
- `LoanApproval.jsx` - Admin reviews and approves/rejects pending loans
- `LoanDetails.jsx` - Detailed loan view with full EMI schedule
- `EMICalculator.jsx` - Standalone EMI calculator with sliders

---

### 6. Payment Processing Module (`/payments`)

**Purpose**: EMI payment processing and tracking

**Models**:
- `Payment`: id, loan_id (FK), emi_number, amount, late_fee, total_amount, status (SUCCESS/FAILED/PENDING), payment_method, transaction_ref, remarks, paid_at, created_at

**Routes**:
- `POST /payments/process/{loan_id}` - Process EMI payment (authenticated)
- `GET /payments/{loan_id}` - Get loan payments (authenticated)
- `GET /payments/my` - Get own payments (authenticated)

**Business Logic**:
- Validates loan is active (DISBURSED or APPROVED status)
- Verifies EMI exists and not already paid
- Generates unique transaction reference (TXN-{UUID})
- Supports payment simulation (success/failure)
- Late fee: ₹500 for failed payments
- Updates EMI status: PENDING → PAID or OVERDUE
- Auto-closes loan when all EMIs paid
- Payment methods: UPI, NEFT, DEBIT_CARD, AUTO_DEBIT

**Frontend Pages**:
- `PaymentProcessing.jsx` - Customer makes EMI payments
- `PaymentHistory.jsx` - Customer views payment history with filters

---

### 7. Reporting Module (`/reports`)

**Purpose**: Regulatory and portfolio analytics

**Models**:
- `Report`: id, report_type (MONTHLY/PORTFOLIO), report_period, total_loans, total_disbursed, total_collections, active_loans, npa_count, npa_amount, average_credit_score, report_data (JSON), generated_at, generated_by

**Routes**:
- `GET /reports/monthly` - Generate monthly report (ADMIN only)
- `GET /reports/portfolio` - Generate portfolio report (ADMIN only)

**Business Logic**:

**Monthly Report**:
- Total loans issued
- Total amount disbursed
- Total collections (successful payments)
- Active, closed, rejected, default loan counts
- Average loan amount

**Portfolio Report**:
- Total customers
- Total loans
- Total disbursed amount
- Total outstanding balance
- Total collections
- Active and closed loan counts
- NPA (Non-Performing Assets): loans with 3+ overdue EMIs
- Average credit score across all customers
- Loan status breakdown

**Frontend Pages**:
- `Reports.jsx` - Admin views monthly and portfolio reports with stats grids

---

### 8. Notifications Module (`/notifications`)

**Purpose**: Internal event system (simulates Kafka)

**Service Functions**:
- `emit_event(event_type, payload)` - Logs events and triggers handlers
- `get_event_log()` - Returns in-memory event log

**Event Types**:
- `KYC_SUBMITTED`, `KYC_APPROVED`, `KYC_REJECTED`
- `CREDIT_GENERATED`
- `LOAN_APPLIED`, `LOAN_APPROVED`, `LOAN_REJECTED`, `LOAN_DISBURSED`
- `PAYMENT_SUCCESS`, `PAYMENT_FAILED`, `PAYMENT_OVERDUE`

**Business Logic**:
- In-memory event log for simulation
- Event handlers trigger downstream actions
- Logs all events for audit trail

---

### 9. Shared Dependencies Module (`/shared`)

**Purpose**: Common utilities and dependencies

**Functions**:
- `get_current_user(token)` - Decodes JWT and returns User object
- `require_role(*roles)` - Dependency factory for role-based access control

**Usage**:
```python
@router.get("/admin-only")
def admin_route(current_user: User = Depends(require_role(UserRole.ADMIN))):
    ...
```

---

## 🎨 Frontend Architecture

### Global State Management

**AuthContext** (`context/AuthContext.jsx`):
- Manages user authentication state
- Stores JWT token and user info in localStorage
- Provides `login()`, `logout()` functions
- Auto-loads auth state on app mount
- Exposes `user`, `token`, `loading` state

### API Service Layer

**api.js** (`services/api.js`):
- Centralized Axios instance with base URL
- Request interceptor: Attaches JWT token to all requests
- Response interceptor: Handles 401 errors (auto-logout)
- Organized API functions by module:
  - `authAPI`: register, login
  - `customerAPI`: create, getAll, getById, getMe, updateMe
  - `kycAPI`: submitFiles, getMe, getAll, approve, downloadFile
  - `creditAPI`: generate, get
  - `loanAPI`: apply, getMy, getPending, getAll, approve, getById
  - `paymentAPI`: process, getByLoan, getMy
  - `reportAPI`: monthly, portfolio

### Routing & Access Control

**App.jsx**:
- `PrivateRoute`: Redirects to login if not authenticated
- `RoleRoute`: Shows access denied if role mismatch
- `SmartDashboard`: Renders role-specific dashboard
- `AppLayout`: Wraps pages with Sidebar

**Route Structure**:
```
/login, /register          → Public
/                          → Smart Dashboard (role-aware)
/profile                   → Customer profile
/kyc/submit                → Customer KYC upload
/loans/apply, /loans/my    → Customer loan pages
/payments                  → Customer payment processing
/emi-calculator            → EMI calculator tool
/kyc                       → Admin KYC verification
/credit                    → Admin credit score generation
/loans/approval            → Admin loan approval
/reports                   → Admin reports
```

### UI Components

**Sidebar** (`components/Sidebar.jsx`):
- Role-based navigation menu
- Grouped by sections (Main, My Account, Services, Admin Operations, Analytics)
- Active link highlighting
- User info display with role badge
- Sign out button

### Page Components

**Dashboard Pages**:
- `Dashboard.jsx` - Admin dashboard with portfolio stats and customer list
- `CustomerDashboard.jsx` - Customer dashboard with KYC status, loan summary, quick actions

**Customer Pages**:
- `Profile.jsx` - View/edit profile, create profile if missing
- `SubmitKYC.jsx` - Upload KYC documents with drag-and-drop, view status
- `ApplyLoan.jsx` - Apply for loan with live EMI preview
- `MyLoans.jsx` - View all loans with filters, expandable EMI schedules
- `LoanDetails.jsx` - Detailed loan view with full EMI table
- `PaymentProcessing.jsx` - Make EMI payments with loan selector
- `PaymentHistory.jsx` - View payment history with filters and stats
- `EMICalculator.jsx` - Calculate EMI with interactive sliders and visual breakdown

**Admin Pages**:
- `CreateCustomer.jsx` - Create new customer
- `VerifyKYC.jsx` - Review and approve/reject KYC documents
- `GenerateCreditScore.jsx` - Generate credit score with circular gauge
- `LoanApproval.jsx` - Review and approve/reject pending loans
- `Reports.jsx` - View monthly and portfolio reports

**Auth Pages**:
- `Login.jsx` - Login form
- `Register.jsx` - Registration form with role selection

---

## 🔄 Complete User Workflows

### Customer Onboarding Flow
1. User registers → Creates User account
2. User logs in → Receives JWT token
3. User completes profile → Creates Customer record
4. User uploads KYC documents → Creates KYCRecord (status: PENDING)
5. Admin reviews KYC → Updates status to APPROVED/REJECTED
6. Admin generates credit score → Creates CreditScore
7. Customer can now apply for loans

### Loan Application Flow
1. Customer applies for loan → Eligibility checks performed
2. If eligible → Loan status = PENDING
3. If ineligible → Loan status = REJECTED with reason
4. Admin reviews pending loan → Approves or rejects
5. If approved → Loan status = DISBURSED, EMI schedule generated
6. Customer makes EMI payments → Payment records created
7. When all EMIs paid → Loan status = CLOSED

### Payment Flow
1. Customer selects loan and EMI number
2. Customer chooses payment method
3. Payment processed → Creates Payment record
4. If successful → EMI status = PAID, Payment status = SUCCESS
5. If failed → EMI status = OVERDUE, Late fee applied
6. When all EMIs paid → Loan auto-closes

---

## 📊 Database Schema

### Tables
1. **users**: Authentication and user accounts
2. **customers**: Customer profiles and demographics
3. **kyc_records**: KYC document verification
4. **credit_scores**: Credit scoring data
5. **loans**: Loan applications and status
6. **emi_schedules**: EMI payment schedules
7. **payments**: Payment transactions
8. **reports**: Generated reports (not actively used in current implementation)

### Relationships
- User 1:1 Customer (user_id FK)
- Customer 1:N KYCRecord (customer_id FK)
- Customer 1:N CreditScore (customer_id FK)
- Customer 1:N Loan (customer_id FK)
- Loan 1:N EMISchedule (loan_id FK)
- Loan 1:N Payment (loan_id FK)

---

## 🚀 Running the Application

### Backend Setup
```bash
cd backend
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Backend runs on: http://localhost:8000
API Docs: http://localhost:8000/docs

### Frontend Setup
```bash
cd frontend
npm install
npm run dev
```

Frontend runs on: http://localhost:5173

### Seed Data
```bash
cd backend
python seed_data.py
```

Creates:
- Admin user: admin1 / Admin@123
- Customer user: customer1 / Cust@123
- 3 sample customers
- KYC records (approved and rejected)
- Credit scores
- Loan applications
- Payment transactions

---

## 🔑 Key Business Rules

### Credit Scoring
- Minimum credit score: 650
- Score range: 300-900
- Risk categories: LOW (750+), MEDIUM (650-749), HIGH (500-649), VERY_HIGH (<500)

### Loan Eligibility
- KYC must be APPROVED
- Credit score must exist and be ≥ 650
- Max loan amount: 50x monthly income
- Max EMI: 40% of monthly income

### Payment Rules
- Late fee: ₹500 for failed payments
- EMI status: PENDING → PAID or OVERDUE
- Loan auto-closes when all EMIs paid
- NPA threshold: 3+ overdue EMIs

### Interest Calculation
- Default interest rate: 10.5% p.a.
- EMI calculated using reducing balance method
- Principal and interest components calculated for each EMI

---

## 🎯 Key Features

### Security
- JWT-based authentication
- Role-based access control (RBAC)
- Password hashing with bcrypt
- CORS protection
- Token expiration handling

### User Experience
- Role-specific dashboards
- Live EMI preview during loan application
- Drag-and-drop file upload
- Interactive EMI calculator with sliders
- Expandable loan details
- Payment history with filters
- Real-time status updates

### Admin Features
- Customer management
- KYC document review and approval
- Credit score generation
- Loan approval workflow
- Comprehensive reporting
- File download for KYC documents

### Customer Features
- Profile management
- KYC document upload
- Loan application
- EMI calculator
- Loan tracking with EMI schedules
- Payment processing
- Payment history

---

## 📝 API Endpoints Summary

### Authentication
- POST /auth/register
- POST /auth/login

### Customers
- POST /customers
- GET /customers
- GET /customers/{id}
- GET /customers/me
- PUT /customers/me

### KYC
- POST /kyc/submit
- GET /kyc/me
- GET /kyc/all
- POST /kyc/approve/{customer_id}
- GET /kyc/file/{customer_id}/{file_type}
- GET /kyc/{customer_id}

### Credit
- POST /credit/generate/{customer_id}
- GET /credit/{customer_id}

### Loans
- POST /loans/apply
- GET /loans/my
- GET /loans/pending
- GET /loans/all
- POST /loans/approve/{loan_id}
- GET /loans/{loan_id}
- GET /loans/customer/{customer_id}

### Payments
- POST /payments/process/{loan_id}
- GET /payments/{loan_id}
- GET /payments/my

### Reports
- GET /reports/monthly
- GET /reports/portfolio

---

## 🛠️ Configuration

### Environment Variables (.env)
```
SECRET_KEY=los-super-secret-key-change-in-production-2024
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=60
DATABASE_URL=sqlite:///./app/database/los.db
```

### Frontend API Configuration
```javascript
const API_BASE = 'http://localhost:8000';
```

---

## 📦 Dependencies

### Backend (requirements.txt)
- fastapi==0.104.1
- uvicorn[standard]==0.24.0
- sqlalchemy==2.0.23
- python-jose[cryptography]==3.3.0
- passlib[bcrypt]==1.7.4
- python-dotenv==1.0.0
- python-multipart==0.0.6
- pydantic[email]==2.5.2
- bcrypt==4.0.1

### Frontend (package.json)
- react: ^18.2.0
- react-dom: ^18.2.0
- react-router-dom: ^6.20.0
- axios: ^1.6.2
- vite: ^5.0.0

---

## 🎨 Styling

The application uses a custom CSS design system with:
- CSS variables for theming
- Responsive grid layouts
- Card-based UI components
- Badge system for status indicators
- Form styling with validation states
- Table components with responsive containers
- Loading spinners and transitions
- Alert components (success, error, info, warning)

---

## 🔮 Future Enhancements

Potential areas for expansion:
1. Real Kafka integration for event streaming
2. PostgreSQL/MySQL for production database
3. Document storage in S3/cloud storage
4. Email/SMS notifications
5. Advanced credit scoring algorithms
6. Loan restructuring features
7. Collateral management
8. Multi-currency support
9. Advanced analytics and dashboards
10. Mobile app integration

---

This comprehensive context document covers the entire LOS project architecture, business logic, workflows, and implementation details. The system is production-ready for a small-scale deployment and can be scaled with the suggested enhancements.
