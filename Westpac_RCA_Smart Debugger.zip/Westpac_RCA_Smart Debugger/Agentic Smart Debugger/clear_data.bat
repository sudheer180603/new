@echo off
echo ========================================
echo   Agentic Smart Debugger - Clear Data
echo ========================================
echo.
echo This will delete:
echo   - debugger.db (main database)
echo   - faiss_index/ (vector embeddings)
echo   - projects/ (project data)
echo.
echo Cloned repositories will NOT be deleted.
echo.
set /p confirm="Are you sure? (y/n): "

if /i "%confirm%"=="y" (
    echo.
    echo Clearing data...
    echo.
    
    REM Delete debugger.db
    if exist debugger.db (
        del /f /q debugger.db
        echo [OK] debugger.db deleted
    ) else (
        echo [--] debugger.db not found
    )
    
    REM Delete faiss_index directory
    if exist faiss_index (
        rmdir /s /q faiss_index
        echo [OK] faiss_index/ deleted
    ) else (
        echo [--] faiss_index/ not found
    )
    
    REM Delete projects directory
    if exist projects (
        rmdir /s /q projects
        echo [OK] projects/ deleted
    ) else (
        echo [--] projects/ not found
    )
    
    echo.
    echo ========================================
    echo   Data cleared successfully!
    echo ========================================
    echo.
    echo The system will recreate databases automatically
    echo when you restart the backend.
    echo.
    echo To also clear cloned repositories, run:
    echo   rmdir /s /q cloned_repos
    echo.
) else (
    echo.
    echo Operation cancelled.
    echo.
)

pause
