from openai import AzureOpenAI
from tenacity import retry, stop_after_attempt, wait_exponential
import logging
from app.config import settings

logger = logging.getLogger(__name__)

class AzureOpenAIClient:
    def __init__(self):
        self.client = AzureOpenAI(
            azure_endpoint=settings.azure_openai_endpoint,
            api_key=settings.azure_openai_api_key,
            api_version=settings.azure_openai_api_version
        )
        self.deployment = settings.azure_openai_deployment
        
        # Determine if model uses new parameter name
        # GPT-4o, GPT-4o-mini, o1-preview, o1-mini use max_completion_tokens
        # Older models use max_tokens
        self.uses_new_param = any(model in self.deployment.lower() for model in 
                                   ['gpt-4o', 'gpt-5', 'o1-preview', 'o1-mini', 'o1', 'o3'])
        
        # Determine if model supports temperature parameter
        # o1-series and some newer models don't support custom temperature
        self.supports_temperature = not any(model in self.deployment.lower() for model in 
                                           ['o1-preview', 'o1-mini', 'o1', 'o3'])
        
        # GPT-5 models may have limited temperature support - check if it's gpt-5
        if 'gpt-5' in self.deployment.lower():
            self.supports_temperature = False
            logger.info(f"Model {self.deployment} detected - temperature parameter will be omitted")
    
    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=10))
    def chat_completion(self, messages: list, temperature: float = None, max_tokens: int = None):
        try:
            # Prepare parameters
            params = {
                "model": self.deployment,
                "messages": messages,
            }
            
            # Add temperature only if model supports it
            if self.supports_temperature:
                params["temperature"] = temperature or settings.temperature
            else:
                logger.info(f"Skipping temperature parameter for model {self.deployment}")
            
            # Use appropriate token parameter based on model
            token_limit = max_tokens or settings.max_tokens
            if self.uses_new_param:
                params["max_completion_tokens"] = token_limit
            else:
                params["max_tokens"] = token_limit
            
            response = self.client.chat.completions.create(**params)
            return response.choices[0].message.content
        except Exception as e:
            logger.error(f"Azure OpenAI API error: {str(e)}")
            raise

azure_client = AzureOpenAIClient()
