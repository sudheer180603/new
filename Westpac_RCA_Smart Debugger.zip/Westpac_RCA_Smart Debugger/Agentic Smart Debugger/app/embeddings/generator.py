from sentence_transformers import SentenceTransformer
import numpy as np
from typing import List, Optional
import logging
from app.config import settings
import torch
from functools import lru_cache

logger = logging.getLogger(__name__)

class EmbeddingGenerator:
    """
    Optimized embedding generator with:
    - GPU acceleration (if available)
    - Faster model option
    - Batch processing optimization
    - Caching for repeated texts
    """
    
    def __init__(self):
        logger.info(f"Loading embedding model: {settings.embedding_model}")
        
        # Determine device (GPU if available)
        self.device = 'cuda' if torch.cuda.is_available() else 'cpu'
        if self.device == 'cuda':
            logger.info(f"✅ GPU acceleration enabled: {torch.cuda.get_device_name(0)}")
        else:
            logger.info("ℹ️ Using CPU (consider GPU for 3-5x speedup)")
        
        # Load model with optimizations
        self.model = SentenceTransformer(
            settings.embedding_model,
            device=self.device
        )
        
        # Enable model optimizations
        if self.device == 'cuda':
            # Use mixed precision for faster inference
            self.model.half()  # FP16 for 2x speedup on GPU
        
        self.dimension = self.model.get_sentence_embedding_dimension()
        
        # Cache for frequently embedded texts
        self._cache = {}
        self._cache_hits = 0
        self._cache_misses = 0
        
        logger.info(f"Model loaded: {self.dimension}D embeddings on {self.device}")
    
    def generate_embeddings(
        self, 
        texts: List[str], 
        batch_size: int = None,
        show_progress: bool = True,
        use_cache: bool = True
    ) -> np.ndarray:
        """
        Generate embeddings with optimizations:
        - Larger batch sizes for GPU
        - Caching for duplicate texts
        - Parallel processing
        """
        if not texts:
            return np.array([])
        
        # Optimize batch size based on device
        if batch_size is None:
            if self.device == 'cuda':
                # GPU can handle larger batches
                batch_size = min(settings.batch_size * 4, 256)
            else:
                batch_size = settings.batch_size
        
        # Check cache for duplicate texts
        if use_cache:
            cached_embeddings = []
            uncached_texts = []
            uncached_indices = []
            
            for i, text in enumerate(texts):
                text_hash = hash(text[:500])  # Hash first 500 chars
                if text_hash in self._cache:
                    cached_embeddings.append((i, self._cache[text_hash]))
                    self._cache_hits += 1
                else:
                    uncached_texts.append(text)
                    uncached_indices.append(i)
                    self._cache_misses += 1
            
            if self._cache_hits + self._cache_misses > 0:
                hit_rate = self._cache_hits / (self._cache_hits + self._cache_misses)
                if self._cache_hits % 100 == 0 and self._cache_hits > 0:
                    logger.debug(f"Cache hit rate: {hit_rate:.1%}")
            
            # Generate embeddings for uncached texts
            if uncached_texts:
                new_embeddings = self.model.encode(
                    uncached_texts,
                    batch_size=batch_size,
                    show_progress_bar=show_progress,
                    normalize_embeddings=True,
                    convert_to_numpy=True
                )
                
                # Update cache (limit cache size)
                if len(self._cache) < 10000:  # Max 10k cached items
                    for text, emb in zip(uncached_texts, new_embeddings):
                        text_hash = hash(text[:500])
                        self._cache[text_hash] = emb
            else:
                new_embeddings = np.array([])
            
            # Combine cached and new embeddings in correct order
            if cached_embeddings:
                all_embeddings = np.zeros((len(texts), self.dimension), dtype=np.float32)
                for idx, emb in cached_embeddings:
                    all_embeddings[idx] = emb
                for i, idx in enumerate(uncached_indices):
                    all_embeddings[idx] = new_embeddings[i]
                return all_embeddings
            else:
                return new_embeddings
        
        # No caching - direct encoding
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=show_progress,
            normalize_embeddings=True,
            convert_to_numpy=True
        )
        return embeddings
    
    def generate_single_embedding(self, text: str, use_cache: bool = True) -> np.ndarray:
        """Generate single embedding with caching"""
        if use_cache:
            text_hash = hash(text[:500])
            if text_hash in self._cache:
                self._cache_hits += 1
                return self._cache[text_hash]
            self._cache_misses += 1
        
        embedding = self.model.encode(
            [text], 
            normalize_embeddings=True,
            convert_to_numpy=True
        )[0]
        
        if use_cache and len(self._cache) < 10000:
            text_hash = hash(text[:500])
            self._cache[text_hash] = embedding
        
        return embedding
    
    def clear_cache(self):
        """Clear embedding cache"""
        self._cache.clear()
        self._cache_hits = 0
        self._cache_misses = 0
        logger.info("Embedding cache cleared")
    
    def get_cache_stats(self) -> dict:
        """Get cache statistics"""
        total = self._cache_hits + self._cache_misses
        hit_rate = self._cache_hits / total if total > 0 else 0
        return {
            "cache_size": len(self._cache),
            "cache_hits": self._cache_hits,
            "cache_misses": self._cache_misses,
            "hit_rate": hit_rate
        }

# Singleton instance
embedding_generator = EmbeddingGenerator()
