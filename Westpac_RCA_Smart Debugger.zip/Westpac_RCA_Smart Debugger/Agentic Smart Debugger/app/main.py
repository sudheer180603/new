from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Any
import logging
import warnings
import sys

# Fix for Python 3.12+ multiprocess ResourceTracker warning
# This must be done before any imports that use multiprocess
warnings.filterwarnings("ignore", category=UserWarning, module="multiprocess.resource_tracker")
warnings.filterwarnings("ignore", message=".*_recursion_count.*")

# Patch multiprocess ResourceTracker to prevent cleanup errors
try:
    import multiprocess.resource_tracker as resource_tracker
    _original_del = resource_tracker.ResourceTracker.__del__
    
    def _patched_del(self):
        try:
            _original_del(self)
        except AttributeError as e:
            if '_recursion_count' not in str(e):
                raise
    
    resource_tracker.ResourceTracker.__del__ = _patched_del
except (ImportError, AttributeError):
    pass

from app.config import settings
from app.database.models import init_db
from app.github.clone import clone_repository
from app.parsers.orchestrator import parse_repository
from app.business_docs.processor import process_business_docs
from app.context_engine.builder import build_unified_context
from app.jira.processor import process_jira_tickets
from app.rca_engine.analyzer import analyze_tickets
from app.consolidation.engine import consolidate_issues
from app.api.projects import router as projects_router

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Agentic Smart Debugger", version="1.0.0")

# Include project router
app.include_router(projects_router)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
async def startup_event():
    init_db()
    logger.info("Database initialized")

@app.get("/")
async def root():
    return {"message": "Agentic Smart Debugger API", "status": "running"}

@app.post("/api/ingest/github")
async def ingest_github(repo_url_or_path: str):
    """
    Ingest a GitHub repository or local folder
    
    Args:
        repo_url_or_path: Either a GitHub URL (e.g., https://github.com/user/repo) 
                         or a local folder path (e.g., C:\\projects\\myapp)
    """
    try:
        if not repo_url_or_path or not repo_url_or_path.strip():
            raise HTTPException(status_code=400, detail="Repository URL or path is required")
        
        logger.info(f"Ingesting repository/folder: {repo_url_or_path}")
        repo_path = clone_repository(repo_url_or_path)
        
        logger.info("Parsing repository")
        parse_result = parse_repository(repo_path)
        
        return {
            "status": "success",
            "repo_path": repo_path,
            "files_parsed": parse_result["total_files"],
            "languages": parse_result["languages"]
        }
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error ingesting repository/folder: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/ingest/business-docs")
async def ingest_business_docs(files: List[UploadFile] = File(...)):
    try:
        logger.info(f"Processing {len(files)} business documents")
        result = await process_business_docs(files)
        
        return {
            "status": "success",
            "documents_processed": len(files),
            "rules_extracted": result["rules_count"]
        }
    except Exception as e:
        logger.error(f"Error processing business docs: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/context/build")
async def build_context():
    try:
        logger.info("Building unified context")
        result = build_unified_context()
        
        return {
            "status": "success",
            "code_blocks": result["code_blocks"],
            "business_rules": result["business_rules"],
            "embeddings_generated": result["embeddings_count"]
        }
    except Exception as e:
        logger.error(f"Error building context: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/jira/process")
async def process_jira(tickets: List[Dict[str, Any]]):
    try:
        # Validate input
        if not tickets:
            raise HTTPException(status_code=400, detail="No tickets provided")
        
        # Validate each ticket has required fields (accept both ticket_id and jira_id)
        for i, ticket in enumerate(tickets):
            if not isinstance(ticket, dict):
                raise HTTPException(status_code=400, detail=f"Ticket at index {i} is not a valid object")
            if "ticket_id" not in ticket and "jira_id" not in ticket:
                raise HTTPException(status_code=400, detail=f"Ticket at index {i} is missing required field 'ticket_id' or 'jira_id'")
        
        logger.info(f"Processing {len(tickets)} Jira tickets")
        result = process_jira_tickets(tickets)
        
        return {
            "status": "success",
            "tickets_processed": result["tickets_processed"]
        }
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error processing Jira tickets: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/rca/analyze")
async def run_rca_analysis():
    try:
        logger.info("Running RCA analysis")
        results = await analyze_tickets()
        
        logger.info("Consolidating issues")
        consolidated = consolidate_issues(results)
        
        return {
            "status": "success",
            "tickets": results,
            "consolidation": consolidated
        }
    except Exception as e:
        logger.error(f"Error running RCA: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/health")
async def health_check():
    return {"status": "healthy"}
