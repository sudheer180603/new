"""
Session manager to track current processing session
"""
from typing import List, Set

class SessionManager:
    def __init__(self):
        self.current_ticket_ids: Set[str] = set()
    
    def set_current_tickets(self, ticket_ids: List[str]):
        """Set the current session ticket IDs"""
        self.current_ticket_ids = set(ticket_ids)
    
    def get_current_tickets(self) -> Set[str]:
        """Get the current session ticket IDs"""
        return self.current_ticket_ids
    
    def clear(self):
        """Clear the current session"""
        self.current_ticket_ids.clear()

# Global session manager instance
session_manager = SessionManager()
