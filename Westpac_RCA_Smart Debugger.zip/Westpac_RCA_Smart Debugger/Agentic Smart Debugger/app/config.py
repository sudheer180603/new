from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # Azure OpenAI Configuration
    azure_openai_endpoint: str
    azure_openai_api_key: str
    azure_openai_deployment: str = "gpt-4"
    azure_openai_api_version: str = "2024-02-15-preview"
    
    # Embedding Model
    embedding_model: str = "BAAI/bge-small-en-v1.5"  # Faster, smaller model (384D vs 1024D)
    # Alternative models:
    # - "BAAI/bge-small-en-v1.5" - Fast, 384D, good quality (RECOMMENDED)
    # - "BAAI/bge-base-en-v1.5" - Balanced, 768D, better quality
    # - "BAAI/bge-large-en-v1.5" - Slow, 1024D, best quality
    # - "all-MiniLM-L6-v2" - Very fast, 384D, decent quality
    embedding_cache_enabled: bool = True  # Enable embedding caching
    embedding_cache_size: int = 10000  # Maximum cached embeddings
    
    # Database
    database_url: str = "sqlite:///./debugger.db"
    
    # Paths
    clone_dir: str = "./cloned_repos"
    docs_dir: str = "./uploaded_docs"
    faiss_index_dir: str = "./faiss_index"
    
    # Processing
    max_file_size_mb: int = 50
    batch_size: int = 32
    top_k_retrieval: int = 10
    similarity_threshold: float = 0.7
    
    # Parser Configuration
    use_universal_parser: bool = True  # Use universal parser for all languages
    max_workers: int = 8  # Number of parallel workers for parsing
    skip_large_files: bool = True  # Skip files larger than max_file_size_mb
    
    # Azure OpenAI
    temperature: float = 0.2
    max_tokens: int = 4000
    
    class Config:
        env_file = ".env"
        case_sensitive = False

settings = Settings()
