from typing import List, Dict, Any
import logging
from app.database.models import Ticket
from app.embeddings.generator import embedding_generator

logger = logging.getLogger(__name__)

def process_jira_tickets(tickets: List[Dict[str, Any]], project_name: str = None) -> dict:
    """Process Jira tickets for a project"""
    if project_name:
        from app.database.project_db import project_db
        from app.vector_store.project_faiss import get_project_store
        db = project_db.get_session(project_name)
        logger.info(f"[{project_name}] Processing {len(tickets)} Jira tickets")
    else:
        from app.database.models import SessionLocal
        from app.vector_store.faiss_store import FAISSStore
        db = SessionLocal()
        logger.info(f"Processing {len(tickets)} Jira tickets")
    
    try:
        # Validate tickets have required fields
        normalized_tickets = []
        for i, ticket_data in enumerate(tickets):
            # Check for ticket_id or jira_id
            if "ticket_id" not in ticket_data and "jira_id" not in ticket_data:
                raise ValueError(f"Ticket at index {i} is missing required field 'ticket_id' or 'jira_id'")
            
            # Normalize to ticket_id
            normalized = ticket_data.copy()
            if "jira_id" in normalized and "ticket_id" not in normalized:
                normalized["ticket_id"] = normalized.pop("jira_id")
            
            # Build comprehensive description from all fields
            desc_parts = [normalized.get("description", "")]
            
            # Add structured fields to description for better context
            if "error_message" in normalized:
                desc_parts.append(f"\nError: {normalized['error_message']}")
            if "stack_trace" in normalized:
                desc_parts.append(f"\nStack Trace: {normalized['stack_trace']}")
            if "affected_module" in normalized:
                desc_parts.append(f"\nAffected Module: {normalized['affected_module']}")
            if "endpoint" in normalized:
                desc_parts.append(f"\nEndpoint: {normalized['endpoint']}")
            if "reproduction_steps" in normalized:
                steps = normalized['reproduction_steps']
                if isinstance(steps, list):
                    desc_parts.append(f"\nReproduction Steps: {'; '.join(steps)}")
            if "severity" in normalized:
                desc_parts.append(f"\nSeverity: {normalized['severity']}")
            
            normalized["description"] = "\n".join(filter(None, desc_parts))
            
            # Map severity to priority if priority not provided
            if "priority" not in normalized and "severity" in normalized:
                severity_map = {
                    "critical": "Critical",
                    "high": "High",
                    "medium": "Medium",
                    "low": "Low"
                }
                normalized["priority"] = severity_map.get(normalized["severity"].lower(), "Medium")
            
            # Use affected_module as module if module not provided
            if "module" not in normalized and "affected_module" in normalized:
                normalized["module"] = normalized["affected_module"]
            
            normalized_tickets.append(normalized)
        
        # Get or create ticket store
        if project_name:
            ticket_store = get_project_store(project_name, embedding_generator.dimension, "tickets")
        else:
            from app.vector_store.faiss_store import FAISSStore
            ticket_store = FAISSStore(embedding_generator.dimension, "tickets")
        
        for ticket_data in normalized_tickets:
            ticket = Ticket(
                ticket_id=ticket_data["ticket_id"],
                summary=ticket_data.get("summary", ""),
                description=ticket_data.get("description", ""),
                priority=ticket_data.get("priority", ""),
                module=ticket_data.get("module", "")
            )
            db.add(ticket)
        
        db.commit()
        
        # Generate embeddings from ticket text
        ticket_texts = [f"{t.get('summary', '')} {t.get('description', '')}" for t in normalized_tickets]
        ticket_embeddings = embedding_generator.generate_embeddings(ticket_texts)
        
        # Store ticket metadata
        ticket_metadata = [{
            "ticket_id": t["ticket_id"],
            "summary": t.get("summary", ""),
            "module": t.get("module", "")
        } for t in normalized_tickets]
        
        ticket_store.add_vectors(ticket_embeddings, ticket_metadata)
        ticket_store.save()
        
        # Update embedding IDs in database
        stored_tickets = db.query(Ticket).filter(
            Ticket.ticket_id.in_([t["ticket_id"] for t in normalized_tickets])
        ).all()
        
        for i, ticket in enumerate(stored_tickets):
            ticket.embedding_id = i
        db.commit()
        
        logger.info(f"[{project_name or 'global'}] Successfully processed {len(normalized_tickets)} Jira tickets")
        return {"tickets_processed": len(normalized_tickets)}
    
    except Exception as e:
        logger.error(f"Error in process_jira_tickets: {str(e)}")
        db.rollback()
        raise
    finally:
        db.close()
