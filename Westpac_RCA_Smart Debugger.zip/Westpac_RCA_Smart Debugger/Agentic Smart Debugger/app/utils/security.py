import os
import re
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

def sanitize_path(path: str, base_dir: str) -> str:
    """Sanitize and validate file paths to prevent directory traversal"""
    clean_path = os.path.normpath(path)
    
    if '..' in clean_path or clean_path.startswith('/'):
        raise ValueError("Invalid path: directory traversal detected")
    
    full_path = os.path.join(base_dir, clean_path)
    
    if not full_path.startswith(os.path.abspath(base_dir)):
        raise ValueError("Invalid path: outside base directory")
    
    return full_path

def validate_file_size(file_path: str, max_size_mb: int = 50) -> bool:
    """Check if file size is within limits"""
    size_mb = os.path.getsize(file_path) / (1024 * 1024)
    return size_mb <= max_size_mb

def validate_json_schema(data: dict, required_fields: list) -> bool:
    """Validate JSON structure has required fields"""
    return all(field in data for field in required_fields)

def sanitize_repo_url(url: str) -> str:
    """Validate and sanitize GitHub repository URL"""
    pattern = r'^https://github\.com/[\w-]+/[\w.-]+(?:\.git)?$'
    if not re.match(pattern, url):
        raise ValueError("Invalid GitHub repository URL")
    return url
