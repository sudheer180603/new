"""
Project-based API endpoints
"""
from fastapi import APIRouter, HTTPException, UploadFile, File
from typing import List, Dict, Any
import logging

from app.project_manager import project_manager
from app.github.clone import clone_repository
from app.parsers.orchestrator import parse_repository
from app.business_docs.processor import process_business_docs
from app.context_engine.builder import build_unified_context
from app.jira.processor import process_jira_tickets
from app.rca_engine.analyzer import analyze_tickets
from app.consolidation.engine import consolidate_issues

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/projects", tags=["projects"])

@router.post("/create")
async def create_project(data: Dict[str, str]):
    """Create a new project"""
    try:
        name = data.get("name")
        if not name:
            raise HTTPException(status_code=400, detail="Project name is required")
        
        project = project_manager.create_project(name)
        return {"status": "success", "project": project.to_dict()}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating project: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/list")
async def list_projects():
    """List all projects"""
    try:
        projects = []
        for name in project_manager.list_projects():
            project = project_manager.get_project(name)
            if project:
                projects.append(project.to_dict())
        return {"projects": projects}
    except Exception as e:
        logger.error(f"Error listing projects: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{project_name}")
async def get_project(project_name: str):
    """Get project details"""
    try:
        project = project_manager.get_project(project_name)
        if not project:
            raise HTTPException(status_code=404, detail=f"Project '{project_name}' not found")
        return {"project": project.to_dict()}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting project: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{project_name}/ingest/github")
async def ingest_github(project_name: str, data: Dict[str, str]):
    """Ingest GitHub repository for a project"""
    try:
        # Set current project
        project_manager.set_current_project(project_name)
        
        # Initialize project database
        from app.database.project_db import project_db
        project_db.init_project_db(project_name)
        
        repo_url_or_path = data.get("repo_url_or_path")
        if not repo_url_or_path:
            raise HTTPException(status_code=400, detail="repo_url_or_path is required")
        
        logger.info(f"[{project_name}] Ingesting repository: {repo_url_or_path}")
        repo_path = clone_repository(repo_url_or_path, project_name)
        
        logger.info(f"[{project_name}] Parsing repository")
        from app.parsers.orchestrator import parse_repository
        parse_result = parse_repository(repo_path, project_name)
        
        # Update project
        project_manager.update_project(project_name, {
            "repo_path": repo_path,
            "code_indexed": True,
            "stats": {
                "files_parsed": parse_result["total_files"],
                "languages": parse_result["languages"]
            }
        })
        
        return {
            "status": "success",
            "repo_path": repo_path,
            "files_parsed": parse_result["total_files"],
            "languages": parse_result["languages"]
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error ingesting repository: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{project_name}/ingest/business-docs")
async def ingest_business_docs(project_name: str, files: List[UploadFile] = File(...)):
    """Ingest business documents for a project"""
    try:
        project_manager.set_current_project(project_name)
        
        logger.info(f"[{project_name}] Processing {len(files)} business documents")
        
        # Use project-specific processor
        from app.business_docs.processor import process_business_docs
        result = await process_business_docs(files, project_name)
        
        # Update project
        project = project_manager.get_project(project_name)
        stats = project.stats.copy()
        stats["business_rules"] = result["rules_count"]
        
        project_manager.update_project(project_name, {
            "business_docs_processed": True,
            "stats": stats
        })
        
        return {
            "status": "success",
            "documents_processed": len(files),
            "rules_extracted": result["rules_count"]
        }
    except Exception as e:
        logger.error(f"Error processing business docs: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{project_name}/context/build")
async def build_context(project_name: str):
    """Build unified context for a project"""
    try:
        project_manager.set_current_project(project_name)
        
        logger.info(f"[{project_name}] Building unified context")
        
        # Use project-specific context builder
        from app.context_engine.project_builder import build_project_context
        result = build_project_context(project_name)
        
        # Update project
        project = project_manager.get_project(project_name)
        stats = project.stats.copy()
        stats["code_blocks"] = result["code_blocks"]
        stats["business_rules"] = result["business_rules"]
        stats["embeddings"] = result["embeddings_count"]
        
        project_manager.update_project(project_name, {
            "context_built": True,
            "stats": stats
        })
        
        return {
            "status": "success",
            "code_blocks": result["code_blocks"],
            "business_rules": result["business_rules"],
            "embeddings_generated": result["embeddings_count"]
        }
    except Exception as e:
        logger.error(f"Error building context: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{project_name}/jira/process")
async def process_jira(project_name: str, tickets: List[Dict[str, Any]]):
    """Process Jira tickets for a project"""
    try:
        project_manager.set_current_project(project_name)
        
        if not tickets:
            raise HTTPException(status_code=400, detail="No tickets provided")
        
        logger.info(f"[{project_name}] Processing {len(tickets)} Jira tickets")
        result = process_jira_tickets(tickets, project_name)
        
        # Update project
        project = project_manager.get_project(project_name)
        stats = project.stats.copy()
        stats["tickets_processed"] = result["tickets_processed"]
        
        project_manager.update_project(project_name, {
            "tickets_processed": True,
            "stats": stats
        })
        
        return {
            "status": "success",
            "tickets_processed": result["tickets_processed"]
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error processing Jira tickets: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{project_name}/tickets/list")
async def list_tickets(project_name: str):
    """List all tickets for a project"""
    try:
        from app.database.project_db import project_db
        from app.database.models import Ticket
        
        db = project_db.get_session(project_name)
        
        try:
            tickets = db.query(Ticket).all()
            
            ticket_list = [{
                "ticket_id": t.ticket_id,
                "summary": t.summary,
                "priority": t.priority,
                "module": t.module
            } for t in tickets]
            
            return {
                "status": "success",
                "tickets": ticket_list,
                "count": len(ticket_list)
            }
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Error listing tickets: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/{project_name}/rca/analyze")
async def run_rca_analysis(project_name: str, data: Dict[str, Any] = None):
    """Run RCA analysis for a project
    
    Args:
        project_name: Name of the project
        data: Optional dict with 'ticket_ids' list to analyze specific tickets
    """
    try:
        project_manager.set_current_project(project_name)
        
        # Get ticket IDs if provided
        ticket_ids = None
        if data and 'ticket_ids' in data:
            ticket_ids = data['ticket_ids']
            logger.info(f"[{project_name}] Running RCA analysis on selected tickets: {ticket_ids}")
        else:
            logger.info(f"[{project_name}] Running RCA analysis on all tickets")
        
        results = await analyze_tickets(project_name, ticket_ids)
        
        logger.info(f"[{project_name}] Consolidating issues")
        consolidated = consolidate_issues(results)
        
        # Update project
        project = project_manager.get_project(project_name)
        stats = project.stats.copy()
        stats["tickets_analyzed"] = len(results)
        
        project_manager.update_project(project_name, {
            "rca_completed": True,
            "stats": stats
        })
        
        return {
            "status": "success",
            "tickets": results,
            "consolidation": consolidated
        }
    except Exception as e:
        logger.error(f"Error running RCA: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/{project_name}")
async def delete_project(project_name: str):
    """Delete a project"""
    try:
        project_manager.delete_project(project_name)
        return {"status": "success", "message": f"Project '{project_name}' deleted"}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Error deleting project: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{project_name}/dependency-graph")
async def get_dependency_graph(project_name: str, source_file: str = None):
    """Get dependency graph for a project
    
    Args:
        project_name: Name of the project
        source_file: Optional filter by source file
    """
    try:
        from app.database.project_db import project_db
        from app.database.models import DependencyGraph
        
        db = project_db.get_session(project_name)
        
        try:
            query = db.query(DependencyGraph)
            
            if source_file:
                query = query.filter(DependencyGraph.source_file == source_file)
            
            dependencies = query.all()
            
            # Build graph structure
            graph_data = {
                "nodes": set(),
                "edges": []
            }
            
            for dep in dependencies:
                graph_data["nodes"].add(dep.source_file)
                graph_data["nodes"].add(dep.target_file)
                graph_data["edges"].append({
                    "source": dep.source_file,
                    "target": dep.target_file,
                    "type": dep.dependency_type,
                    "created_at": dep.created_at.isoformat() if dep.created_at else None
                })
            
            # Convert set to list for JSON serialization
            graph_data["nodes"] = list(graph_data["nodes"])
            
            # Calculate statistics
            stats = {
                "total_nodes": len(graph_data["nodes"]),
                "total_edges": len(graph_data["edges"]),
                "dependency_types": {}
            }
            
            for edge in graph_data["edges"]:
                dep_type = edge["type"]
                stats["dependency_types"][dep_type] = stats["dependency_types"].get(dep_type, 0) + 1
            
            return {
                "status": "success",
                "project": project_name,
                "graph": graph_data,
                "stats": stats
            }
            
        finally:
            db.close()
            
    except Exception as e:
        logger.error(f"Error getting dependency graph: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/{project_name}/rca/{ticket_id}")
async def get_rca_result(project_name: str, ticket_id: str):
    """Get RCA result for a specific ticket including code snippet
    
    Args:
        project_name: Name of the project
        ticket_id: Ticket ID
    """
    try:
        from app.database.project_db import project_db
        from app.database.models import RCAResult
        
        db = project_db.get_session(project_name)
        
        try:
            rca = db.query(RCAResult).filter(RCAResult.ticket_id == ticket_id).first()
            
            if not rca:
                raise HTTPException(status_code=404, detail=f"RCA result not found for ticket {ticket_id}")
            
            return {
                "status": "success",
                "ticket_id": rca.ticket_id,
                "root_cause_type": rca.root_cause_type,
                "impacted_file": rca.impacted_file,
                "impacted_method": rca.impacted_method,
                "code_pointer": rca.code_pointer,
                "current_logic": rca.current_logic,
                "business_expected_logic": rca.business_expected_logic,
                "resolution_logic": rca.resolution_logic,
                "suggested_code_snippet": rca.suggested_code_snippet,
                "fix_type": rca.fix_type,
                "confidence_score": rca.confidence_score,
                "created_at": rca.created_at.isoformat() if rca.created_at else None
            }
            
        finally:
            db.close()
            
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting RCA result: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
