import os
import re
from typing import List, Dict
from fastapi import UploadFile
import PyPDF2
from docx import Document
import logging
from app.config import settings
from app.database.models import SessionLocal, BusinessRule

logger = logging.getLogger(__name__)

async def process_business_docs(files: List[UploadFile], project_name: str = None) -> dict:
    """Process business documents and extract rules with enhanced parsing"""
    # Determine docs directory
    if project_name:
        from app.project_manager import project_manager
        docs_dir = project_manager.get_project_docs_dir(project_name)
    else:
        docs_dir = settings.docs_dir
    
    os.makedirs(docs_dir, exist_ok=True)
    
    rules_count = 0
    
    for file in files:
        file_path = os.path.join(docs_dir, file.filename)
        
        with open(file_path, 'wb') as f:
            content = await file.read()
            f.write(content)
        
        text = extract_text(file_path)
        rules = extract_business_rules_enhanced(text, file.filename)
        
        save_business_rules(rules, project_name)
        rules_count += len(rules)
    
    if project_name:
        logger.info(f"[{project_name}] Extracted {rules_count} business rules from docs in {docs_dir}")
    else:
        logger.info(f"Extracted {rules_count} business rules")
    
    return {"rules_count": rules_count}

def extract_text(file_path: str) -> str:
    """Extract text from various document formats"""
    ext = os.path.splitext(file_path)[1].lower()
    
    try:
        if ext == '.pdf':
            with open(file_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                text = ""
                for page in reader.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
                return text
        
        elif ext == '.docx':
            doc = Document(file_path)
            text_parts = []
            
            # Extract paragraphs
            for para in doc.paragraphs:
                if para.text.strip():
                    text_parts.append(para.text)
            
            # Extract tables
            for table in doc.tables:
                for row in table.rows:
                    row_text = " | ".join([cell.text.strip() for cell in row.cells if cell.text.strip()])
                    if row_text:
                        text_parts.append(row_text)
            
            return "\n".join(text_parts)
        
        elif ext in ['.txt', '.md']:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
    
    except Exception as e:
        logger.error(f"Error extracting text from {file_path}: {str(e)}")
        return ""

def extract_business_rules_enhanced(text: str, source_doc: str) -> List[dict]:
    """Enhanced business rule extraction with pattern recognition"""
    rules = []
    
    # Patterns for identifying business rules
    rule_patterns = [
        r'(?:must|should|shall|required to|needs to|has to)\s+(.+?)(?:\.|$)',
        r'(?:business rule|requirement|constraint|validation):\s*(.+?)(?:\n|$)',
        r'(?:if|when|whenever)\s+(.+?)\s+(?:then|must|should)\s+(.+?)(?:\.|$)',
        r'(?:validation|check|verify|ensure)\s+(?:that\s+)?(.+?)(?:\.|$)',
        r'(?:not allowed|prohibited|forbidden|restricted)\s+(.+?)(?:\.|$)',
    ]
    
    # Split into sections based on headers
    sections = split_into_sections(text)
    
    for section_title, section_content in sections:
        # Categorize based on section title
        category = categorize_section(section_title)
        
        # Extract rules from section
        section_rules = []
        
        # Try pattern matching first
        for pattern in rule_patterns:
            matches = re.finditer(pattern, section_content, re.IGNORECASE | re.MULTILINE)
            for match in matches:
                rule_text = match.group(0).strip()
                if len(rule_text) > 20:  # Filter out too short matches
                    section_rules.append({
                        "rule_text": rule_text,
                        "source_document": source_doc,
                        "category": category,
                        "section": section_title
                    })
        
        # If no patterns matched, use paragraph-based extraction
        if not section_rules:
            paragraphs = extract_paragraphs(section_content)
            for para in paragraphs:
                if is_likely_business_rule(para):
                    section_rules.append({
                        "rule_text": para,
                        "source_document": source_doc,
                        "category": category,
                        "section": section_title
                    })
        
        rules.extend(section_rules)
    
    # Deduplicate rules
    unique_rules = []
    seen_texts = set()
    for rule in rules:
        normalized = rule["rule_text"].lower().strip()
        if normalized not in seen_texts and len(normalized) > 20:
            seen_texts.add(normalized)
            unique_rules.append(rule)
    
    return unique_rules

def split_into_sections(text: str) -> List[tuple]:
    """Split document into sections based on headers"""
    sections = []
    
    # Pattern for headers (markdown style, numbered, or all caps)
    header_pattern = r'^(?:#{1,6}\s+(.+)|(\d+\.?\s+[A-Z].+)|([A-Z\s]{5,}))$'
    
    lines = text.split('\n')
    current_section = "Introduction"
    current_content = []
    
    for line in lines:
        match = re.match(header_pattern, line.strip())
        if match:
            # Save previous section
            if current_content:
                sections.append((current_section, '\n'.join(current_content)))
            
            # Start new section
            current_section = match.group(1) or match.group(2) or match.group(3)
            current_content = []
        else:
            if line.strip():
                current_content.append(line)
    
    # Add last section
    if current_content:
        sections.append((current_section, '\n'.join(current_content)))
    
    return sections if sections else [("General", text)]

def categorize_section(section_title: str) -> str:
    """Categorize section based on title keywords"""
    title_lower = section_title.lower()
    
    categories = {
        "validation": ["validation", "verify", "check", "constraint"],
        "security": ["security", "authentication", "authorization", "access"],
        "business_logic": ["business", "logic", "rule", "process", "workflow"],
        "data": ["data", "database", "storage", "persistence"],
        "integration": ["integration", "api", "interface", "external"],
        "performance": ["performance", "optimization", "speed", "efficiency"],
        "compliance": ["compliance", "regulation", "legal", "audit"],
    }
    
    for category, keywords in categories.items():
        if any(keyword in title_lower for keyword in keywords):
            return category
    
    return "general"

def extract_paragraphs(text: str) -> List[str]:
    """Extract meaningful paragraphs from text"""
    paragraphs = []
    current_para = []
    
    for line in text.split('\n'):
        line = line.strip()
        if not line:
            if current_para:
                para_text = ' '.join(current_para)
                if len(para_text) > 30:  # Minimum length
                    paragraphs.append(para_text)
                current_para = []
        else:
            current_para.append(line)
    
    if current_para:
        para_text = ' '.join(current_para)
        if len(para_text) > 30:
            paragraphs.append(para_text)
    
    return paragraphs

def is_likely_business_rule(text: str) -> bool:
    """Determine if text is likely a business rule"""
    # Keywords that indicate business rules
    rule_indicators = [
        'must', 'should', 'shall', 'required', 'mandatory',
        'not allowed', 'prohibited', 'forbidden',
        'validation', 'verify', 'check', 'ensure',
        'if', 'when', 'whenever', 'then',
        'business rule', 'constraint', 'requirement'
    ]
    
    text_lower = text.lower()
    
    # Check for rule indicators
    has_indicator = any(indicator in text_lower for indicator in rule_indicators)
    
    # Check length (not too short, not too long)
    word_count = len(text.split())
    appropriate_length = 5 <= word_count <= 100
    
    # Check if it's not just a title or header
    not_header = not (text.isupper() or text.endswith(':'))
    
    return has_indicator and appropriate_length and not_header

def save_business_rules(rules: List[dict], project_name: str = None):
    """Save business rules to database (project-specific or global)"""
    if project_name:
        from app.database.project_db import project_db
        db = project_db.get_session(project_name)
    else:
        db = SessionLocal()
    
    try:
        for rule in rules:
            business_rule = BusinessRule(**rule)
            db.add(business_rule)
        db.commit()
    finally:
        db.close()
