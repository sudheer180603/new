import json
import logging
from typing import List, Dict, Any
from app.database.models import Ticket, CodeMetadata, BusinessRule, RCAResult
from app.services.azure_openai_client import azure_client
from app.embeddings.generator import embedding_generator
from app.rca_engine.advanced_analyzer import AdvancedRCAAnalyzer
from app.config import settings
import numpy as np

logger = logging.getLogger(__name__)

async def analyze_tickets(project_name: str = None, ticket_ids: List[str] = None) -> List[Dict[str, Any]]:
    """Enhanced ticket analysis with accurate root cause identification
    
    Args:
        project_name: Name of the project
        ticket_ids: Optional list of specific ticket IDs to analyze. If None, analyzes all tickets.
    """
    
    # Use project-specific database and stores
    if project_name:
        from app.database.project_db import project_db
        from app.vector_store.project_faiss import get_project_store
        db = project_db.get_session(project_name)
        code_store = get_project_store(project_name, embedding_generator.dimension, "code")
        business_store = get_project_store(project_name, embedding_generator.dimension, "business")
        logger.info(f"[{project_name}] Analyzing tickets with project-specific storage")
    else:
        # Fallback to global storage (legacy)
        from app.database.models import SessionLocal
        from app.vector_store.faiss_store import FAISSStore
        db = SessionLocal()
        code_store = FAISSStore(embedding_generator.dimension, "code")
        business_store = FAISSStore(embedding_generator.dimension, "business")
        logger.info("Analyzing tickets with global storage")
    
    try:
        # Get tickets based on selection
        if ticket_ids:
            tickets = db.query(Ticket).filter(Ticket.ticket_id.in_(ticket_ids)).all()
            logger.info(f"[{project_name or 'global'}] Analyzing {len(ticket_ids)} selected tickets: {ticket_ids}")
        else:
            tickets = db.query(Ticket).all()
            logger.info(f"[{project_name or 'global'}] Analyzing all {len(tickets)} tickets")
        
        if not tickets:
            logger.warning(f"[{project_name or 'global'}] No tickets found")
            return []
        
        results = []
        
        # Initialize advanced analyzer
        advanced_analyzer = AdvancedRCAAnalyzer(project_name)
        
        for ticket in tickets:
            logger.info(f"[{project_name or 'global'}] Analyzing ticket: {ticket.ticket_id}")
            
            # Enhanced ticket embedding with multiple queries
            relevant_code, relevant_rules = await retrieve_enhanced_context(
                ticket, code_store, business_store, db
            )
            
            # Use advanced analyzer with confidence boosting
            rca_result = await advanced_analyzer.analyze_with_confidence_boost(
                ticket, relevant_code, relevant_rules, db
            )
            results.append(rca_result)
            
            save_rca_result(rca_result, db)
        
        return results
    
    finally:
        db.close()

async def retrieve_enhanced_context(ticket, code_store, business_store, db) -> tuple:
    """Enhanced context retrieval with multiple search strategies"""
    
    # Strategy 1: Full ticket text
    ticket_text = f"{ticket.summary} {ticket.description}"
    ticket_embedding = embedding_generator.generate_single_embedding(ticket_text)
    
    # Strategy 2: Module-specific search if module is specified
    module_results = []
    if ticket.module:
        module_query = f"module {ticket.module} {ticket.summary}"
        module_embedding = embedding_generator.generate_single_embedding(module_query)
        module_results = code_store.search(module_embedding, k=settings.top_k_retrieval)
    
    # Strategy 3: Error/symptom-focused search
    symptom_embedding = embedding_generator.generate_single_embedding(ticket.description)
    
    # Combine results from all strategies
    code_results_main = code_store.search(ticket_embedding, k=settings.top_k_retrieval)
    code_results_symptom = code_store.search(symptom_embedding, k=settings.top_k_retrieval // 2)
    
    # Merge and deduplicate code results
    seen_ids = set()
    relevant_code = []
    
    for results in [code_results_main, module_results, code_results_symptom]:
        for code_meta, score in results:
            code_id = code_meta["id"]
            if code_id not in seen_ids and score >= settings.similarity_threshold:
                seen_ids.add(code_id)
                relevant_code.append((code_meta, score))
    
    # Sort by score and limit
    relevant_code.sort(key=lambda x: x[1], reverse=True)
    relevant_code = relevant_code[:settings.top_k_retrieval]
    
    # Retrieve business rules
    relevant_rules = business_store.search(ticket_embedding, k=8)
    
    return relevant_code, relevant_rules

async def perform_enhanced_rca(ticket, relevant_code, relevant_rules, db, project_name: str = None) -> Dict[str, Any]:
    """Enhanced RCA with better context and analysis"""
    
    # Build enriched code context
    code_context = []
    for code_meta, score in relevant_code:
        if score >= settings.similarity_threshold:
            code_block = db.query(CodeMetadata).filter(CodeMetadata.id == code_meta["id"]).first()
            if code_block:
                # Include more context
                context_entry = {
                    "file": code_block.file_path,
                    "class": code_block.class_name or "N/A",
                    "method": code_block.method_name or "N/A",
                    "lines": f"{code_block.start_line}-{code_block.end_line}",
                    "code": code_block.raw_code,
                    "node_type": code_block.node_type,
                    "dependencies": code_block.dependencies or [],
                    "similarity_score": float(score)
                }
                
                # Add related business rules if available
                if code_block.related_business_rules:
                    related_rules = db.query(BusinessRule).filter(
                        BusinessRule.id.in_(code_block.related_business_rules[:3])
                    ).all()
                    context_entry["related_business_rules"] = [
                        rule.rule_text[:200] for rule in related_rules
                    ]
                
                code_context.append(context_entry)
    
    # Build enriched business context
    business_context = []
    for rule_meta, score in relevant_rules:
        if score >= settings.similarity_threshold:
            rule = db.query(BusinessRule).filter(BusinessRule.id == rule_meta["id"]).first()
            if rule:
                business_context.append({
                    "rule": rule.rule_text,
                    "source": rule.source_document,
                    "category": getattr(rule, 'category', 'general'),
                    "section": getattr(rule, 'section', None),
                    "similarity_score": float(score)
                })
    
    # Enhanced system prompt with better instructions
    system_prompt = """You are an Enterprise Root Cause Analysis Engine with deep expertise in software debugging.

Your task is to analyze Jira tickets and identify the EXACT root cause based on provided code and business rules.

CRITICAL REQUIREMENTS:
1. ONLY reference code blocks provided in the context - never hallucinate files or methods
2. Identify the SPECIFIC lines of code causing the issue
3. Map the issue to relevant business rules
4. Provide actionable resolution steps
5. Return ONLY valid JSON - no markdown, no explanations outside JSON

ANALYSIS APPROACH:
1. Review the ticket description to understand the symptom
2. Examine each code block for potential issues
3. Cross-reference with business rules to identify gaps
4. Identify the root cause type and impacted code location
5. Provide specific resolution logic

OUTPUT FORMAT (strict JSON):
{
  "root_cause_type": "one of: Environment, Configuration, Data, Functional Gap, Code Defect, Integration Issue, Performance, Security",
  "impacted_file": "exact file path from code context",
  "impacted_method": "exact class.method or function name",
  "code_pointer": "file:line_start-line_end (exact lines from code context)",
  "current_logic": "what the code currently does (be specific)",
  "business_expected_logic": "what business rules expect (reference specific rules)",
  "resolution_logic": "specific steps to fix the issue",
  "fix_type": "one of: Logic fix, Validation added, Refactor, Architecture change, Performance optimization, Security fix",
  "confidence_score": 0.0-1.0,
  "affected_components": ["list of related files/modules that may be impacted"]
}"""

    user_prompt = f"""
TICKET ANALYSIS REQUEST
=======================

TICKET ID: {ticket.ticket_id}
PRIORITY: {ticket.priority}
MODULE: {ticket.module or 'Not specified'}

SUMMARY:
{ticket.summary}

DESCRIPTION:
{ticket.description}

RELEVANT CODE BLOCKS (sorted by relevance):
{json.dumps(code_context, indent=2)}

RELEVANT BUSINESS RULES:
{json.dumps(business_context, indent=2)}

INSTRUCTIONS:
Analyze the ticket against the provided code and business rules. Identify the EXACT root cause and provide specific resolution steps. Focus on the most relevant code blocks (highest similarity scores). Return ONLY the JSON response, no additional text."""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ]
    
    try:
        response = azure_client.chat_completion(messages)
        
        # Clean response (remove markdown if present)
        response = response.strip()
        if response.startswith("```json"):
            response = response[7:]
        if response.startswith("```"):
            response = response[3:]
        if response.endswith("```"):
            response = response[:-3]
        response = response.strip()
        
        rca_data = json.loads(response)
        rca_data["ticket_id"] = ticket.ticket_id
        
        # Validate that referenced files exist in context
        if rca_data.get("impacted_file"):
            file_exists = any(
                code["file"] == rca_data["impacted_file"] 
                for code in code_context
            )
            if not file_exists and code_context:
                # Use the most relevant file from context
                rca_data["impacted_file"] = code_context[0]["file"]
                rca_data["impacted_method"] = f"{code_context[0]['class']}.{code_context[0]['method']}"
                rca_data["code_pointer"] = f"{code_context[0]['file']}:{code_context[0]['lines']}"
        
        return rca_data
        
    except json.JSONDecodeError as e:
        logger.error(f"Failed to parse RCA response for {ticket.ticket_id}: {e}")
        logger.error(f"Response was: {response[:500]}")
        
        # Fallback response with best guess from context
        fallback = {
            "ticket_id": ticket.ticket_id,
            "root_cause_type": "Code Defect",
            "error": "Failed to parse AI response",
            "confidence_score": 0.3
        }
        
        if code_context:
            fallback.update({
                "impacted_file": code_context[0]["file"],
                "impacted_method": f"{code_context[0]['class']}.{code_context[0]['method']}",
                "code_pointer": f"{code_context[0]['file']}:{code_context[0]['lines']}",
                "current_logic": "Unable to analyze - see code context",
                "business_expected_logic": "Unable to determine",
                "resolution_logic": "Manual review required"
            })
        
        return fallback
    
    except Exception as e:
        logger.error(f"Error in RCA for {ticket.ticket_id}: {str(e)}")
        return {
            "ticket_id": ticket.ticket_id,
            "root_cause_type": "Unknown",
            "error": str(e),
            "confidence_score": 0.0
        }

def save_rca_result(rca_result: Dict[str, Any], db):
    """Save RCA result to database including code snippet"""
    rca = RCAResult(
        ticket_id=rca_result.get("ticket_id"),
        root_cause_type=rca_result.get("root_cause_type"),
        impacted_file=rca_result.get("impacted_file"),
        impacted_method=rca_result.get("impacted_method"),
        code_pointer=rca_result.get("code_pointer"),
        current_logic=rca_result.get("current_logic"),
        business_expected_logic=rca_result.get("business_expected_logic"),
        resolution_logic=rca_result.get("resolution_logic"),
        suggested_code_snippet=rca_result.get("suggested_code_snippet"),  # New field
        fix_type=rca_result.get("fix_type"),
        confidence_score=rca_result.get("confidence_score", 0.0)
    )
    db.add(rca)
    db.commit()
