import logging
from app.database.models import SessionLocal, CodeMetadata, BusinessRule
from app.embeddings.generator import embedding_generator
from app.vector_store.faiss_store import FAISSStore
import numpy as np

logger = logging.getLogger(__name__)

def build_unified_context() -> dict:
    db = SessionLocal()
    
    try:
        code_blocks = db.query(CodeMetadata).all()
        business_rules = db.query(BusinessRule).all()
        
        logger.info(f"Building context for {len(code_blocks)} code blocks and {len(business_rules)} business rules")
        
        code_store = FAISSStore(embedding_generator.dimension, "code")
        business_store = FAISSStore(embedding_generator.dimension, "business")
        
        if code_blocks:
            code_texts = [f"{block.class_name or ''}.{block.method_name or ''}\n{block.raw_code}" 
                         for block in code_blocks]
            code_embeddings = embedding_generator.generate_embeddings(code_texts)
            
            code_metadata = [{
                "id": block.id,
                "file_path": block.file_path,
                "class_name": block.class_name,
                "method_name": block.method_name,
                "start_line": block.start_line,
                "end_line": block.end_line
            } for block in code_blocks]
            
            code_store.add_vectors(code_embeddings, code_metadata)
            code_store.save()
            
            for i, block in enumerate(code_blocks):
                block.embedding_id = i
            db.commit()
        
        if business_rules:
            rule_texts = [rule.rule_text for rule in business_rules]
            rule_embeddings = embedding_generator.generate_embeddings(rule_texts)
            
            rule_metadata = [{
                "id": rule.id,
                "rule_text": rule.rule_text,
                "source_document": rule.source_document,
                "category": rule.category
            } for rule in business_rules]
            
            business_store.add_vectors(rule_embeddings, rule_metadata)
            business_store.save()
            
            for i, rule in enumerate(business_rules):
                rule.embedding_id = i
            db.commit()
        
        return {
            "code_blocks": len(code_blocks),
            "business_rules": len(business_rules),
            "embeddings_count": len(code_blocks) + len(business_rules)
        }
    
    finally:
        db.close()
