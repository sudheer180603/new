"""
Optimized project-specific context builder
- Parallel embedding generation
- Efficient cross-mapping with vectorized operations
- Progress tracking
- Memory optimization
"""
import logging
from app.database.project_db import project_db
from app.database.models import CodeMetadata, BusinessRule
from app.embeddings.generator import embedding_generator
from app.vector_store.project_faiss import get_project_store
import numpy as np
from typing import List, Dict
from concurrent.futures import ThreadPoolExecutor, as_completed
import time

logger = logging.getLogger(__name__)

def build_project_context(project_name: str) -> dict:
    """Build context with optimized performance"""
    start_time = time.time()
    db = project_db.get_session(project_name)
    
    try:
        code_blocks = db.query(CodeMetadata).all()
        business_rules = db.query(BusinessRule).all()
        
        logger.info(f"[{project_name}] Building context for {len(code_blocks)} code blocks and {len(business_rules)} business rules")
        
        # Project-specific FAISS stores
        code_store = get_project_store(project_name, embedding_generator.dimension, "code")
        business_store = get_project_store(project_name, embedding_generator.dimension, "business")
        
        embeddings_count = 0
        code_embeddings = None
        rule_embeddings = None
        
        # Process code blocks with optimized batching
        if code_blocks:
            logger.info(f"[{project_name}] Generating embeddings for {len(code_blocks)} code blocks...")
            
            # Prepare texts in parallel
            code_texts = prepare_code_texts_parallel(code_blocks)
            
            # Generate embeddings with optimized batch size
            code_embeddings = embedding_generator.generate_embeddings(
                code_texts,
                show_progress=True,
                use_cache=True
            )
            
            # Prepare metadata
            code_metadata = [{
                "id": block.id,
                "file_path": block.file_path,
                "class_name": block.class_name,
                "method_name": block.method_name,
                "start_line": block.start_line,
                "end_line": block.end_line,
                "node_type": block.node_type,
                "dependencies": block.dependencies
            } for block in code_blocks]
            
            # Add to vector store
            code_store.add_vectors(code_embeddings, code_metadata)
            code_store.save()
            
            # Update database in batch
            for i, block in enumerate(code_blocks):
                block.embedding_id = i
            db.commit()
            
            embeddings_count += len(code_blocks)
            logger.info(f"[{project_name}] Code embeddings complete ({len(code_blocks)} items)")
        
        # Process business rules with optimized batching
        if business_rules:
            logger.info(f"[{project_name}] Generating embeddings for {len(business_rules)} business rules...")
            
            # Prepare texts
            rule_texts = prepare_rule_texts(business_rules)
            
            # Generate embeddings
            rule_embeddings = embedding_generator.generate_embeddings(
                rule_texts,
                show_progress=True,
                use_cache=True
            )
            
            # Prepare metadata
            rule_metadata = [{
                "id": rule.id,
                "rule_text": rule.rule_text,
                "source_document": rule.source_document,
                "category": getattr(rule, 'category', 'general'),
                "section": getattr(rule, 'section', None)
            } for rule in business_rules]
            
            # Add to vector store
            business_store.add_vectors(rule_embeddings, rule_metadata)
            business_store.save()
            
            # Update database in batch
            for i, rule in enumerate(business_rules):
                rule.embedding_id = i
            db.commit()
            
            embeddings_count += len(business_rules)
            logger.info(f"[{project_name}] Business rule embeddings complete ({len(business_rules)} items)")
        
        # Create cross-mappings with optimized algorithm
        if code_blocks and business_rules and code_embeddings is not None and rule_embeddings is not None:
            logger.info(f"[{project_name}] Creating business logic to code mappings...")
            mappings_created = create_business_code_mappings_optimized(
                code_blocks, business_rules, code_embeddings, rule_embeddings, db
            )
            logger.info(f"[{project_name}] Created {mappings_created} business-code mappings")
        
        elapsed = time.time() - start_time
        logger.info(f"[{project_name}] Context building complete in {elapsed:.2f}s: {embeddings_count} total embeddings")
        
        # Log cache stats
        cache_stats = embedding_generator.get_cache_stats()
        if cache_stats['cache_hits'] > 0:
            logger.info(f"[{project_name}] Cache hit rate: {cache_stats['hit_rate']:.1%} ({cache_stats['cache_hits']} hits)")
        
        return {
            "code_blocks": len(code_blocks),
            "business_rules": len(business_rules),
            "embeddings_count": embeddings_count,
            "time_seconds": elapsed
        }
    
    finally:
        db.close()

def prepare_code_texts_parallel(code_blocks: List[CodeMetadata], max_workers: int = 4) -> List[str]:
    """Prepare code texts in parallel for faster processing"""
    
    def prepare_single_text(block):
        context_parts = []
        
        # Add file path context
        file_context = block.file_path.replace('/', ' ').replace('\\', ' ').replace('_', ' ')
        context_parts.append(f"File: {file_context}")
        
        # Add class and method context
        if block.class_name:
            context_parts.append(f"Class: {block.class_name}")
        if block.method_name:
            context_parts.append(f"Method: {block.method_name}")
        
        # Add dependencies context (limit to avoid too long)
        if block.dependencies:
            deps_str = ", ".join(block.dependencies[:10])
            context_parts.append(f"Uses: {deps_str}")
        
        # Add the actual code (truncate if too long)
        code = block.raw_code[:5000] if len(block.raw_code) > 5000 else block.raw_code
        context_parts.append(f"Code:\n{code}")
        
        return "\n".join(context_parts)
    
    # For small datasets, don't use threading overhead
    if len(code_blocks) < 100:
        return [prepare_single_text(block) for block in code_blocks]
    
    # Parallel processing for large datasets
    code_texts = [None] * len(code_blocks)
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(prepare_single_text, block): i 
                  for i, block in enumerate(code_blocks)}
        
        for future in as_completed(futures):
            idx = futures[future]
            code_texts[idx] = future.result()
    
    return code_texts

def prepare_rule_texts(business_rules: List[BusinessRule]) -> List[str]:
    """Prepare business rule texts efficiently"""
    rule_texts = []
    
    for rule in business_rules:
        context_parts = []
        
        if hasattr(rule, 'category') and rule.category:
            context_parts.append(f"Category: {rule.category}")
        
        if hasattr(rule, 'section') and rule.section:
            context_parts.append(f"Section: {rule.section}")
        
        # Truncate very long rules
        rule_text = rule.rule_text[:2000] if len(rule.rule_text) > 2000 else rule.rule_text
        context_parts.append(rule_text)
        
        rule_texts.append("\n".join(context_parts))
    
    return rule_texts

def create_business_code_mappings_optimized(
    code_blocks: List[CodeMetadata],
    business_rules: List[BusinessRule],
    code_embeddings: np.ndarray,
    rule_embeddings: np.ndarray,
    db
) -> int:
    """
    Optimized cross-mapping using vectorized operations
    - Single matrix multiplication for all similarities
    - Efficient top-k selection
    - Batch database updates
    """
    mappings_created = 0
    threshold = 0.65
    
    # Compute all similarities at once (vectorized)
    # Shape: (num_rules, num_code_blocks)
    all_similarities = np.dot(rule_embeddings, code_embeddings.T)
    
    # For each business rule, find top related code blocks
    for rule_idx, rule in enumerate(business_rules):
        similarities = all_similarities[rule_idx]
        
        # Get indices above threshold, sorted by similarity
        above_threshold = np.where(similarities >= threshold)[0]
        if len(above_threshold) > 0:
            # Sort by similarity (descending) and take top 10
            sorted_indices = above_threshold[np.argsort(-similarities[above_threshold])][:10]
            related_code_ids = [code_blocks[idx].id for idx in sorted_indices]
            
            rule.related_code_blocks = related_code_ids
            mappings_created += len(related_code_ids)
    
    # For each code block, find top related business rules
    # Transpose for code-to-rule similarities
    code_to_rule_similarities = all_similarities.T  # Shape: (num_code_blocks, num_rules)
    
    for code_idx, code_block in enumerate(code_blocks):
        similarities = code_to_rule_similarities[code_idx]
        
        # Get indices above threshold, sorted by similarity
        above_threshold = np.where(similarities >= threshold)[0]
        if len(above_threshold) > 0:
            # Sort by similarity (descending) and take top 5
            sorted_indices = above_threshold[np.argsort(-similarities[above_threshold])][:5]
            related_rule_ids = [business_rules[idx].id for idx in sorted_indices]
            
            code_block.related_business_rules = related_rule_ids
    
    # Batch commit
    db.commit()
    
    return mappings_created
