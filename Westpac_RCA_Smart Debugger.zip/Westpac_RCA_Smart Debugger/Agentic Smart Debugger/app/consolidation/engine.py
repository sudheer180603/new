from typing import List, Dict, Any
from sklearn.cluster import DBSCAN
import numpy as np
import logging
from app.embeddings.generator import embedding_generator

logger = logging.getLogger(__name__)

def consolidate_issues(rca_results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if len(rca_results) < 2:
        return []
    
    resolution_texts = [r.get("resolution_logic", "") for r in rca_results]
    embeddings = embedding_generator.generate_embeddings(resolution_texts)
    
    clustering = DBSCAN(eps=0.3, min_samples=2, metric='cosine')
    labels = clustering.fit_predict(embeddings)
    
    consolidated = []
    unique_labels = set(labels)
    
    for label in unique_labels:
        if label == -1:
            continue
        
        cluster_indices = np.where(labels == label)[0]
        cluster_tickets = [rca_results[i] for i in cluster_indices]
        
        impacted_files = list(set([t.get("impacted_file") for t in cluster_tickets if t.get("impacted_file")]))
        
        consolidated.append({
            "cluster_id": int(label),
            "primary_ticket": cluster_tickets[0].get("ticket_id"),
            "related_tickets": [t.get("ticket_id") for t in cluster_tickets[1:]],
            "shared_root_cause": cluster_tickets[0].get("root_cause_type"),
            "impacted_files": impacted_files,
            "ticket_count": len(cluster_tickets)
        })
    
    logger.info(f"Consolidated {len(rca_results)} tickets into {len(consolidated)} clusters")
    return consolidated
