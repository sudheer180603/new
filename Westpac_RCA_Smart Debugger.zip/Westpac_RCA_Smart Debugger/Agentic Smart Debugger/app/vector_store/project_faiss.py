"""
Project-specific FAISS vector store
Each project gets its own isolated FAISS indexes
"""
import faiss
import numpy as np
import pickle
import os
from typing import List, Tuple
import logging
from app.project_manager import project_manager

logger = logging.getLogger(__name__)

class ProjectFAISSStore:
    def __init__(self, project_name: str, dimension: int, index_name: str = "main"):
        self.project_name = project_name
        self.dimension = dimension
        self.index_name = index_name
        
        # Project-specific paths
        faiss_dir = project_manager.get_project_faiss_dir(project_name)
        os.makedirs(faiss_dir, exist_ok=True)
        
        self.index_path = os.path.join(faiss_dir, f"{index_name}.index")
        self.metadata_path = os.path.join(faiss_dir, f"{index_name}_metadata.pkl")
        
        if os.path.exists(self.index_path):
            self.load()
        else:
            self.index = faiss.IndexFlatIP(dimension)
            self.metadata = []
            logger.info(f"Created new FAISS index for project {project_name}: {index_name}")
    
    def add_vectors(self, vectors: np.ndarray, metadata: List[dict]):
        if len(vectors) != len(metadata):
            raise ValueError("Vectors and metadata must have same length")
        
        vectors = vectors.astype('float32')
        faiss.normalize_L2(vectors)
        self.index.add(vectors)
        self.metadata.extend(metadata)
        logger.info(f"[{self.project_name}] Added {len(vectors)} vectors to {self.index_name} index")
    
    def search(self, query_vector: np.ndarray, k: int = 10) -> List[Tuple[dict, float]]:
        if self.index.ntotal == 0:
            logger.warning(f"[{self.project_name}] Index {self.index_name} is empty")
            return []
        
        query_vector = query_vector.astype('float32').reshape(1, -1)
        faiss.normalize_L2(query_vector)
        
        # Limit k to available vectors
        k = min(k, self.index.ntotal)
        
        distances, indices = self.index.search(query_vector, k)
        
        results = []
        for idx, distance in zip(indices[0], distances[0]):
            if idx < len(self.metadata) and idx >= 0:
                results.append((self.metadata[idx], float(distance)))
        
        return results
    
    def save(self):
        faiss.write_index(self.index, self.index_path)
        with open(self.metadata_path, 'wb') as f:
            pickle.dump(self.metadata, f)
        logger.info(f"[{self.project_name}] Saved FAISS index to {self.index_path}")
    
    def load(self):
        self.index = faiss.read_index(self.index_path)
        with open(self.metadata_path, 'rb') as f:
            self.metadata = pickle.load(f)
        logger.info(f"[{self.project_name}] Loaded FAISS index from {self.index_path}")
    
    def get_size(self):
        """Get number of vectors in index"""
        return self.index.ntotal

def get_project_store(project_name: str, dimension: int, index_name: str) -> ProjectFAISSStore:
    """Factory function to get project-specific FAISS store"""
    return ProjectFAISSStore(project_name, dimension, index_name)
