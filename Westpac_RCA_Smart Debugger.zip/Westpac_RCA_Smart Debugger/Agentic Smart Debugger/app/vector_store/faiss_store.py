import faiss
import numpy as np
import pickle
import os
from typing import List, Tuple
import logging
from app.config import settings

logger = logging.getLogger(__name__)

class FAISSStore:
    def __init__(self, dimension: int, index_name: str = "main"):
        self.dimension = dimension
        self.index_name = index_name
        self.index_path = os.path.join(settings.faiss_index_dir, f"{index_name}.index")
        self.metadata_path = os.path.join(settings.faiss_index_dir, f"{index_name}_metadata.pkl")
        
        os.makedirs(settings.faiss_index_dir, exist_ok=True)
        
        if os.path.exists(self.index_path):
            self.load()
        else:
            self.index = faiss.IndexFlatIP(dimension)
            self.metadata = []
    
    def add_vectors(self, vectors: np.ndarray, metadata: List[dict]):
        if len(vectors) != len(metadata):
            raise ValueError("Vectors and metadata must have same length")
        
        vectors = vectors.astype('float32')
        faiss.normalize_L2(vectors)
        self.index.add(vectors)
        self.metadata.extend(metadata)
        logger.info(f"Added {len(vectors)} vectors to FAISS index")
    
    def search(self, query_vector: np.ndarray, k: int = 10) -> List[Tuple[dict, float]]:
        query_vector = query_vector.astype('float32').reshape(1, -1)
        faiss.normalize_L2(query_vector)
        
        distances, indices = self.index.search(query_vector, k)
        
        results = []
        for idx, distance in zip(indices[0], distances[0]):
            if idx < len(self.metadata):
                results.append((self.metadata[idx], float(distance)))
        
        return results
    
    def save(self):
        faiss.write_index(self.index, self.index_path)
        with open(self.metadata_path, 'wb') as f:
            pickle.dump(self.metadata, f)
        logger.info(f"Saved FAISS index to {self.index_path}")
    
    def load(self):
        self.index = faiss.read_index(self.index_path)
        with open(self.metadata_path, 'rb') as f:
            self.metadata = pickle.load(f)
        logger.info(f"Loaded FAISS index from {self.index_path}")
