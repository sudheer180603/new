"""
Project-based context management system
Each project has its own isolated context, embeddings, and tickets
"""
import os
import json
import shutil
from typing import Dict, List, Optional
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

class Project:
    def __init__(self, name: str, repo_path: str = None):
        self.name = name
        self.repo_path = repo_path
        self.created_at = datetime.now().isoformat()
        self.code_indexed = False
        self.business_docs_processed = False
        self.context_built = False
        self.stats = {
            "files_parsed": 0,
            "languages": {},
            "business_rules": 0,
            "code_blocks": 0,
            "embeddings": 0
        }
    
    def to_dict(self):
        return {
            "name": self.name,
            "repo_path": self.repo_path,
            "created_at": self.created_at,
            "code_indexed": self.code_indexed,
            "business_docs_processed": self.business_docs_processed,
            "context_built": self.context_built,
            "stats": self.stats
        }
    
    @staticmethod
    def from_dict(data):
        project = Project(data["name"], data.get("repo_path"))
        project.created_at = data.get("created_at", datetime.now().isoformat())
        project.code_indexed = data.get("code_indexed", False)
        project.business_docs_processed = data.get("business_docs_processed", False)
        project.context_built = data.get("context_built", False)
        project.stats = data.get("stats", {})
        return project

class ProjectManager:
    def __init__(self, projects_dir: str = "./projects"):
        self.projects_dir = projects_dir
        self.current_project: Optional[Project] = None
        os.makedirs(projects_dir, exist_ok=True)
        self.projects_file = os.path.join(projects_dir, "projects.json")
        self.load_projects()
    
    def load_projects(self):
        """Load projects from disk"""
        if os.path.exists(self.projects_file):
            try:
                with open(self.projects_file, 'r') as f:
                    self.projects_data = json.load(f)
            except:
                self.projects_data = {}
        else:
            self.projects_data = {}
    
    def save_projects(self):
        """Save projects to disk"""
        with open(self.projects_file, 'w') as f:
            json.dump(self.projects_data, f, indent=2)
    
    def create_project(self, name: str, repo_path: str = None) -> Project:
        """Create a new project"""
        if name in self.projects_data:
            raise ValueError(f"Project '{name}' already exists")
        
        project = Project(name, repo_path)
        self.projects_data[name] = project.to_dict()
        self.save_projects()
        
        # Create project directory structure
        project_dir = self.get_project_dir(name)
        os.makedirs(project_dir, exist_ok=True)
        os.makedirs(os.path.join(project_dir, "faiss_index"), exist_ok=True)
        os.makedirs(os.path.join(project_dir, "database"), exist_ok=True)
        os.makedirs(os.path.join(project_dir, "cloned_repos"), exist_ok=True)
        os.makedirs(os.path.join(project_dir, "uploaded_docs"), exist_ok=True)
        
        logger.info(f"Created project: {name}")
        return project
    
    def get_project(self, name: str) -> Optional[Project]:
        """Get a project by name"""
        if name in self.projects_data:
            return Project.from_dict(self.projects_data[name])
        return None
    
    def list_projects(self) -> List[str]:
        """List all project names"""
        return list(self.projects_data.keys())
    
    def set_current_project(self, name: str):
        """Set the current active project"""
        project = self.get_project(name)
        if not project:
            raise ValueError(f"Project '{name}' not found")
        self.current_project = project
        logger.info(f"Set current project to: {name}")
    
    def get_current_project(self) -> Optional[Project]:
        """Get the current active project"""
        return self.current_project
    
    def update_project(self, name: str, updates: Dict):
        """Update project data"""
        if name not in self.projects_data:
            raise ValueError(f"Project '{name}' not found")
        
        self.projects_data[name].update(updates)
        self.save_projects()
        
        # Update current project if it's the same
        if self.current_project and self.current_project.name == name:
            self.current_project = Project.from_dict(self.projects_data[name])
    
    def get_project_dir(self, name: str) -> str:
        """Get the directory path for a project"""
        return os.path.join(self.projects_dir, name)
    
    def get_project_db_path(self, name: str) -> str:
        """Get the database path for a project"""
        return os.path.join(self.get_project_dir(name), "database", "project.db")
    
    def get_project_faiss_dir(self, name: str) -> str:
        """Get the FAISS index directory for a project"""
        return os.path.join(self.get_project_dir(name), "faiss_index")
    
    def get_project_repos_dir(self, name: str) -> str:
        """Get the cloned repositories directory for a project"""
        return os.path.join(self.get_project_dir(name), "cloned_repos")
    
    def get_project_docs_dir(self, name: str) -> str:
        """Get the uploaded documents directory for a project"""
        return os.path.join(self.get_project_dir(name), "uploaded_docs")
    
    def delete_project(self, name: str):
        """Delete a project and all its data"""
        if name not in self.projects_data:
            raise ValueError(f"Project '{name}' not found")
        
        # Remove project directory
        project_dir = self.get_project_dir(name)
        if os.path.exists(project_dir):
            shutil.rmtree(project_dir)
        
        # Remove from projects data
        del self.projects_data[name]
        self.save_projects()
        
        # Clear current project if it's the deleted one
        if self.current_project and self.current_project.name == name:
            self.current_project = None
        
        logger.info(f"Deleted project: {name}")

# Global project manager instance
project_manager = ProjectManager()
