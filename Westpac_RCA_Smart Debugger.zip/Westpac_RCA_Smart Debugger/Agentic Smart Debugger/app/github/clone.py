import git
import os
import shutil
from urllib.parse import urlparse
import logging
from app.config import settings

logger = logging.getLogger(__name__)

def is_github_url(path: str) -> bool:
    """Check if the path is a GitHub URL"""
    if not path:
        return False
    path = path.strip()
    return path.startswith('http://') or path.startswith('https://') or path.startswith('git@')

def clone_repository(repo_url_or_path: str, project_name: str = None) -> str:
    """
    Clone a GitHub repository or use a local folder path
    
    Args:
        repo_url_or_path: Either a GitHub URL or a local folder path
        project_name: Optional project name for project-specific storage
        
    Returns:
        Path to the repository (cloned or local)
    """
    if not repo_url_or_path:
        raise ValueError("Repository URL or path cannot be empty")
    
    repo_url_or_path = repo_url_or_path.strip()
    
    if not repo_url_or_path:
        raise ValueError("Repository URL or path cannot be empty")
    
    # Check if it's a local path
    if not is_github_url(repo_url_or_path):
        local_path = os.path.abspath(repo_url_or_path)
        if os.path.exists(local_path) and os.path.isdir(local_path):
            logger.info(f"Using local folder: {local_path}")
            cleanup_repository(local_path)
            return local_path
        else:
            raise ValueError(f"Local path does not exist or is not a directory: {local_path}")
    
    # It's a GitHub URL - clone it
    try:
        parsed = urlparse(repo_url_or_path)
        repo_name = os.path.basename(parsed.path).replace('.git', '')
        
        if not repo_name:
            raise ValueError("Invalid GitHub URL: cannot extract repository name")
        
        # Determine clone directory
        if project_name:
            from app.project_manager import project_manager
            clone_base_dir = project_manager.get_project_repos_dir(project_name)
        else:
            clone_base_dir = settings.clone_dir
        
        # Allow duplicates by adding timestamp
        import time
        timestamp = int(time.time())
        repo_path = os.path.join(clone_base_dir, f"{repo_name}_{timestamp}")
        
        os.makedirs(clone_base_dir, exist_ok=True)
        
        log_prefix = f"[{project_name}] " if project_name else ""
        logger.info(f"{log_prefix}Cloning {repo_url_or_path} to {repo_path}")
        git.Repo.clone_from(repo_url_or_path, repo_path)
        
        cleanup_repository(repo_path)
        
        return repo_path
    except git.exc.GitCommandError as e:
        logger.error(f"Git clone error: {str(e)}")
        raise ValueError(f"Failed to clone repository: {str(e)}")

def cleanup_repository(repo_path: str):
    """Remove unnecessary directories from repository"""
    if not repo_path or not os.path.exists(repo_path):
        logger.warning(f"Cannot cleanup: invalid path {repo_path}")
        return
    
    exclude_dirs = ['node_modules', '.git', 'venv', 'dist', 'build', '__pycache__']
    
    for root, dirs, files in os.walk(repo_path, topdown=True):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
    
    for exclude_dir in exclude_dirs:
        exclude_path = os.path.join(repo_path, exclude_dir)
        if os.path.exists(exclude_path):
            try:
                shutil.rmtree(exclude_path)
                logger.info(f"Removed {exclude_dir}")
            except Exception as e:
                logger.warning(f"Could not remove {exclude_dir}: {str(e)}")
