"""
Project-specific database management
Each project gets its own isolated database
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.database.models import Base
from app.project_manager import project_manager
import os
import logging

logger = logging.getLogger(__name__)

class ProjectDatabase:
    def __init__(self):
        self.engines = {}
        self.session_makers = {}
    
    def get_engine(self, project_name: str):
        """Get or create engine for a project"""
        if project_name not in self.engines:
            db_path = project_manager.get_project_db_path(project_name)
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
            
            db_url = f"sqlite:///{db_path}"
            engine = create_engine(db_url, connect_args={"check_same_thread": False})
            
            # Create tables
            Base.metadata.create_all(bind=engine)
            
            self.engines[project_name] = engine
            self.session_makers[project_name] = sessionmaker(autocommit=False, autoflush=False, bind=engine)
            
            logger.info(f"Created database for project: {project_name} at {db_path}")
        
        return self.engines[project_name]
    
    def get_session(self, project_name: str):
        """Get a database session for a project"""
        if project_name not in self.session_makers:
            self.get_engine(project_name)
        
        return self.session_makers[project_name]()
    
    def init_project_db(self, project_name: str):
        """Initialize database for a project"""
        engine = self.get_engine(project_name)
        Base.metadata.create_all(bind=engine)
        logger.info(f"Initialized database for project: {project_name}")

# Global project database manager
project_db = ProjectDatabase()
