from sqlalchemy import create_engine, Column, Integer, String, Text, Float, JSON, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from app.config import settings

Base = declarative_base()

class CodeMetadata(Base):
    __tablename__ = "code_metadata"
    
    id = Column(Integer, primary_key=True, index=True)
    file_path = Column(String, index=True)
    node_type = Column(String)  # Changed from 'type' to 'node_type' to avoid Python keyword conflict
    class_name = Column(String, nullable=True)
    method_name = Column(String, index=True)
    start_line = Column(Integer)
    end_line = Column(Integer)
    raw_code = Column(Text)
    cst_tree = Column(JSON)
    dependencies = Column(JSON)
    related_business_rules = Column(JSON)
    enrichment = Column(JSON, nullable=True)  # Enhanced extraction data
    enhanced_description = Column(Text, nullable=True)  # Enhanced description for better matching
    embedding_id = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)

class BusinessRule(Base):
    __tablename__ = "business_rules"
    
    id = Column(Integer, primary_key=True, index=True)
    rule_text = Column(Text)
    source_document = Column(String)
    category = Column(String)
    section = Column(String, nullable=True)  # New field for section context
    related_code_blocks = Column(JSON, nullable=True)  # New field for code mappings
    embedding_id = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)

class DependencyGraph(Base):
    __tablename__ = "dependency_graph"
    
    id = Column(Integer, primary_key=True, index=True)
    source_file = Column(String)
    target_file = Column(String)
    dependency_type = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

class Ticket(Base):
    __tablename__ = "tickets"
    
    id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(String, unique=True, index=True)
    summary = Column(String)
    description = Column(Text)
    priority = Column(String)
    module = Column(String)
    embedding_id = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)

class RCAResult(Base):
    __tablename__ = "rca_results"
    
    id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(String, index=True)
    root_cause_type = Column(String)
    impacted_file = Column(String)
    impacted_method = Column(String)
    code_pointer = Column(String)
    current_logic = Column(Text)
    business_expected_logic = Column(Text)
    resolution_logic = Column(Text)
    suggested_code_snippet = Column(Text, nullable=True)  # New field for code snippets
    fix_type = Column(String)
    confidence_score = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)

engine = create_engine(settings.database_url, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def init_db():
    Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
