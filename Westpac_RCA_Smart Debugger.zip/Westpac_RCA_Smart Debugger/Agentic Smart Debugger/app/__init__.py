"""
Smart Debugger Application Package

This module applies necessary patches for Python 3.12+ compatibility
"""
import warnings
import sys

# Apply multiprocess fix for Python 3.12+
if sys.version_info >= (3, 12):
    warnings.filterwarnings("ignore", category=UserWarning, module="multiprocess.resource_tracker")
    warnings.filterwarnings("ignore", message=".*_recursion_count.*")
    
    try:
        import multiprocess.resource_tracker as resource_tracker
        
        # Store original method if it exists
        if hasattr(resource_tracker.ResourceTracker, '__del__'):
            _original_del = resource_tracker.ResourceTracker.__del__
            
            # Create patched version
            def _patched_del(self):
                try:
                    if _original_del is not None:
                        _original_del(self)
                except AttributeError as e:
                    # Silently ignore _recursion_count error
                    if '_recursion_count' not in str(e):
                        raise
                except Exception:
                    # Silently ignore other cleanup errors
                    pass
            
            # Apply patch
            resource_tracker.ResourceTracker.__del__ = _patched_del
        
    except (ImportError, AttributeError, Exception):
        # multiprocess not available or already patched
        pass
