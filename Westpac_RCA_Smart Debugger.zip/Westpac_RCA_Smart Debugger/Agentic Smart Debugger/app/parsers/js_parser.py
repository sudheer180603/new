from tree_sitter import Language, Parser
import tree_sitter_javascript as tsjs
import tree_sitter_typescript as tsts
from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)

class JSParser:
    def __init__(self):
        try:
            self.js_language = Language(tsjs.language())
            self.ts_language = Language(tsts.language_typescript())
            self.parser = Parser()
        except Exception as e:
            logger.error(f"Error initializing JS parser: {str(e)}")
            self.parser = None
    
    def parse_file(self, file_path: str, content: str, is_typescript: bool = False) -> List[Dict[str, Any]]:
        if not self.parser:
            logger.warning(f"Parser not initialized, skipping {file_path}")
            return []
        
        try:
            self.parser.language = self.ts_language if is_typescript else self.js_language
            tree = self.parser.parse(bytes(content, "utf8"))
            self.content_lines = content.split('\n')
            return self.extract_code_blocks(file_path, tree.root_node, content)
        except Exception as e:
            logger.error(f"Error parsing {file_path}: {str(e)}")
            return []
    
    def extract_code_blocks(self, file_path: str, node, content: str, parent_class: str = None) -> List[Dict[str, Any]]:
        code_blocks = []
        
        # Handle class declarations
        if node.type == 'class_declaration':
            class_name = self.get_class_name(node)
            code_blocks.append(self.create_code_block(file_path, node, content, class_name=class_name))
            
            # Process class methods with class context
            for child in node.children:
                if child.type == 'class_body':
                    for method in child.children:
                        if method.type in ['method_definition', 'field_definition']:
                            code_blocks.extend(self.extract_code_blocks(file_path, method, content, parent_class=class_name))
        
        # Handle functions and methods
        elif node.type in ['function_declaration', 'arrow_function', 'method_definition', 
                           'function_expression', 'field_definition']:
            code_blocks.append(self.create_code_block(file_path, node, content, class_name=parent_class))
        
        # Recursively process children (skip if already processed class body)
        else:
            for child in node.children:
                code_blocks.extend(self.extract_code_blocks(file_path, child, content, parent_class))
        
        return code_blocks
    
    def create_code_block(self, file_path: str, node, content: str, class_name: str = None) -> Dict[str, Any]:
        # Accurate line numbers (tree-sitter uses 0-based indexing)
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        
        # Extract exact code
        raw_code = content[node.start_byte:node.end_byte]
        
        # Extract dependencies (imports, function calls)
        dependencies = self.extract_dependencies(node, content)
        
        return {
            "file_path": file_path,
            "node_type": node.type,
            "class_name": class_name,
            "method_name": self.get_function_name(node),
            "start_line": start_line,
            "end_line": end_line,
            "raw_code": raw_code,
            "cst_tree": str(node)[:500],
            "dependencies": dependencies,
            "related_business_rules": None,
            "embedding_id": None
        }
    
    def get_class_name(self, node) -> str:
        """Extract class name from class declaration"""
        for child in node.children:
            if child.type == 'identifier':
                return child.text.decode('utf8')
        return "AnonymousClass"
    
    def get_function_name(self, node) -> str:
        """Extract function/method name"""
        # For method definitions, look for property_identifier
        for child in node.children:
            if child.type in ['identifier', 'property_identifier']:
                return child.text.decode('utf8')
        
        # For arrow functions assigned to variables
        if node.parent and node.parent.type == 'variable_declarator':
            for child in node.parent.children:
                if child.type == 'identifier':
                    return child.text.decode('utf8')
        
        return "anonymous"
    
    def extract_dependencies(self, node, content: str) -> List[str]:
        """Extract function calls and imports from the node"""
        dependencies = []
        
        # Recursively find call expressions
        self._extract_calls(node, dependencies)
        
        return list(set(dependencies))  # Remove duplicates
    
    def _extract_calls(self, node, dependencies: List[str]):
        """Recursively extract function/method calls"""
        if node.type == 'call_expression':
            # Extract the function being called
            func_node = node.child_by_field_name('function')
            if func_node:
                if func_node.type == 'identifier':
                    dependencies.append(func_node.text.decode('utf8'))
                elif func_node.type == 'member_expression':
                    # Extract method calls like obj.method()
                    prop = func_node.child_by_field_name('property')
                    if prop:
                        dependencies.append(prop.text.decode('utf8'))
        
        # Recurse through children
        for child in node.children:
            self._extract_calls(child, dependencies)
