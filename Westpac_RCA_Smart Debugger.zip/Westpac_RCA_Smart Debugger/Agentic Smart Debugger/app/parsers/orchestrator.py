import os
from typing import Dict, Any
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging
from app.parsers.python_parser import PythonParser
from app.parsers.js_parser import JSParser
from app.parsers.universal_parser import UniversalParser, LANGUAGE_CONFIG
from app.parsers.enhanced_extractor import EnhancedExtractor
from app.database.project_db import project_db
from app.database.models import CodeMetadata
from app.project_manager import project_manager
from app.config import settings

logger = logging.getLogger(__name__)

class ParserOrchestrator:
    def __init__(self, project_name: str = None, use_universal: bool = None):
        self.project_name = project_name
        self.use_universal = use_universal if use_universal is not None else settings.use_universal_parser
        
        # Initialize parsers
        if self.use_universal:
            self.universal_parser = UniversalParser()
            self.supported_extensions = LANGUAGE_CONFIG
            logger.info(f"[{self.project_name or 'global'}] Using Universal Parser - {len(LANGUAGE_CONFIG)} languages supported")
        else:
            # Legacy parsers for backward compatibility
            self.python_parser = PythonParser()
            self.js_parser = JSParser()
            self.supported_extensions = {
                '.py': 'python',
                '.js': 'javascript',
                '.jsx': 'javascript',
                '.ts': 'typescript',
                '.tsx': 'typescript'
            }
            logger.info(f"[{self.project_name or 'global'}] Using Legacy Parsers")
    
    def parse_repository(self, repo_path: str) -> Dict[str, Any]:
        files_to_parse = []
        
        # Collect all code files
        for root, dirs, files in os.walk(repo_path):
            # Skip common non-code directories
            dirs[:] = [d for d in dirs if d not in {
                'node_modules', '.git', '__pycache__', 'venv', 'env',
                '.venv', 'build', 'dist', 'target', '.idea', '.vscode'
            }]
            
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                
                if self.use_universal:
                    # Universal parser: accept all known extensions + try unknown ones
                    if ext in self.supported_extensions or self._is_text_file(file):
                        file_path = os.path.join(root, file)
                        # Skip very large files
                        try:
                            if os.path.getsize(file_path) < 5 * 1024 * 1024:  # 5MB limit
                                files_to_parse.append(file_path)
                        except:
                            pass
                else:
                    # Legacy: only supported extensions
                    if ext in self.supported_extensions:
                        files_to_parse.append(os.path.join(root, file))
        
        logger.info(f"[{self.project_name or 'global'}] Found {len(files_to_parse)} files to parse")
        
        results = {"total_files": 0, "languages": {}, "skipped": 0, "dependencies_extracted": 0}
        
        # Use configured number of workers for better performance
        max_workers = min(settings.max_workers, (os.cpu_count() or 4))
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {executor.submit(self.parse_file, fp): fp for fp in files_to_parse}
            
            for future in as_completed(futures):
                file_path = futures[future]
                try:
                    code_blocks = future.result()
                    if code_blocks:
                        self.save_to_db(code_blocks)
                        results["total_files"] += 1
                        
                        ext = os.path.splitext(file_path)[1].lower()
                        if self.use_universal and ext in self.supported_extensions:
                            lang = self.supported_extensions[ext]['name']
                        elif not self.use_universal and ext in self.supported_extensions:
                            lang = self.supported_extensions[ext]
                        else:
                            lang = 'other'
                        
                        results["languages"][lang] = results["languages"].get(lang, 0) + 1
                    else:
                        results["skipped"] += 1
                except Exception as e:
                    logger.error(f"Error processing {file_path}: {str(e)}")
                    results["skipped"] += 1
        
        logger.info(f"[{self.project_name or 'global'}] Parsed {results['total_files']} files, skipped {results['skipped']}")
        return results
    
    def _is_text_file(self, filename: str) -> bool:
        """Check if file is likely a text/code file"""
        text_extensions = {
            '.txt', '.md', '.rst', '.yaml', '.yml', '.json', '.xml',
            '.html', '.css', '.scss', '.sass', '.less', '.sql',
            '.sh', '.bash', '.zsh', '.fish', '.ps1', '.bat', '.cmd'
        }
        ext = os.path.splitext(filename)[1].lower()
        return ext in text_extensions
    
    def parse_file(self, file_path: str):
        """Parse a single file using appropriate parser with enrichment"""
        ext = os.path.splitext(file_path)[1].lower()
        
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except Exception as e:
            logger.error(f"Error reading {file_path}: {e}")
            return []
        
        # Skip empty files
        if not content.strip():
            return []
        
        # Parse based on parser type
        code_blocks = []
        if self.use_universal:
            # Use universal parser for all languages
            code_blocks = self.universal_parser.parse_file(file_path, content)
        else:
            # Legacy parser logic
            if ext == '.py':
                code_blocks = self.python_parser.parse_file(file_path, content)
            elif ext in ['.js', '.jsx']:
                code_blocks = self.js_parser.parse_file(file_path, content, is_typescript=False)
            elif ext in ['.ts', '.tsx']:
                code_blocks = self.js_parser.parse_file(file_path, content, is_typescript=True)
        
        # Enrich code blocks with enhanced extraction
        if code_blocks:
            # Determine language for enrichment
            if self.use_universal and ext in self.supported_extensions:
                language = self.supported_extensions[ext]['name']
            elif not self.use_universal and ext in self.supported_extensions:
                language = self.supported_extensions[ext]
            else:
                language = 'unknown'
            
            # Enrich each code block
            enriched_blocks = []
            for block in code_blocks:
                try:
                    enriched_block = EnhancedExtractor.enrich_code_block(block, language)
                    enriched_blocks.append(enriched_block)
                except Exception as e:
                    logger.warning(f"Failed to enrich block in {file_path}: {e}")
                    enriched_blocks.append(block)  # Use original if enrichment fails
            
            return enriched_blocks
        
        return []
    
    def save_to_db(self, code_blocks):
        """Save code blocks to database with batch optimization and populate dependency graph"""
        if not code_blocks:
            return
        
        if self.project_name:
            db = project_db.get_session(self.project_name)
        else:
            from app.database.models import SessionLocal
            db = SessionLocal()
        
        try:
            # Batch insert for better performance
            db.bulk_insert_mappings(CodeMetadata, code_blocks)
            db.commit()
            
            # Populate dependency graph
            self._populate_dependency_graph(code_blocks, db)
            
        except Exception as e:
            logger.error(f"Batch insert failed, falling back to individual inserts: {e}")
            # Fallback to individual inserts
            db.rollback()
            for block in code_blocks:
                try:
                    metadata = CodeMetadata(**block)
                    db.add(metadata)
                except Exception as block_error:
                    logger.error(f"Error inserting block: {block_error}")
            db.commit()
            
            # Populate dependency graph even after fallback
            self._populate_dependency_graph(code_blocks, db)
            
        finally:
            db.close()
    
    def _populate_dependency_graph(self, code_blocks, db):
        """Extract and store file-level dependencies in DependencyGraph table"""
        from app.database.models import DependencyGraph
        
        dependency_entries = []
        file_dependencies = {}  # Track dependencies per file
        
        for block in code_blocks:
            source_file = block.get('file_path')
            dependencies = block.get('dependencies', [])
            
            if not source_file or not dependencies:
                continue
            
            # Initialize file dependencies tracking
            if source_file not in file_dependencies:
                file_dependencies[source_file] = set()
            
            # Process each dependency
            for dep in dependencies:
                if not dep:
                    continue
                
                # Determine dependency type and target
                dep_type, target_file = self._resolve_dependency(dep, source_file, block)
                
                if target_file and target_file != source_file:
                    # Create unique key to avoid duplicates
                    dep_key = (source_file, target_file, dep_type)
                    
                    if dep_key not in file_dependencies[source_file]:
                        file_dependencies[source_file].add(dep_key)
                        dependency_entries.append({
                            'source_file': source_file,
                            'target_file': target_file,
                            'dependency_type': dep_type
                        })
        
        # Batch insert dependency graph entries
        if dependency_entries:
            try:
                db.bulk_insert_mappings(DependencyGraph, dependency_entries)
                db.commit()
                logger.info(f"[{self.project_name or 'global'}] Populated dependency graph with {len(dependency_entries)} edges")
            except Exception as e:
                logger.error(f"Error populating dependency graph: {e}")
                db.rollback()
    
    def _resolve_dependency(self, dep: str, source_file: str, block: dict) -> tuple:
        """Resolve dependency to target file and type"""
        # Determine dependency type based on patterns
        dep_lower = dep.lower()
        
        # Import dependencies
        if any(keyword in dep_lower for keyword in ['import', 'require', 'from', 'include']):
            return ('import', self._extract_import_target(dep, source_file))
        
        # Inheritance dependencies
        if block.get('node_type') == 'class' and dep in (block.get('dependencies', [])):
            return ('inheritance', f"class:{dep}")
        
        # Function call dependencies
        if '.' in dep:
            # Method call like obj.method or module.function
            parts = dep.split('.')
            if len(parts) == 2:
                return ('method_call', f"method:{dep}")
            return ('module_call', f"module:{parts[0]}")
        
        # Direct function call
        return ('function_call', f"function:{dep}")
    
    def _extract_import_target(self, dep: str, source_file: str) -> str:
        """Extract target file from import statement"""
        # This is a simplified version - can be enhanced based on language
        # For now, return the dependency as-is with import prefix
        return f"import:{dep}"

def parse_repository(repo_path: str, project_name: str = None) -> Dict[str, Any]:
    orchestrator = ParserOrchestrator(project_name)
    return orchestrator.parse_repository(repo_path)
