"""
Enhanced code extraction module for maximum accuracy
- Deep AST analysis
- Control flow extraction
- Variable tracking
- Comment extraction
- Docstring parsing
"""
import re
from typing import List, Dict, Any, Set
import logging

logger = logging.getLogger(__name__)

class EnhancedExtractor:
    """Extract additional context from code for better RCA"""
    
    @staticmethod
    def extract_comments(code: str, comment_char: str = '#') -> List[str]:
        """Extract all comments from code"""
        comments = []
        for line in code.split('\n'):
            stripped = line.strip()
            if stripped.startswith(comment_char):
                comment = stripped.lstrip(comment_char).strip()
                if len(comment) > 5:  # Meaningful comments only
                    comments.append(comment)
        return comments
    
    @staticmethod
    def extract_docstrings(code: str) -> List[str]:
        """Extract docstrings from Python code"""
        docstrings = []
        # Match triple-quoted strings
        patterns = [
            r'"""(.*?)"""',
            r"'''(.*?)'''",
        ]
        for pattern in patterns:
            matches = re.findall(pattern, code, re.DOTALL)
            docstrings.extend([m.strip() for m in matches if len(m.strip()) > 10])
        return docstrings
    
    @staticmethod
    def extract_error_handling(code: str) -> List[Dict[str, str]]:
        """Extract error handling patterns"""
        error_patterns = []
        
        # Try-catch blocks
        try_pattern = r'try\s*{([^}]+)}\s*catch\s*\(([^)]+)\)\s*{([^}]+)}'
        for match in re.finditer(try_pattern, code, re.DOTALL):
            error_patterns.append({
                "type": "try-catch",
                "try_block": match.group(1).strip()[:200],
                "exception": match.group(2).strip(),
                "catch_block": match.group(3).strip()[:200]
            })
        
        # Python try-except
        py_try_pattern = r'try:(.*?)except\s+(\w+).*?:(.*?)(?=\n\S|\Z)'
        for match in re.finditer(py_try_pattern, code, re.DOTALL):
            error_patterns.append({
                "type": "try-except",
                "try_block": match.group(1).strip()[:200],
                "exception": match.group(2).strip(),
                "except_block": match.group(3).strip()[:200]
            })
        
        return error_patterns
    
    @staticmethod
    def extract_validations(code: str) -> List[Dict[str, str]]:
        """Extract validation patterns"""
        validations = []
        
        # If statements with validation keywords
        validation_keywords = ['validate', 'check', 'verify', 'ensure', 'assert', 'require']
        
        for keyword in validation_keywords:
            pattern = rf'if\s+.*{keyword}.*?[{{:]'
            for match in re.finditer(pattern, code, re.IGNORECASE):
                validations.append({
                    "type": "validation",
                    "keyword": keyword,
                    "condition": match.group(0).strip()[:200]
                })
        
        # Null/None checks
        null_pattern = r'if\s+.*(?:==|!=|is|is not)\s*(?:null|None|nil|undefined)'
        for match in re.finditer(null_pattern, code, re.IGNORECASE):
            validations.append({
                "type": "null_check",
                "condition": match.group(0).strip()[:200]
            })
        
        return validations
    
    @staticmethod
    def extract_loops(code: str) -> List[Dict[str, str]]:
        """Extract loop patterns"""
        loops = []
        
        # For loops
        for_pattern = r'for\s*\([^)]+\)|for\s+\w+\s+in\s+'
        for match in re.finditer(for_pattern, code):
            loops.append({
                "type": "for_loop",
                "declaration": match.group(0).strip()[:200]
            })
        
        # While loops
        while_pattern = r'while\s*\([^)]+\)|while\s+.+?:'
        for match in re.finditer(while_pattern, code):
            loops.append({
                "type": "while_loop",
                "condition": match.group(0).strip()[:200]
            })
        
        return loops
    
    @staticmethod
    def extract_database_operations(code: str) -> List[Dict[str, str]]:
        """Extract database operation patterns"""
        db_ops = []
        
        # SQL keywords
        sql_keywords = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'DROP', 'ALTER']
        for keyword in sql_keywords:
            pattern = rf'{keyword}\s+.*?(?:FROM|INTO|TABLE|WHERE)'
            for match in re.finditer(pattern, code, re.IGNORECASE):
                db_ops.append({
                    "type": "sql",
                    "operation": keyword,
                    "query": match.group(0).strip()[:200]
                })
        
        # ORM patterns
        orm_patterns = [
            r'\.query\([^)]+\)',
            r'\.filter\([^)]+\)',
            r'\.save\(\)',
            r'\.delete\(\)',
            r'\.update\([^)]+\)',
        ]
        for pattern in orm_patterns:
            for match in re.finditer(pattern, code):
                db_ops.append({
                    "type": "orm",
                    "operation": match.group(0).strip()[:200]
                })
        
        return db_ops
    
    @staticmethod
    def extract_api_calls(code: str) -> List[Dict[str, str]]:
        """Extract API call patterns"""
        api_calls = []
        
        # HTTP methods
        http_methods = ['get', 'post', 'put', 'delete', 'patch']
        for method in http_methods:
            pattern = rf'\.{method}\s*\([^)]*\)'
            for match in re.finditer(pattern, code, re.IGNORECASE):
                api_calls.append({
                    "type": "http",
                    "method": method.upper(),
                    "call": match.group(0).strip()[:200]
                })
        
        # Fetch/axios patterns
        fetch_pattern = r'(?:fetch|axios)\s*\([^)]+\)'
        for match in re.finditer(fetch_pattern, code):
            api_calls.append({
                "type": "fetch",
                "call": match.group(0).strip()[:200]
            })
        
        return api_calls
    
    @staticmethod
    def extract_security_patterns(code: str) -> List[Dict[str, str]]:
        """Extract security-related patterns"""
        security = []
        
        # Authentication/Authorization
        auth_keywords = ['authenticate', 'authorize', 'login', 'logout', 'token', 'session', 'permission']
        for keyword in auth_keywords:
            pattern = rf'\b{keyword}\b'
            if re.search(pattern, code, re.IGNORECASE):
                security.append({
                    "type": "authentication",
                    "keyword": keyword
                })
        
        # Encryption/Hashing
        crypto_keywords = ['encrypt', 'decrypt', 'hash', 'bcrypt', 'sha', 'md5', 'aes']
        for keyword in crypto_keywords:
            pattern = rf'\b{keyword}\b'
            if re.search(pattern, code, re.IGNORECASE):
                security.append({
                    "type": "cryptography",
                    "keyword": keyword
                })
        
        return security
    
    @staticmethod
    def extract_performance_indicators(code: str) -> List[Dict[str, str]]:
        """Extract performance-related patterns"""
        performance = []
        
        # Caching
        cache_keywords = ['cache', 'memoize', 'redis', 'memcached']
        for keyword in cache_keywords:
            if re.search(rf'\b{keyword}\b', code, re.IGNORECASE):
                performance.append({
                    "type": "caching",
                    "keyword": keyword
                })
        
        # Async/await
        if re.search(r'\basync\b|\bawait\b', code):
            performance.append({
                "type": "async",
                "pattern": "async/await"
            })
        
        # Threading/multiprocessing
        if re.search(r'\bThread\b|\bProcess\b|\bpool\b', code):
            performance.append({
                "type": "concurrency",
                "pattern": "threading/multiprocessing"
            })
        
        return performance
    
    @staticmethod
    def enrich_code_block(code_block: Dict[str, Any], language: str = 'python') -> Dict[str, Any]:
        """Enrich code block with extracted patterns"""
        code = code_block.get('raw_code', '')
        
        # Determine comment character
        comment_chars = {
            'python': '#',
            'javascript': '//',
            'typescript': '//',
            'java': '//',
            'c': '//',
            'cpp': '//',
            'csharp': '//',
            'go': '//',
            'rust': '//',
            'ruby': '#',
            'php': '//',
        }
        comment_char = comment_chars.get(language, '#')
        
        # Extract all patterns
        enrichment = {
            "comments": EnhancedExtractor.extract_comments(code, comment_char),
            "docstrings": EnhancedExtractor.extract_docstrings(code) if language == 'python' else [],
            "error_handling": EnhancedExtractor.extract_error_handling(code),
            "validations": EnhancedExtractor.extract_validations(code),
            "loops": EnhancedExtractor.extract_loops(code),
            "database_ops": EnhancedExtractor.extract_database_operations(code),
            "api_calls": EnhancedExtractor.extract_api_calls(code),
            "security_patterns": EnhancedExtractor.extract_security_patterns(code),
            "performance_indicators": EnhancedExtractor.extract_performance_indicators(code)
        }
        
        # Add enrichment to code block
        code_block['enrichment'] = enrichment
        
        # Create enhanced description for better matching
        description_parts = []
        
        if enrichment['comments']:
            description_parts.append(f"Comments: {' '.join(enrichment['comments'][:3])}")
        
        if enrichment['docstrings']:
            description_parts.append(f"Documentation: {enrichment['docstrings'][0][:100]}")
        
        if enrichment['error_handling']:
            description_parts.append(f"Error handling: {len(enrichment['error_handling'])} blocks")
        
        if enrichment['validations']:
            description_parts.append(f"Validations: {len(enrichment['validations'])} checks")
        
        if enrichment['database_ops']:
            description_parts.append(f"Database: {len(enrichment['database_ops'])} operations")
        
        if enrichment['api_calls']:
            description_parts.append(f"API calls: {len(enrichment['api_calls'])} requests")
        
        code_block['enhanced_description'] = ' | '.join(description_parts)
        
        return code_block
