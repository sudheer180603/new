import libcst as cst
from libcst.metadata import PositionProvider
from typing import List, Dict, Any
import logging
import re

logger = logging.getLogger(__name__)

class PythonParser:
    def parse_file(self, file_path: str, content: str) -> List[Dict[str, Any]]:
        try:
            tree = cst.parse_module(content)
            visitor = CodeVisitor(file_path, content)
            # Use wrapper with position metadata for accurate line numbers
            wrapper = cst.MetadataWrapper(tree)
            wrapper.visit(visitor)
            return visitor.code_blocks
        except Exception as e:
            logger.error(f"Error parsing {file_path}: {str(e)}")
            return []

class CodeVisitor(cst.CSTVisitor):
    METADATA_DEPENDENCIES = (PositionProvider,)
    
    def __init__(self, file_path: str, content: str):
        self.file_path = file_path
        self.content = content
        self.content_lines = content.split('\n')
        self.code_blocks = []
        self.current_class = None
        self.current_class_start = None
    
    def visit_ClassDef(self, node: cst.ClassDef) -> None:
        self.current_class = node.name.value
        
        # Get accurate line numbers using position metadata
        start_line, end_line = self._get_accurate_line_numbers(node)
        self.current_class_start = start_line
        
        # Extract dependencies from imports and base classes
        dependencies = self._extract_class_dependencies(node)
        
        self.code_blocks.append({
            "file_path": self.file_path,
            "node_type": "class",
            "class_name": node.name.value,
            "method_name": None,
            "start_line": start_line,
            "end_line": end_line,
            "raw_code": self._get_node_code(node),
            "cst_tree": str(node)[:500],
            "dependencies": dependencies,
            "related_business_rules": None,
            "embedding_id": None
        })
    
    def leave_ClassDef(self, node: cst.ClassDef) -> None:
        self.current_class = None
        self.current_class_start = None
    
    def visit_FunctionDef(self, node: cst.FunctionDef) -> None:
        # Get accurate line numbers
        start_line, end_line = self._get_accurate_line_numbers(node)
        
        # Extract function dependencies and calls
        dependencies = self._extract_function_dependencies(node)
        
        # Get full function code
        raw_code = self._get_node_code(node)
        
        self.code_blocks.append({
            "file_path": self.file_path,
            "node_type": "function",
            "class_name": self.current_class,
            "method_name": node.name.value,
            "start_line": start_line,
            "end_line": end_line,
            "raw_code": raw_code,
            "cst_tree": str(node)[:500],
            "dependencies": dependencies,
            "related_business_rules": None,
            "embedding_id": None
        })
    
    def _get_accurate_line_numbers(self, node) -> tuple:
        """Get accurate line numbers using position metadata"""
        try:
            # Try to get position from metadata
            position = self.get_metadata(PositionProvider, node)
            if position:
                return position.start.line, position.end.line
        except:
            pass
        
        # Fallback: search in content
        node_code = self._get_node_code(node)
        if node_code:
            # Find the first line of the node in content
            first_line = node_code.split('\n')[0].strip()
            for i, line in enumerate(self.content_lines, 1):
                if first_line in line:
                    # Count lines in node
                    line_count = node_code.count('\n') + 1
                    return i, i + line_count - 1
        
        return 1, 1
    
    def _get_node_code(self, node) -> str:
        """Extract accurate code from node"""
        try:
            # For single nodes, wrap in a module
            if isinstance(node, (cst.ClassDef, cst.FunctionDef)):
                module = cst.Module(body=[node])
                return module.code
            return node.visit(cst.Module([node])).code
        except:
            try:
                return str(node)
            except:
                return ""
    
    def _extract_class_dependencies(self, node: cst.ClassDef) -> List[str]:
        """Extract class dependencies from base classes and decorators"""
        dependencies = []
        
        # Extract base classes
        for arg in node.bases:
            if isinstance(arg.value, cst.Name):
                dependencies.append(arg.value.value)
            elif isinstance(arg.value, cst.Attribute):
                dependencies.append(self._get_full_name(arg.value))
        
        return dependencies
    
    def _extract_function_dependencies(self, node: cst.FunctionDef) -> List[str]:
        """Extract function dependencies from calls and imports"""
        dependencies = []
        
        # Extract function calls from the body
        call_visitor = CallExtractor()
        node.visit(call_visitor)
        dependencies.extend(call_visitor.calls)
        
        return list(set(dependencies))  # Remove duplicates
    
    def _get_full_name(self, node) -> str:
        """Get full dotted name from attribute access"""
        if isinstance(node, cst.Name):
            return node.value
        elif isinstance(node, cst.Attribute):
            return f"{self._get_full_name(node.value)}.{node.attr.value}"
        return ""

class CallExtractor(cst.CSTVisitor):
    """Extract function/method calls from code"""
    def __init__(self):
        self.calls = []
    
    def visit_Call(self, node: cst.Call) -> None:
        if isinstance(node.func, cst.Name):
            self.calls.append(node.func.value)
        elif isinstance(node.func, cst.Attribute):
            # Extract method calls like obj.method()
            if isinstance(node.func.value, cst.Name):
                self.calls.append(f"{node.func.value.value}.{node.func.attr.value}")
            else:
                self.calls.append(node.func.attr.value)
