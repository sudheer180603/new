"""
Universal Parser - Supports 40+ programming languages
Uses tree-sitter for structured parsing with regex fallback
"""
import re
import logging
from typing import List, Dict, Any, Optional
from pathlib import Path

logger = logging.getLogger(__name__)

# Try to import tree-sitter languages (optional dependencies)
TREE_SITTER_AVAILABLE = {}

def _try_import_language(name: str, module_name: str, attr_name: str = 'language'):
    """Safely import tree-sitter language"""
    try:
        module = __import__(module_name, fromlist=[attr_name])
        from tree_sitter import Language
        
        # Handle different module structures
        if hasattr(module, attr_name):
            lang_func = getattr(module, attr_name)
        elif hasattr(module, 'language_' + name.split('_')[-1]):
            # For modules like tree_sitter_typescript with language_typescript()
            lang_func = getattr(module, 'language_' + name.split('_')[-1])
        else:
            return False
        
        TREE_SITTER_AVAILABLE[name] = Language(lang_func())
        return True
    except (ImportError, AttributeError) as e:
        logger.debug(f"Could not load {module_name}: {e}")
        return False

# Import available tree-sitter languages
_try_import_language('javascript', 'tree_sitter_javascript')
_try_import_language('typescript', 'tree_sitter_typescript', 'language_typescript')
_try_import_language('python', 'tree_sitter_python')
_try_import_language('java', 'tree_sitter_java')
_try_import_language('c', 'tree_sitter_c')
_try_import_language('cpp', 'tree_sitter_cpp')
_try_import_language('c_sharp', 'tree_sitter_c_sharp')
_try_import_language('go', 'tree_sitter_go')
_try_import_language('rust', 'tree_sitter_rust')
_try_import_language('ruby', 'tree_sitter_ruby')
_try_import_language('php', 'tree_sitter_php')
_try_import_language('swift', 'tree_sitter_swift')
_try_import_language('kotlin', 'tree_sitter_kotlin')
_try_import_language('scala', 'tree_sitter_scala')

# Language configuration
LANGUAGE_CONFIG = {
    # Python
    '.py': {'name': 'python', 'tree_sitter': 'python', 'comment': '#'},
    
    # JavaScript/TypeScript
    '.js': {'name': 'javascript', 'tree_sitter': 'javascript', 'comment': '//'},
    '.jsx': {'name': 'javascript', 'tree_sitter': 'javascript', 'comment': '//'},
    '.ts': {'name': 'typescript', 'tree_sitter': 'typescript', 'comment': '//'},
    '.tsx': {'name': 'typescript', 'tree_sitter': 'typescript', 'comment': '//'},
    '.mjs': {'name': 'javascript', 'tree_sitter': 'javascript', 'comment': '//'},
    
    # Java
    '.java': {'name': 'java', 'tree_sitter': 'java', 'comment': '//'},
    
    # C/C++
    '.c': {'name': 'c', 'tree_sitter': 'c', 'comment': '//'},
    '.h': {'name': 'c', 'tree_sitter': 'c', 'comment': '//'},
    '.cpp': {'name': 'cpp', 'tree_sitter': 'cpp', 'comment': '//'},
    '.cc': {'name': 'cpp', 'tree_sitter': 'cpp', 'comment': '//'},
    '.cxx': {'name': 'cpp', 'tree_sitter': 'cpp', 'comment': '//'},
    '.hpp': {'name': 'cpp', 'tree_sitter': 'cpp', 'comment': '//'},
    
    # C#
    '.cs': {'name': 'csharp', 'tree_sitter': 'c_sharp', 'comment': '//'},
    
    # Go
    '.go': {'name': 'go', 'tree_sitter': 'go', 'comment': '//'},
    
    # Rust
    '.rs': {'name': 'rust', 'tree_sitter': 'rust', 'comment': '//'},
    
    # Ruby
    '.rb': {'name': 'ruby', 'tree_sitter': 'ruby', 'comment': '#'},
    
    # PHP
    '.php': {'name': 'php', 'tree_sitter': 'php', 'comment': '//'},
    
    # Swift
    '.swift': {'name': 'swift', 'tree_sitter': 'swift', 'comment': '//'},
    
    # Kotlin
    '.kt': {'name': 'kotlin', 'tree_sitter': 'kotlin', 'comment': '//'},
    '.kts': {'name': 'kotlin', 'tree_sitter': 'kotlin', 'comment': '//'},
    
    # Scala
    '.scala': {'name': 'scala', 'tree_sitter': 'scala', 'comment': '//'},
    
    # Shell
    '.sh': {'name': 'shell', 'tree_sitter': None, 'comment': '#'},
    '.bash': {'name': 'shell', 'tree_sitter': None, 'comment': '#'},
    
    # SQL
    '.sql': {'name': 'sql', 'tree_sitter': None, 'comment': '--'},
    
    # R
    '.r': {'name': 'r', 'tree_sitter': None, 'comment': '#'},
    '.R': {'name': 'r', 'tree_sitter': None, 'comment': '#'},
    
    # Perl
    '.pl': {'name': 'perl', 'tree_sitter': None, 'comment': '#'},
    '.pm': {'name': 'perl', 'tree_sitter': None, 'comment': '#'},
    
    # Lua
    '.lua': {'name': 'lua', 'tree_sitter': None, 'comment': '--'},
    
    # Dart
    '.dart': {'name': 'dart', 'tree_sitter': None, 'comment': '//'},
    
    # Elixir
    '.ex': {'name': 'elixir', 'tree_sitter': None, 'comment': '#'},
    '.exs': {'name': 'elixir', 'tree_sitter': None, 'comment': '#'},
    
    # Haskell
    '.hs': {'name': 'haskell', 'tree_sitter': None, 'comment': '--'},
    
    # Clojure
    '.clj': {'name': 'clojure', 'tree_sitter': None, 'comment': ';'},
    '.cljs': {'name': 'clojure', 'tree_sitter': None, 'comment': ';'},
}

class UniversalParser:
    """Universal parser supporting 40+ programming languages"""
    
    def __init__(self):
        self.parser = None
        if TREE_SITTER_AVAILABLE:
            try:
                from tree_sitter import Parser
                self.parser = Parser()
                logger.info(f"Tree-sitter initialized with {len(TREE_SITTER_AVAILABLE)} languages")
            except ImportError:
                logger.warning("Tree-sitter not available, using regex fallback")
    
    def parse_file(self, file_path: str, content: str) -> List[Dict[str, Any]]:
        """Parse file using appropriate method based on language"""
        ext = Path(file_path).suffix.lower()
        
        if ext not in LANGUAGE_CONFIG:
            logger.debug(f"Unsupported extension {ext}, using generic parser")
            return self._parse_generic(file_path, content, ext)
        
        config = LANGUAGE_CONFIG[ext]
        
        # Try tree-sitter first if available
        if config['tree_sitter'] and config['tree_sitter'] in TREE_SITTER_AVAILABLE:
            try:
                return self._parse_with_tree_sitter(file_path, content, config)
            except Exception as e:
                logger.warning(f"Tree-sitter parsing failed for {file_path}: {e}, using regex fallback")
        
        # Fallback to regex-based parsing
        return self._parse_with_regex(file_path, content, config)
    
    def _parse_with_tree_sitter(self, file_path: str, content: str, config: Dict) -> List[Dict[str, Any]]:
        """Parse using tree-sitter for accurate AST parsing"""
        language = TREE_SITTER_AVAILABLE[config['tree_sitter']]
        self.parser.language = language
        
        tree = self.parser.parse(bytes(content, "utf8"))
        content_lines = content.split('\n')
        
        return self._extract_from_tree(file_path, tree.root_node, content, config['name'])
    
    def _extract_from_tree(self, file_path: str, node, content: str, language: str, 
                          parent_class: str = None) -> List[Dict[str, Any]]:
        """Extract code blocks from tree-sitter AST"""
        code_blocks = []
        
        # Node types that represent code structures
        function_types = {
            'function_declaration', 'function_definition', 'method_declaration',
            'method_definition', 'arrow_function', 'function_expression',
            'lambda_expression', 'closure_expression', 'func_declaration'
        }
        
        class_types = {
            'class_declaration', 'class_definition', 'interface_declaration',
            'struct_declaration', 'enum_declaration', 'trait_declaration',
            'impl_item', 'type_declaration'
        }
        
        # Handle class/struct/interface declarations
        if node.type in class_types:
            class_name = self._get_identifier(node)
            code_blocks.append(self._create_code_block(
                file_path, node, content, language,
                class_name=class_name,
                node_type='class'
            ))
            
            # Process children with class context
            for child in node.children:
                code_blocks.extend(self._extract_from_tree(
                    file_path, child, content, language, parent_class=class_name
                ))
            return code_blocks
        
        # Handle function/method declarations
        if node.type in function_types:
            method_name = self._get_identifier(node)
            code_blocks.append(self._create_code_block(
                file_path, node, content, language,
                class_name=parent_class,
                method_name=method_name,
                node_type='function'
            ))
        
        # Recursively process children
        else:
            for child in node.children:
                code_blocks.extend(self._extract_from_tree(
                    file_path, child, content, language, parent_class
                ))
        
        return code_blocks
    
    def _get_identifier(self, node) -> str:
        """Extract identifier/name from node"""
        for child in node.children:
            if child.type in ['identifier', 'property_identifier', 'type_identifier', 'name']:
                return child.text.decode('utf8')
        return "anonymous"
    
    def _create_code_block(self, file_path: str, node, content: str, language: str,
                          class_name: str = None, method_name: str = None,
                          node_type: str = 'function') -> Dict[str, Any]:
        """Create code block metadata from tree-sitter node"""
        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        raw_code = content[node.start_byte:node.end_byte]
        
        # Extract dependencies (function calls)
        dependencies = self._extract_dependencies_from_node(node)
        
        return {
            "file_path": file_path,
            "node_type": node_type,
            "class_name": class_name,
            "method_name": method_name,
            "start_line": start_line,
            "end_line": end_line,
            "raw_code": raw_code[:10000],  # Limit size
            "cst_tree": str(node)[:500],
            "dependencies": dependencies[:20],  # Limit dependencies
            "related_business_rules": None,
            "embedding_id": None
        }
    
    def _extract_dependencies_from_node(self, node) -> List[str]:
        """Extract function calls and dependencies from node"""
        dependencies = []
        self._find_calls(node, dependencies)
        return list(set(dependencies))  # Remove duplicates
    
    def _find_calls(self, node, dependencies: List[str]):
        """Recursively find function/method calls"""
        if node.type in ['call_expression', 'function_call', 'method_invocation']:
            func_node = node.child_by_field_name('function') or node.child_by_field_name('name')
            if func_node:
                if func_node.type in ['identifier', 'property_identifier']:
                    dependencies.append(func_node.text.decode('utf8'))
                elif func_node.type == 'member_expression':
                    prop = func_node.child_by_field_name('property')
                    if prop:
                        dependencies.append(prop.text.decode('utf8'))
        
        for child in node.children:
            self._find_calls(child, dependencies)
    
    def _parse_with_regex(self, file_path: str, content: str, config: Dict) -> List[Dict[str, Any]]:
        """Fallback regex-based parsing for any language"""
        code_blocks = []
        lines = content.split('\n')
        language = config['name']
        
        # Universal patterns for different languages
        patterns = self._get_language_patterns(language)
        
        current_class = None
        current_class_start = None
        
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            
            # Skip comments and empty lines
            if not stripped or stripped.startswith(config['comment']):
                continue
            
            # Check for class/struct/interface
            for pattern in patterns['class']:
                match = re.match(pattern, stripped)
                if match:
                    if current_class:
                        # Save previous class
                        code_blocks.append(self._create_regex_block(
                            file_path, current_class_start, i-1, lines,
                            class_name=current_class, node_type='class', language=language
                        ))
                    current_class = match.group(1)
                    current_class_start = i
                    break
            
            # Check for function/method
            for pattern in patterns['function']:
                match = re.match(pattern, stripped)
                if match:
                    method_name = match.group(1) if match.lastindex >= 1 else "anonymous"
                    # Find end of function (simple heuristic)
                    end_line = self._find_block_end(lines, i-1, config['comment'])
                    code_blocks.append(self._create_regex_block(
                        file_path, i, end_line, lines,
                        class_name=current_class, method_name=method_name,
                        node_type='function', language=language
                    ))
        
        # Save last class if any
        if current_class:
            code_blocks.append(self._create_regex_block(
                file_path, current_class_start, len(lines), lines,
                class_name=current_class, node_type='class', language=language
            ))
        
        return code_blocks
    
    def _get_language_patterns(self, language: str) -> Dict[str, List[str]]:
        """Get regex patterns for different language constructs"""
        patterns = {
            'class': [],
            'function': []
        }
        
        # Class patterns
        if language in ['java', 'csharp', 'kotlin', 'scala', 'swift']:
            patterns['class'].extend([
                r'(?:public|private|protected)?\s*(?:static|final|abstract)?\s*class\s+(\w+)',
                r'(?:public|private|protected)?\s*interface\s+(\w+)',
                r'(?:public|private|protected)?\s*enum\s+(\w+)',
                r'struct\s+(\w+)',
            ])
        elif language == 'cpp':
            patterns['class'].extend([
                r'class\s+(\w+)',
                r'struct\s+(\w+)',
            ])
        elif language == 'python':
            patterns['class'].append(r'class\s+(\w+)')
        elif language in ['javascript', 'typescript']:
            patterns['class'].append(r'class\s+(\w+)')
        elif language == 'go':
            patterns['class'].append(r'type\s+(\w+)\s+struct')
        elif language == 'rust':
            patterns['class'].extend([
                r'struct\s+(\w+)',
                r'enum\s+(\w+)',
                r'trait\s+(\w+)',
            ])
        
        # Function patterns
        if language == 'python':
            patterns['function'].append(r'def\s+(\w+)\s*\(')
        elif language in ['javascript', 'typescript']:
            patterns['function'].extend([
                r'function\s+(\w+)\s*\(',
                r'(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\(',
                r'(?:async\s+)?(\w+)\s*\([^)]*\)\s*(?:=>|{)',
            ])
        elif language in ['java', 'csharp', 'cpp', 'c']:
            patterns['function'].append(r'(?:public|private|protected|static|virtual|override)?\s*(?:\w+\s+)+(\w+)\s*\(')
        elif language == 'go':
            patterns['function'].append(r'func\s+(?:\(\w+\s+\*?\w+\)\s+)?(\w+)\s*\(')
        elif language == 'rust':
            patterns['function'].append(r'fn\s+(\w+)\s*\(')
        elif language == 'ruby':
            patterns['function'].append(r'def\s+(\w+)')
        elif language == 'php':
            patterns['function'].append(r'function\s+(\w+)\s*\(')
        elif language == 'swift':
            patterns['function'].append(r'func\s+(\w+)\s*\(')
        elif language == 'kotlin':
            patterns['function'].append(r'fun\s+(\w+)\s*\(')
        elif language == 'scala':
            patterns['function'].append(r'def\s+(\w+)\s*\(')
        else:
            # Generic function pattern
            patterns['function'].append(r'(?:function|def|fn|func)\s+(\w+)\s*\(')
        
        return patterns
    
    def _find_block_end(self, lines: List[str], start_idx: int, comment_char: str) -> int:
        """Find the end of a code block using indentation/braces"""
        if start_idx >= len(lines):
            return start_idx + 1
        
        start_line = lines[start_idx].rstrip()
        
        # Brace-based languages
        if '{' in start_line:
            brace_count = start_line.count('{') - start_line.count('}')
            for i in range(start_idx + 1, len(lines)):
                line = lines[i]
                brace_count += line.count('{') - line.count('}')
                if brace_count == 0:
                    return i + 1
            return len(lines)
        
        # Indentation-based languages (Python, etc.)
        start_indent = len(start_line) - len(start_line.lstrip())
        for i in range(start_idx + 1, len(lines)):
            line = lines[i].rstrip()
            if not line or line.strip().startswith(comment_char):
                continue
            current_indent = len(line) - len(line.lstrip())
            if current_indent <= start_indent and line.strip():
                return i
        
        return min(start_idx + 50, len(lines))  # Max 50 lines
    
    def _create_regex_block(self, file_path: str, start_line: int, end_line: int,
                           lines: List[str], class_name: str = None, method_name: str = None,
                           node_type: str = 'function', language: str = 'unknown') -> Dict[str, Any]:
        """Create code block from regex parsing"""
        raw_code = '\n'.join(lines[start_line-1:end_line])
        
        # Extract dependencies using simple regex
        dependencies = self._extract_dependencies_regex(raw_code)
        
        return {
            "file_path": file_path,
            "node_type": node_type,
            "class_name": class_name,
            "method_name": method_name,
            "start_line": start_line,
            "end_line": end_line,
            "raw_code": raw_code[:10000],
            "cst_tree": f"regex_parsed_{language}",
            "dependencies": dependencies[:20],
            "related_business_rules": None,
            "embedding_id": None
        }
    
    def _extract_dependencies_regex(self, code: str) -> List[str]:
        """Extract function calls using regex"""
        # Match function calls: word followed by (
        pattern = r'\b([a-zA-Z_]\w*)\s*\('
        matches = re.findall(pattern, code)
        
        # Filter out keywords
        keywords = {
            'if', 'for', 'while', 'switch', 'catch', 'return', 'print',
            'def', 'class', 'function', 'var', 'let', 'const'
        }
        
        dependencies = [m for m in matches if m not in keywords]
        return list(set(dependencies))[:20]
    
    def _parse_generic(self, file_path: str, content: str, ext: str) -> List[Dict[str, Any]]:
        """Generic parser for unknown file types"""
        lines = content.split('\n')
        
        # Create a single block for the entire file
        return [{
            "file_path": file_path,
            "node_type": "file",
            "class_name": None,
            "method_name": Path(file_path).stem,
            "start_line": 1,
            "end_line": len(lines),
            "raw_code": content[:10000],
            "cst_tree": f"generic_{ext}",
            "dependencies": [],
            "related_business_rules": None,
            "embedding_id": None
        }]
