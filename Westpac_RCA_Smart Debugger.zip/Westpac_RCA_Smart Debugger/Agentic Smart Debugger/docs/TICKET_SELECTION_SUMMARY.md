# Ticket Selection Feature - Implementation Summary

## Status: ✅ COMPLETE

You can now select specific Jira tickets for RCA analysis instead of analyzing all tickets every time.

## What Changed

### 1. RCA Analyzer (`app/rca_engine/analyzer.py`)
**Updated:**
```python
async def analyze_tickets(project_name: str = None, ticket_ids: List[str] = None)
```

**Behavior:**
- If `ticket_ids` provided → Analyzes only those tickets
- If `ticket_ids` is None → Analyzes all tickets

### 2. API Endpoints (`app/api/projects.py`)
**Added:**
```
GET /api/projects/{project_name}/tickets/list
```
Returns list of all tickets with ID, summary, priority, module

**Updated:**
```
POST /api/projects/{project_name}/rca/analyze
```
Now accepts optional `{"ticket_ids": ["LOS-105", "LOS-106"]}` in request body

### 3. Frontend (`frontend/streamlined_app.py`)
**Added:**
- Ticket list display with checkboxes
- Select All / Deselect All buttons
- Selection counter
- Two analysis buttons:
  - "Analyze Selected (N)" - Analyzes checked tickets
  - "Analyze All (N)" - Analyzes all tickets
- Priority color indicators (🔴 Critical, 🟠 High, 🟡 Medium, 🟢 Low)

## UI Preview

```
📋 Available Tickets (10)

Select tickets to analyze:
[✅ Select All] [❌ Deselect All]
─────────────────────────────────
☑️ 🔴 LOS-105 - KYC file upload has no file size validation
   Module: kyc

☑️ 🟠 LOS-106 - Payment processing timeout
   Module: payment

☐ 🟡 LOS-107 - UI alignment issue
   Module: frontend

─────────────────────────────────
Selected: 2    Total: 10

[🚀 Analyze Selected (2)]  [🚀 Analyze All (10)]
```

## Benefits

| Benefit | Description |
|---------|-------------|
| **Faster** | Analyze only what you need |
| **Cost Efficient** | Fewer Azure OpenAI API calls |
| **Flexible** | Choose specific tickets or all |
| **Incremental** | Analyze new tickets without re-analyzing old ones |
| **Priority-Based** | Focus on critical tickets first |

## Usage

### Analyze Specific Tickets
1. Go to RCA Analysis step
2. Check desired tickets
3. Click "Analyze Selected (N)"

### Analyze All Tickets
1. Go to RCA Analysis step
2. Click "Analyze All (N)"

### Analyze by Priority
1. Look for priority indicators (🔴🟠🟡🟢)
2. Check high-priority tickets
3. Click "Analyze Selected"

## Files Modified

1. ✅ `app/rca_engine/analyzer.py` - Added `ticket_ids` parameter
2. ✅ `app/api/projects.py` - Added list endpoint, updated analyze endpoint
3. ✅ `frontend/streamlined_app.py` - Added ticket selection UI

## Documentation

1. ✅ `docs/TICKET_SELECTION_FEATURE.md` - Complete feature guide
2. ✅ `docs/TICKET_SELECTION_SUMMARY.md` - This document

## Testing Checklist

- [ ] Create project and process tickets
- [ ] Verify ticket list displays correctly
- [ ] Test "Select All" button
- [ ] Test "Deselect All" button
- [ ] Test individual checkbox selection
- [ ] Test "Analyze Selected" with 1 ticket
- [ ] Test "Analyze Selected" with multiple tickets
- [ ] Test "Analyze All" button
- [ ] Verify only selected tickets are analyzed
- [ ] Verify priority indicators display correctly

## Example Scenarios

### Scenario 1: New Tickets Only
```
Day 1: Process 10 tickets → Analyze all 10
Day 2: Process 5 more tickets → Select only new 5 → Analyze
Result: Only 5 tickets analyzed (saves time and cost)
```

### Scenario 2: Critical First
```
Process 20 tickets (mixed priorities)
Select only Critical (🔴) tickets → Analyze
Select only High (🟠) tickets → Analyze
Result: Prioritized analysis workflow
```

### Scenario 3: Module Focus
```
Process tickets from multiple modules
Select only "kyc" module tickets → Analyze
Select only "payment" module tickets → Analyze
Result: Module-by-module analysis
```

## API Examples

### List Tickets
```bash
curl http://localhost:8000/api/projects/MyProject/tickets/list
```

### Analyze Selected Tickets
```bash
curl -X POST http://localhost:8000/api/projects/MyProject/rca/analyze \
  -H "Content-Type: application/json" \
  -d '{"ticket_ids": ["LOS-105", "LOS-106"]}'
```

### Analyze All Tickets
```bash
curl -X POST http://localhost:8000/api/projects/MyProject/rca/analyze
```

## Summary

✅ Ticket selection UI implemented
✅ Backend supports selective analysis
✅ API endpoints updated
✅ Frontend displays tickets with checkboxes
✅ Priority indicators added
✅ Select All / Deselect All functionality
✅ Analyze Selected / Analyze All options

**Result:** Complete control over which tickets to analyze!

---

**Completed:** February 24, 2026
**Status:** ✅ READY FOR TESTING
