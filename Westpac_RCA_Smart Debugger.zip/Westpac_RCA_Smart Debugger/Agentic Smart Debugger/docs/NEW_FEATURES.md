# New Features Documentation

## Overview
This document describes two major enhancements to the RCA system:
1. **Dependency Graph Database Population**
2. **Code Snippet Generation for RCA Suggestions**

---

## 1. Dependency Graph Database Population

### What It Does
The system now automatically extracts and stores file-level dependencies in the `DependencyGraph` table during code parsing. This creates a comprehensive map of how files and components depend on each other.

### How It Works

#### Extraction Process
When parsing repository code, the system:
1. Extracts dependencies from each code block (imports, function calls, class inheritance, etc.)
2. Resolves dependencies to determine:
   - Source file
   - Target file/component
   - Dependency type
3. Stores relationships in the `DependencyGraph` table

#### Dependency Types
- **import**: Import/require statements
- **inheritance**: Class inheritance relationships
- **function_call**: Direct function calls
- **method_call**: Method invocations (obj.method)
- **module_call**: Module-level calls

#### Database Schema
```sql
CREATE TABLE dependency_graph (
    id INTEGER PRIMARY KEY,
    source_file TEXT,
    target_file TEXT,
    dependency_type TEXT,
    created_at DATETIME
);
```

### Usage

#### API Endpoint
```http
GET /api/projects/{project_name}/dependency-graph?source_file={optional_filter}
```

**Response:**
```json
{
  "status": "success",
  "project": "my-project",
  "graph": {
    "nodes": ["file1.py", "file2.py", "file3.js"],
    "edges": [
      {
        "source": "file1.py",
        "target": "file2.py",
        "type": "import",
        "created_at": "2024-01-01T00:00:00"
      }
    ]
  },
  "stats": {
    "total_nodes": 3,
    "total_edges": 5,
    "dependency_types": {
      "import": 3,
      "function_call": 2
    }
  }
}
```

#### Programmatic Access
```python
from app.database.project_db import project_db
from app.database.models import DependencyGraph

db = project_db.get_session("my-project")

# Get all dependencies
dependencies = db.query(DependencyGraph).all()

# Get dependencies for a specific file
file_deps = db.query(DependencyGraph).filter(
    DependencyGraph.source_file == "app/main.py"
).all()

# Get dependency statistics
dep_types = db.query(
    DependencyGraph.dependency_type,
    db.func.count(DependencyGraph.id)
).group_by(DependencyGraph.dependency_type).all()
```

### Benefits
- **Impact Analysis**: Understand which files are affected by changes
- **Code Navigation**: Trace dependencies across the codebase
- **Architecture Visualization**: Generate dependency graphs
- **Refactoring Support**: Identify tightly coupled components
- **RCA Enhancement**: Better root cause analysis with dependency context

---

## 2. Code Snippet Generation for RCA Suggestions

### What It Does
The RCA engine now generates production-ready code snippets that implement the suggested fixes. These snippets are based on the root cause analysis and resolution logic.

### How It Works

#### Generation Process
1. **RCA Analysis**: System identifies root cause and resolution steps
2. **Context Gathering**: Retrieves original code, dependencies, and business rules
3. **Language Detection**: Determines programming language from file extension
4. **Code Generation**: Uses Azure OpenAI to generate fix implementation
5. **Snippet Enhancement**: Adds metadata, comments, and implementation notes

#### Code Generation Prompt
The system uses a specialized prompt that:
- Matches the original code style and patterns
- Includes proper error handling
- Adds explanatory comments
- Follows language-specific best practices
- Ensures syntactic correctness

#### Database Schema Update
```sql
ALTER TABLE rca_results 
ADD COLUMN suggested_code_snippet TEXT;
```

### Usage

#### API Endpoint
```http
GET /api/projects/{project_name}/rca/{ticket_id}
```

**Response:**
```json
{
  "status": "success",
  "ticket_id": "JIRA-123",
  "root_cause_type": "Code Defect",
  "impacted_file": "app/services/payment.py",
  "impacted_method": "PaymentService.process_payment",
  "code_pointer": "app/services/payment.py:45-67",
  "current_logic": "Method doesn't validate payment amount",
  "business_expected_logic": "Must validate amount > 0 before processing",
  "resolution_logic": "Add validation check at method start",
  "suggested_code_snippet": "# Generated Code Snippet for JIRA-123\n# File: app/services/payment.py\n# Method: PaymentService.process_payment\n# Fix Type: Validation added\n# Confidence: 0.85\n\ndef process_payment(self, amount, customer_id):\n    # Validation: Ensure amount is positive\n    if amount <= 0:\n        raise ValueError('Payment amount must be greater than zero')\n    \n    # Original logic continues...\n    ...",
  "fix_type": "Validation added",
  "confidence_score": 0.85,
  "created_at": "2024-01-01T00:00:00"
}
```

#### Programmatic Access
```python
from app.database.project_db import project_db
from app.database.models import RCAResult

db = project_db.get_session("my-project")

# Get RCA result with code snippet
rca = db.query(RCAResult).filter(
    RCAResult.ticket_id == "JIRA-123"
).first()

if rca.suggested_code_snippet:
    print(f"Suggested Fix:\n{rca.suggested_code_snippet}")
```

### Code Snippet Format
```python
# Generated Code Snippet for {ticket_id}
# File: {impacted_file}
# Method: {impacted_method}
# Fix Type: {fix_type}
# Confidence: {confidence_score}

{generated_code}

# Implementation Notes:
# {resolution_logic_summary}
```

### Supported Languages
- Python (.py)
- JavaScript (.js, .jsx)
- TypeScript (.ts, .tsx)
- Java (.java)
- C/C++ (.c, .cpp)
- C# (.cs)
- Go (.go)
- Ruby (.rb)
- PHP (.php)
- And more...

### Benefits
- **Faster Implementation**: Developers get ready-to-use code
- **Consistency**: Fixes follow established patterns
- **Learning Tool**: Junior developers learn from generated examples
- **Reduced Errors**: AI-generated code includes proper error handling
- **Time Savings**: Reduces time from analysis to implementation

---

## Migration Guide

### For Existing Projects

#### 1. Run Database Migration
```bash
python migrate_add_code_snippet.py
```

This adds the `suggested_code_snippet` column to all existing databases.

#### 2. Re-parse Repository (Optional)
To populate the dependency graph for existing projects:
```bash
# Via API
POST /api/projects/{project_name}/ingest/github
{
  "repo_url_or_path": "/path/to/repo"
}
```

#### 3. Re-run RCA Analysis (Optional)
To generate code snippets for existing RCA results:
```bash
# Via API
POST /api/projects/{project_name}/rca/analyze
```

---

## Testing

### Run Test Suite
```bash
python test_new_features.py
```

This tests:
1. CodeMetadata dependencies population
2. DependencyGraph table population
3. Code snippet generation in RCA results

### Expected Output
```
Testing project: my-project
============================================================
✓ Total code blocks: 150
✓ Code blocks with dependencies: 120
✓ Coverage: 80.0%

✓ Total dependencies in graph: 245
✓ Dependency Types:
  import: 120
  function_call: 85
  method_call: 40

✓ Total RCA results: 10
✓ With code snippets: 8
✓ Coverage: 80.0%

✓ ALL TESTS PASSED
```

---

## Configuration

### Settings (app/config.py)
```python
# Parser Configuration
use_universal_parser: bool = True  # Enable multi-language parsing
max_workers: int = 8  # Parallel parsing threads

# Code Generation
azure_openai_deployment: str = "gpt-4"  # Model for code generation
```

---

## Troubleshooting

### Dependency Graph Not Populated
**Issue**: No dependencies in DependencyGraph table

**Solutions**:
1. Ensure repository has been parsed: `POST /api/projects/{name}/ingest/github`
2. Check parser logs for errors
3. Verify code files have dependencies (imports, function calls)

### Code Snippets Not Generated
**Issue**: RCA results have null `suggested_code_snippet`

**Solutions**:
1. Run database migration: `python migrate_add_code_snippet.py`
2. Re-run RCA analysis: `POST /api/projects/{name}/rca/analyze`
3. Check Azure OpenAI configuration and API key
4. Verify sufficient context (code blocks and business rules)

### Low Code Snippet Quality
**Issue**: Generated code doesn't match expectations

**Solutions**:
1. Improve RCA confidence by adding more business rules
2. Ensure code context is complete and accurate
3. Adjust temperature in code generation (currently 0.2)
4. Review and enhance resolution logic in RCA results

---

## API Reference

### Dependency Graph Endpoints

#### Get Dependency Graph
```http
GET /api/projects/{project_name}/dependency-graph
GET /api/projects/{project_name}/dependency-graph?source_file={file_path}
```

### RCA Endpoints

#### Get RCA Result with Code Snippet
```http
GET /api/projects/{project_name}/rca/{ticket_id}
```

#### Run RCA Analysis (generates snippets)
```http
POST /api/projects/{project_name}/rca/analyze
{
  "ticket_ids": ["JIRA-123", "JIRA-456"]  // optional
}
```

---

## Performance Considerations

### Dependency Graph
- Populated during parsing (no additional overhead)
- Batch inserts for efficiency
- Indexed on source_file and target_file

### Code Snippet Generation
- Generated during RCA analysis
- Uses Azure OpenAI (API call per ticket)
- Cached in database for reuse
- Average generation time: 2-5 seconds per snippet

---

## Future Enhancements

### Dependency Graph
- [ ] Transitive dependency analysis
- [ ] Circular dependency detection
- [ ] Dependency visualization UI
- [ ] Impact analysis reports

### Code Snippets
- [ ] Multi-file fix generation
- [ ] Test case generation
- [ ] Code review suggestions
- [ ] Automated PR creation

---

## Support

For issues or questions:
1. Check logs in `app/parsers/orchestrator.py` and `app/rca_engine/advanced_analyzer.py`
2. Run test suite: `python test_new_features.py`
3. Review API responses for error details
4. Check database schema with SQLite browser

---

## Changelog

### Version 2.0.0 (Current)
- ✓ Added dependency graph database population
- ✓ Added code snippet generation for RCA
- ✓ Added migration script for existing databases
- ✓ Added API endpoints for dependency graph
- ✓ Enhanced RCA results with implementation code
- ✓ Added comprehensive test suite
