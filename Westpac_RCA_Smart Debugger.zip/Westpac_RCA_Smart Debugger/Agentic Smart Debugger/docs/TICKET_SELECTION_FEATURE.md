# Ticket Selection for RCA Analysis

## Overview

You can now select specific Jira tickets for RCA analysis instead of analyzing all tickets every time. This gives you fine-grained control over which tickets to analyze.

## How It Works

### Before (Old Behavior)
- RCA analysis would analyze ALL tickets in the project
- No way to select specific tickets
- Had to analyze everything even if you only wanted one ticket

### After (New Behavior)
- View all available tickets in the project
- Select specific tickets using checkboxes
- Analyze only selected tickets OR analyze all tickets
- Full control over what gets analyzed

## UI Features

### Ticket Selection Interface

When you reach the RCA Analysis step, you'll see:

1. **List of Available Tickets**
   - Shows all tickets processed for the project
   - Each ticket displays:
     - Ticket ID
     - Summary (first 80 characters)
     - Priority (with color indicator)
     - Module

2. **Selection Controls**
   - ✅ **Select All** - Select all tickets at once
   - ❌ **Deselect All** - Clear all selections
   - Individual checkboxes for each ticket

3. **Selection Counter**
   - Shows how many tickets are selected
   - Shows total available tickets

4. **Analysis Buttons**
   - **Analyze Selected** - Analyzes only checked tickets (disabled if none selected)
   - **Analyze All** - Analyzes all tickets regardless of selection

## Usage Examples

### Example 1: Analyze Specific Tickets
```
1. Go to RCA Analysis step
2. Check the tickets you want to analyze (e.g., LOS-105, LOS-106)
3. Click "Analyze Selected (2)"
4. View results for only those 2 tickets
```

### Example 2: Analyze All Tickets
```
1. Go to RCA Analysis step
2. Click "Analyze All (10)"
3. View results for all 10 tickets
```

### Example 3: Analyze High Priority Tickets Only
```
1. Go to RCA Analysis step
2. Look for tickets with 🔴 (Critical) or 🟠 (High) indicators
3. Check only those tickets
4. Click "Analyze Selected"
```

### Example 4: Re-analyze After Changes
```
1. Analyze some tickets
2. Click "Analyze More Tickets"
3. Select different tickets
4. Analyze again
```

## Priority Indicators

Tickets are shown with color-coded priority indicators:
- 🔴 **Critical** - Highest priority
- 🟠 **High** - High priority
- 🟡 **Medium** - Medium priority
- 🟢 **Low** - Low priority
- ⚪ **Unknown** - No priority set

## API Changes

### New Endpoint: List Tickets
```
GET /api/projects/{project_name}/tickets/list
```

**Response:**
```json
{
  "status": "success",
  "tickets": [
    {
      "ticket_id": "LOS-105",
      "summary": "KYC file upload issue",
      "priority": "Critical",
      "module": "kyc"
    }
  ],
  "count": 1
}
```

### Updated Endpoint: RCA Analysis
```
POST /api/projects/{project_name}/rca/analyze
```

**Request Body (Optional):**
```json
{
  "ticket_ids": ["LOS-105", "LOS-106"]
}
```

**Behavior:**
- If `ticket_ids` provided: Analyzes only those tickets
- If `ticket_ids` not provided or empty: Analyzes all tickets

## Backend Changes

### RCA Analyzer (`app/rca_engine/analyzer.py`)

**Updated Function:**
```python
async def analyze_tickets(project_name: str = None, ticket_ids: List[str] = None)
```

**Parameters:**
- `project_name`: Name of the project
- `ticket_ids`: Optional list of specific ticket IDs to analyze

**Behavior:**
- If `ticket_ids` provided: Queries only those tickets from database
- If `ticket_ids` is None: Queries all tickets from database

### API Endpoint (`app/api/projects.py`)

**New Endpoint:**
- `GET /{project_name}/tickets/list` - Lists all tickets for a project

**Updated Endpoint:**
- `POST /{project_name}/rca/analyze` - Now accepts optional `ticket_ids` in request body

## Benefits

### 1. Faster Analysis
- Analyze only the tickets you need
- Don't waste time on tickets already analyzed
- Focus on new or high-priority tickets

### 2. Cost Savings
- Fewer API calls to Azure OpenAI
- Only process what you need
- Reduce token usage

### 3. Better Control
- Choose exactly what to analyze
- Re-analyze specific tickets after code changes
- Focus on specific modules or priorities

### 4. Flexibility
- Can still analyze all tickets if needed
- Can analyze one ticket at a time
- Can analyze by priority or module

## Workflow Examples

### Workflow 1: Incremental Analysis
```
Day 1:
- Process 10 tickets
- Analyze all 10 tickets

Day 2:
- Process 5 more tickets
- Select only the 5 new tickets
- Analyze just those 5
```

### Workflow 2: Priority-Based Analysis
```
Step 1:
- Process 20 tickets (mixed priorities)
- Select only Critical and High priority tickets
- Analyze those first

Step 2:
- Select Medium priority tickets
- Analyze those next

Step 3:
- Select Low priority tickets
- Analyze if time permits
```

### Workflow 3: Module-Based Analysis
```
Step 1:
- Process tickets from multiple modules
- Select only "kyc" module tickets
- Analyze KYC issues

Step 2:
- Select only "payment" module tickets
- Analyze payment issues
```

## Tips

### Tip 1: Use Select All for First Analysis
When analyzing a project for the first time, use "Analyze All" to get a complete picture.

### Tip 2: Use Selection for Updates
When adding new tickets, select only the new ones to save time and cost.

### Tip 3: Group by Priority
Analyze high-priority tickets first, then move to lower priorities.

### Tip 4: Re-analyze After Fixes
After fixing code, re-analyze specific tickets to verify the fix addresses the issue.

### Tip 5: Module-Focused Analysis
If working on a specific module, filter tickets by module and analyze only those.

## Troubleshooting

### "No tickets found"
**Cause:** No tickets have been processed for this project

**Solution:** Go back to Step 5 (Jira Tickets) and process some tickets first

### "Analyze Selected button is disabled"
**Cause:** No tickets are selected

**Solution:** Check at least one ticket to enable the button

### "Error loading tickets"
**Cause:** Backend connection issue or project not found

**Solution:** 
- Verify backend is running
- Verify project name is correct
- Check backend logs for errors

## Summary

The ticket selection feature gives you complete control over RCA analysis:

✅ **Select specific tickets** - Choose exactly what to analyze
✅ **Analyze all tickets** - Still available when needed
✅ **Visual selection** - Easy-to-use checkbox interface
✅ **Priority indicators** - See ticket priorities at a glance
✅ **Flexible workflow** - Analyze incrementally or all at once
✅ **Cost efficient** - Only analyze what you need

---

**Feature Added:** February 24, 2026
**Status:** ✅ READY TO USE
