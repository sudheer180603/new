# Database Migration Guide

## Overview
This guide explains the database schema changes and how to migrate existing projects.

## Schema Changes

### BusinessRule Table
Two new optional fields have been added:

1. **section** (String, nullable)
   - Stores the section/header from the source document
   - Used for better categorization and context

2. **related_code_blocks** (JSON, nullable)
   - Stores array of related code block IDs
   - Created during context building phase
   - Enables quick lookup of code related to business rules

## Migration Options

### Option 1: Automatic Migration (Recommended)
The system will automatically handle the new fields:
- Existing records will have `NULL` values for new fields
- New records will populate these fields automatically
- No manual intervention required

### Option 2: Rebuild Context (For Better Accuracy)
To take full advantage of the enhancements:

1. **For New Projects:**
   - No action needed - new projects automatically use enhanced features

2. **For Existing Projects:**
   ```bash
   # Option A: Keep existing data and rebuild context
   # This will create the cross-mappings
   # Run from project root
   python -c "
   from app.context_engine.project_builder import build_project_context
   build_project_context('YOUR_PROJECT_NAME')
   "
   ```

   ```bash
   # Option B: Full refresh (re-process everything)
   # This will re-extract business rules with enhanced parser
   # 1. Clear project data
   python clear_data.bat YOUR_PROJECT_NAME
   
   # 2. Re-run the workflow from frontend
   # - Ingest repository
   # - Upload business documents
   # - Build context
   ```

## Database Compatibility

### SQLite (Default)
- ✅ Fully compatible
- ✅ Automatic schema updates via SQLAlchemy
- ✅ No manual migration needed

### PostgreSQL/MySQL (If configured)
- ✅ Fully compatible
- ✅ Automatic schema updates via SQLAlchemy
- ✅ May require `alembic` for production environments

## Verification

After migration, verify the changes:

```python
# Check if new fields exist
from app.database.project_db import project_db
from app.database.models import BusinessRule

db = project_db.get_session('YOUR_PROJECT_NAME')
rule = db.query(BusinessRule).first()

print(f"Section: {getattr(rule, 'section', 'Field not found')}")
print(f"Related Code: {getattr(rule, 'related_code_blocks', 'Field not found')}")

db.close()
```

## Rollback (If Needed)

If you need to rollback:

1. **Restore from backup** (if you created one)
2. **Or simply ignore new fields** - they're optional and won't break existing functionality

## Best Practices

1. **Backup Before Migration:**
   ```bash
   # Backup project database
   copy projects\YOUR_PROJECT_NAME\project.db projects\YOUR_PROJECT_NAME\project.db.backup
   ```

2. **Test with Small Project First:**
   - Create a test project
   - Verify all features work
   - Then migrate production projects

3. **Monitor Performance:**
   - Check context building time
   - Verify RCA accuracy improvements
   - Monitor memory usage

## Troubleshooting

### Issue: "Column not found" error
**Solution:** Restart the backend to trigger schema update
```bash
# Stop backend (Ctrl+C)
# Start backend
run_backend.bat
```

### Issue: Context building fails
**Solution:** Check logs for specific errors
```bash
# Check backend logs
# Look for errors in context_engine/project_builder.py
```

### Issue: Old projects not showing improvements
**Solution:** Rebuild context for existing projects
```bash
# Use Option 2B above to fully refresh
```

## Support

For issues or questions:
1. Check `docs/TROUBLESHOOTING.md`
2. Review backend logs
3. Verify `.env` configuration

## Summary

- ✅ Schema changes are backward compatible
- ✅ Existing projects continue to work
- ✅ New projects automatically use enhancements
- ✅ Optional: Rebuild context for existing projects to get full benefits
- ✅ No breaking changes to API or workflow
