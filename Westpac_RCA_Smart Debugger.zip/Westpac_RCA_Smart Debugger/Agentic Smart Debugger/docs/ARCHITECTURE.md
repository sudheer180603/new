# System Architecture

## Overview

Enterprise-grade AI-powered debugging intelligence platform with GitHub context-aware root cause analysis.

## Core Components

### 1. GitHub Repository Ingestion (`app/github/`)
- Clones repositories securely
- Removes unnecessary directories (node_modules, .git, venv, dist, build)
- Validates repository access

### 2. CST Parsing (`app/parsers/`)
- **Python Parser**: Uses libcst for full CST extraction
  - Classes, methods, decorators, API routes
  - Preserves exact indentation and comments
  - Line-level mapping
  
- **JS/TS Parser**: Uses tree-sitter
  - React components, hooks, API calls
  - State variables, JSX tree, props
  - Exports and imports

### 3. Business Document Processing (`app/business_docs/`)
- Supports PDF, DOCX, TXT
- Extracts functional requirements, domain entities, constraints
- Builds structured business knowledge graph

### 4. Unified Context Builder (`app/context_engine/`)
- Merges code CST + business knowledge + dependency graph
- Generates embeddings using HuggingFace BAAI/bge-large-en-v1.5
- Stores in SQLite + FAISS vector store

### 5. Embedding Generation (`app/embeddings/`)
- Model: BAAI/bge-large-en-v1.5 (1024 dimensions)
- Batch processing for efficiency
- Normalized vectors for cosine similarity

### 6. Vector Store (`app/vector_store/`)
- FAISS IndexFlatIP for inner product similarity
- Separate indices for code, business rules, tickets
- Persistent storage with metadata

### 7. Jira Ticket Processing (`app/jira/`)
- Accepts structured JSON tickets
- Generates embeddings per ticket
- Vector search for relevant code + business rules

### 8. RCA Engine (`app/rca_engine/`)
- Uses Azure OpenAI GPT-4 for reasoning
- Structured prompting with context
- Classifies root causes:
  - Environment
  - Configuration
  - Data
  - Functional Gap
  - Code Defect
  - Integration Issue
  - Performance

### 9. Issue Consolidation (`app/consolidation/`)
- DBSCAN clustering on resolution embeddings
- Groups similar root causes
- Identifies shared impacted files

### 10. Azure OpenAI Client (`app/services/`)
- Centralized Azure OpenAI integration
- Retry logic with exponential backoff
- Temperature 0.2 for deterministic output

## Data Flow

```
GitHub URL → Clone → Parse (CST) → Store in DB
                                  ↓
Business Docs → Extract Rules → Store in DB
                                  ↓
                        Build Unified Context
                                  ↓
                    Generate Embeddings (HuggingFace)
                                  ↓
                        Store in FAISS + SQLite
                                  ↓
Jira Tickets → Embed → Vector Search → Retrieve Context
                                  ↓
                        Azure GPT-4 RCA Analysis
                                  ↓
                    Consolidate Similar Issues
                                  ↓
                        Structured JSON Report
```

## Database Schema

### code_metadata
- file_path, class_name, method_name
- start_line, end_line, raw_code
- cst_tree (JSON), dependencies (JSON)
- embedding_id

### business_rules
- rule_text, source_document, category
- embedding_id

### tickets
- ticket_id, summary, description
- priority, module, embedding_id

### rca_results
- ticket_id, root_cause_type
- impacted_file, impacted_method, code_pointer
- current_logic, business_expected_logic, resolution_logic
- fix_type, confidence_score

## Technology Stack

- **Backend**: FastAPI
- **Frontend**: Streamlit
- **LLM**: Azure OpenAI GPT-4
- **Embeddings**: HuggingFace Transformers (BAAI/bge-large-en-v1.5)
- **Vector Store**: FAISS
- **Database**: SQLite
- **Parsing**: libcst (Python), tree-sitter (JS/TS)
- **Document Processing**: PyPDF2, python-docx

## Security Features

- Path sanitization to prevent directory traversal
- File size limits
- JSON schema validation
- Secure Azure key management via environment variables
- No arbitrary code execution
