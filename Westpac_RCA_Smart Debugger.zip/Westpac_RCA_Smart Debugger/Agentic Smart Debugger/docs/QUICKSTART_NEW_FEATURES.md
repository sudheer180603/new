# Quick Start Guide - New Features

## Overview
This guide helps you quickly test the two new features:
1. Dependency Graph Database Population
2. Code Snippet Generation for RCA

---

## Prerequisites
- Python environment set up
- Azure OpenAI credentials configured in `.env`
- Backend and frontend running

---

## Step 1: Migrate Existing Databases (If Applicable)

If you have existing projects, run the migration script:

```bash
python migrate_add_code_snippet.py
```

**Expected Output:**
```
INFO:__main__:Successfully migrated debugger.db
INFO:__main__:Successfully migrated ./projects/my-project/database/project.db
INFO:__main__:Migration complete: 2 databases migrated, 0 failed
```

---

## Step 2: Create a New Project or Use Existing

### Option A: Create New Project
```bash
curl -X POST http://localhost:8000/api/projects/create \
  -H "Content-Type: application/json" \
  -d '{"name": "test-project"}'
```

### Option B: List Existing Projects
```bash
curl http://localhost:8000/api/projects/list
```

---

## Step 3: Ingest Repository Code

This will parse the code and populate the dependency graph:

```bash
curl -X POST http://localhost:8000/api/projects/test-project/ingest/github \
  -H "Content-Type: application/json" \
  -d '{"repo_url_or_path": "/path/to/your/repo"}'
```

**What Happens:**
- Code is parsed using language-specific parsers
- Dependencies are extracted from each code block
- DependencyGraph table is populated automatically
- CodeMetadata table stores code blocks with dependencies

---

## Step 4: Verify Dependency Graph

Check if dependencies were extracted:

```bash
curl http://localhost:8000/api/projects/test-project/dependency-graph
```

**Expected Response:**
```json
{
  "status": "success",
  "project": "test-project",
  "graph": {
    "nodes": ["app/main.py", "app/utils.py", "app/services/api.py"],
    "edges": [
      {
        "source": "app/main.py",
        "target": "import:app.utils",
        "type": "import"
      },
      {
        "source": "app/services/api.py",
        "target": "function:validate_input",
        "type": "function_call"
      }
    ]
  },
  "stats": {
    "total_nodes": 3,
    "total_edges": 15,
    "dependency_types": {
      "import": 8,
      "function_call": 5,
      "method_call": 2
    }
  }
}
```

---

## Step 5: Upload Business Documents (Optional)

```bash
curl -X POST http://localhost:8000/api/projects/test-project/ingest/business-docs \
  -F "files=@business_rules.pdf"
```

---

## Step 6: Build Context

```bash
curl -X POST http://localhost:8000/api/projects/test-project/context/build
```

---

## Step 7: Process Jira Tickets

```bash
curl -X POST http://localhost:8000/api/projects/test-project/jira/process \
  -F "file=@jira_tickets.json"
```

---

## Step 8: Run RCA Analysis with Code Snippet Generation

This will analyze tickets and generate code snippets:

```bash
curl -X POST http://localhost:8000/api/projects/test-project/rca/analyze
```

**What Happens:**
- RCA engine analyzes each ticket
- Identifies root cause and resolution logic
- Generates production-ready code snippet
- Stores everything in RCAResult table

---

## Step 9: Retrieve RCA Result with Code Snippet

```bash
curl http://localhost:8000/api/projects/test-project/rca/JIRA-123
```

**Expected Response:**
```json
{
  "status": "success",
  "ticket_id": "JIRA-123",
  "root_cause_type": "Code Defect",
  "impacted_file": "app/services/payment.py",
  "impacted_method": "PaymentService.process_payment",
  "code_pointer": "app/services/payment.py:45-67",
  "current_logic": "Method doesn't validate payment amount before processing",
  "business_expected_logic": "Must validate amount > 0 and check for null values",
  "resolution_logic": "Add validation at method start: check amount > 0, raise ValueError if invalid",
  "suggested_code_snippet": "# Generated Code Snippet for JIRA-123\n# File: app/services/payment.py\n# Method: PaymentService.process_payment\n# Fix Type: Validation added\n# Confidence: 0.85\n\ndef process_payment(self, amount, customer_id):\n    \"\"\"Process payment with validation\"\"\"\n    # Validation: Ensure amount is positive\n    if amount is None:\n        raise ValueError('Payment amount cannot be None')\n    if amount <= 0:\n        raise ValueError('Payment amount must be greater than zero')\n    \n    # Validation: Ensure customer_id is valid\n    if not customer_id:\n        raise ValueError('Customer ID is required')\n    \n    # Original payment processing logic\n    try:\n        transaction = self.payment_gateway.charge(\n            amount=amount,\n            customer_id=customer_id\n        )\n        return transaction\n    except PaymentError as e:\n        logger.error(f'Payment failed for customer {customer_id}: {e}')\n        raise\n\n# Implementation Notes:\n# Add validation check at method start to ensure amount > 0",
  "fix_type": "Validation added",
  "confidence_score": 0.85,
  "created_at": "2024-01-01T12:00:00"
}
```

---

## Step 10: Run Test Suite

Verify everything is working:

```bash
python test_new_features.py
```

**Expected Output:**
```
############################################################
# NEW FEATURES TEST SUITE
############################################################

Available projects: ['test-project']

Testing project: test-project
============================================================

============================================================
Testing CodeMetadata Dependencies for project: test-project
============================================================
✓ Total code blocks: 150
✓ Code blocks with dependencies: 120
✓ Coverage: 80.0%

Sample Code Blocks with Dependencies:
------------------------------------------------------------
  File: app/main.py
  Function: main
  Dependencies: ['FastAPI', 'uvicorn', 'load_config']

✓ CodeMetadata dependencies test PASSED

============================================================
Testing Dependency Graph for project: test-project
============================================================
✓ Total dependencies in graph: 245

Sample Dependencies:
------------------------------------------------------------
  app/main.py
    → import:FastAPI
    Type: import

Dependency Types Distribution:
------------------------------------------------------------
  import: 120
  function_call: 85
  method_call: 30
  inheritance: 10

Top 5 Files with Most Dependencies:
------------------------------------------------------------
  app/main.py: 25 dependencies
  app/services/api.py: 18 dependencies

✓ Dependency graph test PASSED

============================================================
Testing Code Snippet Generation for project: test-project
============================================================
✓ Total RCA results: 10

Code Snippet Statistics:
------------------------------------------------------------
  With code snippets: 8
  Without code snippets: 2
  Coverage: 80.0%

Sample RCA Result with Code Snippet:
------------------------------------------------------------
  Ticket ID: JIRA-123
  Root Cause: Code Defect
  Impacted File: app/services/payment.py
  Impacted Method: PaymentService.process_payment
  Fix Type: Validation added
  Confidence: 0.85

  Resolution Logic:
  Add validation check at method start to ensure amount > 0...

  Code Snippet Preview:
  ------------------------------------------------------------
  # Generated Code Snippet for JIRA-123
  # File: app/services/payment.py
  # Method: PaymentService.process_payment
  # Fix Type: Validation added
  # Confidence: 0.85

  def process_payment(self, amount, customer_id):
      """Process payment with validation"""
      # Validation: Ensure amount is positive
      if amount is None:
          raise ValueError('Payment amount cannot be None')
      if amount <= 0:
          raise ValueError('Payment amount must be greater than zero')
  ...

✓ Code snippet generation test PASSED

############################################################
# TEST SUMMARY
############################################################

Project: test-project
------------------------------------------------------------
  code_metadata_deps: ✓ PASSED
  dependency_graph: ✓ PASSED
  code_snippets: ✓ PASSED

============================================================
✓ ALL TESTS PASSED
============================================================
```

---

## Troubleshooting

### Issue: No dependencies in graph
**Solution:** Make sure repository was parsed successfully. Check logs for parsing errors.

### Issue: No code snippets generated
**Solution:** 
1. Run migration: `python migrate_add_code_snippet.py`
2. Check Azure OpenAI configuration
3. Re-run RCA analysis

### Issue: Code snippet quality is poor
**Solution:**
1. Add more business rules for better context
2. Ensure code blocks have complete information
3. Check RCA confidence scores

---

## Next Steps

1. **Visualize Dependencies**: Build a UI to display the dependency graph
2. **Apply Code Snippets**: Use the generated code in your IDE
3. **Iterate on RCA**: Refine business rules for better suggestions
4. **Automate Fixes**: Create PRs automatically with generated code

---

## Using in Frontend

The Streamlit frontend automatically displays:
- Dependency graph statistics
- Code snippets in RCA results
- Implementation suggestions

Just navigate to the RCA results page after analysis!

---

## API Endpoints Summary

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/projects/{name}/dependency-graph` | GET | Get dependency graph |
| `/api/projects/{name}/rca/{ticket_id}` | GET | Get RCA with code snippet |
| `/api/projects/{name}/rca/analyze` | POST | Run RCA (generates snippets) |

---

## Support

For detailed documentation, see: `docs/NEW_FEATURES.md`

For issues:
1. Check logs in console
2. Run test suite: `python test_new_features.py`
3. Verify database schema
4. Check Azure OpenAI API status
