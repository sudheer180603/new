# Project Resume Logic

## Overview

The streamlined UI automatically detects where you left off in a project and resumes from that exact point. No manual navigation needed!

## Resume Logic Flow

```
Select Existing Project
         ↓
Check Project Status
         ↓
    ┌────┴────┐
    │         │
code_indexed? NO → Resume at Step 2 (Repository Ingestion)
    │         │
   YES        │
    ↓         │
business_docs_processed? NO → Resume at Step 3 (Business Documents)
    │         │
   YES        │
    ↓         │
context_built? NO → Resume at Step 4 (Context Building)
    │         │
   YES        │
    ↓         │
Resume at Step 5 (Jira Tickets) ✅
```

## Status Detection

The system checks three flags in project metadata:

| Flag | Meaning | Set When |
|------|---------|----------|
| `code_indexed` | Repository parsed | Repository ingestion completes |
| `business_docs_processed` | Documents processed | Business docs uploaded (or skipped) |
| `context_built` | Embeddings generated | Context building completes |

## Resume Examples

### Example 1: Brand New Project
```
Flags: code_indexed=False, business_docs_processed=False, context_built=False
Resume At: Step 2 - Repository Ingestion
Message: "📦 Next: Repository Ingestion"
```

### Example 2: Repo Ingested Only
```
Flags: code_indexed=True, business_docs_processed=False, context_built=False
Resume At: Step 3 - Business Documents
Message: "📄 Next: Business Documents"
Progress: ✅ Repository ⏸️ Business Docs ⏸️ Context Built
```

### Example 3: Docs Processed
```
Flags: code_indexed=True, business_docs_processed=True, context_built=False
Resume At: Step 4 - Context Building
Message: "🧠 Next: Context Building"
Progress: ✅ Repository ✅ Business Docs ⏸️ Context Built
```

### Example 4: Fully Ready
```
Flags: code_indexed=True, business_docs_processed=True, context_built=True
Resume At: Step 5 - Jira Tickets
Message: "✅ Ready for Jira Tickets"
Progress: ✅ Repository ✅ Business Docs ✅ Context Built
```

## UI Display

When you select an existing project, you see:

```
┌─────────────────────────────────────────┐
│ 📂 Existing Project                     │
├─────────────────────────────────────────┤
│ Select Project: [LOS-Analysis ▼]       │
│                                         │
│ Status: 🧠 Next: Context Building      │
│                                         │
│ ┌─────┬─────┬──────────┐              │
│ │Files│Rules│Embeddings│              │
│ │ 342 │ 153 │    0     │              │
│ └─────┴─────┴──────────┘              │
│                                         │
│ Progress:                               │
│ ✅ Repository                          │
│ ✅ Business Docs                       │
│ ⏸️ Context Built                       │
│                                         │
│ [Continue This Project]                 │
└─────────────────────────────────────────┘
```

## Workflow Stage Mapping

| Project Status | Workflow Stage | Step Name |
|----------------|----------------|-----------|
| New project | 1 | Repository Ingestion |
| code_indexed=False | 1 | Repository Ingestion |
| code_indexed=True, business_docs_processed=False | 2 | Business Documents |
| business_docs_processed=True, context_built=False | 3 | Context Building |
| context_built=True | 4 | Jira Tickets |
| After processing tickets | 5 | RCA Analysis |

## Code Implementation

### Detection Logic
```python
# Determine project status and next step
if not project_info.get('code_indexed', False):
    next_step = 1
    status_msg = "📦 Next: Repository Ingestion"
elif not project_info.get('business_docs_processed', False):
    next_step = 2
    status_msg = "📄 Next: Business Documents"
elif not project_info.get('context_built', False):
    next_step = 3
    status_msg = "🧠 Next: Context Building"
else:
    next_step = 4
    status_msg = "✅ Ready for Jira Tickets"
```

### Resume Action
```python
if st.button("Continue This Project"):
    st.session_state.project_name = selected_project
    st.session_state.project_mode = 'existing'
    st.session_state.workflow_stage = next_step  # Auto-resume
    st.rerun()
```

## Benefits

### 1. No Manual Navigation
- Don't need to remember where you left off
- System automatically knows

### 2. Clear Status
- See exactly what's completed
- Know what's next

### 3. Flexible Workflow
- Can stop at any point
- Resume anytime
- No data loss

### 4. Team Collaboration
- Multiple people can work on same project
- Each person sees current status
- No confusion about progress

## Use Cases

### Use Case 1: Interrupted Work
**Scenario:** Started ingesting repo, had to leave
**Action:** Select project next day
**Result:** Automatically resumes at Repository Ingestion

### Use Case 2: Incremental Setup
**Scenario:** Ingested repo today, will add docs tomorrow
**Action:** Select project tomorrow
**Result:** Automatically resumes at Business Documents

### Use Case 3: Long Context Building
**Scenario:** Context building takes 10 minutes, browser crashed
**Action:** Restart browser, select project
**Result:** Automatically resumes at Context Building

### Use Case 4: Regular Ticket Analysis
**Scenario:** Project fully set up, analyze tickets weekly
**Action:** Select project each week
**Result:** Always jumps to Jira Tickets, ready to go

## Troubleshooting

### Project Shows Wrong Status
**Cause:** Backend not updated after completing step
**Solution:** Complete the step again, it will update status

### Can't Skip Steps
**Design:** Intentional - ensures proper workflow
**Solution:** Complete steps in order

### Want to Re-do a Step
**Solution:** 
1. Delete project
2. Create new project with same name
3. Start from beginning

### Multiple People Working
**Best Practice:**
- Each person creates their own project
- Or coordinate who works on which project
- Project status is shared across sessions

## Summary

The resume logic provides:
- ✅ Automatic detection of progress
- ✅ Clear status display
- ✅ Seamless continuation
- ✅ No manual navigation
- ✅ Flexible workflow
- ✅ Team-friendly

**You never lose your place!**

---

**Version:** 2.0.0  
**Updated:** February 2026
