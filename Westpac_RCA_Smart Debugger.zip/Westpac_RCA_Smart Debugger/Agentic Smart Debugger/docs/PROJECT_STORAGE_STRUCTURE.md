# Project Storage Structure - Complete Isolation

## Overview

All outputs for each project are now stored in project-specific folders. Nothing is stored in common/shared folders anymore.

## Complete Project Folder Structure

```
projects/
  {project_name}/
    ├── database/
    │   └── project.db              # SQLite database with all project data
    │                                # - Code metadata
    │                                # - Business rules
    │                                # - Tickets
    │                                # - RCA results
    │
    ├── faiss_index/
    │   ├── code.index              # Code embeddings
    │   ├── code_metadata.pkl       # Code metadata for FAISS
    │   ├── business.index          # Business rules embeddings
    │   ├── business_metadata.pkl   # Business rules metadata
    │   ├── tickets.index           # Ticket embeddings
    │   └── tickets_metadata.pkl    # Ticket metadata
    │
    ├── cloned_repos/
    │   └── {repo_name}_{timestamp}/  # Cloned GitHub repositories
    │       ├── src/
    │       ├── tests/
    │       └── ...
    │
    └── uploaded_docs/
        ├── requirements.pdf        # Uploaded business documents
        ├── api_spec.docx
        └── ...
```

## What Changed?

### Before (Common Storage)
```
├── cloned_repos/           # ALL projects mixed
│   ├── repo1/
│   └── repo2/
├── uploaded_docs/          # ALL projects mixed
│   ├── doc1.pdf
│   └── doc2.pdf
├── faiss_index/            # ALL projects mixed
│   ├── code.index
│   └── business.index
└── debugger.db             # ALL projects mixed
```

### After (Project-Specific Storage)
```
projects/
  ├── ProjectA/
  │   ├── database/project.db       # Only ProjectA data
  │   ├── faiss_index/              # Only ProjectA embeddings
  │   ├── cloned_repos/             # Only ProjectA repos
  │   └── uploaded_docs/            # Only ProjectA docs
  │
  └── ProjectB/
      ├── database/project.db       # Only ProjectB data
      ├── faiss_index/              # Only ProjectB embeddings
      ├── cloned_repos/             # Only ProjectB repos
      └── uploaded_docs/            # Only ProjectB docs
```

## Benefits

### 1. Complete Isolation
- Each project has ALL its data in one folder
- No mixing between projects
- Easy to understand what belongs to what

### 2. Easy Management
- **Backup a project:** Copy `projects/{ProjectName}/` folder
- **Delete a project:** Delete `projects/{ProjectName}/` folder
- **Share a project:** Zip and send `projects/{ProjectName}/` folder
- **Archive a project:** Move `projects/{ProjectName}/` to archive location

### 3. Clean Organization
- All project artifacts in one place
- No searching through common folders
- Clear project boundaries

### 4. Disk Space Management
- See exactly how much space each project uses
- Delete old projects to free space
- No orphaned files in common folders

## Storage Size Examples

### Small Project (100 files)
```
ProjectA/                    Total: ~20 MB
├── database/project.db      2 MB
├── faiss_index/             8 MB
├── cloned_repos/            8 MB
└── uploaded_docs/           2 MB
```

### Medium Project (500 files)
```
ProjectB/                    Total: ~80 MB
├── database/project.db      8 MB
├── faiss_index/             30 MB
├── cloned_repos/            35 MB
└── uploaded_docs/           7 MB
```

### Large Project (2000 files)
```
ProjectC/                    Total: ~250 MB
├── database/project.db      25 MB
├── faiss_index/             100 MB
├── cloned_repos/            110 MB
└── uploaded_docs/           15 MB
```

## Data Flow

### 1. GitHub Repository Ingestion
```
User provides GitHub URL
    ↓
Clone to: projects/{project_name}/cloned_repos/{repo}_{timestamp}/
    ↓
Parse code
    ↓
Store metadata in: projects/{project_name}/database/project.db
```

### 2. Business Documents Processing
```
User uploads PDF/DOCX files
    ↓
Save to: projects/{project_name}/uploaded_docs/{filename}
    ↓
Extract text and rules
    ↓
Store rules in: projects/{project_name}/database/project.db
```

### 3. Context Building
```
Load code metadata from: projects/{project_name}/database/project.db
Load business rules from: projects/{project_name}/database/project.db
    ↓
Generate embeddings
    ↓
Store in: projects/{project_name}/faiss_index/
```

### 4. Ticket Processing
```
User submits Jira tickets
    ↓
Store in: projects/{project_name}/database/project.db
    ↓
Generate embeddings
    ↓
Store in: projects/{project_name}/faiss_index/tickets.index
```

### 5. RCA Analysis
```
Load tickets from: projects/{project_name}/database/project.db
Load embeddings from: projects/{project_name}/faiss_index/
    ↓
Perform analysis
    ↓
Store results in: projects/{project_name}/database/project.db
```

## Implementation Details

### Project Manager
**File:** `app/project_manager.py`

**New Methods:**
```python
get_project_repos_dir(name)  # Returns: projects/{name}/cloned_repos
get_project_docs_dir(name)   # Returns: projects/{name}/uploaded_docs
```

### GitHub Clone
**File:** `app/github/clone.py`

**Updated:**
```python
clone_repository(repo_url, project_name)
# Clones to project-specific folder if project_name provided
```

### Business Docs Processor
**File:** `app/business_docs/processor.py`

**Updated:**
```python
process_business_docs(files, project_name)
# Saves to project-specific folder if project_name provided
```

## Migration from Old System

### If You Have Old Data in Common Folders

**Option 1: Keep Both Systems**
- Old data stays in common folders
- New projects use project-specific folders
- No conflict

**Option 2: Start Fresh**
```powershell
# Clear old common folders
Remove-Item -Recurse -Force cloned_repos
Remove-Item -Recurse -Force uploaded_docs
Remove-Item -Recurse -Force faiss_index
Remove-Item debugger.db

# Start using new system
.\run_backend.bat
.\run_streamlined_frontend.bat
```

**Option 3: Manual Migration**
1. Create new project
2. Copy old data to project folder
3. Rebuild context
4. Delete old common folders

## Best Practices

### Project Naming
Use descriptive names that indicate:
- Service/component: `PaymentService`, `AuthAPI`
- Version: `PaymentService-v2.0`
- Environment: `LOS-Production`, `LOS-Staging`

### Disk Space Management
```powershell
# Check project sizes
Get-ChildItem projects -Directory | ForEach-Object {
    $size = (Get-ChildItem $_.FullName -Recurse | Measure-Object -Property Length -Sum).Sum / 1MB
    Write-Host "$($_.Name): $([math]::Round($size, 2)) MB"
}

# Delete old projects
Remove-Item -Recurse -Force projects/OldProject
```

### Backup Strategy
```powershell
# Backup a project
Compress-Archive -Path projects/ImportantProject -DestinationPath backups/ImportantProject_2026-02-24.zip

# Restore a project
Expand-Archive -Path backups/ImportantProject_2026-02-24.zip -DestinationPath projects/
```

### Sharing Projects
```powershell
# Package for sharing
Compress-Archive -Path projects/MyProject -DestinationPath MyProject.zip

# Recipient extracts to their projects folder
Expand-Archive -Path MyProject.zip -DestinationPath projects/
```

## Troubleshooting

### "Cannot find cloned repository"
**Cause:** Looking in old common folder

**Solution:** Repository is now in `projects/{project_name}/cloned_repos/`

### "Business documents not found"
**Cause:** Looking in old common folder

**Solution:** Documents are now in `projects/{project_name}/uploaded_docs/`

### "Embeddings not loading"
**Cause:** Looking in old common folder

**Solution:** Embeddings are now in `projects/{project_name}/faiss_index/`

### Disk space issues
**Solution:**
```powershell
# Find large projects
Get-ChildItem projects -Directory | ForEach-Object {
    $size = (Get-ChildItem $_.FullName -Recurse | Measure-Object -Property Length -Sum).Sum / 1MB
    [PSCustomObject]@{
        Project = $_.Name
        SizeMB = [math]::Round($size, 2)
    }
} | Sort-Object SizeMB -Descending

# Delete unused projects
Remove-Item -Recurse -Force projects/UnusedProject
```

## Summary

✅ All project data in one folder: `projects/{project_name}/`
✅ Cloned repos: `projects/{project_name}/cloned_repos/`
✅ Uploaded docs: `projects/{project_name}/uploaded_docs/`
✅ Database: `projects/{project_name}/database/project.db`
✅ Embeddings: `projects/{project_name}/faiss_index/`

**Result:** Complete isolation, easy management, clear organization!

---

**Updated:** February 24, 2026
**Version:** 2.2.0
