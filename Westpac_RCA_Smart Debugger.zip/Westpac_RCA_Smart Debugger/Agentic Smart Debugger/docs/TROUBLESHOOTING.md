# 🔧 Troubleshooting Guide

Quick solutions to common issues with the Agentic Smart Debugger.

## Quick Diagnostics

Run this command to verify system health:
```powershell
python verify_parsers.py
```

## Common Issues

### 1. Parser Errors

#### Error: `'Module' object has no attribute 'walk'`
**Status:** ✅ FIXED in latest version

**Solution:** Update to latest code or apply fixes from [FIXES_APPLIED.md](FIXES_APPLIED.md)

#### Error: `'type' is an invalid keyword argument`
**Status:** ✅ FIXED in latest version

**Solution:** Delete old database and restart:
```powershell
Remove-Item debugger.db
.\run_backend.bat
```

### 2. Database Issues

#### Error: Database schema mismatch
**Symptoms:** 
- Fields not found
- Invalid keyword arguments
- Data not saving

**Solution:**
```powershell
# Delete old database
Remove-Item debugger.db

# Restart backend (will recreate database)
.\run_backend.bat
```

#### Error: Database locked
**Symptoms:** `database is locked` error

**Solution:**
```powershell
# Stop all running processes
# Delete database
Remove-Item debugger.db

# Restart
.\run_backend.bat
```

### 3. Backend Issues

#### Error: Backend won't start
**Check:**
1. Python installed? `python --version`
2. Dependencies installed? `pip install -r requirements.txt`
3. Port 8000 available? `netstat -ano | findstr :8000`

**Solution:**
```powershell
# Reinstall dependencies
pip install -r requirements.txt

# Try starting again
.\run_backend.bat
```

#### Error: `Cannot connect to backend`
**Symptoms:** Frontend shows "Backend Offline"

**Check:**
1. Is backend running? Look for terminal with FastAPI output
2. Correct URL? Should be `http://localhost:8000`

**Solution:**
```powershell
# Start backend in new terminal
.\run_backend.bat

# Wait for "Application startup complete"
# Then refresh frontend
```

### 4. Frontend Issues

#### Error: Frontend won't start
**Check:**
1. Streamlit installed? `pip list | findstr streamlit`
2. Port 8501 available?

**Solution:**
```powershell
pip install streamlit
.\run_frontend.bat
```

#### Error: `Connection refused` in frontend
**Cause:** Backend not running

**Solution:**
```powershell
# Start backend first
.\run_backend.bat

# Then start frontend
.\run_frontend.bat
```

### 5. Azure OpenAI Issues

#### Error: `Unsupported parameter: 'max_tokens'`
**Status:** ✅ FIXED in latest version

**Error Message:**
```
Unsupported parameter: 'max_tokens' is not supported with this model. 
Use 'max_completion_tokens' instead.
```

**Cause:** Newer Azure OpenAI models (GPT-4o, GPT-5, o1-series) use `max_completion_tokens` instead of `max_tokens`

**Solution:** The system now automatically detects your model and uses the correct parameter. Restart the backend:
```powershell
# Stop backend (Ctrl+C)
# Restart
.\run_backend.bat
```

#### Error: `Unsupported value: 'temperature'`
**Status:** ✅ FIXED in latest version

**Error Message:**
```
Unsupported value: 'temperature' does not support 0.2 with this model. 
Only the default (1) value is supported.
```

**Cause:** Some models (GPT-5, o1-series) don't support custom temperature values

**Solution:** The system now automatically detects models that don't support temperature and omits the parameter. Restart the backend:
```powershell
# Stop backend (Ctrl+C)
# Restart
.\run_backend.bat
```

**Supported Models:**
- GPT-4, GPT-4-turbo: Uses `max_tokens`, supports temperature
- GPT-4o, GPT-4o-mini: Uses `max_completion_tokens`, supports temperature
- GPT-5, GPT-5-mini: Uses `max_completion_tokens`, NO temperature support
- o1-preview, o1-mini: Uses `max_completion_tokens`, NO temperature support

#### Error: `Invalid API key`
**Check:** `.env` file has correct credentials

**Solution:**
```powershell
# Edit .env file
notepad .env

# Verify these fields:
# AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
# AZURE_OPENAI_API_KEY=your_key_here
# AZURE_OPENAI_DEPLOYMENT=gpt-4
# AZURE_OPENAI_API_VERSION=2024-02-15-preview
```

#### Error: `Deployment not found`
**Cause:** Wrong deployment name in `.env`

**Solution:**
1. Check your Azure OpenAI deployment name
2. Update `AZURE_OPENAI_DEPLOYMENT` in `.env`
3. Restart backend

### 6. Parsing Issues

#### Error: No files parsed
**Check:**
1. Repository path correct?
2. Supported file types? (.py, .js, .jsx, .ts, .tsx)
3. Files not in excluded folders? (node_modules, .git, venv)

**Solution:**
```powershell
# Check if files exist
dir /s *.py
dir /s *.js

# Try with a simple test repository
```

#### Error: Parsing takes too long
**Cause:** Large repository with many files

**Solution:**
- Be patient (100+ files can take 1-2 minutes)
- Check backend terminal for progress
- Consider parsing smaller repositories first

### 7. Jira Ticket Issues

#### Error: `'ticket_id'` KeyError
**Status:** ✅ FIXED in latest version

**Cause:** Missing `ticket_id` field in ticket JSON

**Solution:** Ensure all tickets have a `ticket_id` field:
```json
[
  {
    "ticket_id": "PROJ-123",
    "summary": "Issue summary",
    "description": "Issue description",
    "priority": "High",
    "module": "ModuleName"
  }
]
```

**Note:** Only `ticket_id` is required. All other fields are optional.

#### Error: Invalid JSON format
**Symptoms:** JSON parsing error in frontend

**Solution:**
1. Validate JSON syntax at https://jsonlint.com
2. Ensure proper quotes (use double quotes `"`, not single quotes `'`)
3. Check for trailing commas
4. Verify array brackets `[]` and object braces `{}`

### 8. GitHub Ingestion Issues

#### Error: `Repository URL or path is required`
**Cause:** Empty input field

**Solution:** Enter either:
- GitHub URL: `https://github.com/user/repo`
- Local path: `C:\projects\myapp`

#### Error: `'NoneType' object has no attribute 'split'`
**Status:** ✅ FIXED in latest version

**Solution:** Update to latest code with validation fixes

### 8. Business Document Issues

#### Error: Cannot upload documents
**Check:**
1. File format supported? (PDF, DOCX, TXT, MD)
2. File size reasonable? (<10MB recommended)

**Solution:**
- Use supported formats only
- Split large documents
- Check file isn't corrupted

### 9. Memory Issues

#### Error: Out of memory
**Cause:** Large repository or many documents

**Solution:**
1. Parse smaller repositories
2. Limit CST tree size (already limited to 500 chars)
3. Process documents in batches

### 10. Import Errors

#### Error: `ModuleNotFoundError`
**Cause:** Missing dependencies

**Solution:**
```powershell
# Reinstall all dependencies
pip install -r requirements.txt

# Verify installation
pip list
```

## System Requirements Check

### Minimum Requirements
```powershell
# Python version (need 3.9+)
python --version

# Pip version
pip --version

# Available disk space (need 1GB+)
Get-PSDrive C

# Available memory (need 4GB+)
Get-CimInstance Win32_OperatingSystem | Select FreePhysicalMemory
```

### Verify Installation
```powershell
# Run verification script
python verify_parsers.py

# Should see:
# ✅ ALL TESTS PASSED!
```

## Performance Optimization

### Slow Parsing
1. Reduce worker count in `orchestrator.py` (default: 4)
2. Parse smaller repositories first
3. Exclude unnecessary folders

### High Memory Usage
1. CST trees already limited to 500 chars
2. Process documents in smaller batches
3. Restart backend periodically for long sessions

### Slow RCA Analysis
1. Reduce number of tickets processed at once
2. Check Azure OpenAI rate limits
3. Verify network connection to Azure

## Getting Help

### Check Logs
**Backend logs:** Look at terminal running `run_backend.bat`
**Frontend logs:** Look at terminal running `run_frontend.bat`

### Verify System Health
```powershell
# Run diagnostics
python verify_parsers.py

# Check backend health
curl http://localhost:8000/api/health

# Check database
python -c "from app.database.models import SessionLocal, CodeMetadata; db = SessionLocal(); print(f'Records: {db.query(CodeMetadata).count()}'); db.close()"
```

### Clean Slate
If all else fails, start fresh:
```powershell
# Stop all processes (Ctrl+C in terminals)

# Delete database
Remove-Item debugger.db

# Reinstall dependencies
pip install -r requirements.txt

# Restart
.\run_backend.bat
# (in new terminal)
.\run_frontend.bat
```

## Still Having Issues?

1. Check [FIXES_APPLIED.md](FIXES_APPLIED.md) for recent fixes
2. Review [TASK_9_COMPLETION_SUMMARY.md](TASK_9_COMPLETION_SUMMARY.md) for parser details
3. Verify all steps in [LOCAL_WINDOWS_SETUP.md](LOCAL_WINDOWS_SETUP.md)
4. Run `python verify_parsers.py` for diagnostics

## Quick Reference Commands

```powershell
# Setup
pip install -r requirements.txt

# Start backend
.\run_backend.bat

# Start frontend (new terminal)
.\run_frontend.bat

# Verify system
python verify_parsers.py

# Clean database
Remove-Item debugger.db

# Check health
curl http://localhost:8000/api/health
```

---

**Last Updated:** February 2026
**Version:** 1.0.0
