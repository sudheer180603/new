# Complete Local Windows Setup Guide

## 🎯 100% Local Execution - No Docker, No Bash

This application runs completely locally on Windows using only Command Prompt or PowerShell.

---

## ⚡ Quick Start (3 Steps)

### Step 1: Automated Setup
```cmd
quickstart.bat
```

### Step 2: Configure Azure OpenAI
```cmd
copy .env.example .env
notepad .env
```

Add your Azure credentials:
```
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your_api_key_here
AZURE_OPENAI_DEPLOYMENT=gpt-4
AZURE_OPENAI_API_VERSION=2024-02-15-preview
```

### Step 3: Launch Application
```cmd
REM Open Terminal 1
run_backend.bat

REM Open Terminal 2 (new window)
run_frontend.bat
```

Access: http://localhost:8501

---

## 📋 Manual Setup (If Needed)

### 1. Create Virtual Environment
```cmd
python -m venv venv
venv\Scripts\activate
```

### 2. Install Dependencies
```cmd
pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Create Directories
```cmd
mkdir cloned_repos
mkdir uploaded_docs
mkdir faiss_index
```

### 4. Configure Environment
```cmd
copy .env.example .env
notepad .env
```

### 5. Verify Setup
```cmd
python verify_setup.py
```

---

## 🚀 Running the Application

### Start Backend (Terminal 1)
```cmd
run_backend.bat
```

Or manually:
```cmd
uvicorn app.main:app --reload --port 8000
```

### Start Frontend (Terminal 2)
```cmd
run_frontend.bat
```

Or manually:
```cmd
streamlit run frontend/app.py
```

### Access Application
- Frontend UI: http://localhost:8501
- Backend API: http://localhost:8000
- API Docs: http://localhost:8000/docs

---

## ✅ Verification

### Check Setup
```cmd
python verify_setup.py
```

### Test Backend
Open browser: http://localhost:8000/api/health

Expected: `{"status":"healthy"}`

### Test Frontend
Open browser: http://localhost:8501

Should show "✅ Backend Connected" in sidebar

---

## 🔧 Common Commands

### Activate Virtual Environment
```cmd
venv\Scripts\activate
```

### Deactivate Virtual Environment
```cmd
deactivate
```

### Install New Package
```cmd
pip install package-name
```

### Update Requirements
```cmd
pip freeze > requirements.txt
```

### Clear Data
```cmd
rmdir /s /q cloned_repos
rmdir /s /q faiss_index
del debugger.db
mkdir cloned_repos
mkdir faiss_index
```

---

## 🐛 Troubleshooting

### Port Already in Use
```cmd
REM Find process on port 8000
netstat -ano | findstr :8000

REM Kill process
taskkill /PID <process_id> /F
```

### Python Not Found
- Install Python 3.9+ from python.org
- Add Python to PATH during installation
- Restart Command Prompt

### Module Not Found
```cmd
pip install -r requirements.txt
```

### Azure API Error
- Check .env file exists
- Verify credentials are correct
- Ensure no extra spaces in .env
- Check Azure deployment name matches

### Virtual Environment Issues
```cmd
REM Remove and recreate
rmdir /s /q venv
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

---

## 📊 System Requirements

- Windows 10/11
- Python 3.9 or higher
- 8GB RAM (16GB recommended)
- 5GB free disk space
- Internet connection (for initial setup)
- Azure OpenAI account with GPT-4

---

## 🎯 Workflow

1. **Setup**: Run `quickstart.bat`
2. **Configure**: Edit `.env` file
3. **Verify**: Run `python verify_setup.py`
4. **Launch**: Run `run_backend.bat` and `run_frontend.bat`
5. **Use**: Open http://localhost:8501

---

## 📝 Notes

- No Docker required
- No bash scripts needed
- Runs completely locally
- Only Azure GPT-4 API calls go to cloud
- Embeddings generated locally
- Data stored locally in SQLite and FAISS

---

## 🔐 Security

- Keep `.env` file secure
- Never commit `.env` to git
- Rotate Azure API keys regularly
- Use environment-specific configurations

---

## 💡 Tips

- Keep both terminals open while using
- First run downloads ~1.3GB embedding model
- Model cached in `%USERPROFILE%\.cache\huggingface\`
- Use Ctrl+C to stop servers
- Check logs in terminal for errors

---

**Status**: ✅ 100% Local Windows Setup

**No Docker • No Bash • Pure Windows**
