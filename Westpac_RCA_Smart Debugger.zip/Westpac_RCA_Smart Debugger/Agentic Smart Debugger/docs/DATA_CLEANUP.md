# Data Cleanup Guide

## Overview

This guide explains how to clear data from the Agentic Smart Debugger system.

## What Gets Stored

The system stores data in several locations:

| Location | Contents | Size |
|----------|----------|------|
| `debugger.db` | Main database (tickets, code metadata, RCA results) | ~1-10 MB |
| `faiss_index/` | Vector embeddings for semantic search | ~10-100 MB |
| `projects/` | Project-specific databases and indexes | ~10-100 MB per project |
| `cloned_repos/` | Cloned GitHub repositories | ~10-500 MB per repo |

## When to Clear Data

### Clear Everything
- Starting completely fresh
- Testing the system
- Switching to different codebase
- Freeing up disk space

### Clear Specific Data
- **Database only**: Keep embeddings, clear tickets/results
- **Indexes only**: Keep database, regenerate embeddings
- **Projects only**: Keep global data, clear project-specific data
- **Repos only**: Keep analysis data, clear source code

## Cleanup Methods

### Method 1: Quick Clear (Batch Script)

**Windows Command Prompt:**
```cmd
clear_data.bat
```

**Interactive prompts:**
- Confirms before deleting
- Shows what will be deleted
- Clears: database, indexes, projects
- Keeps: cloned repositories

**What it does:**
```
✓ Deletes debugger.db
✓ Deletes faiss_index/
✓ Deletes projects/
✗ Keeps cloned_repos/
```

### Method 2: Advanced Clear (PowerShell)

**Clear everything:**
```powershell
.\clear_data.ps1 -All
```

**Clear specific items:**
```powershell
# Database only
.\clear_data.ps1 -Database

# Indexes only
.\clear_data.ps1 -Indexes

# Projects only
.\clear_data.ps1 -Projects

# Cloned repos only
.\clear_data.ps1 -Repos

# Multiple items
.\clear_data.ps1 -Database -Indexes

# Skip confirmation
.\clear_data.ps1 -All -Force
```

### Method 3: Manual Deletion

**Delete database:**
```powershell
Remove-Item debugger.db
```

**Delete FAISS indexes:**
```powershell
Remove-Item -Recurse -Force faiss_index
```

**Delete projects:**
```powershell
Remove-Item -Recurse -Force projects
```

**Delete cloned repos:**
```powershell
Remove-Item -Recurse -Force cloned_repos
```

## What Happens After Clearing

### Database (`debugger.db`)
- Recreated automatically on backend startup
- Empty tables created
- No data loss if you have backups

### FAISS Indexes (`faiss_index/`)
- Recreated when you build context
- Requires re-running context building step
- Takes 2-5 minutes for large repos

### Projects (`projects/`)
- Project list cleared
- All project-specific data removed
- Need to recreate projects

### Cloned Repos (`cloned_repos/`)
- Source code removed
- Need to re-clone repositories
- Saves disk space

## Selective Cleanup Scenarios

### Scenario 1: Clear Old Tickets
**Goal:** Remove old ticket data, keep code context

**Steps:**
```powershell
.\clear_data.ps1 -Database
```

**Result:**
- Tickets cleared
- Code embeddings preserved
- Can process new tickets immediately

### Scenario 2: Regenerate Embeddings
**Goal:** Rebuild embeddings with updated model

**Steps:**
```powershell
.\clear_data.ps1 -Indexes
```

**Result:**
- Embeddings cleared
- Database preserved
- Need to rebuild context

### Scenario 3: Start Fresh Project
**Goal:** New analysis, keep old projects

**Steps:**
- Don't clear anything
- Create new project in UI
- Each project is isolated

### Scenario 4: Complete Reset
**Goal:** Clean slate

**Steps:**
```powershell
.\clear_data.ps1 -All -Force
```

**Result:**
- Everything cleared
- Fresh start
- Need to re-ingest everything

### Scenario 5: Free Disk Space
**Goal:** Remove large cloned repos

**Steps:**
```powershell
.\clear_data.ps1 -Repos
```

**Result:**
- Source code removed
- Analysis data preserved
- Can re-clone if needed

## Data Recovery

### Before Clearing
**Backup important data:**
```powershell
# Backup database
Copy-Item debugger.db debugger.db.backup

# Backup projects
Copy-Item -Recurse projects projects.backup

# Backup indexes
Copy-Item -Recurse faiss_index faiss_index.backup
```

### After Clearing
**Restore from backup:**
```powershell
# Restore database
Copy-Item debugger.db.backup debugger.db

# Restore projects
Copy-Item -Recurse projects.backup projects

# Restore indexes
Copy-Item -Recurse faiss_index.backup faiss_index
```

## Disk Space Management

### Check Current Usage
```powershell
# Check database size
(Get-Item debugger.db).Length / 1MB
# Output: Size in MB

# Check indexes size
(Get-ChildItem -Recurse faiss_index | Measure-Object -Property Length -Sum).Sum / 1MB

# Check projects size
(Get-ChildItem -Recurse projects | Measure-Object -Property Length -Sum).Sum / 1MB

# Check repos size
(Get-ChildItem -Recurse cloned_repos | Measure-Object -Property Length -Sum).Sum / 1MB
```

### Typical Sizes
- Small project (100 files): ~50 MB total
- Medium project (500 files): ~200 MB total
- Large project (2000 files): ~500 MB total

## Automated Cleanup

### Schedule Regular Cleanup
Create a scheduled task to clear old data:

```powershell
# Clear data older than 30 days (example)
$cutoffDate = (Get-Date).AddDays(-30)

# Find and delete old project directories
Get-ChildItem projects -Directory | Where-Object {
    $_.CreationTime -lt $cutoffDate
} | Remove-Item -Recurse -Force
```

## Troubleshooting

### "Access Denied" Error
**Cause:** Backend is running and has files locked

**Solution:**
1. Stop backend (Ctrl+C)
2. Run cleanup script
3. Restart backend

### "File Not Found" Error
**Cause:** Already deleted or never created

**Solution:** Ignore - this is normal

### Database Corruption
**Symptoms:** Backend won't start, SQL errors

**Solution:**
```powershell
# Delete corrupted database
Remove-Item debugger.db -Force

# Restart backend (will recreate)
.\run_backend.bat
```

### Indexes Not Regenerating
**Symptoms:** Context building fails

**Solution:**
```powershell
# Clear indexes completely
Remove-Item -Recurse -Force faiss_index

# Rebuild context in UI
# Go to Context Building step
```

## Best Practices

### Regular Maintenance
- Clear old tickets monthly
- Backup before major changes
- Monitor disk space usage

### Project Management
- Delete unused projects
- Archive completed projects
- Use descriptive project names

### Development/Testing
- Use separate test projects
- Clear test data regularly
- Don't mix test and production data

### Production Use
- Backup before clearing
- Clear during off-hours
- Document what was cleared

## Quick Reference

| Command | What It Clears | Safe? |
|---------|----------------|-------|
| `clear_data.bat` | Database, indexes, projects | ✅ Yes (prompts) |
| `.\clear_data.ps1 -All` | Everything | ✅ Yes (prompts) |
| `.\clear_data.ps1 -All -Force` | Everything | ⚠️ No prompt |
| `.\clear_data.ps1 -Database` | Database only | ✅ Yes |
| `.\clear_data.ps1 -Indexes` | Indexes only | ✅ Yes |
| `.\clear_data.ps1 -Projects` | Projects only | ✅ Yes |
| `.\clear_data.ps1 -Repos` | Cloned repos only | ✅ Yes |

## Summary

The cleanup utilities provide:
- ✅ Easy data clearing
- ✅ Selective deletion
- ✅ Safety prompts
- ✅ Multiple methods
- ✅ Flexible options

**Always backup important data before clearing!**

---

**Version:** 1.0.0  
**Updated:** February 2026
