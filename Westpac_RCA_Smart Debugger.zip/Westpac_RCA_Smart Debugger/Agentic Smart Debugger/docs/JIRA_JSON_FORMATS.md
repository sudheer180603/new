# Jira Ticket JSON Formats

This document describes the supported JSON formats for Jira ticket ingestion.

## Required Fields

The system accepts **either** of these ID fields:
- `ticket_id` (standard format)
- `jira_id` (alternative format)

At least one must be present in each ticket.

## Supported Formats

### Format 1: Simple Format (Minimum)

```json
[
  {
    "ticket_id": "LOS-105"
  }
]
```

### Format 2: Standard Format (Recommended)

```json
[
  {
    "ticket_id": "LOS-105",
    "summary": "KYC file upload has no file size validation",
    "description": "The KYC document upload endpoint accepts files of any size",
    "priority": "High",
    "module": "kyc"
  }
]
```

### Format 3: Rich Format (Full Details)

Your original format is now fully supported! The system will automatically extract and consolidate all fields:

```json
[
  {
    "jira_id": "LOS-105",
    "summary": "KYC file upload has no file size validation causing server crashes",
    "description": "The KYC document upload endpoint accepts files of any size. Large files (>100MB) cause memory issues and can crash the FastAPI server.",
    "affected_module": "kyc",
    "error_message": "MemoryError: Unable to allocate memory for file read",
    "stack_trace": "MemoryError: Unable to allocate memory\n  File 'backend/app/kyc/routes.py', line 54, in submit_customer_kyc\n    content = await pan_file.read()\nMemoryError: Unable to allocate memory",
    "reproduction_steps": [
      "Login as customer with complete profile",
      "Navigate to KYC submission page",
      "Upload a very large PDF file (>100MB)",
      "Observe server becomes unresponsive",
      "Server may crash with memory error"
    ],
    "severity": "critical",
    "endpoint": "/kyc/submit"
  }
]
```

## Field Mapping

The system intelligently maps and consolidates fields:

| Your Field | Maps To | Notes |
|------------|---------|-------|
| `jira_id` | `ticket_id` | Automatically normalized |
| `ticket_id` | `ticket_id` | Used as-is |
| `summary` | `summary` | Used as-is |
| `description` | `description` | Base description |
| `error_message` | `description` | Appended to description |
| `stack_trace` | `description` | Appended to description |
| `affected_module` | Both `module` and `description` | Used as module, also added to description |
| `endpoint` | `description` | Appended to description |
| `reproduction_steps` | `description` | Joined and appended to description |
| `severity` | `priority` | Mapped: critical→Critical, high→High, etc. |
| `priority` | `priority` | Used as-is if provided |
| `module` | `module` | Used as-is if provided |

## Automatic Processing

### Severity to Priority Mapping

If you provide `severity` but not `priority`, it's automatically mapped:

```
critical → Critical
high     → High
medium   → Medium
low      → Low
```

### Description Consolidation

All relevant fields are consolidated into a comprehensive description:

**Input:**
```json
{
  "jira_id": "LOS-105",
  "description": "File upload issue",
  "error_message": "MemoryError",
  "stack_trace": "File 'routes.py', line 54",
  "endpoint": "/kyc/submit",
  "severity": "critical"
}
```

**Consolidated Description:**
```
File upload issue

Error: MemoryError

Stack Trace: File 'routes.py', line 54

Endpoint: /kyc/submit

Severity: critical
```

This comprehensive description is used for:
- Embedding generation
- Semantic search
- RCA analysis
- Context building

## Examples

### Example 1: Your Original Ticket (Now Supported!)

```json
[
  {
    "jira_id": "LOS-105",
    "summary": "KYC file upload has no file size validation causing server crashes",
    "description": "The KYC document upload endpoint accepts files of any size. Large files (>100MB) cause memory issues and can crash the FastAPI server. No file size limit is enforced on backend or frontend.",
    "affected_module": "kyc",
    "error_message": "MemoryError: Unable to allocate memory for file read",
    "stack_trace": "MemoryError: Unable to allocate memory\n  File 'backend/app/kyc/routes.py', line 54, in submit_customer_kyc\n    content = await pan_file.read()\nMemoryError: Unable to allocate memory",
    "reproduction_steps": [
      "Login as customer with complete profile",
      "Navigate to KYC submission page",
      "Upload a very large PDF file (>100MB)",
      "Observe server becomes unresponsive",
      "Server may crash with memory error"
    ],
    "severity": "critical",
    "endpoint": "/kyc/submit"
  }
]
```

**Result:**
- `ticket_id`: "LOS-105" (from jira_id)
- `priority`: "Critical" (from severity)
- `module`: "kyc" (from affected_module)
- `description`: Comprehensive text with all details

### Example 2: Multiple Tickets

```json
[
  {
    "ticket_id": "LOS-101",
    "summary": "Login timeout issue",
    "description": "Users experience timeout after 30 seconds",
    "priority": "High",
    "module": "auth"
  },
  {
    "jira_id": "LOS-102",
    "summary": "Payment gateway error",
    "error_message": "Connection refused",
    "severity": "critical",
    "affected_module": "payments",
    "endpoint": "/api/payments/process"
  }
]
```

Both formats work together seamlessly!

## Validation Rules

### ✅ Valid

```json
[{"ticket_id": "ABC-123"}]                    // Minimum required
[{"jira_id": "ABC-123"}]                      // Alternative ID field
[{"ticket_id": "ABC-123", "summary": "..."}]  // With optional fields
```

### ❌ Invalid

```json
[{"summary": "No ID"}]                        // Missing both ticket_id and jira_id
[]                                            // Empty array
{"ticket_id": "ABC-123"}                      // Not an array
[{"ticket_id": 123}]                          // ID should be string
```

## Best Practices

1. **Use Rich Format**: Include all available fields for better RCA analysis
2. **Provide Stack Traces**: Helps identify exact code locations
3. **Include Reproduction Steps**: Aids in understanding the issue
4. **Specify Severity**: Helps prioritize issues
5. **Add Module/Endpoint**: Helps narrow down affected code

## Testing Your JSON

Before submitting, validate your JSON:
1. Use https://jsonlint.com to check syntax
2. Ensure proper quotes (double quotes `"`, not single `'`)
3. Check for trailing commas
4. Verify array brackets `[]` and object braces `{}`

## Summary

The system now supports:
- ✅ Both `ticket_id` and `jira_id` field names
- ✅ Rich structured data with error details
- ✅ Automatic field mapping and consolidation
- ✅ Severity to priority conversion
- ✅ Reproduction steps as arrays
- ✅ Multiple tickets in one submission

Your original JSON format is now fully supported without any modifications needed!

---

**Updated:** February 2026  
**Version:** 1.1.0
