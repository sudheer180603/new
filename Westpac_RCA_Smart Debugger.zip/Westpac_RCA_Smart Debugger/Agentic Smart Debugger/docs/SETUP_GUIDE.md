# Agentic Smart Debugger - Setup Guide

## Prerequisites

- Python 3.9 or higher
- Azure OpenAI account with GPT-4 deployment
- Git installed
- 8GB+ RAM recommended

## Installation Steps

### 1. Clone or Navigate to Project Directory

```bash
cd agentic-smart-debugger
```

### 2. Create Virtual Environment

```bash
python -m venv venv
```

### 3. Activate Virtual Environment

**Windows:**
```bash
venv\Scripts\activate
```

**Linux/Mac:**
```bash
source venv/bin/activate
```

### 4. Install Dependencies

```bash
pip install -r requirements.txt
```

### 5. Configure Azure OpenAI

Create a `.env` file in the project root:

```bash
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your_api_key_here
AZURE_OPENAI_DEPLOYMENT=gpt-4
AZURE_OPENAI_API_VERSION=2024-02-15-preview
```

Replace with your actual Azure OpenAI credentials.

### 6. Create Required Directories

```bash
mkdir cloned_repos uploaded_docs faiss_index
```

## Running the Application

### Start Backend (Terminal 1)

**Windows:**
```bash
run_backend.bat
```

**Linux/Mac:**
```bash
chmod +x run_backend.sh
./run_backend.sh
```

Or manually:
```bash
uvicorn app.main:app --reload --port 8000
```

### Start Frontend (Terminal 2)

**Windows:**
```bash
run_frontend.bat
```

**Linux/Mac:**
```bash
chmod +x run_frontend.sh
./run_frontend.sh
```

Or manually:
```bash
streamlit run frontend/app.py
```

## Usage Workflow

1. **GitHub Ingestion**: Enter repository URL and click "Clone & Parse Repository"
2. **Business Docs**: Upload PDF/DOCX/TXT files containing business requirements
3. **Build Context**: Click "Build Context" to generate embeddings and unified knowledge base
4. **Jira Tickets**: Paste JSON array of tickets and click "Process Tickets"
5. **RCA Analysis**: Click "Run RCA Analysis" to get root cause analysis powered by Azure GPT-4

## API Endpoints

- `GET /` - API status
- `POST /api/ingest/github` - Clone and parse GitHub repository
- `POST /api/ingest/business-docs` - Upload business documents
- `POST /api/context/build` - Build unified context with embeddings
- `POST /api/jira/process` - Process Jira tickets
- `POST /api/rca/analyze` - Run root cause analysis
- `GET /api/health` - Health check

## Jira Ticket JSON Format

```json
[
  {
    "ticket_id": "PROJ-123",
    "summary": "Login fails for users",
    "description": "Users cannot login with valid credentials",
    "priority": "High",
    "module": "Authentication"
  }
]
```

## Troubleshooting

### Backend won't start
- Check if port 8000 is available
- Verify Azure OpenAI credentials in `.env`
- Check Python version (3.9+)

### Frontend won't start
- Check if port 8501 is available (Streamlit default)
- Ensure backend is running first

### Embedding model download
- First run will download BAAI/bge-large-en-v1.5 (~1.3GB)
- Requires internet connection
- Model cached in `~/.cache/huggingface/`

### Azure OpenAI errors
- Verify endpoint URL format
- Check API key validity
- Ensure GPT-4 deployment exists
- Check API version compatibility

## Architecture Overview

- **Backend**: FastAPI (port 8000)
- **Frontend**: Streamlit (port 8501)
- **Database**: SQLite (debugger.db)
- **Vector Store**: FAISS (faiss_index/)
- **LLM**: Azure OpenAI GPT-4
- **Embeddings**: HuggingFace BAAI/bge-large-en-v1.5

## Security Notes

- Never commit `.env` file
- Keep Azure API keys secure
- Sanitize all file paths
- Validate JSON inputs
- Limit file upload sizes
