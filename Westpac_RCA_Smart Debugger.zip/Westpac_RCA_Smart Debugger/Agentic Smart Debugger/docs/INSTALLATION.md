# Complete Installation Guide

## System Requirements

### Minimum Requirements
- **OS**: Windows 10/11, Linux (Ubuntu 20.04+), macOS 10.15+
- **Python**: 3.9 or higher
- **RAM**: 8GB minimum, 16GB recommended
- **Disk Space**: 5GB free space (for models and data)
- **Internet**: Required for initial setup and Azure API calls

### Required Accounts
- **Azure OpenAI**: Active subscription with GPT-4 deployment

## Installation Methods

### Method 1: Automated Quick Start (Recommended)

```cmd
REM 1. Open Command Prompt or PowerShell in project directory
quickstart.bat

REM 2. Configure Azure OpenAI
copy .env.example .env
REM Edit .env with your Azure credentials

REM 3. Verify setup
python verify_setup.py
```

### Method 2: Manual Installation

#### Step 1: Create Virtual Environment
```cmd
python -m venv venv
venv\Scripts\activate
```

#### Step 2: Install Dependencies
```cmd
pip install --upgrade pip
pip install -r requirements.txt
```

This will install:
- FastAPI & Uvicorn (backend)
- Streamlit (frontend)
- OpenAI SDK (Azure integration)
- sentence-transformers (embeddings)
- faiss-cpu (vector store)
- libcst (Python parsing)
- tree-sitter (JS/TS parsing)
- GitPython (repo cloning)
- PyPDF2, python-docx (document processing)
- SQLAlchemy (database)
- And more...

#### Step 3: Create Required Directories
```cmd
mkdir cloned_repos
mkdir uploaded_docs
mkdir faiss_index
```

#### Step 4: Configure Environment
```cmd
REM Copy template
copy .env.example .env

REM Edit .env file with your credentials
```

Required environment variables:
```env
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your_api_key_here
AZURE_OPENAI_DEPLOYMENT=gpt-4
AZURE_OPENAI_API_VERSION=2024-02-15-preview
```

#### Step 5: Verify Installation
```cmd
python verify_setup.py
```

## Azure OpenAI Setup

### 1. Create Azure OpenAI Resource

1. Go to [Azure Portal](https://portal.azure.com)
2. Create new resource → Azure OpenAI
3. Fill in details:
   - Subscription: Your subscription
   - Resource group: Create new or use existing
   - Region: Choose available region
   - Name: Your resource name
   - Pricing tier: Standard S0

### 2. Deploy GPT-4 Model

1. Go to your Azure OpenAI resource
2. Navigate to "Model deployments"
3. Click "Create new deployment"
4. Select:
   - Model: gpt-4 or gpt-4-32k
   - Deployment name: gpt-4 (or custom name)
5. Click "Create"

### 3. Get Credentials

1. In Azure OpenAI resource, go to "Keys and Endpoint"
2. Copy:
   - Endpoint URL (e.g., https://your-resource.openai.azure.com/)
   - Key 1 or Key 2
3. Note your deployment name from step 2

### 4. Configure Application

Update `.env` file:
```env
AZURE_OPENAI_ENDPOINT=<your-endpoint-url>
AZURE_OPENAI_API_KEY=<your-api-key>
AZURE_OPENAI_DEPLOYMENT=<your-deployment-name>
AZURE_OPENAI_API_VERSION=2024-02-15-preview
```

## First Run

### 1. Start Backend

**Windows:**
```bash
run_backend.bat
```

**Linux/Mac:**
```bash
chmod +x run_backend.sh
./run_backend.sh
```

Or manually:
```bash
uvicorn app.main:app --reload --port 8000
```

Expected output:
```
INFO:     Uvicorn running on http://127.0.0.1:8000
INFO:     Application startup complete.
```

### 2. Start Frontend (New Terminal)

**Windows:**
```bash
run_frontend.bat
```

**Linux/Mac:**
```bash
chmod +x run_frontend.sh
./run_frontend.sh
```

Or manually:
```bash
streamlit run frontend/app.py
```

Expected output:
```
You can now view your Streamlit app in your browser.
Local URL: http://localhost:8501
```

### 3. Access Application

Open browser and navigate to:
- **Frontend**: http://localhost:8501
- **Backend API**: http://localhost:8000
- **API Documentation**: http://localhost:8000/docs

## First-Time Model Download

On first run, the system will download the embedding model:
- **Model**: BAAI/bge-large-en-v1.5
- **Size**: ~1.3GB
- **Location**: `~/.cache/huggingface/`
- **Time**: 5-15 minutes depending on connection

Progress will be shown in the terminal.

## Verification Tests

### Test 1: Health Check
Open browser and navigate to:
```
http://localhost:8000/api/health
```

Expected response:
```json
{"status": "healthy"}
```

Or use PowerShell:
```powershell
Invoke-WebRequest -Uri http://localhost:8000/api/health
```

### Test 2: Run Test Script
```cmd
python test_example.py
```

### Test 3: Frontend Access
1. Open http://localhost:8501
2. Check "System Status" in sidebar
3. Should show "✅ Backend Connected"

## Common Installation Issues

### Issue: Python version too old
```
Error: Python 3.9+ required
```
**Solution**: Install Python 3.9 or higher from python.org

### Issue: pip install fails
```
Error: Could not install packages
```
**Solution**:
```bash
pip install --upgrade pip
pip install wheel setuptools
pip install -r requirements.txt
```

### Issue: Port already in use
```
Error: Address already in use
```
**Solution**:
```cmd
REM Find process using port
netstat -ano | findstr :8000
taskkill /PID <process_id> /F
```

### Issue: Azure OpenAI authentication fails
```
Error: Unauthorized
```
**Solution**:
- Verify endpoint URL format (must include https://)
- Check API key is correct
- Ensure deployment name matches Azure
- Verify API version is supported

### Issue: Embedding model download fails
```
Error: Connection timeout
```
**Solution**:
- Check internet connection
- Try again (download resumes automatically)
- Use VPN if behind firewall
- Manually download from HuggingFace

### Issue: Git clone fails
```
Error: Repository not found
```
**Solution**:
- Verify repository URL is correct
- Check repository is public or you have access
- Ensure Git is installed: `git --version`

## Performance Optimization

### For Large Repositories
Edit `app/config.py`:
```python
batch_size = 64  # Increase for faster processing
top_k_retrieval = 20  # More context
```

### For Limited RAM
Edit `app/config.py`:
```python
batch_size = 16  # Reduce memory usage
max_file_size_mb = 25  # Smaller file limit
```

### For Better Accuracy
Edit `app/config.py`:
```python
similarity_threshold = 0.8  # Higher threshold
temperature = 0.1  # More deterministic
```

## Updating the System

### Update Dependencies
```cmd
pip install --upgrade -r requirements.txt
```

### Update Configuration
Edit `app/config.py` or `.env` file as needed

### Clear Cache
```cmd
REM Remove cloned repos
rmdir /s /q cloned_repos
mkdir cloned_repos

REM Remove FAISS indices
rmdir /s /q faiss_index
mkdir faiss_index

REM Remove database
del debugger.db
```

## Uninstallation

### Remove Virtual Environment
```cmd
REM Deactivate first
deactivate

REM Remove directory
rmdir /s /q venv
```

### Remove Data
```cmd
rmdir /s /q cloned_repos uploaded_docs faiss_index
del debugger.db
```

## Next Steps

After successful installation:

1. Read [USAGE_EXAMPLES.md](USAGE_EXAMPLES.md) for usage patterns
2. Review [ARCHITECTURE.md](ARCHITECTURE.md) for system understanding
3. Check [SETUP_GUIDE.md](SETUP_GUIDE.md) for detailed configuration
4. Start with a small test repository

## Support

For issues:
1. Check this installation guide
2. Review [SETUP_GUIDE.md](SETUP_GUIDE.md)
3. Run `python verify_setup.py`
4. Check logs in terminal output

## Security Notes

- Never commit `.env` file to version control
- Keep Azure API keys secure
- Regularly rotate API keys
- Use environment-specific configurations
- Review security settings in `app/utils/security.py`
