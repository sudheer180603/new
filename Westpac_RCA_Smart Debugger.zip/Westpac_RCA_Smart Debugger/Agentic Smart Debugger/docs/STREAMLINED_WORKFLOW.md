# Streamlined Workflow Guide

## Overview

The new streamlined workflow provides a **single-page, sequential interface** that guides you through the entire RCA process step-by-step. Each section unlocks only after completing the previous one, preventing confusion and ensuring proper context management.

## Key Features

### 1. Project-Based Context Management
- Each project has its own isolated context
- No mixing of embeddings or data between projects
- Can reuse existing projects for new tickets

### 2. Sequential Workflow
- One step at a time
- Next step unlocks only after current step completes
- Clear progress tracking in sidebar

### 3. Two Modes

#### New Project Mode
Complete workflow from scratch:
1. Project Selection
2. Repository Ingestion
3. Business Documents
4. Context Building
5. Jira Tickets
6. RCA Analysis

#### Existing Project Mode
Resume from where you left off:
1. Project Selection (choose existing)
2. **Automatically jumps to the next incomplete step:**
   - If repo not ingested → Repository Ingestion
   - If docs not processed → Business Documents
   - If context not built → Context Building
   - If context ready → Jira Tickets
3. Continue through remaining steps
4. RCA Analysis

## Workflow Steps

### Step 1: Project Selection

**Choose your mode:**

**Option A: New Project**
- Enter a unique project name
- Click "Create New Project"
- Proceeds to repository ingestion

**Option B: Existing Project**
- Select from dropdown of ALL existing projects
- See project status and statistics
- System shows where you left off:
  - "📦 Next: Repository Ingestion" (if repo not ingested)
  - "📄 Next: Business Documents" (if repo ingested but no docs)
  - "🧠 Next: Context Building" (if docs processed but context not built)
  - "✅ Ready for Jira Tickets" (if context fully built)
- Click "Continue This Project"
- **Automatically resumes from the correct step**

**Project Status Display:**
- Shows completion status for each stage
- Displays project statistics (files, rules, embeddings)
- Clear visual indicators (✅ completed, ⏸️ pending)

### Step 2: Repository Ingestion (New Projects Only)

**Input:**
- GitHub URL: `https://github.com/user/repo`
- OR Local Path: `C:\projects\myapp`

**Output:**
- Files parsed count
- Languages detected
- Language breakdown table

**Auto-advances** to Business Documents

### Step 3: Business Documents (New Projects Only)

**Input:**
- Upload PDF, DOCX, TXT, or MD files
- Multiple files supported

**Output:**
- Documents processed count
- Business rules extracted

**Options:**
- Process Documents (if you have docs)
- Skip (if no docs available)

**Auto-advances** to Context Building

### Step 4: Context Building (New Projects Only)

**Action:**
- Click "Build Context"
- Generates embeddings (may take 2-5 minutes)

**Output:**
- Code blocks indexed
- Business rules indexed
- Total embeddings generated

**Auto-advances** to Jira Tickets

### Step 5: Jira Tickets

**Input:**
- Paste Jira tickets in JSON format
- Supports both `ticket_id` and `jira_id`
- All rich fields supported

**Output:**
- Tickets processed count
- Tickets stored in current session

**Auto-advances** to RCA Analysis

### Step 6: RCA Analysis

**Action:**
- Click "Run RCA Analysis"
- AI analyzes tickets (may take 1-2 minutes)

**Output:**
- Individual ticket analysis cards
- Each card shows:
  - Root cause type
  - Fix type
  - Confidence score
  - Impacted location (file, method, lines)
  - Current logic
  - Expected business logic
  - Resolution logic

**Options:**
- Download full report (JSON)
- Analyze more tickets (returns to Step 5)

## Progress Tracking

The sidebar shows your current position:

```
✅ Project Selection      (completed)
✅ Repository Ingestion   (completed)
✅ Business Documents     (completed)
✅ Context Building       (completed)
▶️ Jira Tickets          (current)
⏸️ RCA Analysis          (locked)
```

## Project Isolation

Each project maintains:
- **Separate database**: `projects/{project_name}/database/project.db`
- **Separate FAISS index**: `projects/{project_name}/faiss_index/`
- **Separate metadata**: `projects/projects.json`

**Benefits:**
- No context mixing
- No embedding conflicts
- Clean session boundaries
- Can work on multiple projects

## Reusing Projects

Projects can be resumed at any stage:

### Scenario 1: Incomplete Project
- Started repository ingestion but didn't finish
- Select project → Resumes at Repository Ingestion
- Complete remaining steps

### Scenario 2: Partial Completion
- Completed repo ingestion and docs
- Didn't build context yet
- Select project → Resumes at Context Building
- Complete context building and continue

### Scenario 3: Fully Built Context
- All context building complete
- Want to analyze new tickets
- Select project → Jumps to Jira Tickets
- Process new tickets immediately

### Scenario 4: Analyze More Tickets
- Already ran RCA on some tickets
- Want to analyze additional tickets
- Select project → Jumps to Jira Tickets
- Process new batch of tickets

**Use Cases:**
- Interrupted workflow - resume where you left off
- Analyzing new tickets for same codebase
- Different team members analyzing different tickets
- Incremental ticket analysis over time
- Re-analyzing with updated tickets

## Starting the Streamlined UI

### Option 1: New Streamlined UI (Recommended)
```powershell
.\run_streamlined_frontend.bat
```
Access at: http://localhost:8501

### Option 2: Original Tabbed UI
```powershell
.\run_frontend.bat
```
Access at: http://localhost:8501

## Comparison: Old vs New UI

| Feature | Old UI (Tabs) | New UI (Streamlined) |
|---------|---------------|----------------------|
| Layout | Multiple tabs | Single page, sequential |
| Navigation | Free navigation | Guided, step-by-step |
| Progress | No tracking | Clear progress bar |
| Context | Global | Project-based |
| Reusability | No | Yes (existing projects) |
| Confusion | Possible | Prevented |
| Session | Mixed | Isolated |

## Best Practices

### For New Analysis
1. Create a new project with descriptive name
2. Complete all steps in order
3. Don't skip business documents if available
4. Wait for context building to complete
5. Process tickets in batches

### For Existing Projects
1. Select project with matching codebase
2. Verify project statistics
3. Process new tickets directly
4. Download reports for each batch

### Project Naming
- Use descriptive names: `LOS-Production`, `PaymentService-v2`
- Include version if analyzing different versions
- Use consistent naming convention

### Context Building
- Be patient (2-5 minutes for large repos)
- Don't interrupt the process
- Check statistics after completion

### Ticket Analysis
- Process related tickets together
- Use clear ticket IDs
- Include all available fields
- Download reports immediately

## Troubleshooting

### "Project already exists"
- Choose a different name
- Or select existing project to reuse

### "No projects with built context"
- Create a new project first
- Complete context building step

### "Cannot connect to backend"
- Start backend: `.\run_backend.bat`
- Wait for "Application startup complete"

### Context building takes too long
- Normal for large repositories (1000+ files)
- Check backend terminal for progress
- Don't close browser during process

### Tickets not showing in RCA
- Ensure tickets were processed (Step 5)
- Check for error messages
- Verify JSON format

## Reset Workflow

If you need to start over:
1. Click "🔄 Reset Workflow" in sidebar
2. Confirms reset
3. Returns to Project Selection

**Note:** This only resets UI state, not project data

## API Endpoints

The streamlined UI uses project-based endpoints:

```
POST   /api/projects/create
GET    /api/projects/list
GET    /api/projects/{name}
POST   /api/projects/{name}/ingest/github
POST   /api/projects/{name}/ingest/business-docs
POST   /api/projects/{name}/context/build
POST   /api/projects/{name}/jira/process
POST   /api/projects/{name}/rca/analyze
DELETE /api/projects/{name}
```

## Data Storage

```
projects/
├── projects.json              # Project metadata
├── ProjectName1/
│   ├── database/
│   │   └── project.db        # Project-specific database
│   └── faiss_index/
│       ├── code.index        # Code embeddings
│       └── business.index    # Business rule embeddings
└── ProjectName2/
    ├── database/
    └── faiss_index/
```

## Migration from Old UI

If you have data from the old UI:
1. It uses global database (`debugger.db`)
2. Create a new project in streamlined UI
3. Re-ingest your repository
4. Old data remains separate

## Summary

The streamlined workflow provides:
- ✅ Clear, guided process
- ✅ No confusion about current step
- ✅ Project-based isolation
- ✅ Reusable contexts
- ✅ Better user experience
- ✅ Professional presentation

**Recommended for all new analyses!**

---

**Version:** 2.0.0  
**Updated:** February 2026
