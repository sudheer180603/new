# Testing Guide for Enhancements

## Overview
This guide provides step-by-step instructions to test all the enhancements made to the Smart Debugger platform.

## Prerequisites

1. Backend running: `run_backend.bat`
2. Frontend running: `run_streamlined_frontend.bat`
3. Azure OpenAI configured in `.env`
4. Test repository available (or use a sample project)

## Test Suite

### 1. Parser Enhancements Test

#### Test 1.1: Python Parser Accuracy
**Objective:** Verify accurate line number detection and dependency extraction

**Steps:**
1. Create a test Python file with known line numbers:
```python
# test_parser.py (save in a test repo)
import os
import sys

class TestClass:
    def __init__(self):
        self.value = 0
    
    def method_one(self):
        result = self.helper_method()
        return result
    
    def helper_method(self):
        return self.value + 1

def standalone_function():
    obj = TestClass()
    return obj.method_one()
```

2. Ingest the repository containing this file
3. Check database for parsed results:
```python
from app.database.project_db import project_db
from app.database.models import CodeMetadata

db = project_db.get_session('TEST_PROJECT')
blocks = db.query(CodeMetadata).filter(
    CodeMetadata.file_path.like('%test_parser.py%')
).all()

for block in blocks:
    print(f"{block.class_name}.{block.method_name}: Lines {block.start_line}-{block.end_line}")
    print(f"Dependencies: {block.dependencies}")
    print("---")
```

**Expected Results:**
- ✅ Accurate line numbers for each class and method
- ✅ Dependencies list includes: `helper_method`, `TestClass`, etc.
- ✅ Class hierarchy correctly identified

#### Test 1.2: JavaScript/TypeScript Parser
**Objective:** Verify JS/TS parsing with class context

**Steps:**
1. Create test JS file:
```javascript
// test_parser.js
class Calculator {
    constructor() {
        this.result = 0;
    }
    
    add(a, b) {
        return this.calculate(a, b, '+');
    }
    
    calculate(a, b, op) {
        return eval(`${a} ${op} ${b}`);
    }
}

function helperFunction() {
    const calc = new Calculator();
    return calc.add(1, 2);
}
```

2. Ingest and verify parsing
3. Check that methods have correct class context

**Expected Results:**
- ✅ Methods show class name: `Calculator`
- ✅ Line numbers accurate
- ✅ Dependencies include function calls

### 2. Business Document Processor Test

#### Test 2.1: Pattern-Based Rule Extraction
**Objective:** Verify enhanced rule extraction

**Steps:**
1. Create test document (test_rules.md):
```markdown
# Validation Rules

## KYC Requirements
Users must upload a valid government ID for verification.
The system should validate file size is under 5MB.

## Security Constraints
Passwords must contain at least 8 characters.
Users are not allowed to reuse the last 5 passwords.

## Business Logic
When a user submits a loan application, the system must verify credit score.
If credit score is below 600, then the application should be automatically rejected.
```

2. Upload via frontend
3. Check extracted rules:
```python
from app.database.project_db import project_db
from app.database.models import BusinessRule

db = project_db.get_session('TEST_PROJECT')
rules = db.query(BusinessRule).all()

for rule in rules:
    print(f"Category: {rule.category}")
    print(f"Section: {getattr(rule, 'section', 'N/A')}")
    print(f"Rule: {rule.rule_text[:100]}...")
    print("---")
```

**Expected Results:**
- ✅ Rules categorized correctly (validation, security, business_logic)
- ✅ Section information captured
- ✅ Pattern-based rules extracted (must, should, if-then)
- ✅ No duplicate rules

#### Test 2.2: Multi-Format Support
**Objective:** Test PDF, DOCX, and MD extraction

**Steps:**
1. Create same content in different formats
2. Upload all three
3. Verify consistent extraction

**Expected Results:**
- ✅ All formats extract similar rules
- ✅ Table content extracted from DOCX
- ✅ No format-specific errors

### 3. Context Builder Test

#### Test 3.1: Cross-Mapping Creation
**Objective:** Verify business-code mappings

**Steps:**
1. Ingest code with validation logic
2. Upload business docs with validation rules
3. Build context
4. Check mappings:
```python
from app.database.project_db import project_db
from app.database.models import CodeMetadata, BusinessRule

db = project_db.get_session('TEST_PROJECT')

# Check code blocks with related rules
code_blocks = db.query(CodeMetadata).filter(
    CodeMetadata.related_business_rules.isnot(None)
).all()

print(f"Code blocks with related rules: {len(code_blocks)}")

for block in code_blocks[:3]:
    print(f"\nFile: {block.file_path}")
    print(f"Method: {block.method_name}")
    print(f"Related rules: {block.related_business_rules}")

# Check rules with related code
rules = db.query(BusinessRule).filter(
    BusinessRule.related_code_blocks.isnot(None)
).all()

print(f"\nRules with related code: {len(rules)}")
```

**Expected Results:**
- ✅ Mappings created between related code and rules
- ✅ Similarity threshold working (0.65)
- ✅ Bidirectional relationships

#### Test 3.2: Enhanced Embeddings
**Objective:** Verify rich context in embeddings

**Steps:**
1. Build context for project
2. Check vector store files exist
3. Verify embedding quality with search:
```python
from app.embeddings.generator import embedding_generator
from app.vector_store.project_faiss import get_project_store

store = get_project_store('TEST_PROJECT', embedding_generator.dimension, 'code')

# Search for validation-related code
query = "file size validation check"
query_embedding = embedding_generator.generate_single_embedding(query)
results = store.search(query_embedding, k=5)

for meta, score in results:
    print(f"Score: {score:.3f}")
    print(f"File: {meta['file_path']}")
    print(f"Method: {meta['method_name']}")
    print("---")
```

**Expected Results:**
- ✅ Relevant code blocks returned
- ✅ High similarity scores (>0.7) for relevant matches
- ✅ Context-aware matching

### 4. RCA Analyzer Test

#### Test 4.1: Multi-Strategy Retrieval
**Objective:** Verify enhanced context retrieval

**Steps:**
1. Create ticket with module specified:
```json
{
  "ticket_id": "TEST-001",
  "summary": "File upload validation missing",
  "description": "Users can upload files larger than 5MB causing memory issues",
  "priority": "High",
  "module": "kyc"
}
```

2. Process ticket
3. Analyze with RCA
4. Check logs for retrieval strategies

**Expected Results:**
- ✅ Multiple search strategies used
- ✅ Module-specific results included
- ✅ Symptom-focused results included
- ✅ Results merged and deduplicated

#### Test 4.2: Enhanced Analysis Output
**Objective:** Verify improved RCA quality

**Steps:**
1. Run RCA analysis
2. Check output structure:
```python
from app.database.project_db import project_db
from app.database.models import RCAResult

db = project_db.get_session('TEST_PROJECT')
result = db.query(RCAResult).filter(
    RCAResult.ticket_id == 'TEST-001'
).first()

print(f"Root Cause: {result.root_cause_type}")
print(f"File: {result.impacted_file}")
print(f"Method: {result.impacted_method}")
print(f"Lines: {result.code_pointer}")
print(f"Confidence: {result.confidence_score}")
```

**Expected Results:**
- ✅ Specific file and method identified
- ✅ Accurate line numbers
- ✅ Confidence score provided
- ✅ Detailed current/expected/resolution logic

### 5. Frontend Display Test

#### Test 5.1: Table Display
**Objective:** Verify new table-based UI

**Steps:**
1. Complete RCA analysis
2. View results in frontend
3. Check table displays

**Expected Results:**
- ✅ Affected Code Section table shows:
  - File path
  - Class/Method
  - Line range
  - Root cause type
- ✅ Analysis table shows:
  - Current logic (truncated)
  - Expected logic (truncated)
  - Resolution (truncated)
- ✅ Expandable section shows full details
- ✅ Related components displayed

#### Test 5.2: Multiple Tickets
**Objective:** Test with multiple tickets

**Steps:**
1. Process 3-5 tickets
2. Analyze all
3. Verify each displays correctly

**Expected Results:**
- ✅ All tickets show in results
- ✅ Tables render correctly for each
- ✅ Expandable sections work independently

### 6. Performance Test

#### Test 6.1: Large Repository
**Objective:** Test with substantial codebase

**Steps:**
1. Ingest repository with 100+ files
2. Upload 10+ business documents
3. Build context
4. Process 10+ tickets
5. Measure times

**Expected Results:**
- ✅ Parsing completes in reasonable time
- ✅ Context building completes
- ✅ RCA analysis completes per ticket
- ✅ No memory issues

#### Test 6.2: Accuracy Metrics
**Objective:** Measure improvement

**Steps:**
1. Create test cases with known issues
2. Run RCA analysis
3. Compare results to expected

**Expected Results:**
- ✅ 80%+ accuracy on root cause identification
- ✅ 90%+ accuracy on file identification
- ✅ 95%+ accuracy on line numbers

## Automated Test Script

Create `test_enhancements.py`:
```python
import requests
import json

API_BASE = "http://localhost:8000"
PROJECT = "TEST_ENHANCEMENTS"

def test_workflow():
    print("1. Creating project...")
    r = requests.post(f"{API_BASE}/api/projects/create", json={"name": PROJECT})
    assert r.status_code == 200
    
    print("2. Ingesting repository...")
    r = requests.post(
        f"{API_BASE}/api/projects/{PROJECT}/ingest/github",
        json={"repo_url_or_path": "./test_repo"}
    )
    assert r.status_code == 200
    print(f"   Parsed {r.json()['files_parsed']} files")
    
    print("3. Building context...")
    r = requests.post(f"{API_BASE}/api/projects/{PROJECT}/context/build")
    assert r.status_code == 200
    print(f"   Generated {r.json()['embeddings_generated']} embeddings")
    
    print("4. Processing ticket...")
    ticket = {
        "ticket_id": "TEST-001",
        "summary": "Test issue",
        "description": "Test description",
        "priority": "High"
    }
    r = requests.post(
        f"{API_BASE}/api/projects/{PROJECT}/jira/process",
        json=[ticket]
    )
    assert r.status_code == 200
    
    print("5. Running RCA...")
    r = requests.post(f"{API_BASE}/api/projects/{PROJECT}/rca/analyze")
    assert r.status_code == 200
    results = r.json()
    
    print(f"\n✅ All tests passed!")
    print(f"   Root Cause: {results['tickets'][0]['root_cause_type']}")
    print(f"   Confidence: {results['tickets'][0]['confidence_score']}")

if __name__ == "__main__":
    test_workflow()
```

Run: `python test_enhancements.py`

## Success Criteria

All tests should pass with:
- ✅ No errors in backend logs
- ✅ Accurate line numbers (±1 line acceptable)
- ✅ Dependencies correctly extracted
- ✅ Business rules properly categorized
- ✅ Cross-mappings created
- ✅ RCA results specific and actionable
- ✅ Frontend displays correctly

## Troubleshooting

### Parser Issues
- Check file encoding (should be UTF-8)
- Verify syntax is valid
- Check logs for specific errors

### Business Doc Issues
- Verify file format is supported
- Check document structure
- Review extraction logs

### Context Building Issues
- Verify embeddings model loaded
- Check FAISS index creation
- Review memory usage

### RCA Issues
- Verify Azure OpenAI connection
- Check similarity thresholds
- Review prompt responses

## Reporting Issues

If tests fail:
1. Capture error logs
2. Note specific test case
3. Document expected vs actual results
4. Check `docs/TROUBLESHOOTING.md`
