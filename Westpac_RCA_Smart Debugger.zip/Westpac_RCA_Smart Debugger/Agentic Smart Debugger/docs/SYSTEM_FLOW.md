# System Flow Diagram

## Complete Workflow Visualization

```
┌─────────────────────────────────────────────────────────────────────┐
│                         USER INTERACTION                             │
│                    (Streamlit Frontend UI)                           │
│                      http://localhost:8501                           │
└────────────────────────────┬────────────────────────────────────────┘
                             │
                             │ HTTP REST API
                             ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      FASTAPI BACKEND                                 │
│                    http://localhost:8000                             │
└─────────────────────────────────────────────────────────────────────┘
                             │
        ┌────────────────────┼────────────────────┐
        │                    │                    │
        ▼                    ▼                    ▼
┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│   PHASE 1    │    │   PHASE 2    │    │   PHASE 3    │
│   GitHub     │    │  Business    │    │    Jira      │
│  Ingestion   │    │    Docs      │    │   Tickets    │
└──────┬───────┘    └──────┬───────┘    └──────┬───────┘
       │                   │                    │
       ▼                   ▼                    ▼
┌──────────────────────────────────────────────────────┐
│              UNIFIED CONTEXT BUILDER                  │
│  • Merges Code CST + Business Rules + Tickets        │
│  • Generates Embeddings (HuggingFace BGE-large)      │
│  • Stores in SQLite + FAISS                          │
└──────────────────────┬───────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────┐
│              STORAGE LAYER                            │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐          │
│  │  SQLite  │  │  FAISS   │  │  Files   │          │
│  │    DB    │  │  Vector  │  │  System  │          │
│  │          │  │  Store   │  │          │          │
│  └──────────┘  └──────────┘  └──────────┘          │
└──────────────────────┬───────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────┐
│         ROOT CAUSE ANALYSIS ENGINE                    │
│  1. Vector Search (FAISS)                            │
│  2. Context Retrieval (Top-K)                        │
│  3. Azure GPT-4 Reasoning                            │
│  4. Structured Output Generation                     │
└──────────────────────┬───────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────┐
│         ISSUE CONSOLIDATION ENGINE                    │
│  • DBSCAN Clustering                                 │
│  • Similar Root Cause Grouping                       │
│  • Shared File Identification                        │
└──────────────────────┬───────────────────────────────┘
                       │
                       ▼
┌──────────────────────────────────────────────────────┐
│              FINAL OUTPUT                             │
│  • Structured JSON Report                            │
│  • Root Cause Classification                         │
│  • Exact Code Pointers                               │
│  • Resolution Logic                                  │
│  • Consolidation Results                             │
└──────────────────────────────────────────────────────┘
```

## Detailed Phase Breakdown

### PHASE 1: GitHub Repository Ingestion

```
GitHub URL Input
      │
      ▼
┌─────────────┐
│ Git Clone   │ ──► Validate URL
└──────┬──────┘     Check Access
       │
       ▼
┌─────────────┐
│  Cleanup    │ ──► Remove: node_modules, .git, venv, dist, build
└──────┬──────┘
       │
       ▼
┌─────────────┐
│ Detect Lang │ ──► Python, JavaScript, TypeScript
└──────┬──────┘
       │
       ▼
┌─────────────────────────────────┐
│     CST PARSING                 │
│  ┌──────────┐  ┌──────────┐   │
│  │  Python  │  │  JS/TS   │   │
│  │  libcst  │  │tree-sitter│   │
│  └────┬─────┘  └────┬─────┘   │
│       │             │          │
│       ▼             ▼          │
│  Classes       Components      │
│  Methods       Hooks           │
│  Functions     JSX             │
│  Decorators    Props           │
└─────────────────┬───────────────┘
                  │
                  ▼
            Store in DB
```

### PHASE 2: Business Documentation Processing

```
Upload Files (PDF/DOCX/TXT)
      │
      ▼
┌─────────────┐
│Extract Text │ ──► PyPDF2, python-docx
└──────┬──────┘
       │
       ▼
┌─────────────┐
│Parse Rules  │ ──► Functional Requirements
└──────┬──────┘     Domain Entities
       │            Constraints
       ▼
┌─────────────┐
│  Structure  │ ──► Business Knowledge Graph
└──────┬──────┘
       │
       ▼
  Store in DB
```

### PHASE 3: Jira Ticket Processing

```
JSON Ticket Input
      │
      ▼
┌─────────────┐
│  Validate   │ ──► Schema Check
└──────┬──────┘     Required Fields
       │
       ▼
┌─────────────┐
│   Parse     │ ──► ticket_id, summary, description
└──────┬──────┘     priority, module
       │
       ▼
  Store in DB
```

### PHASE 4: Unified Context Building

```
┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│  Code CST    │  │Business Rules│  │   Tickets    │
│   (SQLite)   │  │   (SQLite)   │  │   (SQLite)   │
└──────┬───────┘  └──────┬───────┘  └──────┬───────┘
       │                 │                  │
       └─────────────────┼──────────────────┘
                         │
                         ▼
              ┌──────────────────┐
              │ Embedding Gen    │
              │  HuggingFace     │
              │ BGE-large-1024d  │
              └────────┬─────────┘
                       │
                       ▼
              ┌──────────────────┐
              │  FAISS Index     │
              │  • code_index    │
              │  • business_index│
              │  • ticket_index  │
              └──────────────────┘
```

### PHASE 5: Root Cause Analysis

```
Ticket Query
      │
      ▼
┌─────────────────┐
│ Generate        │
│ Ticket Embedding│ ──► HuggingFace BGE-large
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Vector Search   │ ──► FAISS Similarity Search
│ (Top-K=10)      │     Cosine Similarity
└────────┬────────┘
         │
         ├──► Relevant Code Blocks
         ├──► Relevant Business Rules
         └──► Dependency Context
         │
         ▼
┌─────────────────────────────────┐
│    AZURE OPENAI GPT-4           │
│                                 │
│  System Prompt:                 │
│  • Role: RCA Engine             │
│  • Constraints: No hallucination│
│  • Output: Structured JSON      │
│                                 │
│  User Prompt:                   │
│  • Ticket Details               │
│  • Code Context                 │
│  • Business Rules               │
│                                 │
│  Temperature: 0.2               │
│  Max Tokens: 4000               │
└────────┬────────────────────────┘
         │
         ▼
┌─────────────────┐
│ Parse Response  │
│ Validate JSON   │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────┐
│  RCA OUTPUT                     │
│  • root_cause_type              │
│  • impacted_file                │
│  • impacted_method              │
│  • code_pointer (file:line)     │
│  • current_logic                │
│  • business_expected_logic      │
│  • resolution_logic             │
│  • fix_type                     │
│  • confidence_score             │
└─────────────────────────────────┘
```

### PHASE 6: Issue Consolidation

```
All RCA Results
      │
      ▼
┌─────────────────┐
│ Extract         │
│ Resolution Text │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Generate        │
│ Embeddings      │ ──► HuggingFace BGE-large
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ DBSCAN          │
│ Clustering      │ ──► eps=0.3, min_samples=2
└────────┬────────┘     metric=cosine
         │
         ▼
┌─────────────────────────────────┐
│  CONSOLIDATION OUTPUT           │
│  • cluster_id                   │
│  • primary_ticket               │
│  • related_tickets[]            │
│  • shared_root_cause            │
│  • impacted_files[]             │
│  • ticket_count                 │
└─────────────────────────────────┘
```

## Data Flow Summary

```
INPUT                    PROCESSING                OUTPUT
─────                    ──────────                ──────

GitHub URL          ──►  Clone + Parse        ──►  Code CST
Business Docs       ──►  Extract Rules        ──►  Knowledge Graph
Jira Tickets        ──►  Validate + Store     ──►  Ticket DB
                         
                         ▼
                         
                    Build Context
                    Generate Embeddings
                    Store in FAISS + SQLite
                    
                         ▼
                         
                    Vector Search
                    Retrieve Context
                    
                         ▼
                         
                    Azure GPT-4 Analysis
                    (Temperature: 0.2)
                    
                         ▼
                         
                    Generate RCA
                    Consolidate Issues
                    
                         ▼
                         
                    Structured JSON Report
                    Downloadable Results
```

## Technology Integration Map

```
┌─────────────────────────────────────────────────────────┐
│                    APPLICATION LAYER                     │
│  ┌──────────────┐              ┌──────────────┐        │
│  │  Streamlit   │◄────REST────►│   FastAPI    │        │
│  │   Frontend   │              │   Backend    │        │
│  └──────────────┘              └──────┬───────┘        │
└─────────────────────────────────────────┼───────────────┘
                                          │
┌─────────────────────────────────────────┼───────────────┐
│                    SERVICE LAYER         │               │
│  ┌──────────────┐  ┌──────────────┐  ┌─▼────────────┐ │
│  │ Azure OpenAI │  │ HuggingFace  │  │   GitPython  │ │
│  │    GPT-4     │  │  BGE-large   │  │              │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
└─────────────────────────────────────────┼───────────────┘
                                          │
┌─────────────────────────────────────────┼───────────────┐
│                    DATA LAYER            │               │
│  ┌──────────────┐  ┌──────────────┐  ┌─▼────────────┐ │
│  │    SQLite    │  │    FAISS     │  │ File System  │ │
│  │   Database   │  │ Vector Store │  │              │ │
│  └──────────────┘  └──────────────┘  └──────────────┘ │
└───────────────────────────────────────────────────────┘
```

## Security Flow

```
User Input
    │
    ▼
┌─────────────┐
│  Validate   │ ──► URL Format Check
└──────┬──────┘     JSON Schema Validation
       │
       ▼
┌─────────────┐
│  Sanitize   │ ──► Path Sanitization
└──────┬──────┘     Remove Dangerous Chars
       │
       ▼
┌─────────────┐
│   Check     │ ──► File Size Limits
└──────┬──────┘     Directory Traversal Prevention
       │
       ▼
┌─────────────┐
│  Process    │ ──► Safe Execution
└──────┬──────┘     No Arbitrary Code
       │
       ▼
   Secure Output
```

## Performance Optimization Flow

```
Large Repository
      │
      ▼
┌─────────────────┐
│ Parallel Parse  │ ──► ThreadPoolExecutor (4 workers)
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ Batch Embed     │ ──► Batch Size: 32
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│ FAISS Index     │ ──► Fast Vector Search
└────────┬────────┘     O(log n) complexity
         │
         ▼
┌─────────────────┐
│ Cache Results   │ ──► Persistent Storage
└─────────────────┘
```

This visualization helps understand the complete system flow from input to output!
