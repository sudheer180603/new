# 🪟 Windows Local Setup - No Docker, No Bash

## ✅ What Changed

This application now runs **100% locally on Windows** with:
- ❌ No Docker required
- ❌ No bash scripts
- ❌ No Linux tools needed
- ✅ Pure Windows Command Prompt/PowerShell
- ✅ All data stored locally
- ✅ Only Azure GPT-4 API calls go to cloud

---

## 🚀 Quick Start (3 Commands)

```cmd
REM 1. Setup
quickstart.bat

REM 2. Configure (edit .env with your Azure credentials)
copy .env.example .env
notepad .env

REM 3. Launch (in two separate terminals)
run_backend.bat
run_frontend.bat
```

Open browser: http://localhost:8501

---

## 📁 Files Removed

- ❌ `Dockerfile` - Removed
- ❌ `docker-compose.yml` - Removed
- ❌ `quickstart.sh` - Removed
- ❌ `run_backend.sh` - Removed
- ❌ `run_frontend.sh` - Removed

---

## 📁 Files Available

### Windows Batch Scripts
- ✅ `quickstart.bat` - Automated setup
- ✅ `run_backend.bat` - Start backend server
- ✅ `run_frontend.bat` - Start frontend UI

### Python Scripts
- ✅ `verify_setup.py` - Verify installation
- ✅ `test_example.py` - Test examples

### Documentation
- ✅ `LOCAL_WINDOWS_SETUP.md` - Complete Windows setup guide
- ✅ `README.md` - Project overview
- ✅ All other documentation files

---

## 💻 System Requirements

- Windows 10 or Windows 11
- Python 3.9 or higher
- 8GB RAM (16GB recommended)
- 5GB free disk space
- Internet connection (for initial setup)
- Azure OpenAI account with GPT-4

---

## 🎯 Complete Workflow

### 1. Initial Setup
```cmd
quickstart.bat
```

This will:
- Create virtual environment
- Install all dependencies
- Create required directories

### 2. Configure Azure OpenAI
```cmd
copy .env.example .env
notepad .env
```

Add your credentials:
```
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your_api_key_here
AZURE_OPENAI_DEPLOYMENT=gpt-4
AZURE_OPENAI_API_VERSION=2024-02-15-preview
```

### 3. Verify Setup
```cmd
python verify_setup.py
```

### 4. Start Backend (Terminal 1)
```cmd
run_backend.bat
```

Wait for: `Uvicorn running on http://127.0.0.1:8000`

### 5. Start Frontend (Terminal 2 - New Window)
```cmd
run_frontend.bat
```

Wait for: `Local URL: http://localhost:8501`

### 6. Access Application
Open browser: http://localhost:8501

---

## 🔧 Common Tasks

### Activate Virtual Environment
```cmd
venv\Scripts\activate
```

### Stop Servers
Press `Ctrl+C` in each terminal

### Clear All Data
```cmd
rmdir /s /q cloned_repos
rmdir /s /q faiss_index
del debugger.db
mkdir cloned_repos
mkdir faiss_index
```

### Reinstall Dependencies
```cmd
venv\Scripts\activate
pip install --upgrade pip
pip install -r requirements.txt
```

---

## 🐛 Troubleshooting

### Port Already in Use
```cmd
netstat -ano | findstr :8000
taskkill /PID <process_id> /F
```

### Python Not Found
- Download from python.org
- Install with "Add to PATH" checked
- Restart Command Prompt

### Module Not Found
```cmd
venv\Scripts\activate
pip install -r requirements.txt
```

### Virtual Environment Issues
```cmd
rmdir /s /q venv
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

---

## 📊 What Runs Locally

### Local Components
- ✅ FastAPI backend server
- ✅ Streamlit frontend UI
- ✅ SQLite database
- ✅ FAISS vector store
- ✅ HuggingFace embeddings (BAAI/bge-large-en-v1.5)
- ✅ CST parsing (libcst, tree-sitter)
- ✅ Document processing
- ✅ All data storage

### Cloud Components
- ☁️ Azure OpenAI GPT-4 API calls only

---

## 🔐 Security

- All data stored locally on your machine
- Azure API key stored in `.env` file (never commit)
- No Docker containers
- No external dependencies except Azure GPT-4
- Full control over data

---

## 📚 Documentation

- **[LOCAL_WINDOWS_SETUP.md](LOCAL_WINDOWS_SETUP.md)** - Detailed Windows setup
- **[README.md](README.md)** - Project overview
- **[USAGE_EXAMPLES.md](USAGE_EXAMPLES.md)** - Usage examples
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - System architecture
- **[INDEX.md](INDEX.md)** - All documentation index

---

## ✅ Verification Checklist

- [ ] Python 3.9+ installed
- [ ] Virtual environment created
- [ ] Dependencies installed
- [ ] `.env` file configured
- [ ] `verify_setup.py` passes
- [ ] Backend starts successfully
- [ ] Frontend starts successfully
- [ ] Can access http://localhost:8501
- [ ] Backend health check works

---

## 🎉 You're Ready!

The application is now configured for **100% local Windows execution**.

No Docker, no bash, no Linux tools needed. Just pure Windows!

**Start using**: Run `run_backend.bat` and `run_frontend.bat`

---

**Platform**: Windows 10/11 Only

**No Docker • No Bash • Pure Windows**
