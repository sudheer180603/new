# Agentic Smart Debugger - Complete Documentation

## Table of Contents
1. [Project Overview](#project-overview)
2. [Architecture](#architecture)
3. [Core Components](#core-components)
4. [File-by-File Analysis](#file-by-file-analysis)
5. [Data Flow](#data-flow)
6. [Configuration](#configuration)
7. [API Endpoints](#api-endpoints)
8. [Frontend Interface](#frontend-interface)
9. [Database Schema](#database-schema)
10. [Deployment](#deployment)

---

## Project Overview

The **Agentic Smart Debugger** is an enterprise-grade AI-powered debugging intelligence platform designed to automate root cause analysis (RCA) for software applications. It combines code analysis, business rule extraction, and AI-driven analysis to identify and resolve issues efficiently.

### Key Features:
- **Multi-language Code Parsing**: Supports 40+ programming languages
- **Business Document Processing**: Extracts rules from PDF, DOCX, TXT, MD files
- **AI-Powered RCA**: Uses Azure OpenAI for intelligent root cause analysis
- **Vector Search**: FAISS-based semantic search for code and business rules
- **Project Management**: Isolated project contexts
- **Jira Integration**: Process and analyze tickets

---

## Architecture

### High-Level Architecture
```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Frontend      │    │   Backend API   │    │   AI Services   │
│   (Streamlit)   │◄──►│   (FastAPI)     │◄──►│   (Azure OpenAI)│
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                │
                                ▼
                       ┌─────────────────┐
                       │   Data Layer    │
                       │ (SQLite + FAISS)│
                       └─────────────────┘
```

### Component Architecture
```
┌─────────────────────────────────────────────────────────────┐
│                    Agentic Smart Debugger                    │
├─────────────────────────────────────────────────────────────┤
│  Frontend Layer                                             │
│  ├── app.py (Main Streamlit Interface)                      │
│  └── streamlined_app.py (Advanced Interface)                │
├─────────────────────────────────────────────────────────────┤
│  API Layer (FastAPI)                                        │
│  ├── main.py (Global Endpoints)                             │
│  └── api/projects.py (Project-specific Endpoints)           │
├─────────────────────────────────────────────────────────────┤
│  Core Processing Engines                                    │
│  ├── parsers/ (Code Analysis)                               │
│  ├── business_docs/ (Document Processing)                  │
│  ├── context_engine/ (Vector Context Building)             │
│  ├── jira/ (Ticket Processing)                              │
│  ├── rca_engine/ (Root Cause Analysis)                      │
│  └── consolidation/ (Issue Clustering)                      │
├─────────────────────────────────────────────────────────────┤
│  Supporting Services                                        │
│  ├── embeddings/ (Vector Generation)                        │
│  ├── vector_store/ (FAISS Management)                       │
│  ├── services/ (Azure OpenAI Client)                        │
│  ├── github/ (Repository Cloning)                           │
│  └── database/ (Data Models & Operations)                   │
├─────────────────────────────────────────────────────────────┤
│  Infrastructure                                             │
│  ├── project_manager.py (Project Isolation)                 │
│  ├── config.py (Configuration Management)                   │
│  └── session_manager.py (Session Handling)                  │
└─────────────────────────────────────────────────────────────┘
```

---

## Core Components

### 1. Configuration Management (`app/config.py`)

**Purpose**: Centralized configuration management using Pydantic settings

**Line-by-Line Analysis**:
```python
# Lines 1-2: Import Pydantic settings and Optional type
from pydantic_settings import BaseSettings
from typing import Optional

# Line 4: Define Settings class inheriting from BaseSettings
class Settings(BaseSettings):
    
    # Lines 5-9: Azure OpenAI Configuration
    azure_openai_endpoint: str                    # Azure OpenAI API endpoint URL
    azure_openai_api_key: str                     # Azure OpenAI API authentication key
    azure_openai_deployment: str = "gpt-4"        # Default GPT-4 model deployment
    azure_openai_api_version: str = "2024-02-15-preview"  # API version
    
    # Lines 11-19: Embedding Model Configuration
    embedding_model: str = "BAAI/bge-small-en-v1.5"  # Fast, efficient embedding model
    # Alternative models commented for reference:
    # - "BAAI/bge-base-en-v1.5" - Balanced quality/speed
    # - "BAAI/bge-large-en-v1.5" - Best quality, slower
    # - "all-MiniLM-L6-v2" - Very fast, decent quality
    embedding_cache_enabled: bool = True         # Enable embedding caching
    embedding_cache_size: int = 10000            # Maximum cached embeddings
    
    # Lines 21-22: Database Configuration
    database_url: str = "sqlite:///./debugger.db"  # SQLite database path
    
    # Lines 24-27: Directory Paths Configuration
    clone_dir: str = "./cloned_repos"            # Directory for cloned repositories
    docs_dir: str = "./uploaded_docs"            # Directory for uploaded documents
    faiss_index_dir: str = "./faiss_index"       # Directory for FAISS vector indices
    
    # Lines 29-33: Processing Parameters
    max_file_size_mb: int = 50                   # Maximum file size for processing (50MB)
    batch_size: int = 32                         # Batch size for embedding generation
    top_k_retrieval: int = 10                    # Number of top results to retrieve
    similarity_threshold: float = 0.7            # Minimum similarity score threshold
    
    # Lines 35-38: Parser Configuration
    use_universal_parser: bool = True           # Use universal parser for all languages
    max_workers: int = 8                         # Number of parallel processing workers
    skip_large_files: bool = True                # Skip files larger than max_file_size_mb
    
    # Lines 40-42: Azure OpenAI Parameters
    temperature: float = 0.2                     # AI response randomness (0.2 = focused)
    max_tokens: int = 4000                       # Maximum tokens in AI response
    
    # Lines 44-46: Pydantic Configuration
    class Config:
        env_file = ".env"                        # Load environment variables from .env file
        case_sensitive = False                   # Case-insensitive environment variable matching

# Line 48: Create global settings instance
settings = Settings()
```

**Internal Working**:
- Loads configuration from environment variables and `.env` file
- Provides type-safe configuration access throughout the application
- Defaults ensure the system works out-of-the-box
- Environment-specific overrides allow for different deployment scenarios

### 2. Main Application (`app/main.py`)

**Purpose**: FastAPI application entry point with global API endpoints

**Line-by-Line Analysis**:
```python
# Lines 1-7: Import FastAPI components and utilities
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from typing import List, Dict, Any
import logging
import warnings
import sys

# Lines 8-11: Python 3.12+ multiprocess warning fixes
# This addresses ResourceTracker warnings in Python 3.12+
warnings.filterwarnings("ignore", category=UserWarning, module="multiprocess.resource_tracker")
warnings.filterwarnings("ignore", message=".*_recursion_count.*")

# Lines 13-27: Patch multiprocess ResourceTracker to prevent cleanup errors
try:
    import multiprocess.resource_tracker as resource_tracker
    _original_del = resource_tracker.ResourceTracker.__del__
    
    def _patched_del(self):
        try:
            _original_del(self)
        except AttributeError as e:
            if '_recursion_count' not in str(e):
                raise
    
    resource_tracker.ResourceTracker.__del__ = _patched_del
except (ImportError, AttributeError):
    pass

# Lines 29-38: Import application components
from app.config import settings
from app.database.models import init_db
from app.github.clone import clone_repository
from app.parsers.orchestrator import parse_repository
from app.business_docs.processor import process_business_docs
from app.context_engine.builder import build_unified_context
from app.jira.processor import process_jira_tickets
from app.rca_engine.analyzer import analyze_tickets
from app.consolidation.engine import consolidate_issues
from app.api.projects import router as projects_router

# Lines 40-41: Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Line 43: Create FastAPI application instance
app = FastAPI(title="Agentic Smart Debugger", version="1.0.0")

# Line 46: Include project-specific router
app.include_router(projects_router)

# Lines 48-54: Add CORS middleware for cross-origin requests
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],           # Allow all origins (configure for production)
    allow_credentials=True,        # Allow cookies/authentication
    allow_methods=["*"],           # Allow all HTTP methods
    allow_headers=["*"],           # Allow all headers
)

# Lines 56-59: Startup event handler
@app.on_event("startup")
async def startup_event():
    init_db()                      # Initialize database tables
    logger.info("Database initialized")

# Lines 61-63: Root endpoint
@app.get("/")
async def root():
    return {"message": "Agentic Smart Debugger API", "status": "running"}

# Lines 65-95: GitHub repository ingestion endpoint
@app.post("/api/ingest/github")
async def ingest_github(repo_url_or_path: str):
    """
    Ingest a GitHub repository or local folder
    
    Args:
        repo_url_or_path: Either a GitHub URL or local folder path
    """
    try:
        # Lines 75-76: Input validation
        if not repo_url_or_path or not repo_url_or_path.strip():
            raise HTTPException(status_code=400, detail="Repository URL or path is required")
        
        # Line 78: Log ingestion start
        logger.info(f"Ingesting repository/folder: {repo_url_or_path}")
        
        # Line 79: Clone repository or use local path
        repo_path = clone_repository(repo_url_or_path)
        
        # Lines 81-82: Parse repository for code analysis
        logger.info("Parsing repository")
        parse_result = parse_repository(repo_path)
        
        # Lines 84-89: Return success response with statistics
        return {
            "status": "success",
            "repo_path": repo_path,
            "files_parsed": parse_result["total_files"],
            "languages": parse_result["languages"]
        }
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error ingesting repository/folder: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Lines 97-110: Business document processing endpoint
@app.post("/api/ingest/business-docs")
async def ingest_business_docs(files: List[UploadFile] = File(...)):
    try:
        # Line 100: Log document processing start
        logger.info(f"Processing {len(files)} business documents")
        
        # Line 101: Process documents and extract business rules
        result = await process_business_docs(files)
        
        # Lines 103-107: Return success response
        return {
            "status": "success",
            "documents_processed": len(files),
            "rules_extracted": result["rules_count"]
        }
    except Exception as e:
        logger.error(f"Error processing business docs: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Lines 112-126: Context building endpoint
@app.post("/api/context/build")
async def build_context():
    try:
        # Line 115: Log context building start
        logger.info("Building unified context")
        
        # Line 116: Build vector embeddings and indices
        result = build_unified_context()
        
        # Lines 118-123: Return success response with statistics
        return {
            "status": "success",
            "code_blocks": result["code_blocks"],
            "business_rules": result["business_rules"],
            "embeddings_generated": result["embeddings_count"]
        }
    except Exception as e:
        logger.error(f"Error building context: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Lines 128-156: Jira ticket processing endpoint
@app.post("/api/jira/process")
async def process_jira(tickets: List[Dict[str, Any]]):
    try:
        # Lines 132-133: Input validation
        if not tickets:
            raise HTTPException(status_code=400, detail="No tickets provided")
        
        # Lines 136-140: Validate each ticket structure
        for i, ticket in enumerate(tickets):
            if not isinstance(ticket, dict):
                raise HTTPException(status_code=400, detail=f"Ticket at index {i} is not a valid object")
            if "ticket_id" not in ticket and "jira_id" not in ticket:
                raise HTTPException(status_code=400, detail=f"Ticket at index {i} is missing required field 'ticket_id' or 'jira_id'")
        
        # Line 142: Log ticket processing start
        logger.info(f"Processing {len(tickets)} Jira tickets")
        
        # Line 143: Process tickets and generate embeddings
        result = process_jira_tickets(tickets)
        
        # Lines 145-148: Return success response
        return {
            "status": "success",
            "tickets_processed": result["tickets_processed"]
        }
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error processing Jira tickets: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Lines 158-174: RCA analysis endpoint
@app.post("/api/rca/analyze")
async def run_rca_analysis():
    try:
        # Line 161: Log RCA analysis start
        logger.info("Running RCA analysis")
        
        # Line 162: Perform AI-powered root cause analysis
        results = await analyze_tickets()
        
        # Lines 164-165: Consolidate similar issues
        logger.info("Consolidating issues")
        consolidated = consolidate_issues(results)
        
        # Lines 167-171: Return comprehensive analysis results
        return {
            "status": "success",
            "tickets": results,
            "consolidation": consolidated
        }
    except Exception as e:
        logger.error(f"Error running RCA: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# Lines 176-178: Health check endpoint
@app.get("/api/health")
async def health_check():
    return {"status": "healthy"}
```

**Internal Working**:
- Initializes FastAPI application with CORS support
- Provides global endpoints for non-project-specific operations
- Handles multiprocess warnings for Python 3.12+ compatibility
- Each endpoint includes comprehensive error handling and logging
- Follows RESTful API design principles

### 3. Database Models (`app/database/models.py`)

**Purpose**: SQLAlchemy ORM models for data persistence

**Line-by-Line Analysis**:
```python
# Lines 1-5: Import SQLAlchemy components
from sqlalchemy import create_engine, Column, Integer, String, Text, Float, JSON, DateTime
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from app.config import settings

# Line 7: Create declarative base for ORM models
Base = declarative_base()

# Lines 9-26: CodeMetadata model for storing parsed code information
class CodeMetadata(Base):
    __tablename__ = "code_metadata"              # Database table name
    
    # Primary key and indexing
    id = Column(Integer, primary_key=True, index=True)
    file_path = Column(String, index=True)       # File path with index for fast lookup
    
    # Code structure information
    node_type = Column(String)                   # Type: 'class', 'function', 'method'
    class_name = Column(String, nullable=True)  # Class name if applicable
    method_name = Column(String, index=True)     # Method/function name with index
    
    # Location information
    start_line = Column(Integer)                 # Starting line number
    end_line = Column(Integer)                   # Ending line number
    
    # Code content and analysis
    raw_code = Column(Text)                      # Actual code content (limited size)
    cst_tree = Column(JSON)                      # Concrete Syntax Tree representation
    dependencies = Column(JSON)                  # List of function calls/dependencies
    related_business_rules = Column(JSON)        # Links to business rules
    
    # Enhanced analysis data
    enrichment = Column(JSON, nullable=True)     # Additional extracted metadata
    enhanced_description = Column(Text, nullable=True)  # AI-generated description
    
    # Vector embedding reference
    embedding_id = Column(Integer)               # Reference to vector embedding
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)

# Lines 28-38: BusinessRule model for storing extracted business rules
class BusinessRule(Base):
    __tablename__ = "business_rules"
    
    # Primary key and identification
    id = Column(Integer, primary_key=True, index=True)
    rule_text = Column(Text)                      # The actual business rule text
    source_document = Column(String)              # Document where rule was found
    
    # Categorization
    category = Column(String)                     # Rule category (validation, security, etc.)
    section = Column(String, nullable=True)      # Document section context
    
    # Relationships
    related_code_blocks = Column(JSON, nullable=True)  # Links to code blocks
    
    # Vector embedding reference
    embedding_id = Column(Integer)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)

# Lines 40-47: DependencyGraph model for tracking code dependencies
class DependencyGraph(Base):
    __tablename__ = "dependency_graph"
    
    # Primary key
    id = Column(Integer, primary_key=True, index=True)
    
    # Dependency relationship
    source_file = Column(String)                  # File that has dependency
    target_file = Column(String)                  # File being depended on
    dependency_type = Column(String)              # Type of dependency
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)

# Lines 49-59: Ticket model for storing Jira ticket information
class Ticket(Base):
    __tablename__ = "tickets"
    
    # Primary key and identification
    id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(String, unique=True, index=True)  # Unique ticket identifier
    summary = Column(String)                      # Ticket summary/title
    description = Column(Text)                    # Detailed ticket description
    
    # Classification
    priority = Column(String)                      # Ticket priority (High, Medium, Low)
    module = Column(String)                       # Affected software module
    
    # Vector embedding reference
    embedding_id = Column(Integer)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)

# Lines 61-75: RCAResult model for storing root cause analysis results
class RCAResult(Base):
    __tablename__ = "rca_results"
    
    # Primary key and reference
    id = Column(Integer, primary_key=True, index=True)
    ticket_id = Column(String, index=True)        # Reference to original ticket
    
    # Analysis results
    root_cause_type = Column(String)              # Type of root cause
    impacted_file = Column(String)                 # File containing the issue
    impacted_method = Column(String)              # Method/function with issue
    code_pointer = Column(String)                 # Specific location (file:lines)
    
    # Detailed analysis
    current_logic = Column(Text)                  # What the code currently does
    business_expected_logic = Column(Text)        # What business rules expect
    resolution_logic = Column(Text)               # How to fix the issue
    fix_type = Column(String)                     # Type of fix required
    
    # Confidence metrics
    confidence_score = Column(Float)              # AI confidence in analysis (0.0-1.0)
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)

# Lines 77-78: Database engine and session setup
engine = create_engine(settings.database_url, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Lines 80-81: Database initialization function
def init_db():
    Base.metadata.create_all(bind=engine)          # Create all tables

# Lines 83-88: Database session dependency
def get_db():
    db = SessionLocal()                           # Create new session
    try:
        yield db                                  # Provide session to caller
    finally:
        db.close()                                # Ensure session is closed
```

**Internal Working**:
- Defines the complete data schema for the application
- Uses SQLAlchemy ORM for database operations
- Includes proper indexing for performance optimization
- Supports JSON fields for flexible data storage
- Each model includes created_at timestamps for auditing

### 4. GitHub Repository Cloning (`app/github/clone.py`)

**Purpose**: Handle GitHub repository cloning and local folder processing

**Line-by-Line Analysis**:
```python
# Lines 1-8: Import required libraries
import git                                       # GitPython for Git operations
import os                                        # Operating system interface
import shutil                                    # File system operations
from urllib.parse import urlparse               # URL parsing utilities
import logging
from app.config import settings

# Line 8: Create logger
logger = logging.getLogger(__name__)

# Lines 10-15: GitHub URL detection function
def is_github_url(path: str) -> bool:
    """Check if the path is a GitHub URL"""
    if not path:
        return False
    path = path.strip()
    # Check for common URL patterns and Git SSH URLs
    return path.startswith('http://') or path.startswith('https://') or path.startswith('git@')

# Lines 17-97: Main repository cloning function
def clone_repository(repo_url_or_path: str, project_name: str = None) -> str:
    """
    Clone a GitHub repository or use a local folder path
    
    Args:
        repo_url_or_path: Either a GitHub URL or a local folder path
        project_name: Optional project name for project-specific storage
        
    Returns:
        Path to the repository (cloned or local)
    """
    # Lines 28-34: Input validation
    if not repo_url_or_path:
        raise ValueError("Repository URL or path cannot be empty")
    
    repo_url_or_path = repo_url_or_path.strip()
    
    if not repo_url_or_path:
        raise ValueError("Repository URL or path cannot be empty")
    
    # Lines 36-44: Local path handling
    if not is_github_url(repo_url_or_path):
        local_path = os.path.abspath(repo_url_or_path)
        if os.path.exists(local_path) and os.path.isdir(local_path):
            logger.info(f"Using local folder: {local_path}")
            cleanup_repository(local_path)        # Clean unnecessary directories
            return local_path
        else:
            raise ValueError(f"Local path does not exist or is not a directory: {local_path}")
    
    # Lines 46-74: GitHub URL cloning
    try:
        # Line 48: Parse URL to extract repository name
        parsed = urlparse(repo_url_or_path)
        repo_name = os.path.basename(parsed.path).replace('.git', '')
        
        # Lines 51-52: Validate repository name extraction
        if not repo_name:
            raise ValueError("Invalid GitHub URL: cannot extract repository name")
        
        # Lines 54-59: Determine clone directory based on project context
        if project_name:
            from app.project_manager import project_manager
            clone_base_dir = project_manager.get_project_repos_dir(project_name)
        else:
            clone_base_dir = settings.clone_dir
        
        # Lines 61-64: Create unique repository path with timestamp
        import time
        timestamp = int(time.time())
        repo_path = os.path.join(clone_base_dir, f"{repo_name}_{timestamp}")
        
        # Line 66: Ensure clone directory exists
        os.makedirs(clone_base_dir, exist_ok=True)
        
        # Lines 68-70: Log and perform cloning
        log_prefix = f"[{project_name}] " if project_name else ""
        logger.info(f"{log_prefix}Cloning {repo_url_or_path} to {repo_path}")
        git.Repo.clone_from(repo_url_or_path, repo_path)
        
        # Line 72: Clean cloned repository
        cleanup_repository(repo_path)
        
        # Line 74: Return repository path
        return repo_path
    
    # Lines 75-77: Error handling for Git operations
    except git.exc.GitCommandError as e:
        logger.error(f"Git clone error: {str(e)}")
        raise ValueError(f"Failed to clone repository: {str(e)}")

# Lines 79-97: Repository cleanup function
def cleanup_repository(repo_path: str):
    """Remove unnecessary directories from repository"""
    # Lines 80-83: Input validation
    if not repo_path or not os.path.exists(repo_path):
        logger.warning(f"Cannot cleanup: invalid path {repo_path}")
        return
    
    # Lines 85-86: Define directories to exclude
    exclude_dirs = ['node_modules', '.git', 'venv', 'dist', 'build', '__pycache__']
    
    # Lines 87-88: Walk directory tree and exclude directories
    for root, dirs, files in os.walk(repo_path, topdown=True):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
    
    # Lines 90-97: Remove excluded directories
    for exclude_dir in exclude_dirs:
        exclude_path = os.path.join(repo_path, exclude_dir)
        if os.path.exists(exclude_path):
            try:
                shutil.rmtree(exclude_path)        # Remove directory and contents
                logger.info(f"Removed {exclude_dir}")
            except Exception as e:
                logger.warning(f"Could not remove {exclude_dir}: {str(e)}")
```

**Internal Working**:
- Supports both GitHub URLs and local folder paths
- Creates timestamped directories to avoid conflicts
- Automatically cleans up unnecessary directories (node_modules, .git, etc.)
- Handles project-specific storage when project_name is provided
- Provides comprehensive error handling and logging

### 5. Parser Orchestrator (`app/parsers/orchestrator.py`)

**Purpose**: Coordinate code parsing across multiple languages and file types

**Line-by-Line Analysis**:
```python
# Lines 1-14: Import required modules
import os
from typing import Dict, Any
from concurrent.futures import ThreadPoolExecutor, as_completed  # Parallel processing
import logging
from app.parsers.python_parser import PythonParser
from app.parsers.js_parser import JSParser
from app.parsers.universal_parser import UniversalParser, LANGUAGE_CONFIG
from app.parsers.enhanced_extractor import EnhancedExtractor
from app.database.project_db import project_db
from app.database.models import CodeMetadata
from app.project_manager import project_manager
from app.config import settings

# Line 14: Create logger
logger = logging.getLogger(__name__)

# Lines 16-37: ParserOrchestrator class
class ParserOrchestrator:
    def __init__(self, project_name: str = None, use_universal: bool = None):
        # Lines 17-19: Initialize instance variables
        self.project_name = project_name
        self.use_universal = use_universal if use_universal is not None else settings.use_universal_parser
        
        # Lines 21-26: Initialize universal parser if enabled
        if self.use_universal:
            self.universal_parser = UniversalParser()
            self.supported_extensions = LANGUAGE_CONFIG
            logger.info(f"[{self.project_name or 'global'}] Using Universal Parser - {len(LANGUAGE_CONFIG)} languages supported")
        else:
            # Lines 27-37: Initialize legacy parsers for backward compatibility
            self.python_parser = PythonParser()
            self.js_parser = JSParser()
            self.supported_extensions = {
                '.py': 'python',
                '.js': 'javascript',
                '.jsx': 'javascript',
                '.ts': 'typescript',
                '.tsx': 'typescript'
            }
            logger.info(f"[{self.project_name or 'global'}] Using Legacy Parsers")

# Lines 39-102: Repository parsing method
    def parse_repository(self, repo_path: str) -> Dict[str, Any]:
        files_to_parse = []
        
        # Lines 42-48: Collect all code files from repository
        for root, dirs, files in os.walk(repo_path):
            # Skip common non-code directories
            dirs[:] = [d for d in dirs if d not in {
                'node_modules', '.git', '__pycache__', 'venv', 'env',
                '.venv', 'build', 'dist', 'target', '.idea', '.vscode'
            }]
            
            # Lines 50-66: Process each file
            for file in files:
                ext = os.path.splitext(file)[1].lower()
                
                if self.use_universal:
                    # Universal parser: accept all known extensions + try unknown ones
                    if ext in self.supported_extensions or self._is_text_file(file):
                        file_path = os.path.join(root, file)
                        # Skip very large files
                        try:
                            if os.path.getsize(file_path) < 5 * 1024 * 1024:  # 5MB limit
                                files_to_parse.append(file_path)
                        except:
                            pass
                else:
                    # Legacy: only supported extensions
                    if ext in self.supported_extensions:
                        files_to_parse.append(os.path.join(root, file))
        
        # Line 68: Log file discovery
        logger.info(f"[{self.project_name or 'global'}] Found {len(files_to_parse)} files to parse")
        
        # Line 70: Initialize results dictionary
        results = {"total_files": 0, "languages": {}, "skipped": 0}
        
        # Lines 72-74: Configure parallel processing
        max_workers = min(settings.max_workers, (os.cpu_count() or 4))
        
        # Lines 75-102: Parallel file processing
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all files for parallel processing
            futures = {executor.submit(self.parse_file, fp): fp for fp in files_to_parse}
            
            # Process completed files
            for future in as_completed(futures):
                file_path = futures[future]
                try:
                    code_blocks = future.result()
                    if code_blocks:
                        self.save_to_db(code_blocks)  # Save to database
                        results["total_files"] += 1
                        
                        # Track language statistics
                        ext = os.path.splitext(file_path)[1].lower()
                        if self.use_universal and ext in self.supported_extensions:
                            lang = self.supported_extensions[ext]['name']
                        elif not self.use_universal and ext in self.supported_extensions:
                            lang = self.supported_extensions[ext]
                        else:
                            lang = 'other'
                        
                        results["languages"][lang] = results["languages"].get(lang, 0) + 1
                    else:
                        results["skipped"] += 1
                except Exception as e:
                    logger.error(f"Error processing {file_path}: {str(e)}")
                    results["skipped"] += 1
        
        # Line 101: Log completion
        logger.info(f"[{self.project_name or 'global'}] Parsed {results['total_files']} files, skipped {results['skipped']}")
        return results

# Lines 104-112: Text file detection helper
    def _is_text_file(self, filename: str) -> bool:
        """Check if file is likely a text/code file"""
        text_extensions = {
            '.txt', '.md', '.rst', '.yaml', '.yml', '.json', '.xml',
            '.html', '.css', '.scss', '.sass', '.less', '.sql',
            '.sh', '.bash', '.zsh', '.fish', '.ps1', '.bat', '.cmd'
        }
        ext = os.path.splitext(filename)[1].lower()
        return ext in text_extensions

# Lines 114-165: Single file parsing method
    def parse_file(self, file_path: str):
        """Parse a single file using appropriate parser with enrichment"""
        ext = os.path.splitext(file_path)[1].lower()
        
        # Lines 118-123: Read file content
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except Exception as e:
            logger.error(f"Error reading {file_path}: {e}")
            return []
        
        # Lines 125-127: Skip empty files
        if not content.strip():
            return []
        
        # Lines 129-142: Parse based on parser type
        code_blocks = []
        if self.use_universal:
            # Use universal parser for all languages
            code_blocks = self.universal_parser.parse_file(file_path, content)
        else:
            # Legacy parser logic
            if ext == '.py':
                code_blocks = self.python_parser.parse_file(file_path, content)
            elif ext in ['.js', '.jsx']:
                code_blocks = self.js_parser.parse_file(file_path, content, is_typescript=False)
            elif ext in ['.ts', '.tsx']:
                code_blocks = self.js_parser.parse_file(file_path, content, is_typescript=True)
        
        # Lines 143-165: Enrich code blocks with enhanced extraction
        if code_blocks:
            # Determine language for enrichment
            if self.use_universal and ext in self.supported_extensions:
                language = self.supported_extensions[ext]['name']
            elif not self.use_universal and ext in self.supported_extensions:
                language = self.supported_extensions[ext]
            else:
                language = 'unknown'
            
            # Enrich each code block
            enriched_blocks = []
            for block in code_blocks:
                try:
                    enriched_block = EnhancedExtractor.enrich_code_block(block, language)
                    enriched_blocks.append(enriched_block)
                except Exception as e:
                    logger.warning(f"Failed to enrich block in {file_path}: {e}")
                    enriched_blocks.append(block)  # Use original if enrichment fails
            
            return enriched_blocks
        
        return []

# Lines 167-194: Database saving method
    def save_to_db(self, code_blocks):
        """Save code blocks to database with batch optimization"""
        if not code_blocks:
            return
        
        # Lines 172-176: Get appropriate database session
        if self.project_name:
            db = project_db.get_session(self.project_name)
        else:
            from app.database.models import SessionLocal
            db = SessionLocal()
        
        try:
            # Lines 179-181: Batch insert for better performance
            db.bulk_insert_mappings(CodeMetadata, code_blocks)
            db.commit()
        except Exception as e:
            # Lines 183-192: Fallback to individual inserts if batch fails
            logger.error(f"Batch insert failed, falling back to individual inserts: {e}")
            db.rollback()
            for block in code_blocks:
                try:
                    metadata = CodeMetadata(**block)
                    db.add(metadata)
                except Exception as block_error:
                    logger.error(f"Error inserting block: {block_error}")
            db.commit()
        finally:
            db.close()

# Lines 196-198: Convenience function
def parse_repository(repo_path: str, project_name: str = None) -> Dict[str, Any]:
    orchestrator = ParserOrchestrator(project_name)
    return orchestrator.parse_repository(repo_path)
```

**Internal Working**:
- Supports both universal parser (40+ languages) and legacy parsers
- Uses parallel processing for efficient file parsing
- Automatically detects file types and selects appropriate parser
- Includes enhanced extraction for better code analysis
- Handles project-specific database storage
- Provides comprehensive error handling and fallback mechanisms

---

## File-by-File Analysis

### Backend Core Files

#### `app/business_docs/processor.py`
**Purpose**: Process business documents and extract rules using pattern recognition

**Key Components**:
- **Document Text Extraction** (Lines 46-85): Supports PDF, DOCX, TXT, MD formats
- **Enhanced Rule Extraction** (Lines 87-146): Uses multiple regex patterns for rule identification
- **Section-based Processing** (Lines 148-177): Splits documents into logical sections
- **Rule Categorization** (Lines 179-197): Categorizes rules by type (validation, security, etc.)
- **Deduplication** (Lines 137-145): Removes duplicate rules using normalization

**Internal Flow**:
1. Extract text from uploaded documents
2. Split into sections based on headers
3. Apply pattern matching for rule identification
4. Categorize rules based on section context
5. Deduplicate and save to database

#### `app/context_engine/builder.py`
**Purpose**: Build unified vector context from code and business rules

**Key Components**:
- **Vector Generation** (Lines 22-24): Creates embeddings for code blocks
- **FAISS Index Building** (Lines 18-19): Builds vector search indices
- **Metadata Management** (Lines 26-33): Stores searchable metadata
- **Database Updates** (Lines 38-40, 56-58): Updates embedding references

**Internal Flow**:
1. Retrieve all code blocks and business rules from database
2. Generate text representations for embedding
3. Create vector embeddings using sentence transformers
4. Build FAISS indices for fast similarity search
5. Update database with embedding references

#### `app/jira/processor.py`
**Purpose**: Process Jira tickets and generate embeddings for analysis

**Key Components**:
- **Ticket Normalization** (Lines 22-69): Standardizes ticket data formats
- **Enhanced Description Building** (Lines 34-53): Combines multiple ticket fields
- **Priority Mapping** (Lines 55-63): Maps severity to priority
- **Embedding Generation** (Lines 90-92): Creates vector representations

**Internal Flow**:
1. Validate and normalize ticket data
2. Build comprehensive descriptions from all fields
3. Generate embeddings for semantic search
4. Store in database with metadata
5. Create vector indices for fast retrieval

#### `app/rca_engine/analyzer.py`
**Purpose**: Perform AI-powered root cause analysis

**Key Components**:
- **Enhanced Context Retrieval** (Lines 77-116): Multi-strategy vector search
- **Advanced Analysis** (Lines 54-67): Uses advanced analyzer with confidence boosting
- **AI Prompt Engineering** (Lines 165-218): Structured prompts for accurate analysis
- **Result Validation** (Lines 241-251): Ensures referenced files exist in context

**Internal Flow**:
1. Retrieve relevant code and business rules using vector search
2. Build enriched context with similarity scores
3. Generate structured AI prompts with detailed instructions
4. Call Azure OpenAI for analysis
5. Validate and parse results
6. Save to database with confidence scores

#### `app/consolidation/engine.py`
**Purpose**: Consolidate similar issues using clustering

**Key Components**:
- **Embedding Generation** (Lines 13-14): Creates embeddings for resolution texts
- **DBSCAN Clustering** (Lines 16-17): Groups similar issues
- **Cluster Analysis** (Lines 22-38): Identifies common root causes

**Internal Flow**:
1. Generate embeddings for resolution logic
2. Apply DBSCAN clustering algorithm
3. Analyze clusters to find common patterns
4. Return consolidated issue groups

### Supporting Services

#### `app/embeddings/generator.py`
**Purpose**: Generate vector embeddings with optimization

**Key Components**:
- **GPU Acceleration** (Lines 23-28): Uses CUDA if available
- **Model Optimization** (Lines 37-39): Mixed precision for speed
- **Caching System** (Lines 43-46): Caches frequently used embeddings
- **Batch Processing** (Lines 66-72): Optimized batch sizes for GPU/CPU

**Internal Flow**:
1. Load sentence transformer model with optimizations
2. Check cache for existing embeddings
3. Generate new embeddings for uncached texts
4. Update cache with new embeddings
5. Return combined results

#### `app/vector_store/faiss_store.py`
**Purpose**: Manage FAISS vector indices for fast similarity search

**Key Components**:
- **Index Management** (Lines 20-24): Creates or loads FAISS indices
- **Vector Addition** (Lines 26-34): Adds normalized vectors to index
- **Similarity Search** (Lines 36-47): Performs fast vector search
- **Persistence** (Lines 49-59): Saves and loads indices to disk

**Internal Flow**:
1. Initialize FAISS index with proper dimensions
2. Normalize and add vectors to index
3. Store corresponding metadata
4. Perform similarity searches with query vectors
5. Return ranked results with similarity scores

#### `app/services/azure_openai_client.py`
**Purpose**: Interface with Azure OpenAI API

**Key Components**:
- **Model Detection** (Lines 18-31): Identifies model capabilities
- **Parameter Adaptation** (Lines 42-53): Adjusts parameters per model
- **Retry Logic** (Lines 33-59): Implements exponential backoff

**Internal Flow**:
1. Detect model type and capabilities
2. Adapt parameters based on model requirements
3. Make API calls with retry logic
4. Handle errors and return responses

### Project Management

#### `app/project_manager.py`
**Purpose**: Manage project-based isolation and context

**Key Components**:
- **Project Creation** (Lines 75-93): Creates isolated project environments
- **Directory Management** (Lines 129-147): Manages project-specific directories
- **Metadata Tracking** (Lines 117-127): Tracks project progress and statistics
- **Cleanup Operations** (Lines 149-167): Handles project deletion

**Internal Flow**:
1. Create project directory structure
2. Initialize project metadata
3. Track processing progress
4. Manage isolated storage
5. Handle project lifecycle operations

### Universal Parser

#### `app/parsers/universal_parser.py`
**Purpose**: Parse 40+ programming languages using tree-sitter and regex

**Key Components**:
- **Language Detection** (Lines 52-131): Maps file extensions to languages
- **Tree-sitter Integration** (Lines 166-227): Uses AST parsing for accuracy
- **Regex Fallback** (Lines 282-335): Handles unsupported languages
- **Pattern Matching** (Lines 337-399): Language-specific regex patterns

**Internal Flow**:
1. Detect language from file extension
2. Try tree-sitter parsing if available
3. Fall back to regex-based parsing
4. Extract code structures (classes, functions)
5. Generate metadata with dependencies

### Frontend Interface

#### `frontend/app.py`
**Purpose**: Streamlit interface for user interaction

**Key Components**:
- **Tabbed Interface** (Lines 13-19): Organized workflow sections
- **GitHub Integration** (Lines 21-78): Repository ingestion interface
- **Document Upload** (Lines 80-100): Business document processing
- **API Communication** (Lines 44-76): Backend integration

**Internal Flow**:
1. Create tabbed interface for workflow steps
2. Handle user inputs and file uploads
3. Communicate with backend API
4. Display results and progress
5. Provide error handling and feedback

---

## Data Flow

### Complete Workflow

```
1. Repository Ingestion
   ├── GitHub URL/Local Path → clone_repository()
   ├── Repository Cleanup → cleanup_repository()
   └── Code Parsing → parse_repository()

2. Document Processing
   ├── File Upload → process_business_docs()
   ├── Text Extraction → extract_text()
   ├── Rule Extraction → extract_business_rules_enhanced()
   └── Database Storage → save_business_rules()

3. Context Building
   ├── Data Retrieval → CodeMetadata & BusinessRule queries
   ├── Embedding Generation → embedding_generator.generate_embeddings()
   ├── Vector Index Building → FAISSStore.add_vectors()
   └── Database Updates → embedding_id references

4. Ticket Processing
   ├── Ticket Upload → process_jira_tickets()
   ├── Data Normalization → Field mapping and enhancement
   ├── Embedding Generation → Ticket vector representations
   └── Storage → Ticket database + vector store

5. RCA Analysis
   ├── Context Retrieval → Enhanced vector search
   ├── AI Analysis → Azure OpenAI API calls
   ├── Result Processing → Response parsing and validation
   └── Storage → RCAResult database records

6. Issue Consolidation
   ├── Embedding Generation → Resolution logic vectors
   ├── Clustering → DBSCAN algorithm
   ├── Analysis → Common pattern identification
   └── Reporting → Consolidated issue groups
```

### Data Transformations

```
Raw Code Files → Parser Orchestrator → CodeMetadata Records
                    ↓
                Universal Parser → AST/Regex Parsing → Code Blocks
                    ↓
                Enhanced Extractor → Enriched Metadata → Database

Business Documents → Document Processor → Text Extraction
                    ↓
                Rule Extractor → Pattern Matching → Business Rules
                    ↓
                Categorizer → Section Analysis → Database

Jira Tickets → Ticket Processor → Normalization
                    ↓
                Embedding Generator → Vector Representations
                    ↓
                Vector Store → Semantic Search Index

All Data → Context Builder → Unified Embeddings
                    ↓
                FAISS Store → Search Indices
                    ↓
                RCA Engine → AI Analysis → Results
```

---

## Configuration

### Environment Variables (.env)

```bash
# Azure OpenAI Configuration
AZURE_OPENAI_ENDPOINT=https://your-resource.openai.azure.com/
AZURE_OPENAI_API_KEY=your-api-key
AZURE_OPENAI_DEPLOYMENT=gpt-4
AZURE_OPENAI_API_VERSION=2024-02-15-preview

# Database Configuration
DATABASE_URL=sqlite:///./debugger.db

# Directory Paths
CLONE_DIR=./cloned_repos
DOCS_DIR=./uploaded_docs
FAISS_INDEX_DIR=./faiss_index

# Processing Parameters
MAX_FILE_SIZE_MB=50
BATCH_SIZE=32
TOP_K_RETRIEVAL=10
SIMILARITY_THRESHOLD=0.7

# Parser Configuration
USE_UNIVERSAL_PARSER=true
MAX_WORKERS=8
SKIP_LARGE_FILES=true

# AI Parameters
TEMPERATURE=0.2
MAX_TOKENS=4000
```

### Configuration Impact

- **Embedding Model**: Affects vector quality and processing speed
- **Batch Size**: Influences memory usage and processing efficiency
- **Similarity Threshold**: Controls search result relevance
- **Max Workers**: Determines parallel processing capacity
- **Temperature**: Affects AI response creativity vs. consistency

---

## API Endpoints

### Global Endpoints (app/main.py)

| Endpoint | Method | Purpose | Input | Output |
|----------|--------|---------|-------|--------|
| `/` | GET | Health check | None | API status |
| `/api/ingest/github` | POST | Ingest repository | repo_url_or_path | Parse results |
| `/api/ingest/business-docs` | POST | Process documents | Files | Rule count |
| `/api/context/build` | POST | Build context | None | Embedding stats |
| `/api/jira/process` | POST | Process tickets | Ticket list | Process count |
| `/api/rca/analyze` | POST | Run RCA | None | Analysis results |
| `/api/health` | GET | Health check | None | Status |

### Project Endpoints (app/api/projects.py)

| Endpoint | Method | Purpose | Input | Output |
|----------|--------|---------|-------|--------|
| `/api/projects/create` | POST | Create project | Project data | Project info |
| `/api/projects/list` | GET | List projects | None | Project list |
| `/api/projects/{name}` | GET | Get project | Project name | Project details |
| `/api/projects/{name}/ingest/github` | POST | Ingest to project | Repo data | Parse results |
| `/api/projects/{name}/ingest/business-docs` | POST | Process docs | Files | Rule count |
| `/api/projects/{name}/context/build` | POST | Build context | None | Embedding stats |
| `/api/projects/{name}/jira/process` | POST | Process tickets | Tickets | Process count |
| `/api/projects/{name}/tickets/list` | GET | List tickets | Project name | Ticket list |
| `/api/projects/{name}/rca/analyze` | POST | Run RCA | Optional IDs | Analysis results |
| `/api/projects/{name}` | DELETE | Delete project | Project name | Status |

---

## Frontend Interface

### Streamlit Application (frontend/app.py)

**Tab Structure**:
1. **GitHub Ingestion**: Repository cloning and parsing
2. **Business Docs**: Document upload and processing
3. **Build Context**: Vector index creation
4. **Jira Tickets**: Ticket processing interface
5. **RCA Analysis**: Analysis execution and results

**Key Features**:
- **Progress Tracking**: Real-time processing feedback
- **Error Handling**: User-friendly error messages
- **Data Visualization**: Results in tables and charts
- **File Management**: Multi-file upload support
- **API Integration**: Seamless backend communication

**User Workflow**:
```
1. User selects tab
2. Provides input (URL, files, etc.)
3. Clicks process button
4. Sees progress indicator
5. Views results and statistics
6. Can proceed to next step
```

---

## Database Schema

### Tables and Relationships

```
CodeMetadata
├── id (PK)
├── file_path (indexed)
├── node_type
├── class_name
├── method_name (indexed)
├── start_line
├── end_line
├── raw_code
├── cst_tree (JSON)
├── dependencies (JSON)
├── related_business_rules (JSON)
├── enrichment (JSON)
├── enhanced_description
├── embedding_id
└── created_at

BusinessRule
├── id (PK)
├── rule_text
├── source_document
├── category
├── section
├── related_code_blocks (JSON)
├── embedding_id
└── created_at

Ticket
├── id (PK)
├── ticket_id (unique, indexed)
├── summary
├── description
├── priority
├── module
├── embedding_id
└── created_at

RCAResult
├── id (PK)
├── ticket_id (indexed)
├── root_cause_type
├── impacted_file
├── impacted_method
├── code_pointer
├── current_logic
├── business_expected_logic
├── resolution_logic
├── fix_type
├── confidence_score
└── created_at

DependencyGraph
├── id (PK)
├── source_file
├── target_file
├── dependency_type
└── created_at
```

### Indexing Strategy

- **Primary Keys**: All tables have auto-incrementing primary keys
- **Search Indexes**: file_path, method_name, ticket_id for fast lookups
- **Foreign Key References**: embedding_id links to vector store
- **JSON Fields**: Flexible storage for complex data structures

---

## Deployment

### Requirements

```txt
fastapi>=0.109.0
uvicorn>=0.27.0
streamlit>=1.31.0
openai>=1.12.0
sentence-transformers>=2.3.1
faiss-cpu>=1.7.4
libcst>=1.1.0
tree-sitter>=0.20.4
gitpython>=3.1.41
PyPDF2>=3.0.1
python-docx>=1.1.0
sqlalchemy>=2.0.25
pydantic>=2.6.0
pydantic-settings>=2.1.0
numpy>=1.24.0
pandas>=2.0.0
scikit-learn>=1.3.0
python-multipart>=0.0.6
aiofiles>=23.0.0
httpx>=0.25.0
tenacity>=8.2.0
```

### Setup Instructions

1. **Environment Setup**:
   ```bash
   python -m venv venv
   source venv/bin/activate  # Linux/Mac
   # or
   venv\Scripts\activate     # Windows
   pip install -r requirements.txt
   ```

2. **Configuration**:
   ```bash
   cp .env.example .env
   # Edit .env with your Azure OpenAI credentials
   ```

3. **Database Initialization**:
   ```bash
   python -c "from app.database.models import init_db; init_db()"
   ```

4. **Start Backend**:
   ```bash
   python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
   # or use run_backend.bat
   ```

5. **Start Frontend**:
   ```bash
   streamlit run frontend/app.py
   # or use run_frontend.bat
   ```

### Production Considerations

- **Security**: Configure CORS origins for production
- **Scaling**: Use GPU acceleration for embeddings
- **Database**: Consider PostgreSQL for large deployments
- **Monitoring**: Add logging and monitoring
- **Authentication**: Implement user authentication
- **Rate Limiting**: Add API rate limiting

---

## Conclusion

The Agentic Smart Debugger represents a comprehensive approach to automated root cause analysis in software development. By combining:

- **Multi-language code parsing** with universal parser support
- **Business rule extraction** from documentation
- **AI-powered analysis** using Azure OpenAI
- **Vector-based semantic search** with FAISS
- **Project-based isolation** for enterprise use
- **Streamlined user interface** with Streamlit

The system provides enterprise-grade debugging intelligence that can significantly reduce the time and effort required for root cause analysis while maintaining accuracy and providing actionable insights.

The modular architecture allows for easy extension and customization, while the comprehensive error handling and logging ensure reliable operation in production environments.
