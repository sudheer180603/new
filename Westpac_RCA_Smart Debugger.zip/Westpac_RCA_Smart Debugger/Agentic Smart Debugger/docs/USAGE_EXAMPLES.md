# Usage Examples

## Example 1: Analyzing a Flask Application

### Step 1: Ingest Repository
```
Repository URL: https://github.com/pallets/flask
```

### Step 2: Upload Business Documentation
Upload files containing:
- API endpoint specifications
- Authentication requirements
- Error handling policies
- Performance requirements

### Step 3: Process Jira Tickets

```json
[
  {
    "ticket_id": "FLASK-001",
    "summary": "Authentication middleware not validating tokens correctly",
    "description": "JWT tokens are accepted even when expired. Security vulnerability.",
    "priority": "Critical",
    "module": "Authentication"
  },
  {
    "ticket_id": "FLASK-002",
    "summary": "Database connection pool exhaustion",
    "description": "Application crashes after 100 concurrent requests due to connection pool limits",
    "priority": "High",
    "module": "Database"
  }
]
```

### Expected RCA Output

```json
{
  "tickets": [
    {
      "ticket_id": "FLASK-001",
      "root_cause_type": "Code Defect",
      "impacted_file": "src/auth/middleware.py",
      "impacted_method": "AuthMiddleware.validate_token",
      "code_pointer": "src/auth/middleware.py:45-67",
      "current_logic": "Token validation checks signature but not expiration timestamp",
      "business_expected_logic": "Must validate both signature and expiration before accepting token",
      "resolution_logic": "Add expiration check: if token.exp < datetime.now(): raise TokenExpired()",
      "fix_type": "Logic fix",
      "confidence_score": 0.95
    }
  ]
}
```

## Example 2: React Application Analysis

### Jira Ticket
```json
[
  {
    "ticket_id": "REACT-101",
    "summary": "User profile page shows stale data",
    "description": "After updating profile, old data still displays until page refresh",
    "priority": "Medium",
    "module": "UserProfile"
  }
]
```

### Expected RCA
```json
{
  "ticket_id": "REACT-101",
  "root_cause_type": "Code Defect",
  "impacted_file": "src/components/UserProfile.jsx",
  "impacted_method": "UserProfile.handleUpdate",
  "code_pointer": "src/components/UserProfile.jsx:78-95",
  "current_logic": "Updates backend but doesn't refresh local state",
  "business_expected_logic": "UI should reflect changes immediately after successful update",
  "resolution_logic": "Add state update after API call: setUserData(response.data)",
  "fix_type": "Logic fix"
}
```

## Example 3: Multiple Related Issues

### Jira Tickets
```json
[
  {
    "ticket_id": "API-201",
    "summary": "GET /users endpoint returns 500 error",
    "description": "Internal server error when fetching user list",
    "priority": "High",
    "module": "UserAPI"
  },
  {
    "ticket_id": "API-202",
    "summary": "POST /users fails with database error",
    "description": "Cannot create new users, database constraint violation",
    "priority": "High",
    "module": "UserAPI"
  },
  {
    "ticket_id": "API-203",
    "summary": "User search returns empty results",
    "description": "Search functionality broken, always returns []",
    "priority": "Medium",
    "module": "UserAPI"
  }
]
```

### Expected Consolidation
```json
{
  "consolidation": [
    {
      "cluster_id": 0,
      "primary_ticket": "API-201",
      "related_tickets": ["API-202", "API-203"],
      "shared_root_cause": "Database",
      "impacted_files": [
        "src/api/users.py",
        "src/database/models.py"
      ],
      "ticket_count": 3
    }
  ]
}
```

## Example 4: Business Rule Violation

### Business Document Content
```
User Registration Requirements:
- Email must be unique in the system
- Password must be at least 8 characters
- Username must be alphanumeric only
- Account must be verified within 24 hours
```

### Jira Ticket
```json
{
  "ticket_id": "REG-301",
  "summary": "Users can register with duplicate emails",
  "description": "System allows multiple accounts with same email address",
  "priority": "Critical",
  "module": "Registration"
}
```

### Expected RCA
```json
{
  "ticket_id": "REG-301",
  "root_cause_type": "Functional Gap",
  "impacted_file": "src/auth/registration.py",
  "impacted_method": "RegistrationService.create_user",
  "code_pointer": "src/auth/registration.py:34-56",
  "current_logic": "Creates user without checking email uniqueness",
  "business_expected_logic": "Email must be unique in the system per business requirements",
  "resolution_logic": "Add uniqueness check: if User.query.filter_by(email=email).first(): raise EmailExists()",
  "fix_type": "Logic fix"
}
```

## Example 5: Performance Issue

### Jira Ticket
```json
{
  "ticket_id": "PERF-401",
  "summary": "Dashboard loads slowly with large datasets",
  "description": "Dashboard takes 30+ seconds to load when user has >1000 items",
  "priority": "High",
  "module": "Dashboard"
}
```

### Expected RCA
```json
{
  "ticket_id": "PERF-401",
  "root_cause_type": "Performance",
  "impacted_file": "src/api/dashboard.py",
  "impacted_method": "DashboardAPI.get_user_data",
  "code_pointer": "src/api/dashboard.py:89-112",
  "current_logic": "Loads all user items in single query without pagination",
  "business_expected_logic": "Dashboard should load quickly regardless of data volume",
  "resolution_logic": "Implement pagination: query.limit(50).offset(page*50) and lazy loading",
  "fix_type": "Performance optimization"
}
```

## API Usage Examples

### Using Browser
Simply open these URLs in your browser:
- Health check: http://localhost:8000/api/health
- API Documentation: http://localhost:8000/docs

### Using PowerShell

```powershell
# Health check
Invoke-WebRequest -Uri http://localhost:8000/api/health

# Ingest GitHub repository
Invoke-WebRequest -Uri "http://localhost:8000/api/ingest/github?repo_url=https://github.com/user/repo" -Method POST

# Process Jira tickets
$body = '[{"ticket_id":"TEST-001","summary":"Bug","description":"Issue","priority":"High","module":"Core"}]'
Invoke-WebRequest -Uri http://localhost:8000/api/jira/process -Method POST -Body $body -ContentType "application/json"

# Run RCA analysis
Invoke-WebRequest -Uri http://localhost:8000/api/rca/analyze -Method POST
```

### Using Python

```python
import requests

API_BASE = "http://localhost:8000"

# Ingest repository
response = requests.post(
    f"{API_BASE}/api/ingest/github",
    params={"repo_url": "https://github.com/user/repo"}
)
print(response.json())

# Process tickets
tickets = [
    {
        "ticket_id": "TEST-001",
        "summary": "Login fails",
        "description": "Users cannot login",
        "priority": "High",
        "module": "Auth"
    }
]
response = requests.post(f"{API_BASE}/api/jira/process", json=tickets)
print(response.json())

# Run RCA
response = requests.post(f"{API_BASE}/api/rca/analyze")
results = response.json()
print(results)
```

## Streamlit UI Workflow

1. Open browser to `http://localhost:8501`
2. Navigate to "GitHub Ingestion" tab
3. Enter repository URL: `https://github.com/user/repo`
4. Click "Clone & Parse Repository"
5. Wait for parsing to complete
6. Navigate to "Business Docs" tab
7. Upload PDF/DOCX files with requirements
8. Click "Process Documents"
9. Navigate to "Build Context" tab
10. Click "Build Context"
11. Navigate to "Jira Tickets" tab
12. Paste JSON ticket array
13. Click "Process Tickets"
14. Navigate to "RCA Analysis" tab
15. Click "Run RCA Analysis"
16. View results in table
17. Click "Download RCA Report" for JSON export

## Tips for Best Results

### 1. Business Documentation
- Include clear functional requirements
- Specify expected behaviors
- Document constraints and validations
- Provide API specifications

### 2. Jira Tickets
- Write clear, specific descriptions
- Include error messages if available
- Specify affected module/component
- Set appropriate priority

### 3. Repository Selection
- Ensure repository is accessible
- Remove large binary files if possible
- Include relevant documentation in repo

### 4. Context Building
- Process business docs before building context
- Allow time for embedding generation
- Larger repos take longer to process

### 5. RCA Analysis
- Review similarity threshold in config
- Check Azure OpenAI quota limits
- Verify temperature setting (0.2 recommended)
- Review top_k_retrieval setting
