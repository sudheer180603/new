@echo off
echo ========================================
echo Agentic Smart Debugger - Quick Start
echo ========================================
echo.

echo Step 1: Creating virtual environment...
python -m venv venv
if errorlevel 1 (
    echo Error creating virtual environment
    pause
    exit /b 1
)

echo Step 2: Activating virtual environment...
call venv\Scripts\activate

echo Step 3: Installing dependencies...
pip install -r requirements.txt
if errorlevel 1 (
    echo Error installing dependencies
    pause
    exit /b 1
)

echo Step 4: Creating required directories...
if not exist "cloned_repos" mkdir cloned_repos
if not exist "uploaded_docs" mkdir uploaded_docs
if not exist "faiss_index" mkdir faiss_index

echo.
echo ========================================
echo Setup Complete!
echo ========================================
echo.
echo Next steps:
echo 1. Configure Azure OpenAI in .env file
echo    copy .env.example .env
echo    notepad .env
echo.
echo 2. Run backend: run_backend.bat
echo 3. Run frontend: run_frontend.bat
echo.
echo For detailed instructions, see: docs\START_HERE.md
echo.
pause
