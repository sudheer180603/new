#!/usr/bin/env python3
"""
Insert Extended Test Data - Additional Critical and Medium Level Equipment
For Telecom Equipment Maintenance Scheduler Testing
"""

import sys
import os
from datetime import datetime, date, timedelta

# Add project path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    from utils.database_utils import db_manager
except ImportError as e:
    print(f"Error importing database utilities: {e}")
    sys.exit(1)

def insert_extended_test_data():
    """Insert additional equipment data with various maintenance levels and scenarios"""
    
    print("🚀 Starting Extended Test Data Insertion...")
    print("Adding more critical, medium, and low-risk equipment for comprehensive testing")
    
    try:
        # Test database connection
        if not db_manager.test_connection():
            print("❌ Database connection failed!")
            return False
        
        print("✅ Database connection successful")
        
        # 1. Insert More Critical Level Equipment
        print("\n🚨 Inserting Additional Critical Level Equipment...")
        
        critical_equipment_batch2 = [
            {
                'equipment_id': 'RT-CRIT-007',
                'equipment_type_id': 5,  # Router
                'location': 'Data Center Beta - Edge Room',
                'status': 'maintenance',
                'manufacturer': 'Juniper',
                'model': 'MX960',
                'firmware_version': '21.2R3',
                'installation_date': date(2020, 6, 20),
                'last_maintenance_date': date(2025, 9, 22)
            },
            {
                'equipment_id': 'BS-CRIT-008',
                'equipment_type_id': 2,  # Base Station
                'location': 'Tower Site 23 - East Zone',
                'status': 'failed',
                'manufacturer': 'Nokia',
                'model': 'AirScale Base Station',
                'firmware_version': '20.7.1',
                'installation_date': date(2021, 1, 12),
                'last_maintenance_date': date(2025, 9, 20)
            },
            {
                'equipment_id': 'OT-CRIT-009',
                'equipment_type_id': 4,  # Optical Transport
                'location': 'Metro Ring - Junction Point A',
                'status': 'maintenance',
                'manufacturer': 'Ciena',
                'model': '6500 Packet-Optical Platform',
                'firmware_version': '4.1.2',
                'installation_date': date(2019, 9, 15),
                'last_maintenance_date': date(2025, 9, 21)
            },
            {
                'equipment_id': 'SW-CRIT-010',
                'equipment_type_id': 3,  # Core Switch
                'location': 'Distribution Center - Core Network',
                'status': 'failed',
                'manufacturer': 'Arista',
                'model': '7368X-4',
                'firmware_version': '4.28.1F',
                'installation_date': date(2022, 3, 8),
                'last_maintenance_date': date(2025, 9, 19)
            }
        ]
        
        # 2. Insert More Medium Level Equipment
        print("\n⚠️ Inserting Additional Medium Level Equipment...")
        
        medium_equipment_batch2 = [
            {
                'equipment_id': 'AS-MED-011',
                'equipment_type_id': 1,  # Access Switch
                'location': 'Building D - Floor 2 MDF',
                'status': 'maintenance',
                'manufacturer': 'HPE',
                'model': 'Aruba 2930F-24G',
                'firmware_version': '16.10.0012',
                'installation_date': date(2021, 7, 30),
                'last_maintenance_date': date(2025, 9, 22)
            },
            {
                'equipment_id': 'RT-MED-012',
                'equipment_type_id': 5,  # Router
                'location': 'Branch Office - Regional Hub',
                'status': 'maintenance',
                'manufacturer': 'Cisco',
                'model': 'ISR4451',
                'firmware_version': '16.09.08',
                'installation_date': date(2020, 12, 15),
                'last_maintenance_date': date(2025, 9, 21)
            },
            {
                'equipment_id': 'OT-MED-013',
                'equipment_type_id': 4,  # Optical Transport
                'location': 'Fiber Node - Sector 12',
                'status': 'maintenance',
                'manufacturer': 'Infinera',
                'model': 'GX Series G30',
                'firmware_version': '19.6.0',
                'installation_date': date(2021, 4, 22),
                'last_maintenance_date': date(2025, 9, 23)
            },
            {
                'equipment_id': 'BS-MED-014',
                'equipment_type_id': 2,  # Base Station
                'location': 'Tower Site 31 - South Zone',
                'status': 'maintenance',
                'manufacturer': 'Samsung',
                'model': 'Compact Macro 5G',
                'firmware_version': '2.4.1',
                'installation_date': date(2022, 8, 10),
                'last_maintenance_date': date(2025, 9, 20)
            }
        ]
        
        # 3. Insert Some Active Equipment (Low Risk)
        print("\n✅ Inserting Low Risk Active Equipment...")
        
        active_equipment = [
            {
                'equipment_id': 'RT-ACT-015',
                'equipment_type_id': 5,  # Router
                'location': 'Data Center Gamma - Core',
                'status': 'active',
                'manufacturer': 'Cisco',
                'model': 'ASR9001',
                'firmware_version': '7.8.2',
                'installation_date': date(2023, 1, 15),
                'last_maintenance_date': date(2025, 8, 15)
            },
            {
                'equipment_id': 'AS-ACT-016',
                'equipment_type_id': 1,  # Access Switch
                'location': 'Building E - Floor 1 IDF',
                'status': 'active',
                'manufacturer': 'Juniper',
                'model': 'EX4300-48T',
                'firmware_version': '18.4R3',
                'installation_date': date(2023, 5, 20),
                'last_maintenance_date': date(2025, 7, 20)
            },
            {
                'equipment_id': 'BS-ACT-017',
                'equipment_type_id': 2,  # Base Station
                'location': 'Tower Site 45 - West Zone',
                'status': 'active',
                'manufacturer': 'Ericsson',
                'model': 'Radio 4402',
                'firmware_version': '21.Q1',
                'installation_date': date(2023, 2, 28),
                'last_maintenance_date': date(2025, 6, 28)
            }
        ]
        
        # Combine all equipment
        all_equipment = critical_equipment_batch2 + medium_equipment_batch2 + active_equipment
        
        # Insert all equipment
        for equipment in all_equipment:
            query = """
                INSERT INTO equipment (equipment_id, equipment_type_id, location, status, 
                                     manufacturer, model, firmware_version, installation_date, last_maintenance_date)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            values = (
                equipment['equipment_id'],
                equipment['equipment_type_id'],
                equipment['location'],
                equipment['status'],
                equipment['manufacturer'],
                equipment['model'],
                equipment['firmware_version'],
                equipment['installation_date'],
                equipment['last_maintenance_date']
            )
            
            db_manager.execute_query(query, values)
            print(f"  ✅ Inserted {equipment['equipment_id']} - {equipment['status'].upper()}")
        
        # 4. Get equipment IDs for health metrics
        print("\n❤️ Inserting Extended Health Metrics...")
        
        equipment_ids = {}
        for eq_id in ['RT-CRIT-007', 'BS-CRIT-008', 'OT-CRIT-009', 'SW-CRIT-010',
                     'AS-MED-011', 'RT-MED-012', 'OT-MED-013', 'BS-MED-014',
                     'RT-ACT-015', 'AS-ACT-016', 'BS-ACT-017']:
            query = "SELECT id FROM equipment WHERE equipment_id = %s"
            result = db_manager.execute_query(query, (eq_id,), fetch_one=True)
            if result:
                equipment_ids[eq_id] = result['id']
        
        # Define health metrics for different risk levels
        current_time = datetime.now()
        
        # Critical level health metrics (very poor performance)
        critical_health_metrics = [
            # RT-CRIT-007 - Router with severe packet loss
            {
                'equipment_id': equipment_ids.get('RT-CRIT-007'),
                'timestamp': current_time - timedelta(hours=1),
                'health_score': 0.08,
                'cpu_usage': 95.2,
                'memory_usage': 97.1,
                'temperature': 85.3,
                'power_consumption': 520.8,
                'uptime_hours': 1200,
                'packet_loss_rate': 0.25,
                'error_count': 289,
                'bandwidth_utilization': 95.8,
                'signal_strength': -48.5
            },
            # BS-CRIT-008 - Base station complete failure
            {
                'equipment_id': equipment_ids.get('BS-CRIT-008'),
                'timestamp': current_time - timedelta(minutes=30),
                'health_score': 0.02,
                'cpu_usage': 0.0,  # System down
                'memory_usage': 0.0,
                'temperature': 25.0,  # Ambient temp (powered off)
                'power_consumption': 0.0,
                'uptime_hours': 0,
                'packet_loss_rate': 1.0,  # Complete loss
                'error_count': 500,
                'bandwidth_utilization': 0.0,
                'signal_strength': -80.0  # No signal
            },
            # OT-CRIT-009 - Optical transport fiber cut
            {
                'equipment_id': equipment_ids.get('OT-CRIT-009'),
                'timestamp': current_time - timedelta(hours=2),
                'health_score': 0.11,
                'cpu_usage': 78.9,
                'memory_usage': 82.4,
                'temperature': 67.8,
                'power_consumption': 340.5,
                'uptime_hours': 3450,
                'packet_loss_rate': 0.18,
                'error_count': 234,
                'bandwidth_utilization': 45.2,  # Reduced due to fiber issues
                'signal_strength': -55.3
            },
            # SW-CRIT-010 - Switch fabric failure
            {
                'equipment_id': equipment_ids.get('SW-CRIT-010'),
                'timestamp': current_time - timedelta(minutes=45),
                'health_score': 0.06,
                'cpu_usage': 92.7,
                'memory_usage': 94.8,
                'temperature': 89.2,
                'power_consumption': 425.3,
                'uptime_hours': 890,
                'packet_loss_rate': 0.32,
                'error_count': 367,
                'bandwidth_utilization': 12.5,  # Very low due to failures
                'signal_strength': -38.9
            }
        ]
        
        # Medium level health metrics (degraded performance)
        medium_health_metrics = [
            # AS-MED-011 - Access switch port issues
            {
                'equipment_id': equipment_ids.get('AS-MED-011'),
                'timestamp': current_time - timedelta(hours=3),
                'health_score': 0.52,
                'cpu_usage': 72.3,
                'memory_usage': 68.9,
                'temperature': 61.2,
                'power_consumption': 195.4,
                'uptime_hours': 2340,
                'packet_loss_rate': 0.06,
                'error_count': 123,
                'bandwidth_utilization': 78.6,
                'signal_strength': -32.1
            },
            # RT-MED-012 - Router memory issues
            {
                'equipment_id': equipment_ids.get('RT-MED-012'),
                'timestamp': current_time - timedelta(hours=1, minutes=30),
                'health_score': 0.41,
                'cpu_usage': 76.8,
                'memory_usage': 84.5,
                'temperature': 58.7,
                'power_consumption': 235.7,
                'uptime_hours': 4560,
                'packet_loss_rate': 0.07,
                'error_count': 98,
                'bandwidth_utilization': 69.3,
                'signal_strength': -29.8
            },
            # OT-MED-013 - Optical signal degradation
            {
                'equipment_id': equipment_ids.get('OT-MED-013'),
                'timestamp': current_time - timedelta(hours=4),
                'health_score': 0.49,
                'cpu_usage': 63.2,
                'memory_usage': 71.8,
                'temperature': 54.6,
                'power_consumption': 290.2,
                'uptime_hours': 1890,
                'packet_loss_rate': 0.05,
                'error_count': 87,
                'bandwidth_utilization': 82.1,
                'signal_strength': -28.4
            },
            # BS-MED-014 - Base station intermittent issues
            {
                'equipment_id': equipment_ids.get('BS-MED-014'),
                'timestamp': current_time - timedelta(hours=2, minutes=15),
                'health_score': 0.46,
                'cpu_usage': 69.4,
                'memory_usage': 75.2,
                'temperature': 56.9,
                'power_consumption': 310.8,
                'uptime_hours': 756,
                'packet_loss_rate': 0.08,
                'error_count': 112,
                'bandwidth_utilization': 73.5,
                'signal_strength': -36.7
            }
        ]
        
        # Active equipment health metrics (good performance)
        active_health_metrics = [
            # RT-ACT-015 - Healthy router
            {
                'equipment_id': equipment_ids.get('RT-ACT-015'),
                'timestamp': current_time - timedelta(minutes=15),
                'health_score': 0.89,
                'cpu_usage': 45.2,
                'memory_usage': 52.3,
                'temperature': 42.1,
                'power_consumption': 180.5,
                'uptime_hours': 1440,
                'packet_loss_rate': 0.001,
                'error_count': 2,
                'bandwidth_utilization': 65.8,
                'signal_strength': -22.3
            },
            # AS-ACT-016 - Healthy access switch
            {
                'equipment_id': equipment_ids.get('AS-ACT-016'),
                'timestamp': current_time - timedelta(minutes=20),
                'health_score': 0.92,
                'cpu_usage': 38.7,
                'memory_usage': 41.2,
                'temperature': 39.8,
                'power_consumption': 145.3,
                'uptime_hours': 2160,
                'packet_loss_rate': 0.0005,
                'error_count': 1,
                'bandwidth_utilization': 58.4,
                'signal_strength': -19.8
            },
            # BS-ACT-017 - Healthy base station
            {
                'equipment_id': equipment_ids.get('BS-ACT-017'),
                'timestamp': current_time - timedelta(minutes=10),
                'health_score': 0.86,
                'cpu_usage': 48.9,
                'memory_usage': 55.6,
                'temperature': 44.7,
                'power_consumption': 265.4,
                'uptime_hours': 3360,
                'packet_loss_rate': 0.002,
                'error_count': 3,
                'bandwidth_utilization': 72.1,
                'signal_strength': -24.5
            }
        ]
        
        # Combine all health metrics
        all_health_metrics = critical_health_metrics + medium_health_metrics + active_health_metrics
        
        # Insert health metrics
        for health in all_health_metrics:
            if health['equipment_id']:
                query = """
                    INSERT INTO health_metrics (equipment_id, timestamp, health_score, cpu_usage, 
                                              memory_usage, temperature, power_consumption, uptime_hours,
                                              packet_loss_rate, error_count, bandwidth_utilization, signal_strength)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                values = (
                    health['equipment_id'],
                    health['timestamp'],
                    health['health_score'],
                    health['cpu_usage'],
                    health['memory_usage'],
                    health['temperature'],
                    health['power_consumption'],
                    health['uptime_hours'],
                    health['packet_loss_rate'],
                    health['error_count'],
                    health['bandwidth_utilization'],
                    health['signal_strength']
                )
                
                db_manager.execute_query(query, values)
        
        print(f"  ✅ Inserted {len(all_health_metrics)} health metric records")
        
        # 5. Insert maintenance history for new equipment
        print("\n🔧 Inserting Extended Maintenance History...")
        
        maintenance_records = [
            # Critical maintenance tasks
            {
                'equipment_id': equipment_ids.get('RT-CRIT-007'),
                'maintenance_type': 'emergency',
                'scheduled_date': date(2025, 9, 22),
                'status': 'in_progress',
                'priority': 'critical',
                'description': 'Severe packet loss and CPU overload - immediate intervention required',
                'cost': 3500.00,
                'technician_id': 'TECH005'
            },
            {
                'equipment_id': equipment_ids.get('BS-CRIT-008'),
                'maintenance_type': 'emergency',
                'scheduled_date': date(2025, 9, 22),
                'status': 'in_progress',
                'priority': 'critical',
                'description': 'Complete system failure - hardware replacement required',
                'cost': 8500.00,
                'technician_id': 'TECH006'
            },
            {
                'equipment_id': equipment_ids.get('OT-CRIT-009'),
                'maintenance_type': 'corrective',
                'scheduled_date': date(2025, 9, 23),
                'status': 'scheduled',
                'priority': 'critical',
                'description': 'Fiber optic cable repair and signal amplifier replacement',
                'cost': 5200.00,
                'technician_id': 'TECH007'
            },
            {
                'equipment_id': equipment_ids.get('SW-CRIT-010'),
                'maintenance_type': 'emergency',
                'scheduled_date': date(2025, 9, 22),
                'status': 'scheduled',
                'priority': 'critical',
                'description': 'Switch fabric module failure - urgent replacement needed',
                'cost': 6800.00,
                'technician_id': 'TECH008'
            },
            # Medium level maintenance
            {
                'equipment_id': equipment_ids.get('AS-MED-011'),
                'maintenance_type': 'corrective',
                'scheduled_date': date(2025, 9, 24),
                'status': 'scheduled',
                'priority': 'medium',
                'description': 'Port replacement and configuration optimization',
                'cost': 750.00,
                'technician_id': 'TECH001'
            },
            {
                'equipment_id': equipment_ids.get('RT-MED-012'),
                'maintenance_type': 'preventive',
                'scheduled_date': date(2025, 9, 25),
                'status': 'scheduled',
                'priority': 'medium',
                'description': 'Memory upgrade and system optimization',
                'cost': 1200.00,
                'technician_id': 'TECH002'
            },
            {
                'equipment_id': equipment_ids.get('OT-MED-013'),
                'maintenance_type': 'preventive',
                'scheduled_date': date(2025, 9, 26),
                'status': 'scheduled',
                'priority': 'medium',
                'description': 'Optical module cleaning and recalibration',
                'cost': 850.00,
                'technician_id': 'TECH003'
            },
            {
                'equipment_id': equipment_ids.get('BS-MED-014'),
                'maintenance_type': 'corrective',
                'scheduled_date': date(2025, 9, 25),
                'status': 'scheduled',
                'priority': 'medium',
                'description': 'Signal processing unit maintenance and antenna alignment',
                'cost': 950.00,
                'technician_id': 'TECH004'
            }
        ]
        
        # Insert maintenance records
        for maintenance in maintenance_records:
            if maintenance['equipment_id']:
                query = """
                    INSERT INTO maintenance_history (equipment_id, maintenance_type, scheduled_date, 
                                                   status, priority, description, cost, technician_id)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """
                values = (
                    maintenance['equipment_id'],
                    maintenance['maintenance_type'],
                    maintenance['scheduled_date'],
                    maintenance['status'],
                    maintenance['priority'],
                    maintenance['description'],
                    maintenance['cost'],
                    maintenance['technician_id']
                )
                
                db_manager.execute_query(query, values)
        
        print(f"  ✅ Inserted {len(maintenance_records)} maintenance records")
        
        # 6. Insert failure logs for problematic equipment
        print("\n⚠️ Inserting Extended Failure Logs...")
        
        failure_records = [
            # Critical failures
            {
                'equipment_id': equipment_ids.get('RT-CRIT-007'),
                'failure_type': 'performance',
                'failure_timestamp': current_time - timedelta(hours=2),
                'severity': 'critical',
                'description': 'Severe performance degradation with 25% packet loss rate',
                'resolution_time_minutes': None,
                'resolved': False
            },
            {
                'equipment_id': equipment_ids.get('BS-CRIT-008'),
                'failure_type': 'hardware',
                'failure_timestamp': current_time - timedelta(hours=1),
                'severity': 'critical',
                'description': 'Complete system shutdown - power supply and main board failure',
                'resolution_time_minutes': None,
                'resolved': False
            },
            {
                'equipment_id': equipment_ids.get('OT-CRIT-009'),
                'failure_type': 'optical',
                'failure_timestamp': current_time - timedelta(hours=3),
                'severity': 'critical',
                'description': 'Fiber optic signal loss and amplifier malfunction',
                'resolution_time_minutes': None,
                'resolved': False
            },
            {
                'equipment_id': equipment_ids.get('SW-CRIT-010'),
                'failure_type': 'network',
                'failure_timestamp': current_time - timedelta(minutes=50),
                'severity': 'critical',
                'description': 'Switch fabric failure causing network segmentation',
                'resolution_time_minutes': None,
                'resolved': False
            },
            # Medium severity failures
            {
                'equipment_id': equipment_ids.get('AS-MED-011'),
                'failure_type': 'hardware',
                'failure_timestamp': current_time - timedelta(hours=4),
                'severity': 'medium',
                'description': 'Multiple port failures affecting connectivity',
                'resolution_time_minutes': 150,
                'resolved': True
            },
            {
                'equipment_id': equipment_ids.get('RT-MED-012'),
                'failure_type': 'performance',
                'failure_timestamp': current_time - timedelta(hours=5),
                'severity': 'medium',
                'description': 'Memory utilization exceeded 80% causing slowdowns',
                'resolution_time_minutes': None,
                'resolved': False
            },
            {
                'equipment_id': equipment_ids.get('OT-MED-013'),
                'failure_type': 'optical',
                'failure_timestamp': current_time - timedelta(hours=6),
                'severity': 'medium',
                'description': 'Optical signal degradation in secondary fiber path',
                'resolution_time_minutes': 90,
                'resolved': True
            },
            {
                'equipment_id': equipment_ids.get('BS-MED-014'),
                'failure_type': 'configuration',
                'failure_timestamp': current_time - timedelta(hours=3, minutes=30),
                'severity': 'medium',
                'description': 'Intermittent signal drops due to antenna misalignment',
                'resolution_time_minutes': None,
                'resolved': False
            }
        ]
        
        # Insert failure records
        for failure in failure_records:
            if failure['equipment_id']:
                query = """
                    INSERT INTO failure_logs (equipment_id, failure_type, failure_timestamp, 
                                            severity, description, resolution_time_minutes, resolved)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                values = (
                    failure['equipment_id'],
                    failure['failure_type'],
                    failure['failure_timestamp'],
                    failure['severity'],
                    failure['description'],
                    failure['resolution_time_minutes'],
                    failure['resolved']
                )
                
                db_manager.execute_query(query, values)
        
        print(f"  ✅ Inserted {len(failure_records)} failure log records")
        
        # Summary
        print("\n🎉 Extended Test Data Insertion Complete!")
        print("=" * 60)
        print("📊 Extended Data Summary:")
        print(f"  🚨 Additional Critical Equipment: 4 devices")
        print(f"  ⚠️ Additional Medium Risk Equipment: 4 devices")
        print(f"  ✅ Active (Low Risk) Equipment: 3 devices")
        print(f"  ❤️ Health Metrics: {len(all_health_metrics)} records")
        print(f"  🔧 Maintenance Tasks: {len(maintenance_records)} records")
        print(f"  ⚠️ Failure Logs: {len(failure_records)} records")
        print("=" * 60)
        print("✅ Database now contains comprehensive test data for all scenarios!")
        print("\n📈 Total Test Equipment Summary:")
        print("  🚨 Critical/Failed: 7 devices (high maintenance priority)")
        print("  ⚠️ Medium Risk: 7 devices (scheduled maintenance)")
        print("  ✅ Active/Healthy: 3+ devices (routine monitoring)")
        
        return True
        
    except Exception as e:
        print(f"❌ Error during extended data insertion: {e}")
        return False

if __name__ == "__main__":
    success = insert_extended_test_data()
    if success:
        print("\n🚀 Extended test data insertion completed successfully!")
        print("\n💡 Use this data to test:")
        print("  • AI batch predictions across risk levels")
        print("  • Maintenance scheduling prioritization")
        print("  • Failure analysis and reporting")
        print("  • Health monitoring dashboards")
    else:
        print("\n❌ Extended test data insertion failed!")
