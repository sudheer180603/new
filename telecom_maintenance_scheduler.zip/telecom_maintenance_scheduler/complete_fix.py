#!/usr/bin/env python3
"""Complete fix for database and application errors."""

import mysql.connector
from dotenv import load_dotenv
import os

def fix_all_issues():
    """Fix database schema and verify columns."""
    try:
        load_dotenv()
        conn = mysql.connector.connect(
            host=os.getenv('DB_HOST', 'localhost'),
            port=int(os.getenv('DB_PORT', 3306)),
            database=os.getenv('DB_NAME', 'telecom_maintenance'),
            user=os.getenv('DB_USER', 'root'),
            password=os.getenv('DB_PASSWORD', ''),
            charset='utf8mb4'
        )
        
        cursor = conn.cursor(dictionary=True)
        
        print("Checking database schema...")
        
        # Check if updated_at exists
        cursor.execute("""
            SELECT COUNT(*) AS cnt
            FROM information_schema.columns
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'maintenance_history'
              AND COLUMN_NAME = 'updated_at'
        """)
        
        result = cursor.fetchone()
        if result['cnt'] == 0:
            print("Adding 'updated_at' column...")
            cursor.execute("""
                ALTER TABLE maintenance_history
                ADD COLUMN updated_at TIMESTAMP NULL DEFAULT NULL
                ON UPDATE CURRENT_TIMESTAMP
                AFTER created_at
            """)
            print("✓ Added 'updated_at' column")
        else:
            print("✓ 'updated_at' column already exists")
        
        # Verify both columns exist
        cursor.execute("DESCRIBE maintenance_history")
        columns = cursor.fetchall()
        
        required_columns = ['created_at', 'updated_at']
        existing_columns = [col['Field'] for col in columns]
        
        for req_col in required_columns:
            if req_col in existing_columns:
                print(f"✓ Column '{req_col}' exists")
            else:
                print(f"✗ Column '{req_col}' missing")
        
        conn.commit()
        cursor.close()
        conn.close()
        
        print("✓ Database schema verification completed!")
        
    except Exception as e:
        print(f"✗ Error: {e}")

if __name__ == "__main__":
    fix_all_issues()
