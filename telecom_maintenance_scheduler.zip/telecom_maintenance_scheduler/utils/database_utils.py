"""Database utility functions and connection management."""
import mysql.connector
from mysql.connector import pooling, Error
import logging
from typing import Optional, List, Dict, Any, Tuple
from contextlib import contextmanager
from config.database_config import db_config

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseManager:
    """Database connection and query management."""
    
    def __init__(self):
        self.pool = None
        self.initialize_pool()
    
    def initialize_pool(self):
        """Initialize database connection pool."""
        try:
            self.pool = pooling.MySQLConnectionPool(
                pool_name="telecom_maintenance_pool",
                **db_config.get_pool_params()
            )
            logger.info("Database connection pool initialized successfully")
        except Error as e:
            logger.error(f"Error initializing database pool: {e}")
            raise
    
    @contextmanager
    def get_connection(self):
        """Get database connection from pool with context manager."""
        connection = None
        try:
            connection = self.pool.get_connection()
            yield connection
        except Error as e:
            logger.error(f"Database connection error: {e}")
            if connection:
                connection.rollback()
            raise
        finally:
            if connection and connection.is_connected():
                connection.close()
    
    def execute_query(self, query: str, params: Optional[Tuple] = None, 
                     fetch_one: bool = False, fetch_all: bool = True) -> Any:
        """Execute a SELECT query and return results."""
        try:
            with self.get_connection() as connection:
                cursor = connection.cursor(dictionary=True)
                cursor.execute(query, params or ())
                
                if fetch_one:
                    result = cursor.fetchone()
                elif fetch_all:
                    result = cursor.fetchall()
                else:
                    result = cursor.rowcount
                
                cursor.close()
                return result
        except Error as e:
            logger.error(f"Query execution error: {e}")
            logger.error(f"Query: {query}")
            logger.error(f"Parameters: {params}")
            raise
    
    def execute_insert(self, query: str, params: Optional[Tuple] = None) -> int:
        """Execute an INSERT query and return the last inserted ID."""
        try:
            with self.get_connection() as connection:
                cursor = connection.cursor()
                cursor.execute(query, params or ())
                last_id = cursor.lastrowid
                connection.commit()
                cursor.close()
                return last_id
        except Error as e:
            logger.error(f"Insert execution error: {e}")
            raise
    
    def execute_many(self, query: str, data: List[Tuple]) -> int:
        """Execute multiple queries with different parameters."""
        try:
            with self.get_connection() as connection:
                cursor = connection.cursor()
                cursor.executemany(query, data)
                affected_rows = cursor.rowcount
                connection.commit()
                cursor.close()
                return affected_rows
        except Error as e:
            logger.error(f"Batch execution error: {e}")
            raise
    
    def execute_update(self, query: str, params: Optional[Tuple] = None) -> int:
        """Execute an UPDATE/DELETE query and return affected rows count."""
        try:
            with self.get_connection() as connection:
                cursor = connection.cursor()
                cursor.execute(query, params or ())
                affected_rows = cursor.rowcount
                connection.commit()
                cursor.close()
                return affected_rows
        except Error as e:
            logger.error(f"Update execution error: {e}")
            raise
    
    def test_connection(self) -> bool:
        """Test database connectivity."""
        try:
            with self.get_connection() as connection:
                cursor = connection.cursor()
                cursor.execute("SELECT 1")
                cursor.fetchone()
                cursor.close()
                return True
        except Error as e:
            logger.error(f"Connection test failed: {e}")
            return False

db_manager = DatabaseManager()

def get_db_connection():
    """Get database connection (for backward compatibility)."""
    return db_manager.get_connection()
