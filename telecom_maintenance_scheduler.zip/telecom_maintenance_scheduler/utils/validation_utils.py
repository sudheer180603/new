"""Input validation utilities for the application."""
import re
from datetime import datetime, date
from typing import Any, List, Optional, Union
import logging

logger = logging.getLogger(__name__)

class ValidationUtils:
    """Utility class for input validation."""
    
    @staticmethod
    def validate_equipment_id(equipment_id: str) -> bool:
        """Validate equipment ID format."""
        if not equipment_id or not isinstance(equipment_id, str):
            return False
        pattern = r'^[A-Za-z0-9_-]+$'
        return bool(re.match(pattern, equipment_id)) and len(equipment_id) <= 50
    
    @staticmethod
    def validate_email(email: str) -> bool:
        """Validate email format."""
        if not email or not isinstance(email, str):
            return False
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    @staticmethod
    def validate_date(date_string: str, date_format: str = "%Y-%m-%d") -> bool:
        """Validate date string format."""
        if not date_string or not isinstance(date_string, str):
            return False
        try:
            datetime.strptime(date_string, date_format)
            return True
        except ValueError:
            return False
    
    @staticmethod
    def validate_numeric_range(value: Union[str, int, float], 
                             min_val: Optional[float] = None, 
                             max_val: Optional[float] = None) -> bool:
        """Validate numeric value within specified range."""
        try:
            num_value = float(value)
            if min_val is not None and num_value < min_val:
                return False
            if max_val is not None and num_value > max_val:
                return False
            return True
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_choice(value: Any, valid_choices: List[Any]) -> bool:
        """Validate that value is in list of valid choices."""
        return value in valid_choices
    
    @staticmethod
    def validate_percentage(value: Union[str, int, float]) -> bool:
        """Validate percentage value (0-100)."""
        return ValidationUtils.validate_numeric_range(value, 0, 100)
    
    @classmethod
    def validate_equipment_metrics(cls, metrics: dict) -> tuple[bool, list]:
        """Validate equipment health metrics."""
        errors = []
        
        required_fields = ['cpu_usage', 'memory_usage', 'temperature']
        for field in required_fields:
            if field not in metrics:
                errors.append(f"Missing required field: {field}")
        
        if 'cpu_usage' in metrics:
            if not cls.validate_percentage(metrics['cpu_usage']):
                errors.append("CPU usage must be between 0-100%")
        
        if 'memory_usage' in metrics:
            if not cls.validate_percentage(metrics['memory_usage']):
                errors.append("Memory usage must be between 0-100%")
        
        if 'temperature' in metrics:
            if not cls.validate_numeric_range(metrics['temperature'], -50, 150):
                errors.append("Temperature must be between -50°C and 150°C")
        
        if 'power_consumption' in metrics:
            if not cls.validate_numeric_range(metrics['power_consumption'], 0, 10000):
                errors.append("Power consumption must be between 0-10000 watts")
        
        if 'packet_loss_rate' in metrics:
            if not cls.validate_numeric_range(metrics['packet_loss_rate'], 0, 1):
                errors.append("Packet loss rate must be between 0-1")
        
        return len(errors) == 0, errors
    
    @staticmethod
    def get_user_input(prompt: str, validator=None, error_message: str = "Invalid input. Please try again."):
        """Get validated user input with retry mechanism."""
        while True:
            try:
                user_input = input(prompt).strip()
                if validator is None or validator(user_input):
                    return user_input
                else:
                    print(error_message)
            except KeyboardInterrupt:
                print("\nOperation cancelled by user.")
                return None
            except EOFError:
                print("\nInput stream ended.")
                return None
