"""Main console application for Telecom Equipment Maintenance Scheduler."""

import os
import sys
import logging
from datetime import datetime, date, timedelta
from typing import Optional, Dict, Any
from colorama import Fore, Style, init
from tabulate import tabulate

# Initialize colorama for cross-platform colored output
init(autoreset=True)

# Add project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from modules.equipment_manager import EquipmentManager
from modules.health_monitor import HealthMonitor
from modules.ai_predictor import AIPredictor
from modules.maintenance_scheduler import MaintenanceScheduler
from utils.database_utils import db_manager
from utils.validation_utils import ValidationUtils

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('telecom_maintenance.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

class TelecomMaintenanceApp:
    """Main console application for telecom equipment maintenance management."""
    
    def __init__(self):
        self.equipment_manager = EquipmentManager()
        self.health_monitor = HealthMonitor()
        self.ai_predictor = AIPredictor()
        self.maintenance_scheduler = MaintenanceScheduler()
        self.validator = ValidationUtils()
        
        # Test database connection
        if not db_manager.test_connection():
            print(f"{Fore.RED}✗ Database connection failed! Please check your configuration.{Style.RESET_ALL}")
            sys.exit(1)
        
        print(f"{Fore.GREEN}✓ Database connection successful{Style.RESET_ALL}")
    
    def run(self):
        """Main application loop."""
        print(self.get_banner())
        
        while True:
            try:
                self.show_main_menu()
                choice = input(f"\n{Fore.CYAN}Enter your choice: {Style.RESET_ALL}").strip()
                
                if choice == '1':
                    self.equipment_management_menu()
                elif choice == '2':
                    self.health_monitoring_menu()
                elif choice == '3':
                    self.ai_prediction_menu()
                elif choice == '4':
                    self.maintenance_scheduling_menu()
                elif choice == '5':
                    self.reports_analytics_menu()
                elif choice == '6':
                    self.system_management_menu()
                elif choice == '0':
                    print(f"{Fore.YELLOW}Thank you for using Telecom Maintenance Scheduler!{Style.RESET_ALL}")
                    break
                else:
                    print(f"{Fore.RED}Invalid choice. Please try again.{Style.RESET_ALL}")
                
                input(f"\n{Fore.CYAN}Press Enter to continue...{Style.RESET_ALL}")
                
            except KeyboardInterrupt:
                print(f"\n{Fore.YELLOW}Application interrupted by user.{Style.RESET_ALL}")
                break
            except Exception as e:
                logger.error(f"Unexpected error: {e}")
                print(f"{Fore.RED}An error occurred: {e}{Style.RESET_ALL}")
    
    def get_banner(self):
        """Get application banner."""
        return f"""
{Fore.BLUE}
╔══════════════════════════════════════════════════════════════════════════════╗
║                    TELECOM EQUIPMENT MAINTENANCE SCHEDULER                   ║
║                           Advanced AI-Driven System                          ║
╚══════════════════════════════════════════════════════════════════════════════╝
{Style.RESET_ALL}
{Fore.GREEN}Welcome to the Enterprise Telecom Equipment Maintenance Management System{Style.RESET_ALL}
{Fore.CYAN}Current Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Style.RESET_ALL}
"""
    
    def show_main_menu(self):
        """Display main menu options."""
        print(f"\n{Fore.BLUE}{'='*80}{Style.RESET_ALL}")
        print(f"{Fore.WHITE}                              MAIN MENU{Style.RESET_ALL}")
        print(f"{Fore.BLUE}{'='*80}{Style.RESET_ALL}")
        
        menu_options = [
            ("1", "Equipment Management", "Manage equipment assets and lifecycle"),
            ("2", "Health Monitoring", "Monitor and analyze equipment health metrics"),
            ("3", "AI Predictions", "Machine learning failure predictions"),
            ("4", "Maintenance Scheduling", "Schedule and track maintenance tasks"),
            ("5", "Reports & Analytics", "View reports and system analytics"),
            ("6", "System Management", "System configuration and data management"),
            ("0", "Exit", "Exit the application")
        ]
        
        for option, title, description in menu_options:
            print(f"{Fore.CYAN}{option:>2}. {Fore.WHITE}{title:<25} {Fore.LIGHTBLACK_EX}- {description}{Style.RESET_ALL}")
    
    # Equipment Management Functions
    def equipment_management_menu(self):
        """Equipment management submenu."""
        while True:
            print(f"\n{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            print(f"{Fore.WHITE}                    EQUIPMENT MANAGEMENT{Style.RESET_ALL}")
            print(f"{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            
            options = [
                ("1", "Add New Equipment"),
                ("2", "View Equipment List"),
                ("3", "View Equipment Details"),
                ("4", "Update Equipment"),
                ("5", "Delete Equipment"),
                ("6", "Equipment Statistics"),
                ("0", "Back to Main Menu")
            ]
            
            for option, title in options:
                print(f"{Fore.CYAN}{option}. {Fore.WHITE}{title}{Style.RESET_ALL}")
            
            choice = input(f"\n{Fore.CYAN}Enter your choice: {Style.RESET_ALL}").strip()
            
            if choice == '1':
                self.add_equipment()
            elif choice == '2':
                self.view_equipment_list()
            elif choice == '3':
                self.view_equipment_details()
            elif choice == '4':
                self.update_equipment()
            elif choice == '5':
                self.delete_equipment()
            elif choice == '6':
                self.show_equipment_statistics()
            elif choice == '0':
                break
            else:
                print(f"{Fore.RED}Invalid choice.{Style.RESET_ALL}")
    
    def add_equipment(self):
        """Add new equipment to the system."""
        print(f"\n{Fore.GREEN}=== ADD NEW EQUIPMENT ==={Style.RESET_ALL}")
        
        try:
            # Get equipment types
            equipment_types = self.equipment_manager.get_equipment_types()
            if not equipment_types:
                print(f"{Fore.RED}No equipment types found in database.{Style.RESET_ALL}")
                return
            
            # Display equipment types
            print(f"\n{Fore.CYAN}Available Equipment Types:{Style.RESET_ALL}")
            for i, eq_type in enumerate(equipment_types, 1):
                print(f"{i}. {eq_type['type_name']} - {eq_type['description']}")
            
            # Get user selections
            type_choice = int(input(f"\n{Fore.CYAN}Select equipment type (1-{len(equipment_types)}): {Style.RESET_ALL}")) - 1
            if not 0 <= type_choice < len(equipment_types):
                print(f"{Fore.RED}Invalid equipment type selection.{Style.RESET_ALL}")
                return
            
            selected_type = equipment_types[type_choice]
            
            equipment_data = {}
            equipment_data['equipment_type_id'] = selected_type['id']
            
            # Get equipment details
            equipment_data['equipment_id'] = input(f"{Fore.CYAN}Equipment ID: {Style.RESET_ALL}").strip()
            if not self.validator.validate_equipment_id(equipment_data['equipment_id']):
                print(f"{Fore.RED}Invalid equipment ID format.{Style.RESET_ALL}")
                return
            
            equipment_data['location'] = input(f"{Fore.CYAN}Location: {Style.RESET_ALL}").strip()
            equipment_data['manufacturer'] = input(f"{Fore.CYAN}Manufacturer: {Style.RESET_ALL}").strip()
            equipment_data['model'] = input(f"{Fore.CYAN}Model: {Style.RESET_ALL}").strip()
            equipment_data['firmware_version'] = input(f"{Fore.CYAN}Firmware Version: {Style.RESET_ALL}").strip()
            
            # Installation date
            install_date = input(f"{Fore.CYAN}Installation Date (YYYY-MM-DD) [optional]: {Style.RESET_ALL}").strip()
            if install_date and self.validator.validate_date(install_date):
                equipment_data['installation_date'] = install_date
            
            # Add equipment
            equipment_id = self.equipment_manager.add_equipment(equipment_data)
            
            if equipment_id:
                print(f"{Fore.GREEN}✓ Equipment added successfully with ID: {equipment_id}{Style.RESET_ALL}")
            else:
                print(f"{Fore.RED}✗ Failed to add equipment.{Style.RESET_ALL}")
                
        except (ValueError, IndexError):
            print(f"{Fore.RED}Invalid input. Please try again.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error adding equipment: {e}{Style.RESET_ALL}")
    
    def view_equipment_list(self):
        """Display list of all equipment."""
        print(f"\n{Fore.GREEN}=== EQUIPMENT LIST ==={Style.RESET_ALL}")
        
        try:
            # Get filter options
            print(f"\n{Fore.CYAN}Filter Options:{Style.RESET_ALL}")
            print("1. All Equipment")
            print("2. By Equipment Type")
            print("3. By Status")
            
            filter_choice = input(f"{Fore.CYAN}Select filter (1-3): {Style.RESET_ALL}").strip()
            
            equipment_type = None
            status = None
            
            if filter_choice == '2':
                equipment_types = self.equipment_manager.get_equipment_types()
                print(f"\n{Fore.CYAN}Equipment Types:{Style.RESET_ALL}")
                for i, eq_type in enumerate(equipment_types, 1):
                    print(f"{i}. {eq_type['type_name']}")
                
                type_choice = int(input(f"Select type (1-{len(equipment_types)}): ")) - 1
                equipment_type = equipment_types[type_choice]['type_name']
                
            elif filter_choice == '3':
                statuses = ['active', 'inactive', 'maintenance', 'failed']
                print(f"\n{Fore.CYAN}Statuses:{Style.RESET_ALL}")
                for i, status_opt in enumerate(statuses, 1):
                    print(f"{i}. {status_opt}")
                
                status_choice = int(input(f"Select status (1-{len(statuses)}): ")) - 1
                status = statuses[status_choice]
            
            # Get equipment list
            equipment_list = self.equipment_manager.get_all_equipment(equipment_type, status)
            
            if not equipment_list:
                print(f"{Fore.YELLOW}No equipment found matching criteria.{Style.RESET_ALL}")
                return
            
            # Prepare table data
            headers = ['Equipment ID', 'Type', 'Location', 'Status', 'Manufacturer', 'Model', 'Install Date']
            table_data = []
            
            for equipment in equipment_list:
                table_data.append([
                    equipment['equipment_id'],
                    equipment['type_name'],
                    equipment['location'] or 'N/A',
                    equipment['status'],
                    equipment['manufacturer'] or 'N/A',
                    equipment['model'] or 'N/A',
                    equipment['installation_date'] or 'N/A'
                ])
            
            print(f"\n{Fore.WHITE}Equipment List ({len(equipment_list)} items):{Style.RESET_ALL}")
            print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
        except (ValueError, IndexError):
            print(f"{Fore.RED}Invalid selection.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error retrieving equipment list: {e}{Style.RESET_ALL}")
    
    def view_equipment_details(self):
        """Display detailed equipment information."""
        print(f"\n{Fore.GREEN}=== EQUIPMENT DETAILS ==={Style.RESET_ALL}")
        
        try:
            equipment_id = input(f"{Fore.CYAN}Enter Equipment ID: {Style.RESET_ALL}").strip()
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                print(f"{Fore.RED}Equipment not found.{Style.RESET_ALL}")
                return
            
            # Get latest health metrics
            latest_health = self.health_monitor.get_latest_health_metrics(equipment['id'])
            
            # Display equipment details
            print(f"\n{Fore.WHITE}Equipment Information:{Style.RESET_ALL}")
            print(f"ID: {equipment['equipment_id']}")
            print(f"Type: {equipment['type_name']}")
            print(f"Location: {equipment['location'] or 'N/A'}")
            print(f"Status: {equipment['status']}")
            print(f"Manufacturer: {equipment['manufacturer'] or 'N/A'}")
            print(f"Model: {equipment['model'] or 'N/A'}")
            print(f"Firmware: {equipment['firmware_version'] or 'N/A'}")
            print(f"Installation Date: {equipment['installation_date'] or 'N/A'}")
            print(f"Last Maintenance: {equipment['last_maintenance_date'] or 'Never'}")
            
            if latest_health:
                print(f"\n{Fore.WHITE}Latest Health Metrics:{Style.RESET_ALL}")
                print(f"Timestamp: {latest_health['timestamp']}")
                print(f"Health Score: {latest_health['health_score']:.4f}")
                print(f"CPU Usage: {latest_health['cpu_usage']}%")
                print(f"Memory Usage: {latest_health['memory_usage']}%")
                print(f"Temperature: {latest_health['temperature']}°C")
                print(f"Uptime: {latest_health['uptime_hours']} hours")
            else:
                print(f"{Fore.YELLOW}No health data available.{Style.RESET_ALL}")
                
        except Exception as e:
            print(f"{Fore.RED}Error retrieving equipment details: {e}{Style.RESET_ALL}")
    
    def update_equipment(self):
        """Update equipment information."""
        print(f"\n{Fore.GREEN}=== UPDATE EQUIPMENT ==={Style.RESET_ALL}")
        
        try:
            equipment_id = input(f"{Fore.CYAN}Enter Equipment ID: {Style.RESET_ALL}").strip()
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                print(f"{Fore.RED}Equipment not found.{Style.RESET_ALL}")
                return
            
            print(f"\n{Fore.WHITE}Current Equipment: {equipment['equipment_id']} ({equipment['type_name']}){Style.RESET_ALL}")
            print("Press Enter to keep current value, or enter new value:")
            
            update_data = {}
            
            # Get updated values
            location = input(f"{Fore.CYAN}Location [{equipment['location'] or 'N/A'}]: {Style.RESET_ALL}").strip()
            if location:
                update_data['location'] = location
            
            manufacturer = input(f"{Fore.CYAN}Manufacturer [{equipment['manufacturer'] or 'N/A'}]: {Style.RESET_ALL}").strip()
            if manufacturer:
                update_data['manufacturer'] = manufacturer
            
            model = input(f"{Fore.CYAN}Model [{equipment['model'] or 'N/A'}]: {Style.RESET_ALL}").strip()
            if model:
                update_data['model'] = model
            
            firmware = input(f"{Fore.CYAN}Firmware Version [{equipment['firmware_version'] or 'N/A'}]: {Style.RESET_ALL}").strip()
            if firmware:
                update_data['firmware_version'] = firmware
            
            # Status update
            statuses = ['active', 'inactive', 'maintenance', 'failed']
            print(f"\n{Fore.CYAN}Status Options:{Style.RESET_ALL}")
            for i, status_opt in enumerate(statuses, 1):
                marker = " (current)" if status_opt == equipment['status'] else ""
                print(f"{i}. {status_opt}{marker}")
            
            status_choice = input(f"Select new status (1-{len(statuses)}) [current: {equipment['status']}]: ").strip()
            if status_choice and status_choice.isdigit():
                choice_idx = int(status_choice) - 1
                if 0 <= choice_idx < len(statuses):
                    update_data['status'] = statuses[choice_idx]
            
            if not update_data:
                print(f"{Fore.YELLOW}No changes made.{Style.RESET_ALL}")
                return
            
            success = self.equipment_manager.update_equipment(equipment_id, update_data)
            
            if success:
                print(f"{Fore.GREEN}✓ Equipment updated successfully.{Style.RESET_ALL}")
            else:
                print(f"{Fore.RED}✗ Failed to update equipment.{Style.RESET_ALL}")
                
        except Exception as e:
            print(f"{Fore.RED}Error updating equipment: {e}{Style.RESET_ALL}")
    
    def delete_equipment(self):
        """Remove equipment from the system."""
        print(f"\n{Fore.GREEN}=== DELETE EQUIPMENT ==={Style.RESET_ALL}")
        
        try:
            equipment_id = input(f"{Fore.CYAN}Enter Equipment ID: {Style.RESET_ALL}").strip()
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                print(f"{Fore.RED}Equipment not found.{Style.RESET_ALL}")
                return
            
            print(f"\n{Fore.YELLOW}WARNING: This will permanently delete equipment and all associated data:{Style.RESET_ALL}")
            print(f"ID: {equipment['equipment_id']}")
            print(f"Type: {equipment['type_name']}")
            print(f"Location: {equipment['location'] or 'N/A'}")
            
            confirm = input(f"\n{Fore.RED}Type 'DELETE' to confirm: {Style.RESET_ALL}").strip()
            
            if confirm == 'DELETE':
                success = self.equipment_manager.delete_equipment(equipment_id)
                
                if success:
                    print(f"{Fore.GREEN}✓ Equipment deleted successfully.{Style.RESET_ALL}")
                else:
                    print(f"{Fore.RED}✗ Failed to delete equipment.{Style.RESET_ALL}")
            else:
                print(f"{Fore.YELLOW}Deletion cancelled.{Style.RESET_ALL}")
                
        except Exception as e:
            print(f"{Fore.RED}Error deleting equipment: {e}{Style.RESET_ALL}")
    
    def show_equipment_statistics(self):
        """Show equipment statistics."""
        print(f"\n{Fore.GREEN}=== EQUIPMENT STATISTICS ==={Style.RESET_ALL}")
        
        try:
            stats = self.equipment_manager.get_equipment_statistics()
            
            if not stats:
                print(f"{Fore.YELLOW}No statistics available.{Style.RESET_ALL}")
                return
            
            print(f"{Fore.WHITE}Total Equipment: {stats['total_count']}{Style.RESET_ALL}")
            
            # Equipment by type
            print(f"\n{Fore.CYAN}Equipment by Type:{Style.RESET_ALL}")
            for item in stats['by_type']:
                print(f"  {item['type_name']}: {item['count']}")
            
            # Equipment by status
            print(f"\n{Fore.CYAN}Equipment by Status:{Style.RESET_ALL}")
            for item in stats['by_status']:
                print(f"  {item['status']}: {item['count']}")
            
            # Equipment by age
            if stats['by_age']:
                print(f"\n{Fore.CYAN}Equipment by Age:{Style.RESET_ALL}")
                for item in stats['by_age']:
                    print(f"  {item['age_group']}: {item['count']}")
                
        except Exception as e:
            print(f"{Fore.RED}Error retrieving statistics: {e}{Style.RESET_ALL}")
    
    # Health Monitoring Functions
    def health_monitoring_menu(self):
        """Health monitoring submenu."""
        while True:
            print(f"\n{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            print(f"{Fore.WHITE}                    HEALTH MONITORING{Style.RESET_ALL}")
            print(f"{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            
            options = [
                ("1", "Record Health Metrics"),
                ("2", "View Current Health Status"),
                ("3", "View Health History"),
                ("4", "Detect Anomalies"),
                ("5", "Health Trends Analysis"),
                ("0", "Back to Main Menu")
            ]
            
            for option, title in options:
                print(f"{Fore.CYAN}{option}. {Fore.WHITE}{title}{Style.RESET_ALL}")
            
            choice = input(f"\n{Fore.CYAN}Enter your choice: {Style.RESET_ALL}").strip()
            
            if choice == '1':
                self.record_health_metrics()
            elif choice == '2':
                self.view_health_status()
            elif choice == '3':
                self.view_health_history()
            elif choice == '4':
                self.detect_anomalies()
            elif choice == '5':
                self.analyze_health_trends()
            elif choice == '0':
                break
            else:
                print(f"{Fore.RED}Invalid choice.{Style.RESET_ALL}")
    
    def record_health_metrics(self):
        """Record health metrics for equipment."""
        print(f"\n{Fore.GREEN}=== RECORD HEALTH METRICS ==={Style.RESET_ALL}")
        
        try:
            # Get equipment ID
            equipment_id = input(f"{Fore.CYAN}Enter Equipment ID: {Style.RESET_ALL}").strip()
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                print(f"{Fore.RED}Equipment not found.{Style.RESET_ALL}")
                return
            
            print(f"{Fore.GREEN}Recording metrics for: {equipment['equipment_id']} ({equipment['type_name']}){Style.RESET_ALL}")
            
            # Collect metrics
            metrics = {}
            
            metric_prompts = [
                ('cpu_usage', 'CPU Usage (%)', 0, 100),
                ('memory_usage', 'Memory Usage (%)', 0, 100),
                ('temperature', 'Temperature (°C)', -50, 150),
                ('power_consumption', 'Power Consumption (W)', 0, 10000),
                ('uptime_hours', 'Uptime (hours)', 0, 8760),
                ('packet_loss_rate', 'Packet Loss Rate (0-1)', 0, 1),
                ('error_count', 'Error Count', 0, 1000),
                ('bandwidth_utilization', 'Bandwidth Utilization (%)', 0, 100),
                ('signal_strength', 'Signal Strength (dBm)', -100, 0)
            ]
            
            for metric, prompt, min_val, max_val in metric_prompts:
                while True:
                    try:
                        value_str = input(f"{Fore.CYAN}{prompt}: {Style.RESET_ALL}").strip()
                        if not value_str:
                            break  # Skip optional metrics
                        
                        value = float(value_str)
                        if min_val <= value <= max_val:
                            metrics[metric] = value
                            break
                        else:
                            print(f"{Fore.RED}Value must be between {min_val} and {max_val}.{Style.RESET_ALL}")
                    except ValueError:
                        print(f"{Fore.RED}Please enter a valid number.{Style.RESET_ALL}")
            
            if not metrics:
                print(f"{Fore.YELLOW}No metrics provided.{Style.RESET_ALL}")
                return
            
            # Record metrics
            success = self.health_monitor.record_health_metrics(equipment['id'], metrics)
            
            if success:
                print(f"{Fore.GREEN}✓ Health metrics recorded successfully.{Style.RESET_ALL}")
            else:
                print(f"{Fore.RED}✗ Failed to record health metrics.{Style.RESET_ALL}")
                
        except Exception as e:
            print(f"{Fore.RED}Error recording metrics: {e}{Style.RESET_ALL}")
    
    def view_health_status(self):
        """View current health status of all equipment."""
        print(f"\n{Fore.GREEN}=== CURRENT HEALTH STATUS ==={Style.RESET_ALL}")
        
        try:
            # Get filter option
            print(f"\n{Fore.CYAN}Filter Options:{Style.RESET_ALL}")
            print("1. All Equipment")
            print("2. By Equipment Type")
            
            choice = input(f"{Fore.CYAN}Select filter (1-2): {Style.RESET_ALL}").strip()
            
            equipment_type = None
            if choice == '2':
                equipment_types = self.equipment_manager.get_equipment_types()
                print(f"\n{Fore.CYAN}Equipment Types:{Style.RESET_ALL}")
                for i, eq_type in enumerate(equipment_types, 1):
                    print(f"{i}. {eq_type['type_name']}")
                
                type_choice = int(input(f"Select type (1-{len(equipment_types)}): ")) - 1
                equipment_type = equipment_types[type_choice]['type_name']
            
            # Get health summary
            health_data = self.health_monitor.get_equipment_health_summary(equipment_type)
            
            if not health_data:
                print(f"{Fore.YELLOW}No health data available.{Style.RESET_ALL}")
                return
            
            # Prepare table
            headers = ['Equipment ID', 'Type', 'Location', 'Health Score', 'Status', 'Last Check']
            table_data = []
            
            for item in health_data:
                # Color-code health status
                health_status = item['health_status']
                status_color = {
                    'NORMAL': '✓',
                    'WARNING': '⚠️',
                    'CRITICAL': '🚨'
                }.get(health_status, '?')
                
                table_data.append([
                    item['equipment_id'][:15],
                    item['type_name'][:12],
                    item['location'][:20] if item['location'] else 'N/A',
                    f"{item['health_score']:.3f}" if item['health_score'] else 'N/A',
                    f"{status_color} {health_status}",
                    item['last_check'].strftime('%Y-%m-%d %H:%M') if item['last_check'] else 'Never'
                ])
            
            print(f"\n{Fore.WHITE}Health Status Summary ({len(health_data)} items):{Style.RESET_ALL}")
            print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
        except (ValueError, IndexError):
            print(f"{Fore.RED}Invalid selection.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error retrieving health status: {e}{Style.RESET_ALL}")
    
    def view_health_history(self):
        """View health history for specific equipment."""
        print(f"\n{Fore.GREEN}=== HEALTH HISTORY ==={Style.RESET_ALL}")
        
        try:
            equipment_id = input(f"{Fore.CYAN}Enter Equipment ID: {Style.RESET_ALL}").strip()
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                print(f"{Fore.RED}Equipment not found.{Style.RESET_ALL}")
                return
            
            days = int(input(f"{Fore.CYAN}Number of days to show (default 7): {Style.RESET_ALL}") or "7")
            
            history = self.health_monitor.get_health_history(equipment['id'], days)
            
            if not history:
                print(f"{Fore.YELLOW}No health history found for the specified period.{Style.RESET_ALL}")
                return
            
            # Prepare table
            headers = ['Timestamp', 'Health Score', 'CPU %', 'Memory %', 'Temp °C', 'Errors']
            table_data = []
            
            for record in history[:20]:  # Show last 20 records
                table_data.append([
                    record['timestamp'].strftime('%m-%d %H:%M'),
                    f"{record['health_score']:.3f}",
                    f"{record['cpu_usage']:.1f}" if record['cpu_usage'] else 'N/A',
                    f"{record['memory_usage']:.1f}" if record['memory_usage'] else 'N/A',
                    f"{record['temperature']:.1f}" if record['temperature'] else 'N/A',
                    record['error_count'] or 0
                ])
            
            print(f"\n{Fore.WHITE}Health History for {equipment['equipment_id']} (Last {len(table_data)} records):{Style.RESET_ALL}")
            print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
        except ValueError:
            print(f"{Fore.RED}Invalid number of days.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error retrieving health history: {e}{Style.RESET_ALL}")
    
    def detect_anomalies(self):
        """Detect anomalies in equipment health metrics."""
        print(f"\n{Fore.GREEN}=== ANOMALY DETECTION ==={Style.RESET_ALL}")
        
        try:
            equipment_id = input(f"{Fore.CYAN}Enter Equipment ID: {Style.RESET_ALL}").strip()
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                print(f"{Fore.RED}Equipment not found.{Style.RESET_ALL}")
                return
            
            days = int(input(f"{Fore.CYAN}Analysis period in days (default 7): {Style.RESET_ALL}") or "7")
            
            anomalies = self.health_monitor.detect_anomalies(equipment['id'], days)
            
            if not anomalies:
                print(f"{Fore.GREEN}No anomalies detected in the specified period.{Style.RESET_ALL}")
                return
            
            # Prepare table
            headers = ['Timestamp', 'Metric', 'Value', 'Threshold', 'Deviation', 'Severity']
            table_data = []
            
            for anomaly in anomalies:
                severity_color = '🚨' if anomaly['severity'] == 'HIGH' else '⚠️'
                table_data.append([
                    anomaly['timestamp'].strftime('%m-%d %H:%M'),
                    anomaly['metric'],
                    anomaly['value'],
                    anomaly['threshold'],
                    f"+{anomaly['deviation']:.2f}",
                    f"{severity_color} {anomaly['severity']}"
                ])
            
            print(f"\n{Fore.WHITE}Anomalies Detected for {equipment['equipment_id']} ({len(anomalies)} found):{Style.RESET_ALL}")
            print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
        except ValueError:
            print(f"{Fore.RED}Invalid input.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error detecting anomalies: {e}{Style.RESET_ALL}")
    
    def analyze_health_trends(self):
        """Analyze health trends for equipment."""
        print(f"\n{Fore.GREEN}=== HEALTH TRENDS ANALYSIS ==={Style.RESET_ALL}")
        
        try:
            equipment_id = input(f"{Fore.CYAN}Enter Equipment ID: {Style.RESET_ALL}").strip()
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                print(f"{Fore.RED}Equipment not found.{Style.RESET_ALL}")
                return
            
            days = int(input(f"{Fore.CYAN}Analysis period in days (default 30): {Style.RESET_ALL}") or "30")
            
            trends = self.health_monitor.get_health_trends(equipment['id'], days)
            
            if not trends:
                print(f"{Fore.YELLOW}No trend data available for analysis.{Style.RESET_ALL}")
                return
            
            print(f"\n{Fore.WHITE}Health Trends for {equipment['equipment_id']}:{Style.RESET_ALL}")
            
            # Prepare table
            headers = ['Metric', 'Current', 'Average', 'Trend', 'Min', 'Max']
            table_data = []
            
            for metric, data in trends.items():
                trend_arrow = {
                    'INCREASING': '↗️',
                    'DECREASING': '↘️',
                    'STABLE': '→'
                }.get(data['trend_direction'], '?')
                
                table_data.append([
                    metric.replace('_', ' ').title(),
                    f"{data['current_value']:.2f}",
                    f"{data['average_value']:.2f}",
                    f"{trend_arrow} {data['trend_direction']}",
                    f"{data['min_value']:.2f}",
                    f"{data['max_value']:.2f}"
                ])
            
            print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
        except ValueError:
            print(f"{Fore.RED}Invalid input.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error analyzing trends: {e}{Style.RESET_ALL}")
    
    # AI Prediction Functions
    def ai_prediction_menu(self):
        """AI prediction submenu."""
        while True:
            print(f"\n{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            print(f"{Fore.WHITE}                    AI PREDICTIONS{Style.RESET_ALL}")
            print(f"{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            
            options = [
                ("1", "Train Model for Equipment Type"),
                ("2", "Predict Failure Risk"),
                ("3", "Batch Predictions"),
                ("4", "Model Information"),
                ("5", "Retrain All Models"),
                ("0", "Back to Main Menu")
            ]
            
            for option, title in options:
                print(f"{Fore.CYAN}{option}. {Fore.WHITE}{title}{Style.RESET_ALL}")
            
            choice = input(f"\n{Fore.CYAN}Enter your choice: {Style.RESET_ALL}").strip()
            
            if choice == '1':
                self.train_model()
            elif choice == '2':
                self.predict_failure_risk()
            elif choice == '3':
                self.run_batch_predictions()
            elif choice == '4':
                self.show_model_info()
            elif choice == '5':
                self.retrain_all_models()
            elif choice == '0':
                break
            else:
                print(f"{Fore.RED}Invalid choice.{Style.RESET_ALL}")
    
    def train_model(self):
        """Train ML model for specific equipment type."""
        print(f"\n{Fore.GREEN}=== TRAIN AI MODEL ==={Style.RESET_ALL}")
        
        try:
            # Get equipment types
            equipment_types = self.equipment_manager.get_equipment_types()
            
            print(f"\n{Fore.CYAN}Available Equipment Types:{Style.RESET_ALL}")
            for i, eq_type in enumerate(equipment_types, 1):
                print(f"{i}. {eq_type['type_name']}")
            
            type_choice = int(input(f"\n{Fore.CYAN}Select equipment type (1-{len(equipment_types)}): {Style.RESET_ALL}")) - 1
            if not 0 <= type_choice < len(equipment_types):
                print(f"{Fore.RED}Invalid selection.{Style.RESET_ALL}")
                return
            
            equipment_type = equipment_types[type_choice]['type_name']
            
            print(f"\n{Fore.YELLOW}Training model for {equipment_type}...{Style.RESET_ALL}")
            print("This may take a few minutes depending on data size.")
            
            success = self.ai_predictor.train_model(equipment_type, retrain=True)
            
            if success:
                print(f"{Fore.GREEN}✓ Model trained successfully for {equipment_type}!{Style.RESET_ALL}")
            else:
                print(f"{Fore.RED}✗ Model training failed. Check if sufficient training data exists.{Style.RESET_ALL}")
                
        except (ValueError, IndexError):
            print(f"{Fore.RED}Invalid selection.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error training model: {e}{Style.RESET_ALL}")
    
    def predict_failure_risk(self):
        """Predict failure risk for specific equipment."""
        print(f"\n{Fore.GREEN}=== PREDICT FAILURE RISK ==={Style.RESET_ALL}")
        
        try:
            # Get equipment
            equipment_id = input(f"{Fore.CYAN}Enter Equipment ID: {Style.RESET_ALL}").strip()
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                print(f"{Fore.RED}Equipment not found.{Style.RESET_ALL}")
                return
            
            print(f"{Fore.GREEN}Equipment: {equipment['equipment_id']} ({equipment['type_name']}){Style.RESET_ALL}")
            
            # Get latest health metrics or allow manual input
            latest_metrics = self.health_monitor.get_latest_health_metrics(equipment['id'])
            
            if latest_metrics:
                print(f"\n{Fore.CYAN}Use latest health metrics? (Y/n): {Style.RESET_ALL}")
                use_latest = input().strip().lower()
                
                if use_latest != 'n':
                    metrics = {
                        'cpu_usage': latest_metrics['cpu_usage'],
                        'memory_usage': latest_metrics['memory_usage'],
                        'temperature': latest_metrics['temperature'],
                        'power_consumption': latest_metrics['power_consumption'],
                        'uptime_hours': latest_metrics['uptime_hours'],
                        'packet_loss_rate': latest_metrics['packet_loss_rate'],
                        'error_count': latest_metrics['error_count'],
                        'bandwidth_utilization': latest_metrics['bandwidth_utilization'],
                        'signal_strength': latest_metrics['signal_strength']
                    }
                else:
                    print(f"{Fore.YELLOW}Manual metric input not implemented in demo. Using latest metrics.{Style.RESET_ALL}")
                    metrics = {
                        'cpu_usage': latest_metrics['cpu_usage'],
                        'memory_usage': latest_metrics['memory_usage'],
                        'temperature': latest_metrics['temperature'],
                        'power_consumption': latest_metrics['power_consumption'],
                        'uptime_hours': latest_metrics['uptime_hours'],
                        'packet_loss_rate': latest_metrics['packet_loss_rate'],
                        'error_count': latest_metrics['error_count'],
                        'bandwidth_utilization': latest_metrics['bandwidth_utilization'],
                        'signal_strength': latest_metrics['signal_strength']
                    }
            else:
                print(f"{Fore.YELLOW}No health metrics found. Cannot make prediction.{Style.RESET_ALL}")
                return
            
            # Make prediction
            print(f"\n{Fore.YELLOW}Making prediction...{Style.RESET_ALL}")
            prediction = self.ai_predictor.predict_failure_risk(
                equipment['id'], equipment['type_name'], metrics
            )
            
            # Display results
            if 'error' in prediction:
                print(f"{Fore.RED}✗ Prediction Error: {prediction['error']}{Style.RESET_ALL}")
                return
            
            print(f"\n{Fore.GREEN}=== PREDICTION RESULTS ==={Style.RESET_ALL}")
            print(f"{Fore.WHITE}Equipment: {prediction['equipment_name'] if 'equipment_name' in prediction else equipment_id}{Style.RESET_ALL}")
            print(f"{Fore.WHITE}Type: {prediction['equipment_type']}{Style.RESET_ALL}")
            print(f"{Fore.WHITE}Timestamp: {prediction['timestamp']}{Style.RESET_ALL}")
            
            # Color-code risk level
            risk_level = prediction['risk_level']
            risk_colors = {
                'LOW': Fore.GREEN,
                'MEDIUM': Fore.YELLOW,
                'HIGH': Fore.LIGHTRED_EX,
                'CRITICAL': Fore.RED
            }
            
            print(f"{Fore.WHITE}Risk Level: {risk_colors.get(risk_level, Fore.WHITE)}{risk_level}{Style.RESET_ALL}")
            print(f"{Fore.WHITE}Failure Probability: {prediction['failure_probability']:.4f} ({prediction['failure_probability']*100:.2f}%){Style.RESET_ALL}")
            print(f"{Fore.WHITE}Confidence Score: {prediction['confidence_score']:.4f}{Style.RESET_ALL}")
            
            if prediction.get('missing_features'):
                print(f"{Fore.YELLOW}Missing Features: {', '.join(prediction['missing_features'])}{Style.RESET_ALL}")
            
            print(f"\n{Fore.CYAN}Recommendations:{Style.RESET_ALL}")
            for i, recommendation in enumerate(prediction['recommendations'], 1):
                print(f"{i}. {recommendation}")
                
        except Exception as e:
            print(f"{Fore.RED}Error making prediction: {e}{Style.RESET_ALL}")
    
    def run_batch_predictions(self):
        """Run batch predictions for equipment type."""
        print(f"\n{Fore.GREEN}=== BATCH PREDICTIONS ==={Style.RESET_ALL}")
        
        try:
            # Get equipment types
            equipment_types = self.equipment_manager.get_equipment_types()
            
            print(f"\n{Fore.CYAN}Available Equipment Types:{Style.RESET_ALL}")
            for i, eq_type in enumerate(equipment_types, 1):
                print(f"{i}. {eq_type['type_name']}")
            
            type_choice = int(input(f"\n{Fore.CYAN}Select equipment type (1-{len(equipment_types)}): {Style.RESET_ALL}")) - 1
            if not 0 <= type_choice < len(equipment_types):
                print(f"{Fore.RED}Invalid selection.{Style.RESET_ALL}")
                return
            
            equipment_type = equipment_types[type_choice]['type_name']
            
            print(f"\n{Fore.YELLOW}Running batch predictions for {equipment_type}...{Style.RESET_ALL}")
            predictions = self.ai_predictor.batch_predict(equipment_type)
            
            if not predictions:
                print(f"{Fore.YELLOW}No predictions generated. Ensure models are trained and equipment has health data.{Style.RESET_ALL}")
                return
            
            # Filter out errors and sort by risk
            valid_predictions = [p for p in predictions if 'error' not in p]
            valid_predictions.sort(key=lambda x: x['failure_probability'], reverse=True)
            
            # Prepare table
            headers = ['Equipment', 'Risk Level', 'Probability', 'Confidence', 'Recommendations']
            table_data = []
            
            for pred in valid_predictions[:15]:  # Show top 15
                risk_color = {
                    'CRITICAL': '🚨',
                    'HIGH': '⚠️',
                    'MEDIUM': '🟡',
                    'LOW': '✅'
                }.get(pred['risk_level'], '?')
                
                recommendations = pred['recommendations'][:2]  # First 2 recommendations
                rec_text = '; '.join(recommendations)
                if len(rec_text) > 50:
                    rec_text = rec_text[:50] + "..."
                
                table_data.append([
                    pred['equipment_name'][:15],
                    f"{risk_color} {pred['risk_level']}",
                    f"{pred['failure_probability']:.4f}",
                    f"{pred['confidence_score']:.3f}",
                    rec_text
                ])
            
            print(f"\n{Fore.WHITE}Batch Prediction Results for {equipment_type} ({len(valid_predictions)} devices):{Style.RESET_ALL}")
            print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
            # Show summary
            risk_summary = {}
            for pred in valid_predictions:
                risk_level = pred['risk_level']
                risk_summary[risk_level] = risk_summary.get(risk_level, 0) + 1
            
            print(f"\n{Fore.CYAN}Risk Level Summary:{Style.RESET_ALL}")
            for level, count in risk_summary.items():
                print(f"  {level}: {count} devices")
                
        except (ValueError, IndexError):
            print(f"{Fore.RED}Invalid selection.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error running batch predictions: {e}{Style.RESET_ALL}")
    
    def show_model_info(self):
        """Show ML model information."""
        print(f"\n{Fore.GREEN}=== MODEL INFORMATION ==={Style.RESET_ALL}")
        
        try:
            # Get equipment types
            equipment_types = self.equipment_manager.get_equipment_types()
            
            print(f"\n{Fore.CYAN}Available Equipment Types:{Style.RESET_ALL}")
            for i, eq_type in enumerate(equipment_types, 1):
                print(f"{i}. {eq_type['type_name']}")
            
            type_choice = int(input(f"\n{Fore.CYAN}Select equipment type (1-{len(equipment_types)}): {Style.RESET_ALL}")) - 1
            if not 0 <= type_choice < len(equipment_types):
                print(f"{Fore.RED}Invalid selection.{Style.RESET_ALL}")
                return
            
            equipment_type = equipment_types[type_choice]['type_name']
            
            info = self.ai_predictor.get_model_info(equipment_type)
            
            if 'error' in info:
                print(f"{Fore.RED}Model information not available: {info['error']}{Style.RESET_ALL}")
                return
            
            print(f"\n{Fore.WHITE}Model Information for {equipment_type}:{Style.RESET_ALL}")
            print(f"Model Type: {info['model_type']}")
            print(f"Model Size: {info['model_size_mb']} MB")
            print(f"Created: {info['created_at']}")
            print(f"Features: {len(info['features_used'])}")
            
            if 'n_estimators' in info:
                print(f"Estimators: {info['n_estimators']}")
                print(f"Max Depth: {info['max_depth']}")
                print(f"Classes: {info['n_classes']}")
            
            print(f"\n{Fore.CYAN}Features Used:{Style.RESET_ALL}")
            for feature in info['features_used']:
                print(f"  - {feature}")
                
        except (ValueError, IndexError):
            print(f"{Fore.RED}Invalid selection.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error getting model info: {e}{Style.RESET_ALL}")
    
    def retrain_all_models(self):
        """Retrain all equipment type models."""
        print(f"\n{Fore.GREEN}=== RETRAIN ALL MODELS ==={Style.RESET_ALL}")
        
        try:
            print(f"{Fore.YELLOW}This will retrain models for all equipment types.{Style.RESET_ALL}")
            print("This process may take several minutes.")
            
            confirm = input(f"\n{Fore.CYAN}Continue with retraining? (y/N): {Style.RESET_ALL}").strip().lower()
            
            if confirm != 'y':
                print("Retraining cancelled.")
                return
            
            equipment_types = self.equipment_manager.get_equipment_types()
            success_count = 0
            
            for eq_type in equipment_types:
                equipment_type = eq_type['type_name']
                print(f"\n{Fore.YELLOW}Training model for {equipment_type}...{Style.RESET_ALL}")
                
                success = self.ai_predictor.train_model(equipment_type, retrain=True)
                if success:
                    success_count += 1
                    print(f"{Fore.GREEN}✓ {equipment_type} model trained successfully{Style.RESET_ALL}")
                else:
                    print(f"{Fore.RED}✗ {equipment_type} model training failed{Style.RESET_ALL}")
            
            print(f"\n{Fore.WHITE}Retraining completed: {success_count}/{len(equipment_types)} models successful{Style.RESET_ALL}")
            
        except Exception as e:
            print(f"{Fore.RED}Error retraining models: {e}{Style.RESET_ALL}")
    
    # Maintenance Scheduling Functions
    def maintenance_scheduling_menu(self):
        """Maintenance scheduling submenu."""
        while True:
            print(f"\n{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            print(f"{Fore.WHITE}                 MAINTENANCE SCHEDULING{Style.RESET_ALL}")
            print(f"{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            
            options = [
                ("1", "Schedule Maintenance"),
                ("2", "View Maintenance Schedule"),
                ("3", "Generate AI-Driven Schedule"),
                ("4", "Update Maintenance Status"),
                ("5", "Maintenance Analytics"),
                ("0", "Back to Main Menu")
            ]
            
            for option, title in options:
                print(f"{Fore.CYAN}{option}. {Fore.WHITE}{title}{Style.RESET_ALL}")
            
            choice = input(f"\n{Fore.CYAN}Enter your choice: {Style.RESET_ALL}").strip()
            
            if choice == '1':
                self.schedule_maintenance()
            elif choice == '2':
                self.view_maintenance_schedule()
            elif choice == '3':
                self.generate_ai_schedule()
            elif choice == '4':
                self.update_maintenance_status()
            elif choice == '5':
                self.show_maintenance_analytics()
            elif choice == '0':
                break
            else:
                print(f"{Fore.RED}Invalid choice.{Style.RESET_ALL}")
    
    def schedule_maintenance(self):
        """Schedule a new maintenance task."""
        print(f"\n{Fore.GREEN}=== SCHEDULE MAINTENANCE ==={Style.RESET_ALL}")
        
        try:
            # Get equipment
            equipment_id = input(f"{Fore.CYAN}Enter Equipment ID: {Style.RESET_ALL}").strip()
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                print(f"{Fore.RED}Equipment not found.{Style.RESET_ALL}")
                return
            
            print(f"{Fore.GREEN}Equipment: {equipment['equipment_id']} ({equipment['type_name']}){Style.RESET_ALL}")
            
            # Get maintenance details
            print(f"\n{Fore.CYAN}Maintenance Type:{Style.RESET_ALL}")
            maintenance_types = ['preventive', 'corrective', 'emergency', 'scheduled']
            for i, mtype in enumerate(maintenance_types, 1):
                print(f"{i}. {mtype.title()}")
            
            type_choice = int(input(f"Select type (1-{len(maintenance_types)}): ")) - 1
            if not 0 <= type_choice < len(maintenance_types):
                print(f"{Fore.RED}Invalid selection.{Style.RESET_ALL}")
                return
            
            maintenance_data = {
                'maintenance_type': maintenance_types[type_choice],
                'scheduled_date': input(f"{Fore.CYAN}Scheduled Date (YYYY-MM-DD): {Style.RESET_ALL}").strip(),
                'description': input(f"{Fore.CYAN}Description: {Style.RESET_ALL}").strip(),
                'technician_id': input(f"{Fore.CYAN}Technician ID (optional): {Style.RESET_ALL}").strip(),
            }
            
            # Validate date
            if not self.validator.validate_date(maintenance_data['scheduled_date']):
                print(f"{Fore.RED}Invalid date format.{Style.RESET_ALL}")
                return
            
            # Get priority
            print(f"\n{Fore.CYAN}Priority:{Style.RESET_ALL}")
            priorities = ['low', 'medium', 'high', 'critical']
            for i, priority in enumerate(priorities, 1):
                print(f"{i}. {priority.title()}")
            
            priority_choice = int(input(f"Select priority (1-{len(priorities)}): ")) - 1
            if 0 <= priority_choice < len(priorities):
                maintenance_data['priority'] = priorities[priority_choice]
            
            # Get estimated cost
            cost_str = input(f"{Fore.CYAN}Estimated Cost (optional): {Style.RESET_ALL}").strip()
            if cost_str and self.validator.validate_numeric_range(cost_str, 0, 100000):
                maintenance_data['cost'] = float(cost_str)
            
            # Schedule maintenance
            maintenance_id = self.maintenance_scheduler.schedule_maintenance(
                equipment['id'], maintenance_data
            )
            
            if maintenance_id:
                print(f"{Fore.GREEN}✓ Maintenance scheduled successfully with ID: {maintenance_id}{Style.RESET_ALL}")
            else:
                print(f"{Fore.RED}✗ Failed to schedule maintenance.{Style.RESET_ALL}")
                
        except (ValueError, IndexError):
            print(f"{Fore.RED}Invalid input.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error scheduling maintenance: {e}{Style.RESET_ALL}")
    
    def view_maintenance_schedule(self):
        """View scheduled maintenance tasks."""
        print(f"\n{Fore.GREEN}=== MAINTENANCE SCHEDULE ==={Style.RESET_ALL}")
        
        try:
            # Get filter options
            print(f"\n{Fore.CYAN}Filter Options:{Style.RESET_ALL}")
            print("1. All Scheduled Maintenance")
            print("2. By Equipment")
            print("3. By Status")
            print("4. By Date Range")
            
            filter_choice = input(f"{Fore.CYAN}Select filter (1-4): {Style.RESET_ALL}").strip()
            
            equipment_id = None
            status = None
            days_ahead = 30
            
            if filter_choice == '2':
                equipment_name = input(f"{Fore.CYAN}Equipment ID: {Style.RESET_ALL}").strip()
                equipment = self.equipment_manager.get_equipment_by_id(equipment_name)
                if equipment:
                    equipment_id = equipment['id']
                else:
                    print(f"{Fore.RED}Equipment not found.{Style.RESET_ALL}")
                    return
            
            elif filter_choice == '3':
                statuses = ['scheduled', 'in_progress', 'completed', 'cancelled']
                print(f"\n{Fore.CYAN}Statuses:{Style.RESET_ALL}")
                for i, status_opt in enumerate(statuses, 1):
                    print(f"{i}. {status_opt}")
                
                status_choice = int(input(f"Select status (1-{len(statuses)}): ")) - 1
                if 0 <= status_choice < len(statuses):
                    status = statuses[status_choice]
            
            elif filter_choice == '4':
                days_ahead = int(input(f"{Fore.CYAN}Days ahead to show (default 30): {Style.RESET_ALL}") or "30")
            
            # Get maintenance schedule
            schedule = self.maintenance_scheduler.get_maintenance_schedule(
                equipment_id, status, days_ahead
            )
            
            if not schedule:
                print(f"{Fore.YELLOW}No maintenance tasks found matching criteria.{Style.RESET_ALL}")
                return
            
            # Prepare table
            headers = ['ID', 'Equipment', 'Type', 'Priority', 'Scheduled', 'Status', 'Cost']
            table_data = []
            
            for task in schedule:
                priority_icon = {
                    'critical': '🚨',
                    'high': '⚠️',
                    'medium': '🔶',
                    'low': '🔹'
                }.get(task['priority'], '?')
                
                table_data.append([
                    task['id'],
                    task['equipment_name'][:15],
                    task['maintenance_type'][:10],
                    f"{priority_icon} {task['priority']}",
                    task['scheduled_date'],
                    task['status'],
                    f"${task['cost']:.0f}" if task['cost'] else 'N/A'
                ])
            
            print(f"\n{Fore.WHITE}Maintenance Schedule ({len(schedule)} tasks):{Style.RESET_ALL}")
            print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
        except (ValueError, IndexError):
            print(f"{Fore.RED}Invalid input.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error retrieving maintenance schedule: {e}{Style.RESET_ALL}")
    
    def generate_ai_schedule(self):
        """Generate AI-driven maintenance schedule."""
        print(f"\n{Fore.GREEN}=== GENERATE AI-DRIVEN SCHEDULE ==={Style.RESET_ALL}")
        
        try:
            print(f"{Fore.YELLOW}Generating AI-driven maintenance recommendations...{Style.RESET_ALL}")
            print("This may take a moment as we analyze all equipment.")
            
            recommendations = self.maintenance_scheduler.generate_ai_driven_schedule()
            
            if not recommendations:
                print(f"{Fore.YELLOW}No maintenance recommendations generated.{Style.RESET_ALL}")
                return
            
            # Display recommendations
            headers = ['Equipment', 'Type', 'Priority', 'Scheduled', 'Risk Level', 'Est. Cost', 'Description']
            table_data = []
            
            for rec in recommendations[:20]:  # Show top 20
                risk_indicator = "⚠️" if rec.get('failure_probability', 0) > 0.7 else ""
                description = rec['description']
                if len(description) > 40:
                    description = description[:40] + "..."
                
                table_data.append([
                    rec['equipment_name'][:15],
                    rec['equipment_type'][:12],
                    rec['priority'].upper(),
                    rec['scheduled_date'],
                    f"{rec.get('failure_probability', 0):.3f} {risk_indicator}",
                    f"${rec['estimated_cost']:.0f}",
                    description
                ])
            
            print(f"\n{Fore.WHITE}AI-Generated Maintenance Recommendations (Top 20):{Style.RESET_ALL}")
            print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
            if len(recommendations) > 20:
                print(f"\n{Fore.CYAN}Showing 20 of {len(recommendations)} recommendations.{Style.RESET_ALL}")
            
            # Ask if user wants to schedule any
            schedule_choice = input(f"\n{Fore.CYAN}Schedule these recommendations? (y/N): {Style.RESET_ALL}").strip().lower()
            
            if schedule_choice == 'y':
                scheduled_count = 0
                for rec in recommendations:
                    maintenance_data = {
                        'maintenance_type': rec['maintenance_type'],
                        'scheduled_date': rec['scheduled_date'],
                        'description': rec['description'],
                        'priority': rec['priority'],
                        'cost': rec['estimated_cost']
                    }
                    
                    maintenance_id = self.maintenance_scheduler.schedule_maintenance(
                        rec['equipment_id'], maintenance_data
                    )
                    
                    if maintenance_id:
                        scheduled_count += 1
                
                print(f"{Fore.GREEN}✓ Scheduled {scheduled_count} maintenance tasks.{Style.RESET_ALL}")
                
        except Exception as e:
            print(f"{Fore.RED}Error generating AI schedule: {e}{Style.RESET_ALL}")
    
    def update_maintenance_status(self):
        """Update maintenance task status."""
        print(f"\n{Fore.GREEN}=== UPDATE MAINTENANCE STATUS ==={Style.RESET_ALL}")
        
        try:
            maintenance_id = int(input(f"{Fore.CYAN}Enter Maintenance ID: {Style.RESET_ALL}").strip())
            
            # Get current maintenance info
            current_query = """
                SELECT mh.*, e.equipment_id, et.type_name 
                FROM maintenance_history mh
                JOIN equipment e ON mh.equipment_id = e.id
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE mh.id = %s
            """
            current = db_manager.execute_query(current_query, (maintenance_id,), fetch_one=True)
            
            if not current:
                print(f"{Fore.RED}Maintenance task not found.{Style.RESET_ALL}")
                return
            
            print(f"\n{Fore.WHITE}Current Maintenance Task:{Style.RESET_ALL}")
            print(f"ID: {current['id']}")
            print(f"Equipment: {current['equipment_id']} ({current['type_name']})")
            print(f"Type: {current['maintenance_type']}")
            print(f"Current Status: {current['status']}")
            print(f"Scheduled: {current['scheduled_date']}")
            
            # Get new status
            print(f"\n{Fore.CYAN}New Status:{Style.RESET_ALL}")
            statuses = ['scheduled', 'in_progress', 'completed', 'cancelled']
            for i, status_opt in enumerate(statuses, 1):
                marker = " (current)" if status_opt == current['status'] else ""
                print(f"{i}. {status_opt}{marker}")
            
            status_choice = int(input(f"Select new status (1-{len(statuses)}): ")) - 1
            if not 0 <= status_choice < len(statuses):
                print(f"{Fore.RED}Invalid selection.{Style.RESET_ALL}")
                return
            
            new_status = statuses[status_choice]
            
            completion_data = {}
            
            # If completing, get additional details
            if new_status == 'completed':
                completion_data['completed_date'] = input(
                    f"{Fore.CYAN}Completion Date (YYYY-MM-DD) [default: today]: {Style.RESET_ALL}"
                ).strip() or datetime.now().date().strftime('%Y-%m-%d')
                
                cost_str = input(f"{Fore.CYAN}Actual Cost (optional): {Style.RESET_ALL}").strip()
                if cost_str and self.validator.validate_numeric_range(cost_str, 0, 100000):
                    completion_data['actual_cost'] = float(cost_str)
                
                downtime_str = input(f"{Fore.CYAN}Downtime in minutes (optional): {Style.RESET_ALL}").strip()
                if downtime_str and self.validator.validate_numeric_range(downtime_str, 0, 10000):
                    completion_data['downtime_minutes'] = int(float(downtime_str))
                
                notes = input(f"{Fore.CYAN}Additional notes (optional): {Style.RESET_ALL}").strip()
                if notes:
                    completion_data['description'] = f"{current['description']}\nCompletion notes: {notes}"
            
            # Update status
            success = self.maintenance_scheduler.update_maintenance_status(
                maintenance_id, new_status, completion_data
            )
            
            if success:
                print(f"{Fore.GREEN}✓ Maintenance status updated successfully.{Style.RESET_ALL}")
            else:
                print(f"{Fore.RED}✗ Failed to update maintenance status.{Style.RESET_ALL}")
                
        except (ValueError, IndexError):
            print(f"{Fore.RED}Invalid input.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error updating maintenance status: {e}{Style.RESET_ALL}")
    
    def show_maintenance_analytics(self):
        """Show maintenance analytics and statistics."""
        print(f"\n{Fore.GREEN}=== MAINTENANCE ANALYTICS ==={Style.RESET_ALL}")
        
        try:
            days_back = int(input(f"{Fore.CYAN}Analysis period in days (default 90): {Style.RESET_ALL}") or "90")
            
            analytics = self.maintenance_scheduler.get_maintenance_analytics(days_back)
            
            if not analytics:
                print(f"{Fore.YELLOW}No analytics data available.{Style.RESET_ALL}")
                return
            
            print(f"\n{Fore.WHITE}Maintenance Analytics - Last {days_back} Days:{Style.RESET_ALL}")
            
            # By status
            if analytics['by_status']:
                print(f"\n{Fore.CYAN}By Status:{Style.RESET_ALL}")
                headers = ['Status', 'Count', 'Avg Cost', 'Total Downtime (hrs)']
                table_data = []
                
                for item in analytics['by_status']:
                    downtime_hours = (item['total_downtime'] or 0) / 60.0
                    table_data.append([
                        item['status'],
                        item['count'],
                        f"${item['avg_cost']:.0f}" if item['avg_cost'] else 'N/A',
                        f"{downtime_hours:.1f}"
                    ])
                
                print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
            # By type
            if analytics['by_type']:
                print(f"\n{Fore.CYAN}By Maintenance Type:{Style.RESET_ALL}")
                headers = ['Type', 'Count', 'Avg Cost', 'Avg Downtime (mins)']
                table_data = []
                
                for item in analytics['by_type']:
                    table_data.append([
                        item['maintenance_type'],
                        item['count'],
                        f"${item['avg_cost']:.0f}" if item['avg_cost'] else 'N/A',
                        f"{item['avg_downtime']:.0f}" if item['avg_downtime'] else 'N/A'
                    ])
                
                print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
            # By equipment type
            if analytics['by_equipment_type']:
                print(f"\n{Fore.CYAN}By Equipment Type:{Style.RESET_ALL}")
                headers = ['Equipment Type', 'Maintenance Count', 'Avg Cost', 'Equipment Count']
                table_data = []
                
                for item in analytics['by_equipment_type']:
                    table_data.append([
                        item['type_name'],
                        item['maintenance_count'] or 0,
                        f"${item['avg_cost']:.0f}" if item['avg_cost'] else 'N/A',
                        item['equipment_count']
                    ])
                
                print(tabulate(table_data, headers=headers, tablefmt='grid'))
                
        except ValueError:
            print(f"{Fore.RED}Invalid number of days.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error retrieving maintenance analytics: {e}{Style.RESET_ALL}")
    
    # Reports & Analytics Functions
    def reports_analytics_menu(self):
        """Reports and analytics submenu."""
        while True:
            print(f"\n{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            print(f"{Fore.WHITE}                   REPORTS & ANALYTICS{Style.RESET_ALL}")
            print(f"{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            
            options = [
                ("1", "Equipment Summary Report"),
                ("2", "Health Status Dashboard"),
                ("3", "Failure Analysis Report"),
                ("4", "Maintenance Performance Report"),
                ("5", "Predictive Analytics Summary"),
                ("6", "Cost Analysis Report"),
                ("0", "Back to Main Menu")
            ]
            
            for option, title in options:
                print(f"{Fore.CYAN}{option}. {Fore.WHITE}{title}{Style.RESET_ALL}")
            
            choice = input(f"\n{Fore.CYAN}Enter your choice: {Style.RESET_ALL}").strip()
            
            if choice == '1':
                self.equipment_summary_report()
            elif choice == '2':
                self.health_status_dashboard()
            elif choice == '3':
                self.failure_analysis_report()
            elif choice == '4':
                self.maintenance_performance_report()
            elif choice == '5':
                self.predictive_analytics_summary()
            elif choice == '6':
                self.cost_analysis_report()
            elif choice == '0':
                break
            else:
                print(f"{Fore.RED}Invalid choice.{Style.RESET_ALL}")
    
    def equipment_summary_report(self):
        """Generate equipment summary report."""
        print(f"\n{Fore.GREEN}=== EQUIPMENT SUMMARY REPORT ==={Style.RESET_ALL}")
        
        try:
            # Get comprehensive equipment data
            query = """
                SELECT 
                    et.type_name,
                    COUNT(e.id) as total_count,
                    COUNT(CASE WHEN e.status = 'active' THEN 1 END) as active_count,
                    COUNT(CASE WHEN e.status = 'maintenance' THEN 1 END) as maintenance_count,
                    COUNT(CASE WHEN e.status = 'failed' THEN 1 END) as failed_count,
                    AVG(DATEDIFF(CURDATE(), e.installation_date)) as avg_age_days,
                    COUNT(CASE WHEN hm.health_score >= et.critical_threshold THEN 1 END) as critical_health,
                    COUNT(CASE WHEN hm.health_score >= et.warning_threshold 
                               AND hm.health_score < et.critical_threshold THEN 1 END) as warning_health
                FROM equipment_types et
                LEFT JOIN equipment e ON et.id = e.equipment_type_id
                LEFT JOIN (
                    SELECT equipment_id, health_score,
                           ROW_NUMBER() OVER (PARTITION BY equipment_id ORDER BY timestamp DESC) as rn
                    FROM health_metrics
                ) hm ON e.id = hm.equipment_id AND hm.rn = 1
                GROUP BY et.id, et.type_name
                ORDER BY et.type_name
            """
            
            data = db_manager.execute_query(query)
            
            if not data:
                print(f"{Fore.YELLOW}No equipment data available.{Style.RESET_ALL}")
                return
            
            print(f"\n{Fore.WHITE}Equipment Summary Report - Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Style.RESET_ALL}")
            
            headers = ['Equipment Type', 'Total', 'Active', 'Maintenance', 'Failed', 'Avg Age (Days)', 'Critical Health', 'Warning Health']
            table_data = []
            
            total_equipment = 0
            total_active = 0
            total_critical = 0
            
            for item in data:
                total_equipment += item['total_count'] or 0
                total_active += item['active_count'] or 0
                total_critical += item['critical_health'] or 0
                
                table_data.append([
                    item['type_name'],
                    item['total_count'] or 0,
                    item['active_count'] or 0,
                    item['maintenance_count'] or 0,
                    item['failed_count'] or 0,
                    f"{item['avg_age_days']:.0f}" if item['avg_age_days'] else 'N/A',
                    item['critical_health'] or 0,
                    item['warning_health'] or 0
                ])
            
            print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
            # Summary statistics
            print(f"\n{Fore.CYAN}Summary Statistics:{Style.RESET_ALL}")
            print(f"Total Equipment: {total_equipment}")
            print(f"Active Equipment: {total_active} ({(total_active/total_equipment*100) if total_equipment > 0 else 0:.1f}%)")
            print(f"Equipment with Critical Health: {total_critical}")
            print(f"Overall Health Risk: {(total_critical/total_equipment*100) if total_equipment > 0 else 0:.1f}%")
            
        except Exception as e:
            print(f"{Fore.RED}Error generating equipment summary: {e}{Style.RESET_ALL}")
    
    def health_status_dashboard(self):
        """Display health status dashboard."""
        print(f"\n{Fore.GREEN}=== HEALTH STATUS DASHBOARD ==={Style.RESET_ALL}")
        
        try:
            equipment_type_filter = input(f"{Fore.CYAN}Equipment type filter (leave empty for all): {Style.RESET_ALL}").strip()
            
            # Get health metrics summary
            base_query = """
                SELECT 
                    e.equipment_id,
                    et.type_name,
                    e.location,
                    hm.health_score,
                    hm.cpu_usage,
                    hm.memory_usage,
                    hm.temperature,
                    hm.timestamp,
                    CASE 
                        WHEN hm.health_score >= et.critical_threshold THEN 'CRITICAL'
                        WHEN hm.health_score >= et.warning_threshold THEN 'WARNING'
                        ELSE 'NORMAL'
                    END as health_status,
                    DATEDIFF(CURDATE(), e.last_maintenance_date) as days_since_maintenance
                FROM equipment e
                JOIN equipment_types et ON e.equipment_type_id = et.id
                LEFT JOIN (
                    SELECT equipment_id, health_score, cpu_usage, memory_usage, temperature, timestamp,
                           ROW_NUMBER() OVER (PARTITION BY equipment_id ORDER BY timestamp DESC) as rn
                    FROM health_metrics
                ) hm ON e.id = hm.equipment_id AND hm.rn = 1
                WHERE e.status = 'active'
            """
            
            params = []
            if equipment_type_filter:
                base_query += " AND et.type_name = %s"
                params.append(equipment_type_filter)
            
            base_query += " ORDER BY hm.health_score DESC, e.equipment_id"
            
            data = db_manager.execute_query(base_query, tuple(params) if params else None)
            
            if not data:
                print(f"{Fore.YELLOW}No health data available.{Style.RESET_ALL}")
                return
            
            # Categorize by health status
            critical_items = [item for item in data if item['health_status'] == 'CRITICAL']
            warning_items = [item for item in data if item['health_status'] == 'WARNING']
            normal_items = [item for item in data if item['health_status'] == 'NORMAL']
            
            print(f"\n{Fore.WHITE}Health Status Dashboard - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Style.RESET_ALL}")
            
            # Critical items
            if critical_items:
                print(f"\n{Fore.RED}🚨 CRITICAL HEALTH ITEMS ({len(critical_items)}):{Style.RESET_ALL}")
                headers = ['Equipment', 'Type', 'Health Score', 'CPU %', 'Memory %', 'Temp °C', 'Last Maintenance']
                table_data = []
                
                for item in critical_items[:10]:  # Top 10 critical
                    table_data.append([
                        item['equipment_id'][:15],
                        item['type_name'][:12],
                        f"{item['health_score']:.3f}" if item['health_score'] else 'N/A',
                        f"{item['cpu_usage']:.1f}" if item['cpu_usage'] else 'N/A',
                        f"{item['memory_usage']:.1f}" if item['memory_usage'] else 'N/A',
                        f"{item['temperature']:.1f}" if item['temperature'] else 'N/A',
                        f"{item['days_since_maintenance']} days" if item['days_since_maintenance'] else 'Never'
                    ])
                
                print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
            # Warning items
            if warning_items:
                print(f"\n{Fore.YELLOW}⚠️ WARNING HEALTH ITEMS ({len(warning_items)}):{Style.RESET_ALL}")
                print(f"First 5 items requiring attention:")
                for item in warning_items[:5]:
                    print(f"  • {item['equipment_id']} ({item['type_name']}) - Health: {item['health_score']:.3f}")
            
            # Summary
            total_items = len(data)
            print(f"\n{Fore.CYAN}Health Summary:{Style.RESET_ALL}")
            print(f"Total Active Equipment: {total_items}")
            print(f"Critical: {len(critical_items)} ({len(critical_items)/total_items*100:.1f}%)")
            print(f"Warning: {len(warning_items)} ({len(warning_items)/total_items*100:.1f}%)")
            print(f"Normal: {len(normal_items)} ({len(normal_items)/total_items*100:.1f}%)")
            
        except Exception as e:
            print(f"{Fore.RED}Error generating health dashboard: {e}{Style.RESET_ALL}")
    
    def failure_analysis_report(self):
        """Generate failure analysis report."""
        print(f"\n{Fore.GREEN}=== FAILURE ANALYSIS REPORT ==={Style.RESET_ALL}")
        
        try:
            days_back = int(input(f"{Fore.CYAN}Analysis period in days (default 90): {Style.RESET_ALL}") or "90")
            
            # Failure statistics
            failure_query = """
                SELECT 
                    et.type_name,
                    COUNT(fl.id) as failure_count,
                    AVG(fl.resolution_time_minutes) as avg_resolution_time,
                    COUNT(CASE WHEN fl.severity = 'critical' THEN 1 END) as critical_failures,
                    COUNT(CASE WHEN fl.severity = 'high' THEN 1 END) as high_failures,
                    COUNT(DISTINCT e.id) as affected_equipment_count,
                    COUNT(DISTINCT fl.failure_type) as unique_failure_types
                FROM failure_logs fl
                JOIN equipment e ON fl.equipment_id = e.id
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE fl.failure_timestamp >= DATE_SUB(NOW(), INTERVAL %s DAY)
                GROUP BY et.id, et.type_name
                ORDER BY failure_count DESC
            """
            
            # Top failure types
            failure_type_query = """
                SELECT 
                    fl.failure_type,
                    COUNT(*) as occurrence_count,
                    AVG(fl.resolution_time_minutes) as avg_resolution_time,
                    COUNT(CASE WHEN fl.severity IN ('critical', 'high') THEN 1 END) as high_severity_count
                FROM failure_logs fl
                WHERE fl.failure_timestamp >= DATE_SUB(NOW(), INTERVAL %s DAY)
                GROUP BY fl.failure_type
                ORDER BY occurrence_count DESC
                LIMIT 10
            """
            
            failure_data = db_manager.execute_query(failure_query, (days_back,))
            failure_type_data = db_manager.execute_query(failure_type_query, (days_back,))
            
            print(f"\n{Fore.WHITE}Failure Analysis Report - Last {days_back} Days{Style.RESET_ALL}")
            
            if failure_data:
                print(f"\n{Fore.CYAN}Failures by Equipment Type:{Style.RESET_ALL}")
                headers = ['Equipment Type', 'Failures', 'Avg Resolution (mins)', 'Critical', 'High', 'Equipment Affected', 'Unique Types']
                table_data = []
                
                for item in failure_data:
                    table_data.append([
                        item['type_name'],
                        item['failure_count'],
                        f"{item['avg_resolution_time']:.0f}" if item['avg_resolution_time'] else 'N/A',
                        item['critical_failures'],
                        item['high_failures'],
                        item['affected_equipment_count'],
                        item['unique_failure_types']
                    ])
                
                print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
            if failure_type_data:
                print(f"\n{Fore.CYAN}Top Failure Types:{Style.RESET_ALL}")
                headers = ['Failure Type', 'Occurrences', 'Avg Resolution (mins)', 'High Severity Count']
                table_data = []
                
                for item in failure_type_data:
                    table_data.append([
                        item['failure_type'].replace('_', ' ').title(),
                        item['occurrence_count'],
                        f"{item['avg_resolution_time']:.0f}" if item['avg_resolution_time'] else 'N/A',
                        item['high_severity_count']
                    ])
                
                print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
            # Calculate MTTR and MTBF if we have data
            if failure_data:
                total_failures = sum(item['failure_count'] for item in failure_data)
                if total_failures > 0:
                    total_equipment = db_manager.execute_query("SELECT COUNT(*) as count FROM equipment WHERE status = 'active'", fetch_one=True)['count']
                    
                    print(f"\n{Fore.CYAN}Key Metrics:{Style.RESET_ALL}")
                    print(f"Total Failures: {total_failures}")
                    print(f"Failure Rate: {total_failures/total_equipment:.2f} failures per equipment")
                    print(f"Average Time to Recovery: {sum(item['avg_resolution_time'] or 0 for item in failure_data)/len(failure_data):.0f} minutes")
            else:
                print(f"\n{Fore.GREEN}No failures recorded in the specified period.{Style.RESET_ALL}")
                
        except ValueError:
            print(f"{Fore.RED}Invalid number of days.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error generating failure analysis: {e}{Style.RESET_ALL}")
    
    def maintenance_performance_report(self):
        """Generate maintenance performance report."""
        print(f"\n{Fore.GREEN}=== MAINTENANCE PERFORMANCE REPORT ==={Style.RESET_ALL}")
        
        try:
            days_back = int(input(f"{Fore.CYAN}Analysis period in days (default 180): {Style.RESET_ALL}") or "180")
            
            # Maintenance performance metrics
            performance_query = """
                SELECT 
                    et.type_name,
                    COUNT(mh.id) as total_maintenance,
                    COUNT(CASE WHEN mh.status = 'completed' THEN 1 END) as completed_maintenance,
                    COUNT(CASE WHEN mh.maintenance_type = 'preventive' THEN 1 END) as preventive_count,
                    COUNT(CASE WHEN mh.maintenance_type = 'corrective' THEN 1 END) as corrective_count,
                    COUNT(CASE WHEN mh.maintenance_type = 'emergency' THEN 1 END) as emergency_count,
                    AVG(mh.cost) as avg_cost,
                    SUM(mh.cost) as total_cost,
                    AVG(mh.downtime_minutes) as avg_downtime,
                    SUM(mh.downtime_minutes) as total_downtime
                FROM maintenance_history mh
                JOIN equipment e ON mh.equipment_id = e.id
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE mh.scheduled_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
                GROUP BY et.id, et.type_name
                ORDER BY total_maintenance DESC
            """
            
            # Completion rate over time
            completion_trend_query = """
                SELECT 
                    DATE_FORMAT(mh.scheduled_date, '%%Y-%%m') as month,
                    COUNT(mh.id) as scheduled,
                    COUNT(CASE WHEN mh.status = 'completed' THEN 1 END) as completed,
                    (COUNT(CASE WHEN mh.status = 'completed' THEN 1 END) / COUNT(mh.id) * 100) as completion_rate
                FROM maintenance_history mh
                WHERE mh.scheduled_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
                GROUP BY DATE_FORMAT(mh.scheduled_date, '%%Y-%%m')
                ORDER BY month DESC
                LIMIT 12
            """
            
            performance_data = db_manager.execute_query(performance_query, (days_back,))
            completion_data = db_manager.execute_query(completion_trend_query, (days_back,))
            
            print(f"\n{Fore.WHITE}Maintenance Performance Report - Last {days_back} Days{Style.RESET_ALL}")
            
            if performance_data:
                print(f"\n{Fore.CYAN}Performance by Equipment Type:{Style.RESET_ALL}")
                headers = ['Equipment Type', 'Total', 'Completed', 'Preventive', 'Corrective', 'Emergency', 'Avg Cost', 'Total Cost', 'Avg Downtime (hrs)']
                table_data = []
                
                total_cost = 0
                total_downtime = 0
                
                for item in performance_data:
                    total_cost += item['total_cost'] or 0
                    total_downtime += item['total_downtime'] or 0
                    
                    completion_rate = (item['completed_maintenance'] / item['total_maintenance'] * 100) if item['total_maintenance'] > 0 else 0
                    
                    table_data.append([
                        item['type_name'],
                        item['total_maintenance'],
                        f"{item['completed_maintenance']} ({completion_rate:.1f}%)",
                        item['preventive_count'],
                        item['corrective_count'],
                        item['emergency_count'],
                        f"${item['avg_cost']:.0f}" if item['avg_cost'] else 'N/A',
                        f"${item['total_cost']:.0f}" if item['total_cost'] else '$0',
                        f"{(item['avg_downtime'] or 0) / 60:.1f}"
                    ])
                
                print(tabulate(table_data, headers=headers, tablefmt='grid'))
                
                print(f"\n{Fore.CYAN}Overall Totals:{Style.RESET_ALL}")
                print(f"Total Maintenance Cost: ${total_cost:.0f}")
                print(f"Total Downtime: {total_downtime / 60:.1f} hours")
            
            if completion_data:
                print(f"\n{Fore.CYAN}Monthly Completion Trends:{Style.RESET_ALL}")
                headers = ['Month', 'Scheduled', 'Completed', 'Completion Rate']
                table_data = []
                
                for item in completion_data:
                    table_data.append([
                        item['month'],
                        item['scheduled'],
                        item['completed'],
                        f"{item['completion_rate']:.1f}%"
                    ])
                
                print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
        except ValueError:
            print(f"{Fore.RED}Invalid number of days.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error generating maintenance performance report: {e}{Style.RESET_ALL}")
    
    def predictive_analytics_summary(self):
        """Generate predictive analytics summary."""
        print(f"\n{Fore.GREEN}=== PREDICTIVE ANALYTICS SUMMARY ==={Style.RESET_ALL}")
        
        try:
            risk_threshold = input(f"{Fore.CYAN}Risk threshold (low/medium/high/critical) [default: medium]: {Style.RESET_ALL}").strip().lower() or 'medium'
            
            threshold_values = {
                'low': 0.3,
                'medium': 0.5,
                'high': 0.7,
                'critical': 0.9
            }
            
            threshold_value = threshold_values.get(risk_threshold, 0.5)
            
            # Recent predictions analysis
            predictions_query = """
                SELECT 
                    et.type_name,
                    COUNT(p.id) as total_predictions,
                    COUNT(CASE WHEN p.failure_probability >= %s THEN 1 END) as high_risk_predictions,
                    AVG(p.failure_probability) as avg_failure_probability,
                    MAX(p.failure_probability) as max_failure_probability,
                    COUNT(CASE WHEN p.failure_probability >= 0.9 THEN 1 END) as critical_risk_count,
                    COUNT(DISTINCT p.equipment_id) as equipment_analyzed
                FROM predictions p
                JOIN equipment e ON p.equipment_id = e.id
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE p.prediction_timestamp >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                GROUP BY et.id, et.type_name
                ORDER BY avg_failure_probability DESC
            """
            
            # Prediction accuracy (if we have failure data to compare)
            accuracy_query = """
                SELECT 
                    COUNT(p.id) as predictions_made,
                    COUNT(CASE WHEN fl.id IS NOT NULL AND p.failure_probability >= 0.7 THEN 1 END) as correct_high_risk,
                    COUNT(CASE WHEN fl.id IS NULL AND p.failure_probability < 0.3 THEN 1 END) as correct_low_risk,
                    COUNT(fl.id) as actual_failures
                FROM predictions p
                LEFT JOIN failure_logs fl ON p.equipment_id = fl.equipment_id
                    AND fl.failure_timestamp BETWEEN p.prediction_timestamp 
                    AND DATE_ADD(p.prediction_timestamp, INTERVAL 30 DAY)
                WHERE p.prediction_timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            """
            
            predictions_data = db_manager.execute_query(predictions_query, (threshold_value,))
            accuracy_data = db_manager.execute_query(accuracy_query, fetch_one=True)
            
            print(f"\n{Fore.WHITE}Predictive Analytics Summary - Last 7 Days{Style.RESET_ALL}")
            print(f"Risk Threshold: {risk_threshold.upper()} ({threshold_value:.1f})")
            
            if predictions_data:
                print(f"\n{Fore.CYAN}Predictions by Equipment Type:{Style.RESET_ALL}")
                headers = ['Equipment Type', 'Total Predictions', 'High Risk', 'Critical Risk', 'Avg Risk Score', 'Max Risk Score', 'Equipment Analyzed']
                table_data = []
                
                total_predictions = 0
                total_high_risk = 0
                
                for item in predictions_data:
                    total_predictions += item['total_predictions']
                    total_high_risk += item['high_risk_predictions']
                    
                    table_data.append([
                        item['type_name'],
                        item['total_predictions'],
                        item['high_risk_predictions'],
                        item['critical_risk_count'],
                        f"{item['avg_failure_probability']:.3f}",
                        f"{item['max_failure_probability']:.3f}",
                        item['equipment_analyzed']
                    ])
                
                print(tabulate(table_data, headers=headers, tablefmt='grid'))
                
                print(f"\n{Fore.CYAN}Summary Statistics:{Style.RESET_ALL}")
                print(f"Total Predictions Made: {total_predictions}")
                print(f"High Risk Predictions: {total_high_risk} ({total_high_risk/total_predictions*100:.1f}%)" if total_predictions > 0 else "No predictions available")
            
            if accuracy_data and accuracy_data['predictions_made'] > 0:
                print(f"\n{Fore.CYAN}Prediction Accuracy (Last 30 Days):{Style.RESET_ALL}")
                print(f"Total Predictions: {accuracy_data['predictions_made']}")
                print(f"Actual Failures: {accuracy_data['actual_failures']}")
                print(f"Correct High Risk Predictions: {accuracy_data['correct_high_risk']}")
                print(f"Correct Low Risk Predictions: {accuracy_data['correct_low_risk']}")
                
                if accuracy_data['actual_failures'] > 0:
                    precision = accuracy_data['correct_high_risk'] / accuracy_data['actual_failures']
                    print(f"Prediction Precision: {precision:.2f}")
            
        except Exception as e:
            print(f"{Fore.RED}Error generating predictive analytics summary: {e}{Style.RESET_ALL}")
    
    def cost_analysis_report(self):
        """Generate cost analysis report."""
        print(f"\n{Fore.GREEN}=== COST ANALYSIS REPORT ==={Style.RESET_ALL}")
        
        try:
            days_back = int(input(f"{Fore.CYAN}Analysis period in days (default 365): {Style.RESET_ALL}") or "365")
            
            # Cost breakdown by equipment type
            cost_query = """
                SELECT 
                    et.type_name,
                    COUNT(DISTINCT e.id) as equipment_count,
                    COUNT(mh.id) as maintenance_events,
                    SUM(mh.cost) as total_maintenance_cost,
                    AVG(mh.cost) as avg_maintenance_cost,
                    SUM(mh.cost) / COUNT(DISTINCT e.id) as cost_per_equipment,
                    SUM(CASE WHEN mh.maintenance_type = 'emergency' THEN mh.cost ELSE 0 END) as emergency_costs,
                    SUM(CASE WHEN mh.maintenance_type = 'preventive' THEN mh.cost ELSE 0 END) as preventive_costs
                FROM equipment_types et
                LEFT JOIN equipment e ON et.id = e.equipment_type_id
                LEFT JOIN maintenance_history mh ON e.id = mh.equipment_id 
                    AND mh.scheduled_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
                    AND mh.status = 'completed'
                GROUP BY et.id, et.type_name
                ORDER BY total_maintenance_cost DESC
            """
            
            # Monthly cost trends
            monthly_cost_query = """
                SELECT 
                    DATE_FORMAT(mh.scheduled_date, '%%Y-%%m') as month,
                    COUNT(mh.id) as maintenance_count,
                    SUM(mh.cost) as total_cost,
                    AVG(mh.cost) as avg_cost,
                    SUM(CASE WHEN mh.maintenance_type = 'emergency' THEN mh.cost ELSE 0 END) as emergency_cost,
                    SUM(CASE WHEN mh.maintenance_type = 'preventive' THEN mh.cost ELSE 0 END) as preventive_cost
                FROM maintenance_history mh
                WHERE mh.scheduled_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
                AND mh.status = 'completed'
                AND mh.cost IS NOT NULL
                GROUP BY DATE_FORMAT(mh.scheduled_date, '%%Y-%%m')
                ORDER BY month DESC
                LIMIT 12
            """
            
            cost_data = db_manager.execute_query(cost_query, (days_back,))
            monthly_data = db_manager.execute_query(monthly_cost_query, (days_back,))
            
            print(f"\n{Fore.WHITE}Cost Analysis Report - Last {days_back} Days{Style.RESET_ALL}")
            
            if cost_data:
                print(f"\n{Fore.CYAN}Cost Analysis by Equipment Type:{Style.RESET_ALL}")
                headers = ['Equipment Type', 'Equipment Count', 'Maintenance Events', 'Total Cost', 'Avg Cost/Event', 'Cost/Equipment', 'Emergency Cost', 'Preventive Cost']
                table_data = []
                
                grand_total = 0
                total_emergency = 0
                total_preventive = 0
                
                for item in cost_data:
                    total_cost = item['total_maintenance_cost'] or 0
                    emergency_cost = item['emergency_costs'] or 0
                    preventive_cost = item['preventive_costs'] or 0
                    
                    grand_total += total_cost
                    total_emergency += emergency_cost
                    total_preventive += preventive_cost
                    
                    table_data.append([
                        item['type_name'],
                        item['equipment_count'],
                        item['maintenance_events'] or 0,
                        f"${total_cost:.0f}",
                        f"${item['avg_maintenance_cost']:.0f}" if item['avg_maintenance_cost'] else '$0',
                        f"${item['cost_per_equipment']:.0f}" if item['cost_per_equipment'] else '$0',
                        f"${emergency_cost:.0f}",
                        f"${preventive_cost:.0f}"
                    ])
                
                print(tabulate(table_data, headers=headers, tablefmt='grid'))
                
                print(f"\n{Fore.CYAN}Cost Summary:{Style.RESET_ALL}")
                print(f"Grand Total: ${grand_total:.0f}")
                print(f"Emergency Costs: ${total_emergency:.0f} ({total_emergency/grand_total*100:.1f}%)" if grand_total > 0 else "Emergency Costs: $0")
                print(f"Preventive Costs: ${total_preventive:.0f} ({total_preventive/grand_total*100:.1f}%)" if grand_total > 0 else "Preventive Costs: $0")
                
                # Cost efficiency ratio
                if total_emergency > 0 and total_preventive > 0:
                    efficiency_ratio = total_preventive / total_emergency
                    print(f"Preventive/Emergency Cost Ratio: {efficiency_ratio:.2f}")
                    if efficiency_ratio < 1:
                        print(f"{Fore.YELLOW}⚠️ Consider increasing preventive maintenance to reduce emergency costs.{Style.RESET_ALL}")
            
            if monthly_data:
                print(f"\n{Fore.CYAN}Monthly Cost Trends:{Style.RESET_ALL}")
                headers = ['Month', 'Maintenance Count', 'Total Cost', 'Avg Cost', 'Emergency Cost', 'Preventive Cost']
                table_data = []
                
                for item in monthly_data:
                    table_data.append([
                        item['month'],
                        item['maintenance_count'],
                        f"${item['total_cost']:.0f}" if item['total_cost'] else '$0',
                        f"${item['avg_cost']:.0f}" if item['avg_cost'] else '$0',
                        f"${item['emergency_cost']:.0f}" if item['emergency_cost'] else '$0',
                        f"${item['preventive_cost']:.0f}" if item['preventive_cost'] else '$0'
                    ])
                
                print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
        except ValueError:
            print(f"{Fore.RED}Invalid number of days.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error generating cost analysis: {e}{Style.RESET_ALL}")
    
    # System Management Functions
    def system_management_menu(self):
        """System management submenu."""
        while True:
            print(f"\n{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            print(f"{Fore.WHITE}                   SYSTEM MANAGEMENT{Style.RESET_ALL}")
            print(f"{Fore.BLUE}{'='*60}{Style.RESET_ALL}")
            
            options = [
                ("1", "Database Status"),
                ("2", "Generate Training Data"),
                ("3", "System Configuration"),
                ("4", "Export Data"),
                ("5", "System Logs"),
                ("6", "Backup Database"),
                ("0", "Back to Main Menu")
            ]
            
            for option, title in options:
                print(f"{Fore.CYAN}{option}. {Fore.WHITE}{title}{Style.RESET_ALL}")
            
            choice = input(f"\n{Fore.CYAN}Enter your choice: {Style.RESET_ALL}").strip()
            
            if choice == '1':
                self.show_database_status()
            elif choice == '2':
                self.generate_training_data()
            elif choice == '3':
                self.show_system_config()
            elif choice == '4':
                self.export_data()
            elif choice == '5':
                self.show_system_logs()
            elif choice == '6':
                self.backup_database()
            elif choice == '0':
                break
            else:
                print(f"{Fore.RED}Invalid choice.{Style.RESET_ALL}")
    
    def show_database_status(self):
        """Show database connection and statistics."""
        print(f"\n{Fore.GREEN}=== DATABASE STATUS ==={Style.RESET_ALL}")
        
        try:
            # Test connection
            if db_manager.test_connection():
                print(f"{Fore.GREEN}✓ Database Connection: Active{Style.RESET_ALL}")
            else:
                print(f"{Fore.RED}✗ Database Connection: Failed{Style.RESET_ALL}")
                return
            
            # Get table statistics
            tables = [
                'equipment_types', 'equipment', 'health_metrics', 
                'maintenance_history', 'failure_logs', 'predictions'
            ]
            
            print(f"\n{Fore.WHITE}Table Statistics:{Style.RESET_ALL}")
            table_data = []
            total_records = 0
            
            for table in tables:
                try:
                    result = db_manager.execute_query(f"SELECT COUNT(*) as count FROM {table}", fetch_one=True)
                    count = result['count'] if result else 0
                    total_records += count
                    
                    # Get table size information
                    size_query = f"""
                        SELECT 
                            ROUND(((data_length + index_length) / 1024 / 1024), 2) AS size_mb
                        FROM information_schema.TABLES 
                        WHERE table_schema = DATABASE() AND table_name = '{table}'
                    """
                    size_result = db_manager.execute_query(size_query, fetch_one=True)
                    size_mb = size_result['size_mb'] if size_result else 0
                    
                    table_data.append([table, f"{count:,}", f"{size_mb:.2f} MB"])
                    
                except Exception as e:
                    table_data.append([table, "Error", f"Error: {str(e)[:20]}..."])
            
            headers = ['Table', 'Records', 'Size']
            print(tabulate(table_data, headers=headers, tablefmt='grid'))
            
            print(f"\n{Fore.CYAN}Total Records: {total_records:,}{Style.RESET_ALL}")
            
            # Database performance metrics
            print(f"\n{Fore.WHITE}Database Performance:{Style.RESET_ALL}")
            perf_queries = [
                ("Active Connections", "SHOW STATUS LIKE 'Threads_connected'"),
                ("Queries per Second", "SHOW STATUS LIKE 'Questions'"),
                ("Uptime", "SHOW STATUS LIKE 'Uptime'")
            ]
            
            for metric, query in perf_queries:
                try:
                    result = db_manager.execute_query(query, fetch_one=True)
                    if result:
                        value = list(result.values())[1] if len(result.values()) > 1 else 'N/A'
                        if metric == "Uptime" and str(value).isdigit():
                            hours = int(value) / 3600
                            print(f"{metric}: {hours:.1f} hours")
                        else:
                            print(f"{metric}: {value}")
                except Exception:
                    print(f"{metric}: N/A")
            
        except Exception as e:
            print(f"{Fore.RED}Error checking database status: {e}{Style.RESET_ALL}")
    
    def generate_training_data(self):
        """Generate synthetic training data."""
        print(f"\n{Fore.GREEN}=== GENERATE TRAINING DATA ==={Style.RESET_ALL}")
        print(f"{Fore.YELLOW}Warning: This will generate synthetic data for training ML models.{Style.RESET_ALL}")
        
        confirm = input(f"{Fore.CYAN}Continue? (y/N): {Style.RESET_ALL}").strip().lower()
        if confirm != 'y':
            return
        
        try:
            # Import and run training data generator
            from insert_training_data import TrainingDataGenerator
            
            generator = TrainingDataGenerator()
            
            # Get parameters
            num_equipment = int(input(f"{Fore.CYAN}Equipment per type (default 5): {Style.RESET_ALL}") or "5")
            days_data = int(input(f"{Fore.CYAN}Days of data (default 30): {Style.RESET_ALL}") or "30")
            
            print(f"\n{Fore.YELLOW}Generating training data...{Style.RESET_ALL}")
            success = generator.generate_complete_dataset(
                num_equipment_per_type=num_equipment,
                days_of_data=days_data,
                measurements_per_day=12  # Every 2 hours
            )
            
            if success:
                print(f"{Fore.GREEN}✓ Training data generated successfully!{Style.RESET_ALL}")
            else:
                print(f"{Fore.RED}✗ Training data generation failed.{Style.RESET_ALL}")
                
        except ImportError:
            print(f"{Fore.RED}Training data generator module not found.{Style.RESET_ALL}")
        except Exception as e:
            print(f"{Fore.RED}Error generating training data: {e}{Style.RESET_ALL}")
    
    def show_system_config(self):
        """Show system configuration."""
        print(f"\n{Fore.GREEN}=== SYSTEM CONFIGURATION ==={Style.RESET_ALL}")
        
        try:
            from config.database_config import db_config
            from config.ml_config import ml_config
            
            print(f"\n{Fore.CYAN}Database Configuration:{Style.RESET_ALL}")
            print(f"Host: {db_config.host}")
            print(f"Port: {db_config.port}")
            print(f"Database: {db_config.database}")
            print(f"User: {db_config.user}")
            print(f"Connection Pool Size: {db_config.pool_size}")
            
            print(f"\n{Fore.CYAN}ML Configuration:{Style.RESET_ALL}")
            print(f"Model Storage Path: {ml_config.model_base_path}")
            print(f"Feature Count: {len(ml_config.feature_columns)}")
            print(f"Test Size: {ml_config.test_size}")
            print(f"Random Forest Estimators: {ml_config.random_forest_params['n_estimators']}")
            print(f"Failure Probability Threshold: {ml_config.failure_probability_threshold}")
            print(f"High Risk Threshold: {ml_config.high_risk_threshold}")
            print(f"Critical Risk Threshold: {ml_config.critical_risk_threshold}")
            
            print(f"\n{Fore.CYAN}Feature Columns:{Style.RESET_ALL}")
            for i, feature in enumerate(ml_config.feature_columns, 1):
                print(f"{i:2d}. {feature}")
            
        except Exception as e:
            print(f"{Fore.RED}Error displaying system configuration: {e}{Style.RESET_ALL}")
    
    def export_data(self):
        """Export system data to files."""
        print(f"\n{Fore.GREEN}=== EXPORT DATA ==={Style.RESET_ALL}")
        
        try:
            print(f"\n{Fore.CYAN}Export Options:{Style.RESET_ALL}")
            print("1. Equipment Data")
            print("2. Health Metrics (Last 30 Days)")
            print("3. Maintenance History")
            print("4. Failure Logs")
            print("5. All Data")
            
            choice = input(f"{Fore.CYAN}Select export type (1-5): {Style.RESET_ALL}").strip()
            
            date_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
            export_path = f"exports_{date_suffix}"
            
            # Create exports directory
            import os
            if not os.path.exists(export_path):
                os.makedirs(export_path)
            
            exports_completed = []
            
            if choice in ['1', '5']:  # Equipment Data
                query = """
                    SELECT e.*, et.type_name, et.description as type_description
                    FROM equipment e
                    JOIN equipment_types et ON e.equipment_type_id = et.id
                    ORDER BY e.equipment_id
                """
                self._export_to_csv(query, f"{export_path}/equipment_data.csv", "Equipment Data")
                exports_completed.append("Equipment Data")
            
            if choice in ['2', '5']:  # Health Metrics
                query = """
                    SELECT hm.*, e.equipment_id, et.type_name
                    FROM health_metrics hm
                    JOIN equipment e ON hm.equipment_id = e.id
                    JOIN equipment_types et ON e.equipment_type_id = et.id
                    WHERE hm.timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                    ORDER BY hm.timestamp DESC
                """
                self._export_to_csv(query, f"{export_path}/health_metrics.csv", "Health Metrics")
                exports_completed.append("Health Metrics")
            
            if choice in ['3', '5']:  # Maintenance History
                query = """
                    SELECT mh.*, e.equipment_id, et.type_name
                    FROM maintenance_history mh
                    JOIN equipment e ON mh.equipment_id = e.id
                    JOIN equipment_types et ON e.equipment_type_id = et.id
                    ORDER BY mh.scheduled_date DESC
                """
                self._export_to_csv(query, f"{export_path}/maintenance_history.csv", "Maintenance History")
                exports_completed.append("Maintenance History")
            
            if choice in ['4', '5']:  # Failure Logs
                query = """
                    SELECT fl.*, e.equipment_id, et.type_name
                    FROM failure_logs fl
                    JOIN equipment e ON fl.equipment_id = e.id
                    JOIN equipment_types et ON e.equipment_type_id = et.id
                    ORDER BY fl.failure_timestamp DESC
                """
                self._export_to_csv(query, f"{export_path}/failure_logs.csv", "Failure Logs")
                exports_completed.append("Failure Logs")
            
            if exports_completed:
                print(f"\n{Fore.GREEN}✓ Export completed successfully!{Style.RESET_ALL}")
                print(f"Exported: {', '.join(exports_completed)}")
                print(f"Location: {export_path}/")
            else:
                print(f"{Fore.YELLOW}No exports completed.{Style.RESET_ALL}")
                
        except Exception as e:
            print(f"{Fore.RED}Error exporting data: {e}{Style.RESET_ALL}")
    
    def _export_to_csv(self, query: str, filename: str, description: str):
        """Export query results to CSV file."""
        try:
            import csv
            data = db_manager.execute_query(query)
            
            if data:
                with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                    if data:
                        fieldnames = data[0].keys()
                        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                        writer.writeheader()
                        writer.writerows(data)
                
                print(f"✓ {description}: {len(data)} records exported to {filename}")
            else:
                print(f"⚠️ {description}: No data found")
                
        except Exception as e:
            print(f"✗ {description}: Export failed - {e}")
    
    def show_system_logs(self):
        """Display recent system logs."""
        print(f"\n{Fore.GREEN}=== SYSTEM LOGS ==={Style.RESET_ALL}")
        
        try:
            log_file = 'telecom_maintenance.log'
            
            if not os.path.exists(log_file):
                print(f"{Fore.YELLOW}Log file not found: {log_file}{Style.RESET_ALL}")
                return
            
            # Get log filter options
            print(f"\n{Fore.CYAN}Log Level Filter:{Style.RESET_ALL}")
            print("1. All Logs")
            print("2. INFO and above")
            print("3. WARNING and above")
            print("4. ERROR only")
            
            filter_choice = input(f"{Fore.CYAN}Select filter (1-4): {Style.RESET_ALL}").strip()
            
            num_lines = int(input(f"{Fore.CYAN}Number of recent lines (default 50): {Style.RESET_ALL}") or "50")
            
            # Read log file
            with open(log_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # Apply filters
            filtered_lines = []
            for line in lines:
                if filter_choice == '1':  # All logs
                    filtered_lines.append(line)
                elif filter_choice == '2' and ('INFO' in line or 'WARNING' in line or 'ERROR' in line):
                    filtered_lines.append(line)
                elif filter_choice == '3' and ('WARNING' in line or 'ERROR' in line):
                    filtered_lines.append(line)
                elif filter_choice == '4' and 'ERROR' in line:
                    filtered_lines.append(line)
            
            # Show recent lines
            recent_lines = filtered_lines[-num_lines:] if filtered_lines else []
            
            if recent_lines:
                print(f"\n{Fore.WHITE}Recent Log Entries ({len(recent_lines)} lines):{Style.RESET_ALL}")
                print("-" * 100)
                
                for line in recent_lines:
                    line = line.strip()
                    if 'ERROR' in line:
                        print(f"{Fore.RED}{line}{Style.RESET_ALL}")
                    elif 'WARNING' in line:
                        print(f"{Fore.YELLOW}{line}{Style.RESET_ALL}")
                    elif 'INFO' in line:
                        print(f"{Fore.GREEN}{line}{Style.RESET_ALL}")
                    else:
                        print(line)
            else:
                print(f"{Fore.YELLOW}No log entries found matching criteria.{Style.RESET_ALL}")
                
        except Exception as e:
            print(f"{Fore.RED}Error reading system logs: {e}{Style.RESET_ALL}")
    
    def backup_database(self):
        """Create database backup."""
        print(f"\n{Fore.GREEN}=== DATABASE BACKUP ==={Style.RESET_ALL}")
        
        try:
            from config.database_config import db_config
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_file = f"backup_telecom_maintenance_{timestamp}.sql"
            
            print(f"{Fore.YELLOW}Creating database backup...{Style.RESET_ALL}")
            print(f"Backup file: {backup_file}")
            
            # Create mysqldump command
            dump_cmd = f"mysqldump -h {db_config.host} -u {db_config.user}"
            if db_config.password:
                dump_cmd += f" -p{db_config.password}"
            dump_cmd += f" {db_config.database} > {backup_file}"
            
            print(f"{Fore.CYAN}Execute the following command to create backup:{Style.RESET_ALL}")
            print(f"{dump_cmd}")
            
            print(f"\n{Fore.YELLOW}Note: Backup functionality requires mysqldump to be installed and accessible.{Style.RESET_ALL}")
            print(f"Alternative: Use your database management tool to export the database.")
            
        except Exception as e:
            print(f"{Fore.RED}Error setting up database backup: {e}{Style.RESET_ALL}")

def main():
    """Main entry point."""
    try:
        app = TelecomMaintenanceApp()
        app.run()
    except KeyboardInterrupt:
        print(f"\n{Fore.YELLOW}Application interrupted.{Style.RESET_ALL}")
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        print(f"{Fore.RED}Fatal error: {e}{Style.RESET_ALL}")

if __name__ == "__main__":
    main()
