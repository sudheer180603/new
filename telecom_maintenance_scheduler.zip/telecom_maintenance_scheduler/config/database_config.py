"""Database configuration management."""
import os
from dotenv import load_dotenv

load_dotenv()

class DatabaseConfig:
    """Database connection configuration."""
    
    def __init__(self):
        self.host = os.getenv('DB_HOST', 'localhost')
        self.port = int(os.getenv('DB_PORT', 3306))
        self.database = os.getenv('DB_NAME', 'telecom_maintenance')
        self.user = os.getenv('DB_USER', 'root')
        self.password = os.getenv('DB_PASSWORD', 'root')
        self.charset = 'utf8mb4'
        self.autocommit = True
        self.pool_size = 10
        self.pool_reset_session = True
        
    def get_connection_params(self):
        """Get database connection parameters."""
        return {
            'host': self.host,
            'port': self.port,
            'database': self.database,
            'user': self.user,
            'password': self.password,
            'charset': self.charset,
            'autocommit': self.autocommit
        }
    
    def get_pool_params(self):
        """Get connection pool parameters."""
        params = self.get_connection_params()
        params.update({
            'pool_size': self.pool_size,
            'pool_reset_session': self.pool_reset_session
        })
        return params

db_config = DatabaseConfig()
