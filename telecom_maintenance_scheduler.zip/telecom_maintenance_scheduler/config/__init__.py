"""Configuration package for Telecom Equipment Maintenance Scheduler."""
__version__ = "1.0.0"
__author__ = "Telecom Maintenance Team"
