"""Machine learning configuration and hyperparameters."""
import os

class MLConfig:
    """Machine learning model configuration."""
    
    def __init__(self):
        self.model_base_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'models')
        self.model_extension = '.pkl'
        
        self.feature_columns = [
            'cpu_usage', 'memory_usage', 'temperature', 'power_consumption',
            'uptime_hours', 'packet_loss_rate', 'error_count', 
            'bandwidth_utilization', 'signal_strength'
        ]
        
        self.random_forest_params = {
            'n_estimators': 100,
            'max_depth': 10,
            'min_samples_split': 5,
            'min_samples_leaf': 2,
            'random_state': 42,
            'n_jobs': -1
        }
        
        self.test_size = 0.2
        self.validation_size = 0.15
        self.cv_folds = 5
        self.random_state = 42
        
        self.failure_probability_threshold = 0.7
        self.high_risk_threshold = 0.8
        self.critical_risk_threshold = 0.9
        
        self.missing_value_strategy = 'median'
        self.outlier_detection_method = 'isolation_forest'
        self.feature_scaling = True
        
        self.primary_metric = 'f1_score'
        self.secondary_metrics = ['precision', 'recall', 'roc_auc']
        
        self.min_samples_for_training = 100
        self.retrain_threshold_days = 30
        self.model_performance_threshold = 0.75
        
    def get_model_path(self, equipment_type):
        """Get the file path for a specific equipment type model."""
        if not os.path.exists(self.model_base_path):
            os.makedirs(self.model_base_path)
        return os.path.join(self.model_base_path, f"{equipment_type}_model{self.model_extension}")
    
    def get_feature_importance_path(self, equipment_type):
        """Get the file path for feature importance data."""
        return os.path.join(self.model_base_path, f"{equipment_type}_feature_importance.json")

ml_config = MLConfig()
