"""Equipment management module for CRUD operations and asset lifecycle management."""
import logging
from typing import List, Dict, Optional, Any
from datetime import datetime, date
from utils.database_utils import db_manager
from utils.validation_utils import ValidationUtils

logger = logging.getLogger(__name__)

class EquipmentManager:
    """Manages equipment assets and their lifecycle data."""
    
    def __init__(self):
        self.db = db_manager
        self.validator = ValidationUtils()
    
    def add_equipment(self, equipment_data: Dict[str, Any]) -> Optional[int]:
        """Add new equipment to the system."""
        try:
            if not self._validate_equipment_data(equipment_data):
                return None
            
            query = """
                INSERT INTO equipment (equipment_id, equipment_type_id, location, 
                                     installation_date, manufacturer, model, firmware_version, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            params = (
                equipment_data['equipment_id'],
                equipment_data['equipment_type_id'],
                equipment_data.get('location', ''),
                equipment_data.get('installation_date'),
                equipment_data.get('manufacturer', ''),
                equipment_data.get('model', ''),
                equipment_data.get('firmware_version', ''),
                equipment_data.get('status', 'active')
            )
            
            equipment_id = self.db.execute_insert(query, params)
            logger.info(f"Equipment {equipment_data['equipment_id']} added successfully with ID: {equipment_id}")
            return equipment_id
            
        except Exception as e:
            logger.error(f"Error adding equipment: {e}")
            return None
    
    def get_equipment_by_id(self, equipment_id: str) -> Optional[Dict]:
        """Retrieve equipment details by equipment ID."""
        try:
            query = """
                SELECT e.*, et.type_name, et.description as type_description
                FROM equipment e
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE e.equipment_id = %s
            """
            
            result = self.db.execute_query(query, (equipment_id,), fetch_one=True)
            return result
            
        except Exception as e:
            logger.error(f"Error retrieving equipment {equipment_id}: {e}")
            return None
    
    def get_all_equipment(self, equipment_type: Optional[str] = None, 
                         status: Optional[str] = None) -> List[Dict]:
        """Retrieve all equipment with optional filtering."""
        try:
            base_query = """
                SELECT e.*, et.type_name, et.description as type_description
                FROM equipment e
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE 1=1
            """
            
            params = []
            
            if equipment_type:
                base_query += " AND et.type_name = %s"
                params.append(equipment_type)
            
            if status:
                base_query += " AND e.status = %s"
                params.append(status)
            
            base_query += " ORDER BY e.equipment_id"
            
            return self.db.execute_query(base_query, tuple(params) if params else None)
            
        except Exception as e:
            logger.error(f"Error retrieving equipment list: {e}")
            return []
    
    def update_equipment(self, equipment_id: str, update_data: Dict[str, Any]) -> bool:
        """Update equipment information."""
        try:
            if not update_data:
                return False
            
            set_clauses = []
            params = []
            
            allowed_fields = ['location', 'status', 'manufacturer', 'model', 
                            'firmware_version', 'last_maintenance_date']
            
            for field, value in update_data.items():
                if field in allowed_fields:
                    set_clauses.append(f"{field} = %s")
                    params.append(value)
            
            if not set_clauses:
                logger.warning("No valid fields to update")
                return False
            
            query = f"""
                UPDATE equipment 
                SET {', '.join(set_clauses)}, updated_at = NOW()
                WHERE equipment_id = %s
            """
            params.append(equipment_id)
            
            affected_rows = self.db.execute_update(query, tuple(params))
            
            if affected_rows > 0:
                logger.info(f"Equipment {equipment_id} updated successfully")
                return True
            else:
                logger.warning(f"No equipment found with ID: {equipment_id}")
                return False
                
        except Exception as e:
            logger.error(f"Error updating equipment {equipment_id}: {e}")
            return False
    
    def delete_equipment(self, equipment_id: str) -> bool:
        """Remove equipment from the system."""
        try:
            query = "DELETE FROM equipment WHERE equipment_id = %s"
            affected_rows = self.db.execute_update(query, (equipment_id,))
            
            if affected_rows > 0:
                logger.info(f"Equipment {equipment_id} deleted successfully")
                return True
            else:
                logger.warning(f"No equipment found with ID: {equipment_id}")
                return False
                
        except Exception as e:
            logger.error(f"Error deleting equipment {equipment_id}: {e}")
            return False
    
    def get_equipment_types(self) -> List[Dict]:
        """Retrieve all equipment types."""
        try:
            query = """
                SELECT id, type_name, description, default_maintenance_interval_days,
                       critical_threshold, warning_threshold
                FROM equipment_types
                ORDER BY type_name
            """
            return self.db.execute_query(query)
            
        except Exception as e:
            logger.error(f"Error retrieving equipment types: {e}")
            return []
    
    def get_equipment_statistics(self) -> Dict[str, Any]:
        """Get equipment statistics and summary information."""
        try:
            type_query = """
                SELECT et.type_name, COUNT(e.id) as count
                FROM equipment_types et
                LEFT JOIN equipment e ON et.id = e.equipment_type_id
                GROUP BY et.id, et.type_name
                ORDER BY et.type_name
            """
            
            status_query = """
                SELECT status, COUNT(*) as count
                FROM equipment
                GROUP BY status
            """
            
            age_query = """
                SELECT 
                    CASE 
                        WHEN DATEDIFF(CURDATE(), installation_date) <= 365 THEN '0-1 years'
                        WHEN DATEDIFF(CURDATE(), installation_date) <= 1095 THEN '1-3 years'
                        WHEN DATEDIFF(CURDATE(), installation_date) <= 1825 THEN '3-5 years'
                        ELSE '5+ years'
                    END as age_group,
                    COUNT(*) as count
                FROM equipment
                WHERE installation_date IS NOT NULL
                GROUP BY age_group
            """
            
            type_stats = self.db.execute_query(type_query)
            status_stats = self.db.execute_query(status_query)
            age_stats = self.db.execute_query(age_query)
            
            return {
                'by_type': type_stats,
                'by_status': status_stats,
                'by_age': age_stats,
                'total_count': sum(item['count'] for item in type_stats)
            }
            
        except Exception as e:
            logger.error(f"Error retrieving equipment statistics: {e}")
            return {}
    
    def _validate_equipment_data(self, data: Dict[str, Any]) -> bool:
        """Validate equipment data before insertion."""
        try:
            if 'equipment_id' not in data or not data['equipment_id']:
                logger.error("Equipment ID is required")
                return False
            
            if not self.validator.validate_equipment_id(data['equipment_id']):
                logger.error("Invalid equipment ID format")
                return False
            
            if 'equipment_type_id' not in data:
                logger.error("Equipment type ID is required")
                return False
            
            type_query = "SELECT id FROM equipment_types WHERE id = %s"
            type_result = self.db.execute_query(type_query, (data['equipment_type_id'],), fetch_one=True)
            if not type_result:
                logger.error("Invalid equipment type ID")
                return False
            
            duplicate_query = "SELECT id FROM equipment WHERE equipment_id = %s"
            duplicate_result = self.db.execute_query(duplicate_query, (data['equipment_id'],), fetch_one=True)
            if duplicate_result:
                logger.error("Equipment ID already exists")
                return False
            
            if 'installation_date' in data and data['installation_date']:
                if isinstance(data['installation_date'], str):
                    if not self.validator.validate_date(data['installation_date']):
                        logger.error("Invalid installation date format")
                        return False
            
            return True
            
        except Exception as e:
            logger.error(f"Validation error: {e}")
            return False
