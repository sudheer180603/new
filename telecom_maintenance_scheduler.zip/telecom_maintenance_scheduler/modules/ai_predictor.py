"""AI Predictor module for equipment failure prediction using machine learning."""
import os
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, roc_auc_score, confusion_matrix
from sklearn.preprocessing import StandardScaler
import joblib
import logging
from typing import Dict, Optional, List, Any, Tuple
from datetime import datetime, timedelta
from decimal import Decimal
from config.ml_config import ml_config
from utils.database_utils import db_manager

logger = logging.getLogger(__name__)

class AIPredictor:
    """Machine learning predictor for equipment failure risk assessment."""
    
    def __init__(self):
        self.model = None
        self.scaler = None
        self.ml_config = ml_config
        self.db = db_manager
        self.feature_columns = ml_config.feature_columns
    
    def load_training_data(self, equipment_type: str, days_back: int = 180) -> pd.DataFrame:
        """Load training data from database for specific equipment type."""
        try:
            query = """
                SELECT 
                    hm.cpu_usage, hm.memory_usage, hm.temperature, hm.power_consumption,
                    hm.uptime_hours, hm.packet_loss_rate, hm.error_count,
                    hm.bandwidth_utilization, hm.signal_strength,
                    CASE 
                        WHEN fl.id IS NOT NULL THEN 1 
                        ELSE 0 
                    END AS failure_label,
                    hm.timestamp,
                    e.equipment_id
                FROM health_metrics hm
                JOIN equipment e ON hm.equipment_id = e.id
                JOIN equipment_types et ON e.equipment_type_id = et.id
                LEFT JOIN failure_logs fl ON e.id = fl.equipment_id 
                    AND fl.failure_timestamp BETWEEN hm.timestamp 
                    AND DATE_ADD(hm.timestamp, INTERVAL 7 DAY)
                WHERE et.type_name = %s 
                AND hm.timestamp >= DATE_SUB(NOW(), INTERVAL %s DAY)
                ORDER BY hm.timestamp DESC
            """
            
            data = self.db.execute_query(query, (equipment_type, days_back))
            df = pd.DataFrame(data)
            
            if df.empty:
                logger.warning(f"No training data found for {equipment_type}")
                return df
            
            # Convert Decimal to float to fix type issues
            numeric_columns = ['cpu_usage', 'memory_usage', 'temperature', 'power_consumption',
                             'uptime_hours', 'packet_loss_rate', 'error_count',
                             'bandwidth_utilization', 'signal_strength']
            
            for col in numeric_columns:
                if col in df.columns:
                    df[col] = df[col].apply(lambda x: float(x) if isinstance(x, Decimal) else (float(x) if x is not None else x))
            
            # Handle missing values
            df = self._handle_missing_values(df)
            
            # Feature engineering
            df = self._engineer_features(df)
            
            logger.info(f"Loaded {len(df)} training samples for {equipment_type}")
            return df
            
        except Exception as e:
            logger.error(f"Error loading training data for {equipment_type}: {e}")
            return pd.DataFrame()
    
    def _handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """Handle missing values in the dataset."""
        df_clean = df.copy()
        
        # Fill missing values with median for numeric columns
        numeric_columns = df_clean.select_dtypes(include=[np.number]).columns
        for col in numeric_columns:
            if col in self.feature_columns and col in df_clean.columns:
                median_val = df_clean[col].median()
                df_clean.loc[:, col] = df_clean[col].fillna(median_val)
        
        # Remove rows where target is missing
        df_clean = df_clean.dropna(subset=['failure_label'])
        
        return df_clean
    
    def _engineer_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Create additional features from existing data."""
        try:
            df_eng = df.copy()
            
            # Composite health indicators - ensure all operations use float
            if all(col in df_eng.columns for col in ['cpu_usage', 'memory_usage']):
                df_eng['resource_pressure'] = (df_eng['cpu_usage'].astype(float) + 
                                             df_eng['memory_usage'].astype(float)) / 2
            
            if all(col in df_eng.columns for col in ['packet_loss_rate', 'error_count']):
                df_eng['network_health'] = (df_eng['packet_loss_rate'].astype(float) * 100 + 
                                          df_eng['error_count'].astype(float) / 100)
            
            return df_eng
            
        except Exception as e:
            logger.error(f"Error in feature engineering: {e}")
            return df
    
    def preprocess_features(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
        """Prepare feature matrix X and target vector y."""
        # Select only the original feature columns for consistency
        available_features = [col for col in self.feature_columns if col in df.columns]
        
        if len(available_features) < len(self.feature_columns):
            missing_features = set(self.feature_columns) - set(available_features)
            logger.warning(f"Missing features: {missing_features}")
        
        X = df[available_features].copy()
        y = df['failure_label']
        
        # Remove any remaining NaN values
        mask = ~(X.isnull().any(axis=1) | y.isnull())
        X = X[mask]
        y = y[mask]
        
        return X, y
    
    def train_model(self, equipment_type: str, retrain: bool = False) -> bool:
        """Train a Random Forest model for given equipment type."""
        try:
            # Check if model already exists and retrain is False
            model_path = self.ml_config.get_model_path(equipment_type)
            if os.path.exists(model_path) and not retrain:
                logger.info(f"Model already exists for {equipment_type}. Use retrain=True to retrain.")
                return True
            
            # Load training data
            df = self.load_training_data(equipment_type)
            
            if df.empty or len(df) < self.ml_config.min_samples_for_training:
                logger.warning(f"Insufficient training data for {equipment_type}: {len(df)} samples")
                return False
            
            # Prepare features
            X, y = self.preprocess_features(df)
            
            if len(X) == 0:
                logger.error("No valid training samples after preprocessing")
                return False
            
            # Check class balance and ensure we have failures
            failure_rate = y.mean()
            logger.info(f"Failure rate in training data: {failure_rate:.3f}")
            
            # If no failures exist, create some synthetic failure scenarios
            if failure_rate == 0:
                logger.info("No failures in data. Creating synthetic failure scenarios...")
                X, y = self._create_synthetic_failures(X, y, equipment_type)
                failure_rate = y.mean()
                logger.info(f"Updated failure rate: {failure_rate:.3f}")
            
            if failure_rate == 0 or failure_rate == 1:
                logger.warning("Training data still has no class variation - cannot train model")
                return False
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, 
                test_size=self.ml_config.test_size, 
                random_state=self.ml_config.random_state,
                stratify=y
            )
            
            # Scale features if configured
            if self.ml_config.feature_scaling:
                self.scaler = StandardScaler()
                X_train_scaled = self.scaler.fit_transform(X_train)
                X_test_scaled = self.scaler.transform(X_test)
            else:
                X_train_scaled = X_train
                X_test_scaled = X_test
            
            # Train Random Forest model
            self.model = RandomForestClassifier(**self.ml_config.random_forest_params)
            self.model.fit(X_train_scaled, y_train)
            
            # Evaluate model
            y_pred = self.model.predict(X_test_scaled)
            y_proba = self.model.predict_proba(X_test_scaled)[:, 1]
            
            # Print evaluation metrics
            print(f"\n=== Model Training Results for {equipment_type} ===")
            print(f"Training samples: {len(X_train)}")
            print(f"Test samples: {len(X_test)}")
            print(f"Features used: {list(X.columns)}")
            
            print("\nClassification Report:")
            print(classification_report(y_test, y_pred))
            
            print(f"ROC AUC Score: {roc_auc_score(y_test, y_proba):.4f}")
            
            # Cross-validation score
            cv_scores = cross_val_score(
                self.model, X_train_scaled, y_train, 
                cv=min(5, len(X_train)//10), scoring='roc_auc'
            )
            print(f"Cross-validation AUC: {cv_scores.mean():.4f} (+/- {cv_scores.std() * 2:.4f})")
            
            # Feature importance
            feature_importance = pd.DataFrame({
                'feature': X.columns,
                'importance': self.model.feature_importances_
            }).sort_values('importance', ascending=False)
            
            print("\nTop Feature Importances:")
            print(feature_importance.head(10))
            
            # Save model and scaler
            self._save_model_artifacts(equipment_type)
            
            logger.info(f"Model successfully trained and saved for {equipment_type}")
            return True
            
        except Exception as e:
            logger.error(f"Error training model for {equipment_type}: {e}")
            return False
    
    def _create_synthetic_failures(self, X: pd.DataFrame, y: pd.Series, equipment_type: str) -> Tuple[pd.DataFrame, pd.Series]:
        """Create synthetic failure scenarios when no real failures exist."""
        try:
            # Create synthetic failure cases (about 10% of data)
            n_failures = max(int(len(X) * 0.1), 10)
            
            # Select random indices for failures
            failure_indices = np.random.choice(X.index, size=min(n_failures, len(X)), replace=False)
            
            # Create modified feature vectors for failures
            X_failures = X.loc[failure_indices].copy()
            
            # Modify features to simulate failure conditions based on equipment type
            failure_patterns = {
                'Router': {'cpu_usage': 1.3, 'memory_usage': 1.4, 'temperature': 1.2, 'error_count': 5},
                'Core_Switch': {'cpu_usage': 1.2, 'memory_usage': 1.3, 'packet_loss_rate': 3, 'error_count': 8},
                'Access_Switch': {'cpu_usage': 1.4, 'memory_usage': 1.5, 'temperature': 1.3, 'error_count': 10},
                'Base_Station': {'signal_strength': 0.7, 'error_count': 15, 'temperature': 1.3},
                'Optical_Transport': {'signal_strength': 0.8, 'packet_loss_rate': 2, 'error_count': 3}
            }
            
            pattern = failure_patterns.get(equipment_type, {'cpu_usage': 1.3, 'error_count': 5})
            
            for feature, multiplier in pattern.items():
                if feature in X_failures.columns:
                    if feature == 'error_count':
                        X_failures.loc[:, feature] = X_failures[feature] + multiplier
                    elif feature == 'signal_strength':
                        X_failures.loc[:, feature] = X_failures[feature] * multiplier
                    else:
                        X_failures.loc[:, feature] = np.minimum(X_failures[feature] * multiplier, 100)
            
            # Combine original data with synthetic failures
            X_combined = pd.concat([X, X_failures], ignore_index=True)
            y_combined = pd.concat([y, pd.Series([1] * len(X_failures))], ignore_index=True)
            
            return X_combined, y_combined
            
        except Exception as e:
            logger.error(f"Error creating synthetic failures: {e}")
            return X, y
    
    def _save_model_artifacts(self, equipment_type: str):
        """Save model and associated artifacts."""
        model_path = self.ml_config.get_model_path(equipment_type)
        
        # Save model
        joblib.dump(self.model, model_path)
        
        # Save scaler if used
        if self.scaler is not None:
            scaler_path = model_path.replace('_model.pkl', '_scaler.pkl')
            joblib.dump(self.scaler, scaler_path)
        
        logger.info(f"Model artifacts saved for {equipment_type}")
    
    def load_model(self, equipment_type: str) -> bool:
        """Load trained model from disk."""
        try:
            model_path = self.ml_config.get_model_path(equipment_type)
            
            if not os.path.exists(model_path):
                logger.warning(f"Model file not found for {equipment_type}: {model_path}")
                return False
            
            # Load model
            self.model = joblib.load(model_path)
            
            # Load scaler if exists
            scaler_path = model_path.replace('_model.pkl', '_scaler.pkl')
            if os.path.exists(scaler_path):
                self.scaler = joblib.load(scaler_path)
            
            logger.info(f"Model loaded successfully for {equipment_type}")
            return True
            
        except Exception as e:
            logger.error(f"Error loading model for {equipment_type}: {e}")
            return False
    
    def predict_failure_risk(self, equipment_id: int, equipment_type: str, 
                           metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Predict failure risk for given equipment and metrics."""
        try:
            # Load model if not already loaded
            if self.model is None:
                if not self.load_model(equipment_type):
                    return {
                        'error': f'Model not available for equipment type: {equipment_type}',
                        'equipment_id': equipment_id
                    }
            
            # Prepare feature vector
            feature_vector = []
            missing_features = []
            
            for feature in self.feature_columns:
                if feature in metrics and metrics[feature] is not None:
                    feature_vector.append(float(metrics[feature]))
                else:
                    # Use default value or median
                    default_value = self._get_default_feature_value(feature)
                    feature_vector.append(default_value)
                    missing_features.append(feature)
            
            # Create DataFrame for prediction
            X = pd.DataFrame([feature_vector], columns=self.feature_columns)
            
            # Scale features if scaler is available
            if self.scaler is not None:
                X_scaled = self.scaler.transform(X)
            else:
                X_scaled = X
            
            # Make prediction
            failure_probability = self.model.predict_proba(X_scaled)[0, 1]
            prediction_binary = self.model.predict(X_scaled)[0]
            
            # Determine risk level and recommendations
            risk_level = self._calculate_risk_level(failure_probability)
            recommendations = self._generate_recommendations(
                risk_level, failure_probability, metrics, equipment_type
            )
            
            # Store prediction in database
            self._store_prediction(equipment_id, failure_probability, risk_level)
            
            result = {
                'equipment_id': equipment_id,
                'equipment_type': equipment_type,
                'failure_probability': round(failure_probability, 4),
                'risk_level': risk_level,
                'prediction_binary': bool(prediction_binary),
                'confidence_score': self._calculate_confidence(failure_probability),
                'recommendations': recommendations,
                'timestamp': datetime.now().isoformat(),
                'missing_features': missing_features
            }
            
            logger.info(f"Prediction completed for equipment {equipment_id}: {risk_level} risk")
            return result
            
        except Exception as e:
            logger.error(f"Error predicting failure risk: {e}")
            return {
                'error': f'Prediction failed: {str(e)}',
                'equipment_id': equipment_id
            }
    
    def _get_default_feature_value(self, feature: str) -> float:
        """Get default value for missing features."""
        defaults = {
            'cpu_usage': 50.0,
            'memory_usage': 60.0,
            'temperature': 35.0,
            'power_consumption': 200.0,
            'uptime_hours': 720,  # 30 days
            'packet_loss_rate': 0.001,
            'error_count': 0,
            'bandwidth_utilization': 40.0,
            'signal_strength': -50.0
        }
        return defaults.get(feature, 0.0)
    
    def _calculate_risk_level(self, probability: float) -> str:
        """Calculate risk level based on failure probability."""
        if probability >= self.ml_config.critical_risk_threshold:
            return 'CRITICAL'
        elif probability >= self.ml_config.high_risk_threshold:
            return 'HIGH'
        elif probability >= self.ml_config.failure_probability_threshold:
            return 'MEDIUM'
        else:
            return 'LOW'
    
    def _calculate_confidence(self, probability: float) -> float:
        """Calculate confidence score for the prediction."""
        # Higher confidence for predictions closer to 0 or 1
        return round(max(probability, 1 - probability), 4)
    
    def _generate_recommendations(self, risk_level: str, probability: float, 
                                metrics: Dict[str, Any], equipment_type: str) -> List[str]:
        """Generate maintenance recommendations based on prediction and metrics."""
        recommendations = []
        
        if risk_level == 'CRITICAL':
            recommendations.append("URGENT: Schedule immediate maintenance inspection")
            recommendations.append("Consider taking equipment offline for detailed analysis")
        elif risk_level == 'HIGH':
            recommendations.append("Schedule maintenance within 48 hours")
            recommendations.append("Increase monitoring frequency")
        elif risk_level == 'MEDIUM':
            recommendations.append("Schedule preventive maintenance within 1 week")
            recommendations.append("Monitor key metrics closely")
        else:
            recommendations.append("Continue normal operation")
            recommendations.append("Regular monitoring recommended")
        
        # Specific recommendations based on metrics
        if metrics.get('cpu_usage', 0) > 85:
            recommendations.append("High CPU usage detected - check for resource-intensive processes")
        
        if metrics.get('memory_usage', 0) > 90:
            recommendations.append("Memory usage critical - potential memory leak investigation needed")
        
        if metrics.get('temperature', 0) > 70:
            recommendations.append("Temperature elevated - check cooling systems")
        
        if metrics.get('packet_loss_rate', 0) > 0.01:
            recommendations.append("High packet loss - inspect network connections")
        
        return recommendations
    
    def _store_prediction(self, equipment_id: int, probability: float, risk_level: str):
        """Store prediction result in database."""
        try:
            query = """
                INSERT INTO predictions (equipment_id, failure_probability, 
                                      predicted_failure_date, confidence_score, recommended_action)
                VALUES (%s, %s, %s, %s, %s)
            """
            
            # Calculate predicted failure date based on probability
            days_to_failure = max(1, int(30 * (1 - probability)))  # 1-30 days based on risk
            predicted_date = datetime.now() + timedelta(days=days_to_failure)
            
            confidence = self._calculate_confidence(probability)
            action = f"{risk_level} risk - see recommendations"
            
            params = (equipment_id, probability, predicted_date.date(), confidence, action)
            self.db.execute_insert(query, params)
            
        except Exception as e:
            logger.error(f"Error storing prediction: {e}")
    
    def batch_predict(self, equipment_type: str) -> List[Dict[str, Any]]:
        """Run predictions for all active equipment of given type."""
        try:
            # Get all active equipment of this type
            query = """
                SELECT e.id, e.equipment_id, hm.*
                FROM equipment e
                JOIN equipment_types et ON e.equipment_type_id = et.id
                LEFT JOIN (
                    SELECT equipment_id, cpu_usage, memory_usage, temperature, 
                           power_consumption, uptime_hours, packet_loss_rate, 
                           error_count, bandwidth_utilization, signal_strength,
                           ROW_NUMBER() OVER (PARTITION BY equipment_id ORDER BY timestamp DESC) as rn
                    FROM health_metrics
                ) hm ON e.id = hm.equipment_id AND hm.rn = 1
                WHERE et.type_name = %s AND e.status = 'active'
            """
            
            equipment_data = self.db.execute_query(query, (equipment_type,))
            results = []
            
            for equipment in equipment_data:
                if equipment.get('cpu_usage') is not None:  # Has health data
                    metrics = {
                        'cpu_usage': equipment['cpu_usage'],
                        'memory_usage': equipment['memory_usage'],
                        'temperature': equipment['temperature'],
                        'power_consumption': equipment['power_consumption'],
                        'uptime_hours': equipment['uptime_hours'],
                        'packet_loss_rate': equipment['packet_loss_rate'],
                        'error_count': equipment['error_count'],
                        'bandwidth_utilization': equipment['bandwidth_utilization'],
                        'signal_strength': equipment['signal_strength']
                    }
                    
                    prediction = self.predict_failure_risk(
                        equipment['id'], equipment_type, metrics
                    )
                    prediction['equipment_name'] = equipment['equipment_id']
                    results.append(prediction)
            
            logger.info(f"Batch prediction completed for {len(results)} {equipment_type} devices")
            return results
            
        except Exception as e:
            logger.error(f"Error in batch prediction: {e}")
            return []
    
    def get_model_info(self, equipment_type: str) -> Dict[str, Any]:
        """Get information about the trained model."""
        try:
            model_path = self.ml_config.get_model_path(equipment_type)
            
            if not os.path.exists(model_path):
                return {'error': 'Model not found'}
            
            # Load model if not already loaded
            if self.model is None:
                self.load_model(equipment_type)
            
            info = {
                'equipment_type': equipment_type,
                'model_type': 'RandomForestClassifier',
                'model_path': model_path,
                'model_size_mb': round(os.path.getsize(model_path) / (1024*1024), 2),
                'features_used': self.feature_columns,
                'created_at': datetime.fromtimestamp(os.path.getctime(model_path)).isoformat()
            }
            
            if self.model is not None:
                info.update({
                    'n_estimators': self.model.n_estimators,
                    'max_depth': self.model.max_depth,
                    'n_features': self.model.n_features_in_,
                    'n_classes': self.model.n_classes_
                })
            
            return info
            
        except Exception as e:
            logger.error(f"Error getting model info: {e}")
            return {'error': str(e)}
