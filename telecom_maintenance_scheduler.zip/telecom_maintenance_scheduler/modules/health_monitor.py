"""Health monitoring module for collecting and analyzing equipment health metrics."""
import logging
from typing import List, Dict, Optional, Any, Tuple
from datetime import datetime, timedelta
from decimal import Decimal
from utils.database_utils import db_manager
from utils.validation_utils import ValidationUtils
import statistics

logger = logging.getLogger(__name__)

class HealthMonitor:
    """Monitors and analyzes equipment health metrics."""
    
    def __init__(self):
        self.db = db_manager
        self.validator = ValidationUtils()
    
    def record_health_metrics(self, equipment_id: int, metrics: Dict[str, Any]) -> bool:
        """Record health metrics for specific equipment."""
        try:
            is_valid, errors = self.validator.validate_equipment_metrics(metrics)
            if not is_valid:
                logger.error(f"Validation errors: {errors}")
                return False
            
            health_score = self._calculate_health_score(metrics)
            
            query = """
                INSERT INTO health_metrics (
                    equipment_id, cpu_usage, memory_usage, temperature, 
                    power_consumption, uptime_hours, packet_loss_rate, 
                    error_count, bandwidth_utilization, signal_strength, health_score
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            params = (
                equipment_id,
                metrics.get('cpu_usage'),
                metrics.get('memory_usage'),
                metrics.get('temperature'),
                metrics.get('power_consumption'),
                metrics.get('uptime_hours'),
                metrics.get('packet_loss_rate'),
                metrics.get('error_count', 0),
                metrics.get('bandwidth_utilization'),
                metrics.get('signal_strength'),
                health_score
            )
            
            self.db.execute_insert(query, params)
            
            self._check_for_anomalies(equipment_id, metrics, health_score)
            
            logger.info(f"Health metrics recorded for equipment ID {equipment_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error recording health metrics: {e}")
            return False
    
    def get_latest_health_metrics(self, equipment_id: int) -> Optional[Dict]:
        """Get the most recent health metrics for equipment."""
        try:
            query = """
                SELECT hm.*, e.equipment_id, et.type_name
                FROM health_metrics hm
                JOIN equipment e ON hm.equipment_id = e.id
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE hm.equipment_id = %s
                ORDER BY hm.timestamp DESC
                LIMIT 1
            """
            
            return self.db.execute_query(query, (equipment_id,), fetch_one=True)
            
        except Exception as e:
            logger.error(f"Error retrieving latest health metrics: {e}")
            return None
    
    def get_health_history(self, equipment_id: int, days: int = 30) -> List[Dict]:
        """Get health metrics history for specified period."""
        try:
            query = """
                SELECT *
                FROM health_metrics
                WHERE equipment_id = %s 
                AND timestamp >= DATE_SUB(NOW(), INTERVAL %s DAY)
                ORDER BY timestamp DESC
            """
            
            return self.db.execute_query(query, (equipment_id, days))
            
        except Exception as e:
            logger.error(f"Error retrieving health history: {e}")
            return []
    
    def get_equipment_health_summary(self, equipment_type: Optional[str] = None) -> List[Dict]:
        """Get health summary for all equipment or specific type."""
        try:
            base_query = """
                SELECT 
                    e.equipment_id,
                    et.type_name,
                    e.location,
                    e.status,
                    hm.health_score,
                    hm.cpu_usage,
                    hm.memory_usage,
                    hm.temperature,
                    hm.timestamp as last_check,
                    CASE 
                        WHEN hm.health_score >= et.critical_threshold THEN 'CRITICAL'
                        WHEN hm.health_score >= et.warning_threshold THEN 'WARNING'
                        ELSE 'NORMAL'
                    END as health_status
                FROM equipment e
                JOIN equipment_types et ON e.equipment_type_id = et.id
                LEFT JOIN (
                    SELECT equipment_id, health_score, cpu_usage, memory_usage, 
                           temperature, timestamp,
                           ROW_NUMBER() OVER (PARTITION BY equipment_id ORDER BY timestamp DESC) as rn
                    FROM health_metrics
                ) hm ON e.id = hm.equipment_id AND hm.rn = 1
                WHERE e.status = 'active'
            """
            
            params = []
            if equipment_type:
                base_query += " AND et.type_name = %s"
                params.append(equipment_type)
            
            base_query += " ORDER BY hm.health_score DESC, e.equipment_id"
            
            return self.db.execute_query(base_query, tuple(params) if params else None)
            
        except Exception as e:
            logger.error(f"Error retrieving health summary: {e}")
            return []
    
    def detect_anomalies(self, equipment_id: int, days: int = 7) -> List[Dict]:
        """Detect anomalies in equipment health metrics."""
        try:
            history = self.get_health_history(equipment_id, days)
            
            if len(history) < 5:
                return []
            
            anomalies = []
            metrics_to_analyze = ['cpu_usage', 'memory_usage', 'temperature', 'health_score']
            
            for metric in metrics_to_analyze:
                values = []
                for h in history:
                    val = h[metric]
                    if val is not None:
                        # Convert Decimal to float
                        if isinstance(val, Decimal):
                            val = float(val)
                        values.append(val)
                
                if len(values) < 3:
                    continue
                
                mean_val = statistics.mean(values)
                stdev_val = statistics.stdev(values) if len(values) > 1 else 0
                
                threshold = mean_val + (2 * stdev_val)
                
                for record in history:
                    val = record[metric]
                    if val is not None:
                        if isinstance(val, Decimal):
                            val = float(val)
                        
                        if val > threshold:
                            anomalies.append({
                                'timestamp': record['timestamp'],
                                'metric': metric,
                                'value': val,
                                'threshold': round(threshold, 2),
                                'deviation': round(val - mean_val, 2),
                                'severity': 'HIGH' if val > threshold * 1.2 else 'MEDIUM'
                            })
            
            return sorted(anomalies, key=lambda x: x['timestamp'], reverse=True)
            
        except Exception as e:
            logger.error(f"Error detecting anomalies: {e}")
            return []
    
    def get_health_trends(self, equipment_id: int, days: int = 30) -> Dict[str, Any]:
        """Analyze health trends for equipment."""
        try:
            history = self.get_health_history(equipment_id, days)
            
            if len(history) < 2:
                return {}
            
            history.sort(key=lambda x: x['timestamp'])
            
            trends = {}
            metrics = ['cpu_usage', 'memory_usage', 'temperature', 'health_score']
            
            for metric in metrics:
                values = []
                for h in history:
                    val = h[metric]
                    if val is not None:
                        if isinstance(val, Decimal):
                            val = float(val)
                        values.append(val)
                
                if len(values) < 2:
                    continue
                
                n = len(values)
                x_vals = list(range(n))
                
                x_mean = sum(x_vals) / n
                y_mean = sum(values) / n
                
                numerator = sum((x_vals[i] - x_mean) * (values[i] - y_mean) for i in range(n))
                denominator = sum((x_vals[i] - x_mean) ** 2 for i in range(n))
                
                slope = numerator / denominator if denominator != 0 else 0
                
                trends[metric] = {
                    'current_value': values[-1],
                    'average_value': round(y_mean, 2),
                    'trend_direction': 'INCREASING' if slope > 0.01 else 'DECREASING' if slope < -0.01 else 'STABLE',
                    'trend_strength': abs(slope),
                    'min_value': min(values),
                    'max_value': max(values)
                }
            
            return trends
            
        except Exception as e:
            logger.error(f"Error calculating health trends: {e}")
            return {}
    
    def _calculate_health_score(self, metrics: Dict[str, Any]) -> float:
        """Calculate overall health score based on metrics."""
        try:
            score = 0.0
            weight_sum = 0.0
            
            weights = {
                'cpu_usage': 0.2,
                'memory_usage': 0.2,
                'temperature': 0.15,
                'packet_loss_rate': 0.15,
                'error_count': 0.1,
                'power_consumption': 0.1,
                'bandwidth_utilization': 0.05,
                'signal_strength': 0.05
            }
            
            for metric, weight in weights.items():
                if metric in metrics and metrics[metric] is not None:
                    value = float(metrics[metric])
                    
                    if metric in ['cpu_usage', 'memory_usage']:
                        normalized = value / 100.0
                    elif metric == 'temperature':
                        if 20 <= value <= 40:
                            normalized = 0.0
                        elif value < 20:
                            normalized = (20 - value) / 50.0
                        else:
                            normalized = min((value - 40) / 60.0, 1.0)
                    elif metric == 'packet_loss_rate':
                        normalized = min(value * 10, 1.0)
                    elif metric == 'error_count':
                        normalized = min(value / 100.0, 1.0)
                    elif metric == 'power_consumption':
                        if 50 <= value <= 500:
                            normalized = 0.0
                        else:
                            normalized = min(abs(value - 275) / 500.0, 1.0)
                    elif metric == 'bandwidth_utilization':
                        normalized = value / 100.0
                    elif metric == 'signal_strength':
                        if -70 <= value <= -30:
                            normalized = 0.0
                        else:
                            normalized = min(abs(value + 50) / 50.0, 1.0)
                    else:
                        normalized = 0.0
                    
                    score += normalized * weight
                    weight_sum += weight
            
            if weight_sum > 0:
                final_score = score / weight_sum
                return round(final_score, 4)
            else:
                return 0.0
                
        except Exception as e:
            logger.error(f"Error calculating health score: {e}")
            return 0.0
    
    def _check_for_anomalies(self, equipment_id: int, metrics: Dict[str, Any], health_score: float):
        """Check for immediate anomalies and log them."""
        try:
            query = """
                SELECT et.critical_threshold, et.warning_threshold, et.type_name
                FROM equipment e
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE e.id = %s
            """
            
            result = self.db.execute_query(query, (equipment_id,), fetch_one=True)
            
            if not result:
                return
            
            critical_threshold = float(result['critical_threshold'])
            warning_threshold = float(result['warning_threshold'])
            equipment_type = result['type_name']
            
            if health_score >= critical_threshold:
                logger.warning(f"CRITICAL: Equipment {equipment_id} ({equipment_type}) health score: {health_score}")
            elif health_score >= warning_threshold:
                logger.warning(f"WARNING: Equipment {equipment_id} ({equipment_type}) health score: {health_score}")
            
            if metrics.get('cpu_usage', 0) > 90:
                logger.warning(f"High CPU usage: {metrics['cpu_usage']}% on equipment {equipment_id}")
            
            if metrics.get('memory_usage', 0) > 85:
                logger.warning(f"High memory usage: {metrics['memory_usage']}% on equipment {equipment_id}")
            
            if metrics.get('temperature', 0) > 80:
                logger.warning(f"High temperature: {metrics['temperature']}°C on equipment {equipment_id}")
                
        except Exception as e:
            logger.error(f"Error checking anomalies: {e}")
