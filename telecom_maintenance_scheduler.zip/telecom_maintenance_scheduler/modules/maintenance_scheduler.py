"""Maintenance scheduler module for managing maintenance tasks and priorities."""
import logging
from typing import List, Dict, Optional, Any
from datetime import datetime, date, timedelta
from utils.database_utils import db_manager
from utils.validation_utils import ValidationUtils
from modules.ai_predictor import AIPredictor

logger = logging.getLogger(__name__)

class MaintenanceScheduler:
    """Manages maintenance scheduling based on AI predictions and equipment status."""
    
    def __init__(self):
        self.db = db_manager
        self.validator = ValidationUtils()
        self.ai_predictor = AIPredictor()
    
    def schedule_maintenance(self, equipment_id: int, maintenance_data: Dict[str, Any]) -> Optional[int]:
        """Schedule a new maintenance task."""
        try:
            if not self._validate_maintenance_data(maintenance_data):
                return None
            
            query = """
                INSERT INTO maintenance_history (
                    equipment_id, maintenance_type, scheduled_date, description, 
                    priority, technician_id, cost, status
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            params = (
                equipment_id,
                maintenance_data['maintenance_type'],
                maintenance_data['scheduled_date'],
                maintenance_data.get('description', ''),
                maintenance_data.get('priority', 'medium'),
                maintenance_data.get('technician_id', ''),
                maintenance_data.get('cost', 0),
                maintenance_data.get('status', 'scheduled')
            )
            
            maintenance_id = self.db.execute_insert(query, params)
            
            if maintenance_data.get('maintenance_type') == 'emergency':
                self._update_equipment_status(equipment_id, 'maintenance')
            
            logger.info(f"Maintenance scheduled with ID: {maintenance_id}")
            return maintenance_id
            
        except Exception as e:
            logger.error(f"Error scheduling maintenance: {e}")
            return None
    
    def generate_ai_driven_schedule(self, equipment_type: Optional[str] = None, 
                                  days_ahead: int = 30) -> List[Dict[str, Any]]:
        """Generate maintenance schedule based on AI failure predictions."""
        try:
            if equipment_type:
                equipment_types = [equipment_type]
            else:
                types_data = self.db.execute_query("SELECT type_name FROM equipment_types")
                equipment_types = [t['type_name'] for t in types_data]
            
            all_recommendations = []
            
            for eq_type in equipment_types:
                predictions = self.ai_predictor.batch_predict(eq_type)
                
                for prediction in predictions:
                    if 'error' in prediction:
                        continue
                    
                    recommendations = self._generate_maintenance_recommendations(
                        prediction, days_ahead
                    )
                    
                    all_recommendations.extend(recommendations)
            
            all_recommendations.sort(
                key=lambda x: (self._priority_weight(x['priority']), x['scheduled_date'])
            )
            
            logger.info(f"Generated {len(all_recommendations)} maintenance recommendations")
            return all_recommendations
            
        except Exception as e:
            logger.error(f"Error generating AI-driven schedule: {e}")
            return []
    
    def _generate_maintenance_recommendations(self, prediction: Dict[str, Any], 
                                           days_ahead: int) -> List[Dict[str, Any]]:
        """Generate specific maintenance recommendations based on prediction."""
        recommendations = []
        equipment_id = prediction['equipment_id']
        risk_level = prediction['risk_level']
        probability = prediction['failure_probability']
        
        equipment_query = """
            SELECT e.*, et.type_name, et.default_maintenance_interval_days
            FROM equipment e
            JOIN equipment_types et ON e.equipment_type_id = et.id
            WHERE e.id = %s
        """
        equipment_data = self.db.execute_query(equipment_query, (equipment_id,), fetch_one=True)
        
        if not equipment_data:
            return recommendations
        
        if risk_level == 'CRITICAL':
            recommendations.append({
                'equipment_id': equipment_id,
                'equipment_name': equipment_data['equipment_id'],
                'equipment_type': equipment_data['type_name'],
                'maintenance_type': 'emergency',
                'priority': 'critical',
                'scheduled_date': datetime.now().date(),
                'description': f'CRITICAL failure risk detected ({probability:.3f}). Immediate inspection required.',
                'estimated_cost': self._estimate_maintenance_cost('emergency', equipment_data['type_name']),
                'recommended_downtime_hours': 4,
                'failure_probability': probability,
                'ai_recommendation': True
            })
        
        elif risk_level == 'HIGH':
            recommendations.append({
                'equipment_id': equipment_id,
                'equipment_name': equipment_data['equipment_id'],
                'equipment_type': equipment_data['type_name'],
                'maintenance_type': 'corrective',
                'priority': 'high',
                'scheduled_date': (datetime.now() + timedelta(days=2)).date(),
                'description': f'High failure risk detected ({probability:.3f}). Preventive action recommended.',
                'estimated_cost': self._estimate_maintenance_cost('corrective', equipment_data['type_name']),
                'recommended_downtime_hours': 2,
                'failure_probability': probability,
                'ai_recommendation': True
            })
        
        elif risk_level == 'MEDIUM':
            recommendations.append({
                'equipment_id': equipment_id,
                'equipment_name': equipment_data['equipment_id'],
                'equipment_type': equipment_data['type_name'],
                'maintenance_type': 'preventive',
                'priority': 'medium',
                'scheduled_date': (datetime.now() + timedelta(days=7)).date(),
                'description': f'Medium failure risk detected ({probability:.3f}). Preventive maintenance advised.',
                'estimated_cost': self._estimate_maintenance_cost('preventive', equipment_data['type_name']),
                'recommended_downtime_hours': 1,
                'failure_probability': probability,
                'ai_recommendation': True
            })
        
        # Check if regular scheduled maintenance is due
        last_maintenance = equipment_data['last_maintenance_date']
        interval_days = equipment_data['default_maintenance_interval_days']
        
        if last_maintenance:
            days_since_maintenance = (datetime.now().date() - last_maintenance).days
            if days_since_maintenance >= interval_days:
                recommendations.append({
                    'equipment_id': equipment_id,
                    'equipment_name': equipment_data['equipment_id'],
                    'equipment_type': equipment_data['type_name'],
                    'maintenance_type': 'scheduled',
                    'priority': 'medium',
                    'scheduled_date': (datetime.now() + timedelta(days=3)).date(),
                    'description': f'Regular scheduled maintenance due (last: {last_maintenance})',
                    'estimated_cost': self._estimate_maintenance_cost('scheduled', equipment_data['type_name']),
                    'recommended_downtime_hours': 1,
                    'failure_probability': probability,
                    'ai_recommendation': False
                })
        
        return recommendations
    
    def _estimate_maintenance_cost(self, maintenance_type: str, equipment_type: str) -> float:
        """Estimate maintenance cost based on type and equipment."""
        base_costs = {
            'Router': {'emergency': 2000, 'corrective': 800, 'preventive': 300, 'scheduled': 200},
            'Core_Switch': {'emergency': 3000, 'corrective': 1200, 'preventive': 500, 'scheduled': 300},
            'Access_Switch': {'emergency': 1500, 'corrective': 600, 'preventive': 250, 'scheduled': 150},
            'Base_Station': {'emergency': 5000, 'corrective': 2000, 'preventive': 800, 'scheduled': 500},
            'Optical_Transport': {'emergency': 4000, 'corrective': 1500, 'preventive': 600, 'scheduled': 400}
        }
        
        return base_costs.get(equipment_type, {}).get(maintenance_type, 500)
    
    def _priority_weight(self, priority: str) -> int:
        """Convert priority to numeric weight for sorting."""
        weights = {'critical': 1, 'high': 2, 'medium': 3, 'low': 4}
        return weights.get(priority, 5)
    
    def get_maintenance_schedule(self, equipment_id: Optional[int] = None,
                               status: Optional[str] = None,
                               days_ahead: int = 30) -> List[Dict]:
        """Retrieve maintenance schedule with optional filtering."""
        try:
            base_query = """
                SELECT 
                    mh.*,
                    e.equipment_id as equipment_name,
                    et.type_name as equipment_type,
                    e.location,
                    e.status as equipment_status
                FROM maintenance_history mh
                JOIN equipment e ON mh.equipment_id = e.id
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE mh.scheduled_date <= DATE_ADD(CURDATE(), INTERVAL %s DAY)
            """
            
            params = [days_ahead]
            
            if equipment_id:
                base_query += " AND mh.equipment_id = %s"
                params.append(equipment_id)
            
            if status:
                base_query += " AND mh.status = %s"
                params.append(status)
            
            base_query += " ORDER BY mh.priority, mh.scheduled_date"
            
            return self.db.execute_query(base_query, tuple(params))
            
        except Exception as e:
            logger.error(f"Error retrieving maintenance schedule: {e}")
            return []
    
    def update_maintenance_status(self, maintenance_id: int, status: str, 
                                completion_data: Optional[Dict[str, Any]] = None) -> bool:
        """Update maintenance task status and completion details."""
        try:
            update_fields = ['status = %s', 'updated_at = NOW()']
            params = [status]
            
            if completion_data:
                if 'completed_date' in completion_data:
                    update_fields.append('completed_date = %s')
                    params.append(completion_data['completed_date'])
                
                if 'actual_cost' in completion_data:
                    update_fields.append('cost = %s')
                    params.append(completion_data['actual_cost'])
                
                if 'downtime_minutes' in completion_data:
                    update_fields.append('downtime_minutes = %s')
                    params.append(completion_data['downtime_minutes'])
                
                if 'description' in completion_data:
                    update_fields.append('description = %s')
                    params.append(completion_data['description'])
            
            query = f"""
                UPDATE maintenance_history 
                SET {', '.join(update_fields)}
                WHERE id = %s
            """
            params.append(maintenance_id)
            
            affected_rows = self.db.execute_update(query, tuple(params))
            
            if status == 'completed' and affected_rows > 0:
                self._update_equipment_after_maintenance(maintenance_id)
            
            return affected_rows > 0
            
        except Exception as e:
            logger.error(f"Error updating maintenance status: {e}")
            return False
    
    def _update_equipment_after_maintenance(self, maintenance_id: int):
        """Update equipment status after maintenance completion."""
        try:
            query = """
                SELECT equipment_id, maintenance_type, completed_date
                FROM maintenance_history
                WHERE id = %s
            """
            maintenance = self.db.execute_query(query, (maintenance_id,), fetch_one=True)
            
            if maintenance:
                update_query = """
                    UPDATE equipment 
                    SET last_maintenance_date = %s, status = 'active'
                    WHERE id = %s
                """
                self.db.execute_update(
                    update_query, 
                    (maintenance['completed_date'], maintenance['equipment_id'])
                )
                
        except Exception as e:
            logger.error(f"Error updating equipment after maintenance: {e}")
    
    def _update_equipment_status(self, equipment_id: int, status: str):
        """Update equipment status."""
        try:
            query = "UPDATE equipment SET status = %s WHERE id = %s"
            self.db.execute_update(query, (status, equipment_id))
        except Exception as e:
            logger.error(f"Error updating equipment status: {e}")
    
    def get_maintenance_analytics(self, days_back: int = 90) -> Dict[str, Any]:
        """Get maintenance analytics and statistics."""
        try:
            completion_query = """
                SELECT 
                    status,
                    COUNT(*) as count,
                    AVG(cost) as avg_cost,
                    SUM(downtime_minutes) as total_downtime
                FROM maintenance_history
                WHERE scheduled_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
                GROUP BY status
            """
            
            type_query = """
                SELECT 
                    maintenance_type,
                    COUNT(*) as count,
                    AVG(cost) as avg_cost,
                    AVG(downtime_minutes) as avg_downtime
                FROM maintenance_history
                WHERE scheduled_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
                GROUP BY maintenance_type
            """
            
            equipment_query = """
                SELECT 
                    et.type_name,
                    COUNT(mh.id) as maintenance_count,
                    AVG(mh.cost) as avg_cost,
                    COUNT(DISTINCT e.id) as equipment_count
                FROM equipment_types et
                LEFT JOIN equipment e ON et.id = e.equipment_type_id
                LEFT JOIN maintenance_history mh ON e.id = mh.equipment_id
                    AND mh.scheduled_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
                GROUP BY et.id, et.type_name
            """
            
            completion_stats = self.db.execute_query(completion_query, (days_back,))
            type_stats = self.db.execute_query(type_query, (days_back,))
            equipment_stats = self.db.execute_query(equipment_query, (days_back,))
            
            return {
                'by_status': completion_stats,
                'by_type': type_stats,
                'by_equipment_type': equipment_stats,
                'period_days': days_back
            }
            
        except Exception as e:
            logger.error(f"Error generating maintenance analytics: {e}")
            return {}
    
    def _validate_maintenance_data(self, data: Dict[str, Any]) -> bool:
        """Validate maintenance scheduling data."""
        try:
            required_fields = ['maintenance_type', 'scheduled_date']
            for field in required_fields:
                if field not in data or not data[field]:
                    logger.error(f"Missing required field: {field}")
                    return False
            
            valid_types = ['preventive', 'corrective', 'emergency', 'scheduled']
            if data['maintenance_type'] not in valid_types:
                logger.error(f"Invalid maintenance type: {data['maintenance_type']}")
                return False
            
            if isinstance(data['scheduled_date'], str):
                if not self.validator.validate_date(data['scheduled_date']):
                    logger.error("Invalid scheduled date format")
                    return False
            
            if 'priority' in data:
                valid_priorities = ['low', 'medium', 'high', 'critical']
                if data['priority'] not in valid_priorities:
                    logger.error(f"Invalid priority: {data['priority']}")
                    return False
            
            if 'cost' in data and data['cost'] is not None:
                if not self.validator.validate_numeric_range(data['cost'], 0, 100000):
                    logger.error("Invalid cost value")
                    return False
            
            return True
            
        except Exception as e:
            logger.error(f"Validation error: {e}")
            return False
