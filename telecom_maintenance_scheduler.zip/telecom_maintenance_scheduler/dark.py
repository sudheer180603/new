#!/usr/bin/env python3
"""
Enhanced Popup CLI for Telecom Equipment Maintenance Scheduler
Creates popup windows and sequential flow with Enter-to-continue navigation
"""

import os
import sys
import logging
import subprocess
import asyncio
from datetime import datetime, date, timedelta
from typing import Optional, Dict, Any, List
import time

# Enhanced UI imports
try:
    from prompt_toolkit import PromptSession, print_formatted_text
    from prompt_toolkit.shortcuts import message_dialog, yes_no_dialog, input_dialog, radiolist_dialog
    from prompt_toolkit.styles import Style
    from prompt_toolkit.formatted_text import HTML
    from prompt_toolkit.application import Application
    from prompt_toolkit.key_binding import KeyBindings
    from prompt_toolkit.layout.containers import VSplit, HSplit
    from prompt_toolkit.layout.controls import FormattedTextControl
    from prompt_toolkit.layout.layout import Layout
    from prompt_toolkit.widgets import Box, Frame, TextArea, Button
    HAS_PROMPT_TOOLKIT = True
except ImportError:
    print("Installing required dependencies...")
    subprocess.check_call([sys.executable, "-m", "pip", "install", "prompt-toolkit"])
    from prompt_toolkit import PromptSession, print_formatted_text
    from prompt_toolkit.shortcuts import message_dialog, yes_no_dialog, input_dialog, radiolist_dialog
    from prompt_toolkit.styles import Style
    from prompt_toolkit.formatted_text import HTML
    HAS_PROMPT_TOOLKIT = True

# Add project root to Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    from modules.equipment_manager import EquipmentManager
    from modules.health_monitor import HealthMonitor
    from modules.ai_predictor import AIPredictor
    from modules.maintenance_scheduler import MaintenanceScheduler
    from utils.database_utils import db_manager
    from utils.validation_utils import ValidationUtils
except ImportError as e:
    print(f"Error importing modules: {e}")
    sys.exit(1)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('telecom_maintenance.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Enhanced popup style
popup_style = Style.from_dict({
    'dialog': 'bg:#1e3a5f #e8f4f8',
    'dialog.body': 'bg:#0f1419 #87ceeb',
    'dialog.shadow': 'bg:#2c3e50',
    'button': 'bg:#2980b9 #ffffff bold',
    'button.focused': 'bg:#3498db #ffffff bold',
    'text-area': '#87ceeb bg:#0f1419',
    'text-area.prompt': '#f39c12 bg:#0f1419 bold',
    'radio': '#87ceeb bg:#0f1419',
    'radio.selected': '#ffffff bg:#2980b9 bold',
    'checkbox': '#87ceeb bg:#0f1419',
    'title': '#f39c12 bold'
})
        
class PopupTelecomMaintenanceApp:
    """Enhanced Popup CLI Application for Telecom Maintenance Scheduler"""
    
    def __init__(self):
        """Initialize application with popup support"""
        self.session = PromptSession(style=popup_style)
        self.equipment_manager = EquipmentManager()
        self.health_monitor = HealthMonitor()
        self.ai_predictor = AIPredictor()
        self.maintenance_scheduler = MaintenanceScheduler()
        self.validator = ValidationUtils()
        
        # Initialize database connection
        if not db_manager.test_connection():
            asyncio.run(self._show_error("Database connection failed! Please check configuration."))
            sys.exit(1)

    async def _show_message(self, title: str, message: str):
        """Show formatted message dialog"""
        await message_dialog(
            title=f"🚀 {title}",
            text=message,
            style=popup_style
        ).run_async()

    async def _show_error(self, message: str):
        """Show error message dialog"""
        await message_dialog(
            title="❌ Error",
            text=f"Error: {message}",
            style=popup_style
        ).run_async()

    async def _show_success(self, message: str):
        """Show success message dialog"""
        await message_dialog(
            title="✅ Success",
            text=message,
            style=popup_style
        ).run_async()

    async def _show_warning(self, message: str):
        """Show warning message dialog"""
        await message_dialog(
            title="⚠️ Warning",
            text=message,
            style=popup_style
        ).run_async()

    async def _get_input(self, title: str, prompt: str, default: str = "") -> str:
        """Get input through popup dialog"""
        result = await input_dialog(
            title=f"📝 {title}",
            text=prompt,
            default=default,
            style=popup_style
        ).run_async()
        return result or ""

    async def _wait_for_continue(self):
        """Wait for user to press Enter to continue"""
        await self._get_input("Continue", "Press Enter to continue...", "")

    async def _show_data_table(self, title: str, data: List[Dict], headers: List[str]):
        """Display data in a formatted table popup"""
        if not data:
            await self._show_warning("No data available.")
            return

        # Format data as table
        table_text = f"{title}\n\n"
        
        # Headers
        header_line = " | ".join(f"{header:<15}" for header in headers)
        table_text += header_line + "\n"
        table_text += "-" * len(header_line) + "\n"
        
        # Data rows
        for row in data[:20]:  # Limit to 20 rows for popup display
            row_line = " | ".join(f"{str(row.get(header, 'N/A')):<15}" for header in headers)
            table_text += row_line + "\n"
        
        if len(data) > 20:
            table_text += f"\n... and {len(data) - 20} more records"

        await message_dialog(
            title=f"📊 {title}",
            text=table_text,
            style=popup_style
        ).run_async()

    async def run(self):
        """Main application loop with popup interface"""
        # Show welcome message
        await self._show_message(
            "Welcome",
            "🏢 Telecom Equipment Maintenance Scheduler\n🚀 Enhanced AI-Driven System\n\nWelcome to the Enterprise Telecom Infrastructure Management System!"
        )

        while True:
            # Main menu selection
            main_options = [
                ("1", "📦 Equipment Management"),
                ("2", "❤️ Health Monitoring"), 
                ("3", "🤖 AI Predictions"),
                ("4", "🔧 Maintenance Scheduling"),
                ("5", "📊 Reports & Analytics"),
                ("6", "⚙️ System Management"),
                ("0", "🚪 Exit Application")
            ]

            choice = await radiolist_dialog(
                title="🚀 Main Menu - Telecom Maintenance Scheduler",
                text="Select a module to access:",
                values=main_options,
                style=popup_style
            ).run_async()

            if not choice or choice == "0":
                confirm_exit = await yes_no_dialog(
                    title="🚪 Exit Application",
                    text="Are you sure you want to exit the Telecom Maintenance Scheduler?",
                    style=popup_style
                ).run_async()
                
                if confirm_exit:
                    await self._show_message(
                        "Goodbye",
                        "Thank you for using Telecom Maintenance Scheduler!\n🚀 Have a great day!"
                    )
                    break
            else:
                await self._handle_main_menu_choice(choice)

    async def _handle_main_menu_choice(self, choice: str):
        """Handle main menu selection with popup flow"""
        try:
            if choice == "1":
                await self._equipment_management_flow()
            elif choice == "2":
                await self._health_monitoring_flow()
            elif choice == "3":
                await self._ai_predictions_flow()
            elif choice == "4":
                await self._maintenance_scheduling_flow()
            elif choice == "5":
                await self._reports_analytics_flow()
            elif choice == "6":
                await self._system_management_flow()
        except Exception as e:
            await self._show_error(f"An error occurred: {str(e)}")
            logger.error(f"Error in menu choice {choice}: {e}")

    # Equipment Management Flow
    async def _equipment_management_flow(self):
        """Equipment management popup flow"""
        while True:
            options = [
                ("1", "➕ Add New Equipment"),
                ("2", "📋 View Equipment List"), 
                ("3", "🔍 View Equipment Details"),
                ("4", "✏️ Update Equipment"),
                ("5", "🗑️ Delete Equipment"),
                ("6", "📈 Equipment Statistics"),
                ("0", "🔙 Back to Main Menu")
            ]

            choice = await radiolist_dialog(
                title="📦 Equipment Management",
                text="Select an equipment management operation:",
                values=options,
                style=popup_style
            ).run_async()

            if not choice or choice == "0":
                break

            if choice == "1":
                await self._add_equipment_flow()
            elif choice == "2":
                await self._view_equipment_list_flow()
            elif choice == "3":
                await self._view_equipment_details_flow()
            elif choice == "4":
                await self._update_equipment_flow()
            elif choice == "5":
                await self._delete_equipment_flow()
            elif choice == "6":
                await self._equipment_statistics_flow()

    async def _add_equipment_flow(self):
        """Add equipment popup flow"""
        await self._show_message("Add Equipment", "🔄 Loading equipment types...")
        
        try:
            equipment_types = self.equipment_manager.get_equipment_types()
            if not equipment_types:
                await self._show_error("No equipment types found in database.")
                return

            # Select equipment type
            type_options = [(str(i), f"{eq_type['type_name']} - {eq_type['description']}") 
                           for i, eq_type in enumerate(equipment_types)]
            
            type_choice = await radiolist_dialog(
                title="➕ Select Equipment Type",
                text="Choose the type of equipment to add:",
                values=type_options,
                style=popup_style
            ).run_async()

            if not type_choice:
                return

            selected_type = equipment_types[int(type_choice)]

            # Get equipment details
            equipment_id = await self._get_input("Equipment ID", "Enter unique equipment identifier:")
            if not equipment_id:
                await self._show_warning("Equipment ID is required.")
                return

            location = await self._get_input("Location", "Enter equipment location:")
            manufacturer = await self._get_input("Manufacturer", "Enter manufacturer name:")
            model = await self._get_input("Model", "Enter equipment model:")
            firmware = await self._get_input("Firmware", "Enter firmware version:")

            # Create equipment data
            equipment_data = {
                'equipment_type_id': selected_type['id'],
                'equipment_id': equipment_id,
                'location': location,
                'manufacturer': manufacturer,
                'model': model,
                'firmware_version': firmware
            }

            # Add equipment
            result_id = self.equipment_manager.add_equipment(equipment_data)
            
            if result_id:
                await self._show_success(f"Equipment added successfully!\n\n✅ Equipment ID: {equipment_id}\n🆔 Database ID: {result_id}")
            else:
                await self._show_error("Failed to add equipment. Please check the details and try again.")

        except Exception as e:
            await self._show_error(f"Error adding equipment: {str(e)}")

        await self._wait_for_continue()

    async def _view_equipment_list_flow(self):
        """View equipment list popup flow"""
        await self._show_message("Equipment List", "🔄 Loading equipment data...")
        
        try:
            # Filter options
            filter_options = [
                ("all", "📋 All Equipment"),
                ("by_type", "📦 By Equipment Type"),
                ("by_status", "📊 By Status")
            ]

            filter_choice = await radiolist_dialog(
                title="📋 Equipment List Filter",
                text="How would you like to filter the equipment list?",
                values=filter_options,
                style=popup_style
            ).run_async()

            equipment_type = None
            status = None

            if filter_choice == "by_type":
                equipment_types = self.equipment_manager.get_equipment_types()
                type_options = [(eq_type['type_name'], eq_type['type_name']) for eq_type in equipment_types]
                
                equipment_type = await radiolist_dialog(
                    title="📦 Select Equipment Type",
                    text="Choose equipment type to filter:",
                    values=type_options,
                    style=popup_style
                ).run_async()

            elif filter_choice == "by_status":
                status_options = [
                    ("active", "✅ Active"),
                    ("inactive", "⭕ Inactive"), 
                    ("maintenance", "🔧 Under Maintenance"),
                    ("failed", "❌ Failed")
                ]
                
                status = await radiolist_dialog(
                    title="📊 Select Status",
                    text="Choose status to filter:",
                    values=status_options,
                    style=popup_style
                ).run_async()

            # Get equipment list
            equipment_list = self.equipment_manager.get_all_equipment(equipment_type, status)
            
            if not equipment_list:
                await self._show_warning("No equipment found matching the selected criteria.")
                return

            # Show formatted equipment list
            list_text = f"📋 Equipment List ({len(equipment_list)} items)\n\n"
            
            for i, equipment in enumerate(equipment_list[:10], 1):  # Show first 10
                status_icon = {"active": "✅", "inactive": "⭕", "maintenance": "🔧", "failed": "❌"}.get(equipment['status'], "❓")
                list_text += f"{i:2d}. {status_icon} {equipment['equipment_id']}\n"
                list_text += f"    📦 Type: {equipment['type_name']}\n"
                list_text += f"    📍 Location: {equipment['location'] or 'N/A'}\n"
                list_text += f"    🏭 Manufacturer: {equipment['manufacturer'] or 'N/A'}\n"
                list_text += f"    📱 Model: {equipment['model'] or 'N/A'}\n\n"
            
            if len(equipment_list) > 10:
                list_text += f"... and {len(equipment_list) - 10} more equipment items"

            await message_dialog(
                title="📋 Equipment List",
                text=list_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error retrieving equipment list: {str(e)}")

        await self._wait_for_continue()

    async def _view_equipment_details_flow(self):
        """View equipment details popup flow"""
        equipment_id = await self._get_input("Equipment Details", "Enter Equipment ID to view details:")
        
        if not equipment_id:
            await self._show_warning("Equipment ID is required.")
            return

        try:
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                await self._show_error(f"Equipment with ID '{equipment_id}' not found.")
                return

            # Get latest health metrics
            latest_health = self.health_monitor.get_latest_health_metrics(equipment['id'])

            # Format equipment details
            details = f"🔍 Equipment Details\n\n"
            details += f"🆔 ID: {equipment['equipment_id']}\n"
            details += f"📦 Type: {equipment['type_name']}\n"
            details += f"📍 Location: {equipment['location'] or 'N/A'}\n"
            details += f"📊 Status: {equipment['status']}\n"
            details += f"🏭 Manufacturer: {equipment['manufacturer'] or 'N/A'}\n"
            details += f"📱 Model: {equipment['model'] or 'N/A'}\n"
            details += f"💾 Firmware: {equipment['firmware_version'] or 'N/A'}\n"
            details += f"📅 Installed: {equipment['installation_date'] or 'N/A'}\n"
            details += f"🔧 Last Maintenance: {equipment['last_maintenance_date'] or 'Never'}\n"

            if latest_health:
                details += f"\n❤️ Latest Health Metrics:\n"
                details += f"📊 Health Score: {latest_health['health_score']:.4f}\n"
                details += f"💻 CPU Usage: {latest_health['cpu_usage']}%\n"
                details += f"💾 Memory Usage: {latest_health['memory_usage']}%\n"
                details += f"🌡️ Temperature: {latest_health['temperature']}°C\n"
                details += f"⏰ Uptime: {latest_health['uptime_hours']} hours\n"
            else:
                details += f"\n⚠️ No health data available"

            await message_dialog(
                title=f"🔍 Equipment: {equipment_id}",
                text=details,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error retrieving equipment details: {str(e)}")

        await self._wait_for_continue()

    async def _update_equipment_flow(self):
        """Update equipment popup flow"""
        equipment_id = await self._get_input("Update Equipment", "Enter Equipment ID to update:")
        
        if not equipment_id:
            await self._show_warning("Equipment ID is required.")
            return

        try:
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                await self._show_error(f"Equipment with ID '{equipment_id}' not found.")
                return

            # Show current details
            await self._show_message(
                "Current Equipment Details",
                f"🆔 ID: {equipment['equipment_id']}\n📦 Type: {equipment['type_name']}\n📍 Location: {equipment['location'] or 'N/A'}\n📊 Status: {equipment['status']}"
            )

            # Get updates
            new_location = await self._get_input("Update Location", f"New location (current: {equipment['location'] or 'N/A'}):", equipment['location'] or "")
            new_manufacturer = await self._get_input("Update Manufacturer", f"New manufacturer (current: {equipment['manufacturer'] or 'N/A'}):", equipment['manufacturer'] or "")
            new_model = await self._get_input("Update Model", f"New model (current: {equipment['model'] or 'N/A'}):", equipment['model'] or "")

            # Status update
            status_options = [
                ("active", "✅ Active"),
                ("inactive", "⭕ Inactive"),
                ("maintenance", "🔧 Under Maintenance"),
                ("failed", "❌ Failed")
            ]

            new_status = await radiolist_dialog(
                title="📊 Update Status",
                text=f"Current status: {equipment['status']}\nSelect new status:",
                values=status_options,
                default=equipment['status'],
                style=popup_style
            ).run_async()

            # Prepare update data
            update_data = {}
            if new_location and new_location != equipment['location']:
                update_data['location'] = new_location
            if new_manufacturer and new_manufacturer != equipment['manufacturer']:
                update_data['manufacturer'] = new_manufacturer
            if new_model and new_model != equipment['model']:
                update_data['model'] = new_model
            if new_status and new_status != equipment['status']:
                update_data['status'] = new_status

            if not update_data:
                await self._show_warning("No changes made.")
                return

            # Update equipment
            success = self.equipment_manager.update_equipment(equipment_id, update_data)
            
            if success:
                await self._show_success("Equipment updated successfully!")
            else:
                await self._show_error("Failed to update equipment.")

        except Exception as e:
            await self._show_error(f"Error updating equipment: {str(e)}")

        await self._wait_for_continue()

    async def _delete_equipment_flow(self):
        """Delete equipment popup flow"""
        equipment_id = await self._get_input("Delete Equipment", "⚠️ Enter Equipment ID to DELETE:")
        
        if not equipment_id:
            await self._show_warning("Equipment ID is required.")
            return

        try:
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                await self._show_error(f"Equipment with ID '{equipment_id}' not found.")
                return

            # Confirmation dialog
            confirm = await yes_no_dialog(
                title="🗑️ Confirm Deletion",
                text=f"⚠️ WARNING: This will permanently delete equipment and ALL associated data!\n\n🆔 ID: {equipment['equipment_id']}\n📦 Type: {equipment['type_name']}\n📍 Location: {equipment['location'] or 'N/A'}\n\nAre you absolutely sure?",
                style=popup_style
            ).run_async()

            if confirm:
                success = self.equipment_manager.delete_equipment(equipment_id)
                
                if success:
                    await self._show_success("Equipment deleted successfully!")
                else:
                    await self._show_error("Failed to delete equipment.")
            else:
                await self._show_message("Deletion Cancelled", "Equipment deletion was cancelled.")

        except Exception as e:
            await self._show_error(f"Error deleting equipment: {str(e)}")

        await self._wait_for_continue()

    async def _equipment_statistics_flow(self):
        """Equipment statistics popup flow"""
        await self._show_message("Statistics", "🔄 Generating equipment statistics...")
        
        try:
            stats = self.equipment_manager.get_equipment_statistics()
            
            if not stats:
                await self._show_warning("No statistics available.")
                return

            # Format statistics
            stats_text = f"📈 Equipment Statistics\n\n"
            stats_text += f"📊 Total Equipment: {stats['total_count']}\n\n"
            
            stats_text += f"📦 By Equipment Type:\n"
            for item in stats['by_type']:
                stats_text += f"  • {item['type_name']}: {item['count']}\n"
            
            stats_text += f"\n📊 By Status:\n"
            status_icons = {"active": "✅", "inactive": "⭕", "maintenance": "🔧", "failed": "❌"}
            for item in stats['by_status']:
                icon = status_icons.get(item['status'], "❓")
                stats_text += f"  {icon} {item['status']}: {item['count']}\n"

            if stats.get('by_age'):
                stats_text += f"\n📅 By Age Groups:\n"
                for item in stats['by_age']:
                    stats_text += f"  • {item['age_group']}: {item['count']}\n"

            await message_dialog(
                title="📈 Equipment Statistics",
                text=stats_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error generating statistics: {str(e)}")

        await self._wait_for_continue()

    # Health Monitoring Flow
    async def _health_monitoring_flow(self):
        """Health monitoring popup flow"""
        while True:
            options = [
                ("1", "📝 Record Health Metrics"),
                ("2", "📊 View Current Health Status"),
                ("3", "📈 View Health History"),
                ("4", "🔍 Detect Anomalies"),
                ("5", "📉 Health Trends Analysis"),
                ("0", "🔙 Back to Main Menu")
            ]

            choice = await radiolist_dialog(
                title="❤️ Health Monitoring",
                text="Select a health monitoring operation:",
                values=options,
                style=popup_style
            ).run_async()

            if not choice or choice == "0":
                break

            if choice == "1":
                await self._record_health_metrics_flow()
            elif choice == "2":
                await self._view_health_status_flow()
            elif choice == "3":
                await self._view_health_history_flow()
            elif choice == "4":
                await self._detect_anomalies_flow()
            elif choice == "5":
                await self._health_trends_flow()

    async def _record_health_metrics_flow(self):
        """Record health metrics popup flow"""
        equipment_id = await self._get_input("Record Health Metrics", "Enter Equipment ID:")
        
        if not equipment_id:
            await self._show_warning("Equipment ID is required.")
            return

        try:
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                await self._show_error(f"Equipment with ID '{equipment_id}' not found.")
                return

            await self._show_message("Equipment Found", f"Recording metrics for:\n🆔 {equipment['equipment_id']} ({equipment['type_name']})")

            # Collect metrics through individual dialogs
            metrics = {}
            
            metric_prompts = [
                ('cpu_usage', '💻 CPU Usage (%)', 0, 100),
                ('memory_usage', '💾 Memory Usage (%)', 0, 100),
                ('temperature', '🌡️ Temperature (°C)', -50, 150),
                ('power_consumption', '⚡ Power Consumption (W)', 0, 10000),
                ('uptime_hours', '⏰ Uptime (hours)', 0, 8760),
                ('error_count', '❌ Error Count', 0, 1000)
            ]

            for metric, prompt, min_val, max_val in metric_prompts:
                value_str = await self._get_input("Health Metrics", f"{prompt} (optional, {min_val}-{max_val}):")
                
                if value_str:
                    try:
                        value = float(value_str)
                        if min_val <= value <= max_val:
                            metrics[metric] = value
                        else:
                            await self._show_warning(f"Value must be between {min_val} and {max_val}. Skipping {metric}.")
                    except ValueError:
                        await self._show_warning(f"Invalid number format for {metric}. Skipping.")

            if not metrics:
                await self._show_warning("No valid metrics provided.")
                return

            # Record metrics
            success = self.health_monitor.record_health_metrics(equipment['id'], metrics)
            
            if success:
                await self._show_success(f"Health metrics recorded successfully!\n\n📊 Recorded {len(metrics)} metrics for {equipment['equipment_id']}")
            else:
                await self._show_error("Failed to record health metrics.")

        except Exception as e:
            await self._show_error(f"Error recording metrics: {str(e)}")

        await self._wait_for_continue()

    async def _view_health_status_flow(self):
        """View health status popup flow"""
        await self._show_message("Health Status", "🔄 Loading health status data...")
        
        try:
            # Filter options
            filter_options = [
                ("all", "📊 All Equipment"),
                ("by_type", "📦 By Equipment Type")
            ]

            filter_choice = await radiolist_dialog(
                title="📊 Health Status Filter",
                text="How would you like to filter the health status?",
                values=filter_options,
                style=popup_style
            ).run_async()

            equipment_type = None
            if filter_choice == "by_type":
                equipment_types = self.equipment_manager.get_equipment_types()
                type_options = [(eq_type['type_name'], eq_type['type_name']) for eq_type in equipment_types]
                
                equipment_type = await radiolist_dialog(
                    title="📦 Select Equipment Type",
                    text="Choose equipment type:",
                    values=type_options,
                    style=popup_style
                ).run_async()

            # Get health summary
            health_data = self.health_monitor.get_equipment_health_summary(equipment_type)
            
            if not health_data:
                await self._show_warning("No health data available.")
                return

            # Format health status
            status_text = f"❤️ Health Status Summary ({len(health_data)} items)\n\n"
            
            # Categorize by health status
            critical_items = [item for item in health_data if item.get('health_status') == 'CRITICAL']
            warning_items = [item for item in health_data if item.get('health_status') == 'WARNING']
            normal_items = [item for item in health_data if item.get('health_status') == 'NORMAL']

            if critical_items:
                status_text += f"🚨 CRITICAL ({len(critical_items)}):\n"
                for item in critical_items[:5]:
                    status_text += f"  • {item['equipment_id']} - Score: {item.get('health_score', 0):.3f}\n"
            
            if warning_items:
                status_text += f"\n⚠️ WARNING ({len(warning_items)}):\n"
                for item in warning_items[:5]:
                    status_text += f"  • {item['equipment_id']} - Score: {item.get('health_score', 0):.3f}\n"
            
            status_text += f"\n✅ NORMAL: {len(normal_items)} equipment\n"
            
            # Summary
            total_items = len(health_data)
            status_text += f"\n📊 Summary:\n"
            status_text += f"  Total: {total_items}\n"
            status_text += f"  Critical: {len(critical_items)} ({len(critical_items)/total_items*100:.1f}%)\n"
            status_text += f"  Warning: {len(warning_items)} ({len(warning_items)/total_items*100:.1f}%)\n"
            status_text += f"  Normal: {len(normal_items)} ({len(normal_items)/total_items*100:.1f}%)\n"

            await message_dialog(
                title="❤️ Health Status Dashboard",
                text=status_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error retrieving health status: {str(e)}")

        await self._wait_for_continue()

    async def _view_health_history_flow(self):
        """View health history popup flow"""
        equipment_id = await self._get_input("Health History", "Enter Equipment ID:")
        
        if not equipment_id:
            await self._show_warning("Equipment ID is required.")
            return

        try:
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                await self._show_error(f"Equipment with ID '{equipment_id}' not found.")
                return

            days_str = await self._get_input("History Period", "Number of days to show (default 7):", "7")
            days = int(days_str) if days_str.isdigit() else 7

            history = self.health_monitor.get_health_history(equipment['id'], days)
            
            if not history:
                await self._show_warning("No health history found for the specified period.")
                return

            # Format history
            history_text = f"📈 Health History - {equipment['equipment_id']}\n"
            history_text += f"📅 Last {days} days ({len(history)} records)\n\n"
            
            for i, record in enumerate(history[:10], 1):  # Show first 10 records
                history_text += f"{i:2d}. {record['timestamp'].strftime('%m-%d %H:%M')}\n"
                history_text += f"    📊 Health: {record['health_score']:.3f}\n"
                if record.get('cpu_usage'):
                    history_text += f"    💻 CPU: {record['cpu_usage']:.1f}%\n"
                if record.get('memory_usage'):
                    history_text += f"    💾 Memory: {record['memory_usage']:.1f}%\n"
                if record.get('temperature'):
                    history_text += f"    🌡️ Temp: {record['temperature']:.1f}°C\n"
                history_text += "\n"
            
            if len(history) > 10:
                history_text += f"... and {len(history) - 10} more records"

            await message_dialog(
                title=f"📈 Health History - {equipment_id}",
                text=history_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error retrieving health history: {str(e)}")

        await self._wait_for_continue()

    async def _detect_anomalies_flow(self):
        """Detect anomalies popup flow"""
        equipment_id = await self._get_input("Anomaly Detection", "Enter Equipment ID:")
        
        if not equipment_id:
            await self._show_warning("Equipment ID is required.")
            return

        try:
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                await self._show_error(f"Equipment with ID '{equipment_id}' not found.")
                return

            days_str = await self._get_input("Analysis Period", "Analysis period in days (default 7):", "7")
            days = int(days_str) if days_str.isdigit() else 7

            await self._show_message("Analyzing", f"🔍 Detecting anomalies for {equipment_id}...")

            anomalies = self.health_monitor.detect_anomalies(equipment['id'], days)
            
            if not anomalies:
                await self._show_success("No anomalies detected in the specified period!")
                return

            # Format anomalies
            anomaly_text = f"🔍 Anomalies Detected - {equipment['equipment_id']}\n"
            anomaly_text += f"📅 Period: {days} days ({len(anomalies)} anomalies)\n\n"
            
            for i, anomaly in enumerate(anomalies[:10], 1):  # Show first 10
                severity_icon = '🚨' if anomaly['severity'] == 'HIGH' else '⚠️'
                anomaly_text += f"{i:2d}. {severity_icon} {anomaly['timestamp'].strftime('%m-%d %H:%M')}\n"
                anomaly_text += f"    📊 Metric: {anomaly['metric']}\n"
                anomaly_text += f"    📈 Value: {anomaly['value']}\n"
                anomaly_text += f"    ⚖️ Threshold: {anomaly['threshold']}\n"
                anomaly_text += f"    📏 Deviation: +{anomaly['deviation']:.2f}\n"
                anomaly_text += f"    🚨 Severity: {anomaly['severity']}\n\n"
            
            if len(anomalies) > 10:
                anomaly_text += f"... and {len(anomalies) - 10} more anomalies"

            await message_dialog(
                title=f"🔍 Anomalies - {equipment_id}",
                text=anomaly_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error detecting anomalies: {str(e)}")

        await self._wait_for_continue()

    async def _health_trends_flow(self):
        """Health trends analysis popup flow"""
        equipment_id = await self._get_input("Health Trends", "Enter Equipment ID:")
        
        if not equipment_id:
            await self._show_warning("Equipment ID is required.")
            return

        try:
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                await self._show_error(f"Equipment with ID '{equipment_id}' not found.")
                return

            days_str = await self._get_input("Analysis Period", "Analysis period in days (default 30):", "30")
            days = int(days_str) if days_str.isdigit() else 30

            await self._show_message("Analyzing", f"📉 Analyzing health trends for {equipment_id}...")

            trends = self.health_monitor.get_health_trends(equipment['id'], days)
            
            if not trends:
                await self._show_warning("No trend data available for analysis.")
                return

            # Format trends
            trends_text = f"📉 Health Trends - {equipment['equipment_id']}\n"
            trends_text += f"📅 Period: {days} days\n\n"
            
            for metric, data in trends.items():
                trend_arrow = {
                    'INCREASING': '↗️',
                    'DECREASING': '↘️',
                    'STABLE': '→'
                }.get(data['trend_direction'], '❓')
                
                trends_text += f"📊 {metric.replace('_', ' ').title()}:\n"
                trends_text += f"  📈 Current: {data['current_value']:.2f}\n"
                trends_text += f"  📊 Average: {data['average_value']:.2f}\n"
                trends_text += f"  {trend_arrow} Trend: {data['trend_direction']}\n"
                trends_text += f"  📉 Min: {data['min_value']:.2f}\n"
                trends_text += f"  📈 Max: {data['max_value']:.2f}\n\n"

            await message_dialog(
                title=f"📉 Health Trends - {equipment_id}",
                text=trends_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error analyzing trends: {str(e)}")

        await self._wait_for_continue()

    # AI Predictions Flow
    async def _ai_predictions_flow(self):
        """AI predictions popup flow"""
        while True:
            options = [
                ("1", "🧠 Train Model for Equipment Type"),
                ("2", "🔮 Predict Failure Risk"),
         
                ("3", "ℹ️ Model Information"),
                ("4", "🔄 Retrain All Models"),
                ("0", "🔙 Back to Main Menu")
            ]

            choice = await radiolist_dialog(
                title="🤖 AI Predictions",
                text="Select an AI prediction operation:",
                values=options,
                style=popup_style
            ).run_async()

            if not choice or choice == "0":
                break

            if choice == "1":
                await self._train_model_flow()
            elif choice == "2":
                await self._predict_failure_risk_flow()
            elif choice == "8":
                await self._batch_predictions_flow()
            elif choice == "3":
                await self._model_information_flow()
            elif choice == "4":
                await self._retrain_all_models_flow()

    async def _train_model_flow(self):
        """Train model popup flow"""
        await self._show_message("Train Model", "🔄 Loading equipment types...")
        
        try:
            equipment_types = self.equipment_manager.get_equipment_types()
            type_options = [(eq_type['type_name'], eq_type['type_name']) for eq_type in equipment_types]
            
            equipment_type = await radiolist_dialog(
                title="🧠 Select Equipment Type",
                text="Choose equipment type to train AI model:",
                values=type_options,
                style=popup_style
            ).run_async()

            if not equipment_type:
                return

            await self._show_message("Training", f"🚀 Training AI model for {equipment_type}...\nThis may take a few minutes depending on data size.")

            success = self.ai_predictor.train_model(equipment_type, retrain=True)
            
            if success:
                await self._show_success(f"🎉 Model trained successfully for {equipment_type}!\n\n✅ The AI model is now ready for predictions.")
            else:
                await self._show_error(f"Model training failed for {equipment_type}.\n\nPlease ensure sufficient training data exists.")

        except Exception as e:
            await self._show_error(f"Error training model: {str(e)}")

        await self._wait_for_continue()

    async def _predict_failure_risk_flow(self):
        """Predict failure risk popup flow"""
        equipment_id = await self._get_input("Failure Risk Prediction", "Enter Equipment ID:")
        
        if not equipment_id:
            await self._show_warning("Equipment ID is required.")
            return

        try:
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                await self._show_error(f"Equipment with ID '{equipment_id}' not found.")
                return

            await self._show_message("Equipment Found", f"🔮 Preparing prediction for:\n🆔 {equipment['equipment_id']} ({equipment['type_name']})")

            # Get latest health metrics
            latest_metrics = self.health_monitor.get_latest_health_metrics(equipment['id'])
            
            if not latest_metrics:
                await self._show_warning("No health metrics found. Cannot make prediction.")
                return

            # Use latest metrics
            metrics = {
                'cpu_usage': latest_metrics['cpu_usage'],
                'memory_usage': latest_metrics['memory_usage'],
                'temperature': latest_metrics['temperature'],
                'power_consumption': latest_metrics['power_consumption'],
                'uptime_hours': latest_metrics['uptime_hours'],
                'packet_loss_rate': latest_metrics['packet_loss_rate'],
                'error_count': latest_metrics['error_count'],
                'bandwidth_utilization': latest_metrics['bandwidth_utilization'],
                'signal_strength': latest_metrics['signal_strength']
            }

            await self._show_message("Processing", "🤖 Analyzing data and making prediction...")

            prediction = self.ai_predictor.predict_failure_risk(
                equipment['id'], equipment['type_name'], metrics
            )

            # Display results
            if 'error' in prediction:
                await self._show_error(f"Prediction Error: {prediction['error']}")
                return

            # Format prediction results
            risk_level = prediction['risk_level']
            risk_icons = {
                'LOW': '✅',
                'MEDIUM': '🟡',
                'HIGH': '⚠️',
                'CRITICAL': '🚨'
            }

            result_text = f"🎯 Prediction Results\n\n"
            result_text += f"🆔 Equipment: {prediction.get('equipment_name', equipment_id)}\n"
            result_text += f"📦 Type: {prediction['equipment_type']}\n"
            result_text += f"📅 Timestamp: {prediction['timestamp']}\n\n"
            result_text += f"{risk_icons.get(risk_level, '❓')} Risk Level: {risk_level}\n"
            result_text += f"📊 Failure Probability: {prediction['failure_probability']:.4f} ({prediction['failure_probability']*100:.2f}%)\n"
            result_text += f"🎯 Confidence Score: {prediction['confidence_score']:.4f}\n\n"

            if prediction.get('missing_features'):
                result_text += f"⚠️ Missing Features: {', '.join(prediction['missing_features'])}\n\n"

            result_text += f"💡 Recommendations:\n"
            for i, recommendation in enumerate(prediction['recommendations'], 1):
                result_text += f"  {i}. {recommendation}\n"

            await message_dialog(
                title=f"🔮 Prediction Results - {equipment_id}",
                text=result_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error making prediction: {str(e)}")

        await self._wait_for_continue()

    async def _batch_predictions_flow(self):
        """Batch predictions popup flow"""
        await self._show_message("Batch Predictions", "🔄 Loading equipment types...")
        
        try:
            equipment_types = self.equipment_manager.get_equipment_types()
            type_options = [(eq_type['type_name'], eq_type['type_name']) for eq_type in equipment_types]
            
            equipment_type = await radiolist_dialog(
                title="📊 Select Equipment Type",
                text="Choose equipment type for batch predictions:",
                values=type_options,
                style=popup_style
            ).run_async()

            if not equipment_type:
                return

            await self._show_message("Processing", f"🚀 Running batch predictions for {equipment_type}...\nThis may take a few moments.")

            predictions = self.ai_predictor.batch_predict(equipment_type)
            
            if not predictions:
                await self._show_warning("No predictions generated.\nEnsure models are trained and equipment has health data.")
                return

            # Filter valid predictions
            valid_predictions = [p for p in predictions if isinstance(p, dict) and 'error' not in p]
            
            if not valid_predictions:
                await self._show_warning("No valid predictions to display.")
                return

            # Sort by risk level
            valid_predictions.sort(key=lambda x: x.get('failure_probability', 0), reverse=True)

            # Format results
            results_text = f"📊 Batch Prediction Results - {equipment_type}\n"
            results_text += f"🔮 Processed: {len(valid_predictions)} devices\n\n"

            # Show top 10 results
            for i, pred in enumerate(valid_predictions[:10], 1):
                risk_level = pred.get('risk_level', 'UNKNOWN')
                risk_icons = {
                    'CRITICAL': '🚨',
                    'HIGH': '⚠️',
                    'MEDIUM': '🟡',
                    'LOW': '✅'
                }.get(risk_level, '❓')

                results_text += f"{i:2d}. {risk_icons} {pred.get('equipment_name', 'Unknown')[:15]}\n"
                results_text += f"    📊 Risk: {risk_level}\n"
                results_text += f"    📈 Probability: {pred.get('failure_probability', 0):.4f}\n"
                results_text += f"    🎯 Confidence: {pred.get('confidence_score', 0):.3f}\n\n"

            if len(valid_predictions) > 10:
                results_text += f"... and {len(valid_predictions) - 10} more devices\n\n"

            # Risk summary
            risk_summary = {}
            for pred in valid_predictions:
                risk_level = pred.get('risk_level', 'UNKNOWN')
                risk_summary[risk_level] = risk_summary.get(risk_level, 0) + 1

            results_text += f"📈 Risk Level Summary:\n"
            for level, count in risk_summary.items():
                risk_icon = {
                    'CRITICAL': '🚨',
                    'HIGH': '⚠️',
                    'MEDIUM': '🟡',
                    'LOW': '✅'
                }.get(level, '❓')
                results_text += f"  {risk_icon} {level}: {count} devices\n"

            await message_dialog(
                title=f"📊 Batch Predictions - {equipment_type}",
                text=results_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error running batch predictions: {str(e)}")

        await self._wait_for_continue()

    async def _model_information_flow(self):
        """Model information popup flow"""
        await self._show_message("Model Information", "🔄 Loading equipment types...")
        
        try:
            equipment_types = self.equipment_manager.get_equipment_types()
            type_options = [(eq_type['type_name'], eq_type['type_name']) for eq_type in equipment_types]
            
            equipment_type = await radiolist_dialog(
                title="ℹ️ Select Equipment Type",
                text="Choose equipment type to view model information:",
                values=type_options,
                style=popup_style
            ).run_async()

            if not equipment_type:
                return

            info = self.ai_predictor.get_model_info(equipment_type)
            
            if 'error' in info:
                await self._show_error(f"Model information not available: {info['error']}")
                return

            # Format model info
            info_text = f"ℹ️ Model Information - {equipment_type}\n\n"
            info_text += f"🤖 Model Type: {info['model_type']}\n"
            info_text += f"💾 Model Size: {info['model_size_mb']} MB\n"
            info_text += f"📅 Created: {info['created_at']}\n"
            info_text += f"🎯 Features: {len(info['features_used'])}\n"

            if 'n_estimators' in info:
                info_text += f"🌳 Estimators: {info['n_estimators']}\n"
                info_text += f"📏 Max Depth: {info['max_depth']}\n"
                info_text += f"🎯 Classes: {info['n_classes']}\n"

            info_text += f"\n🎯 Features Used:\n"
            for i, feature in enumerate(info['features_used'], 1):
                info_text += f"  {i:2d}. {feature}\n"

            await message_dialog(
                title=f"ℹ️ Model Info - {equipment_type}",
                text=info_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error getting model info: {str(e)}")

        await self._wait_for_continue()

    async def _retrain_all_models_flow(self):
        """Retrain all models popup flow"""
        confirm = await yes_no_dialog(
            title="🔄 Retrain All Models",
            text="⚠️ This will retrain models for all equipment types.\nThis process may take several minutes.\n\nContinue with retraining?",
            style=popup_style
        ).run_async()

        if not confirm:
            await self._show_message("Cancelled", "Model retraining was cancelled.")
            return

        try:
            equipment_types = self.equipment_manager.get_equipment_types()
            success_count = 0

            await self._show_message("Retraining", f"🚀 Starting batch retraining for {len(equipment_types)} equipment types...")

            for eq_type in equipment_types:
                equipment_type = eq_type['type_name']
                
                success = self.ai_predictor.train_model(equipment_type, retrain=True)
                if success:
                    success_count += 1

            result_text = f"🎯 Retraining Completed\n\n"
            result_text += f"✅ Successful: {success_count}/{len(equipment_types)} models\n"
            
            if success_count == len(equipment_types):
                result_text += f"\n🎉 All models trained successfully!"
            elif success_count > 0:
                result_text += f"\n⚠️ Some models failed to train. Check logs for details."
            else:
                result_text += f"\n❌ All model training failed. Check data and configuration."

            await message_dialog(
                title="🔄 Retraining Results",
                text=result_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error retraining models: {str(e)}")

        await self._wait_for_continue()

    # Maintenance Scheduling Flow
    async def _maintenance_scheduling_flow(self):
        """Maintenance scheduling popup flow"""
        while True:
            options = [
                ("1", "📅 Schedule Maintenance"),
                ("2", "📋 View Maintenance Schedule"),
                ("3", "🤖 Generate AI-Driven Schedule"),
                ("4", "✏️ Update Maintenance Status"),
                ("5", "📊 Maintenance Analytics"),
                ("0", "🔙 Back to Main Menu")
            ]

            choice = await radiolist_dialog(
                title="🔧 Maintenance Scheduling",
                text="Select a maintenance scheduling operation:",
                values=options,
                style=popup_style
            ).run_async()

            if not choice or choice == "0":
                break

            if choice == "1":
                await self._schedule_maintenance_flow()
            elif choice == "2":
                await self._view_maintenance_schedule_flow()
            elif choice == "3":
                await self._generate_ai_schedule_flow()
            elif choice == "4":
                await self._update_maintenance_status_flow()
            elif choice == "5":
                await self._maintenance_analytics_flow()

    async def _schedule_maintenance_flow(self):
        """Schedule maintenance popup flow"""
        equipment_id = await self._get_input("Schedule Maintenance", "Enter Equipment ID:")
        
        if not equipment_id:
            await self._show_warning("Equipment ID is required.")
            return

        try:
            equipment = self.equipment_manager.get_equipment_by_id(equipment_id)
            
            if not equipment:
                await self._show_error(f"Equipment with ID '{equipment_id}' not found.")
                return

            await self._show_message("Equipment Found", f"Scheduling maintenance for:\n🆔 {equipment['equipment_id']} ({equipment['type_name']})")

            # Maintenance type selection
            type_options = [
                ("preventive", "🛡️ Preventive"),
                ("corrective", "🔧 Corrective"),
                ("emergency", "🚨 Emergency"),
                ("scheduled", "📅 Scheduled")
            ]

            maintenance_type = await radiolist_dialog(
                title="🔧 Maintenance Type",
                text="Choose the type of maintenance:",
                values=type_options,
                style=popup_style
            ).run_async()

            if not maintenance_type:
                return

            # Get maintenance details
            scheduled_date = await self._get_input("Schedule Date", "Scheduled Date (YYYY-MM-DD):")
            if not scheduled_date:
                await self._show_warning("Scheduled date is required.")
                return

            description = await self._get_input("Description", "Maintenance description:")
            technician_id = await self._get_input("Technician", "Technician ID (optional):")

            # Priority selection
            priority_options = [
                ("low", "🟢 Low"),
                ("medium", "🟡 Medium"),
                ("high", "🟠 High"),
                ("critical", "🔴 Critical")
            ]

            priority = await radiolist_dialog(
                title="📊 Priority Level",
                text="Select maintenance priority:",
                values=priority_options,
                style=popup_style
            ).run_async()

            cost_str = await self._get_input("Cost", "Estimated Cost (optional):")
            cost = None
            if cost_str:
                try:
                    cost = float(cost_str)
                except ValueError:
                    await self._show_warning("Invalid cost format. Continuing without cost.")

            # Prepare maintenance data
            maintenance_data = {
                'maintenance_type': maintenance_type,
                'scheduled_date': scheduled_date,
                'description': description,
                'priority': priority or 'medium',
            }

            if technician_id:
                maintenance_data['technician_id'] = technician_id
            if cost:
                maintenance_data['cost'] = cost

            # Schedule maintenance
            maintenance_id = self.maintenance_scheduler.schedule_maintenance(equipment['id'], maintenance_data)
            
            if maintenance_id:
                await self._show_success(f"✅ Maintenance scheduled successfully!\n\n🆔 Maintenance ID: {maintenance_id}\n📅 Scheduled: {scheduled_date}\n🔧 Type: {maintenance_type}\n📊 Priority: {priority or 'medium'}")
            else:
                await self._show_error("Failed to schedule maintenance.")

        except Exception as e:
            await self._show_error(f"Error scheduling maintenance: {str(e)}")

        await self._wait_for_continue()

    async def _view_maintenance_schedule_flow(self):
        """View maintenance schedule popup flow"""
        await self._show_message("Maintenance Schedule", "🔄 Loading maintenance schedule...")
        
        try:
            # Filter options
            filter_options = [
                ("all", "📋 All Scheduled Maintenance"),
                ("by_equipment", "📦 By Equipment"),
                ("by_status", "📊 By Status"),
                ("by_date", "📅 By Date Range")
            ]

            filter_choice = await radiolist_dialog(
                title="📋 Schedule Filter",
                text="How would you like to filter the maintenance schedule?",
                values=filter_options,
                style=popup_style
            ).run_async()

            equipment_id = None
            status = None
            days_ahead = 30

            if filter_choice == "by_equipment":
                equipment_name = await self._get_input("Filter by Equipment", "Enter Equipment ID:")
                equipment = self.equipment_manager.get_equipment_by_id(equipment_name)
                if equipment:
                    equipment_id = equipment['id']
                else:
                    await self._show_error("Equipment not found.")
                    return

            elif filter_choice == "by_status":
                status_options = [
                    ("scheduled", "📅 Scheduled"),
                    ("in_progress", "⚡ In Progress"),
                    ("completed", "✅ Completed"),
                    ("cancelled", "❌ Cancelled")
                ]
                
                status = await radiolist_dialog(
                    title="📊 Select Status",
                    text="Choose maintenance status:",
                    values=status_options,
                    style=popup_style
                ).run_async()

            elif filter_choice == "by_date":
                days_str = await self._get_input("Date Range", "Days ahead to show (default 30):", "30")
                days_ahead = int(days_str) if days_str.isdigit() else 30

            # Get maintenance schedule
            schedule = self.maintenance_scheduler.get_maintenance_schedule(equipment_id, status, days_ahead)
            
            if not schedule:
                await self._show_warning("No maintenance tasks found matching criteria.")
                return

            # Format schedule
            schedule_text = f"📋 Maintenance Schedule ({len(schedule)} tasks)\n\n"
            
            for i, task in enumerate(schedule[:15], 1):  # Show first 15
                priority_icons = {
                    'critical': '🔴',
                    'high': '🟠',
                    'medium': '🟡',
                    'low': '🟢'
                }.get(task['priority'], '⚪')
                
                status_icons = {
                    'scheduled': '📅',
                    'in_progress': '⚡',
                    'completed': '✅',
                    'cancelled': '❌'
                }.get(task['status'], '⚪')

                schedule_text += f"{i:2d}. {status_icons} ID: {task['id']}\n"
                schedule_text += f"    📦 Equipment: {task['equipment_name'][:20]}\n"
                schedule_text += f"    🔧 Type: {task['maintenance_type']}\n"
                schedule_text += f"    {priority_icons} Priority: {task['priority']}\n"
                schedule_text += f"    📅 Scheduled: {task['scheduled_date']}\n"
                if task.get('cost'):
                    schedule_text += f"    💰 Cost: ${task['cost']:.0f}\n"
                schedule_text += "\n"
            
            if len(schedule) > 15:
                schedule_text += f"... and {len(schedule) - 15} more tasks"

            await message_dialog(
                title="📋 Maintenance Schedule",
                text=schedule_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error retrieving maintenance schedule: {str(e)}")

        await self._wait_for_continue()

    async def _generate_ai_schedule_flow(self):
        """Generate AI-driven schedule popup flow"""
        await self._show_message("AI Schedule", "🤖 Generating AI-driven maintenance recommendations...\nAnalyzing equipment health and failure predictions...")
        
        try:
            recommendations = self.maintenance_scheduler.generate_ai_driven_schedule()
            
            if not recommendations:
                await self._show_warning("No maintenance recommendations generated.")
                return

            # Format recommendations
            rec_text = f"🤖 AI-Generated Maintenance Recommendations\n"
            rec_text += f"🎯 Total Recommendations: {len(recommendations)}\n\n"
            
            # Show top 10 recommendations
            for i, rec in enumerate(recommendations[:10], 1):
                risk_prob = rec.get('failure_probability', 0)
                risk_indicator = "🚨" if risk_prob > 0.7 else "⚠️" if risk_prob > 0.4 else "🟡"
                
                priority_icons = {
                    'critical': '🔴',
                    'high': '🟠',
                    'medium': '🟡',
                    'low': '🟢'
                }.get(rec['priority'], '⚪')

                rec_text += f"{i:2d}. {risk_indicator} {rec['equipment_name'][:20]}\n"
                rec_text += f"    📦 Type: {rec['equipment_type']}\n"
                rec_text += f"    {priority_icons} Priority: {rec['priority'].upper()}\n"
                rec_text += f"    📅 Scheduled: {rec['scheduled_date']}\n"
                rec_text += f"    📊 Risk: {risk_prob:.3f}\n"
                rec_text += f"    💰 Est. Cost: ${rec['estimated_cost']:.0f}\n"
                rec_text += f"    📝 {rec['description'][:40]}...\n\n"
            
            if len(recommendations) > 10:
                rec_text += f"... and {len(recommendations) - 10} more recommendations"

            await message_dialog(
                title="🤖 AI Maintenance Recommendations",
                text=rec_text,
                style=popup_style
            ).run_async()

            # Ask to schedule recommendations
            schedule_all = await yes_no_dialog(
                title="📅 Schedule Recommendations",
                text="Would you like to schedule these AI-generated maintenance recommendations?",
                style=popup_style
            ).run_async()

            if schedule_all:
                await self._show_message("Scheduling", "📅 Scheduling maintenance tasks...")
                
                scheduled_count = 0
                for rec in recommendations:
                    maintenance_data = {
                        'maintenance_type': rec['maintenance_type'],
                        'scheduled_date': rec['scheduled_date'],
                        'description': rec['description'],
                        'priority': rec['priority'],
                        'cost': rec['estimated_cost']
                    }
                    
                    maintenance_id = self.maintenance_scheduler.schedule_maintenance(
                        rec['equipment_id'], maintenance_data
                    )
                    
                    if maintenance_id:
                        scheduled_count += 1

                await self._show_success(f"✅ Scheduled {scheduled_count} maintenance tasks from AI recommendations!")

        except Exception as e:
            await self._show_error(f"Error generating AI schedule: {str(e)}")

        await self._wait_for_continue()

    async def _update_maintenance_status_flow(self):
        """Update maintenance status popup flow"""
        maintenance_id_str = await self._get_input("Update Status", "Enter Maintenance ID:")
        
        if not maintenance_id_str or not maintenance_id_str.isdigit():
            await self._show_warning("Valid Maintenance ID is required.")
            return

        maintenance_id = int(maintenance_id_str)

        try:
            # Get current maintenance info
            current_query = """
                SELECT mh.*, e.equipment_id, et.type_name 
                FROM maintenance_history mh
                JOIN equipment e ON mh.equipment_id = e.id
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE mh.id = %s
            """
            current = db_manager.execute_query(current_query, (maintenance_id,), fetch_one=True)
            
            if not current:
                await self._show_error("Maintenance task not found.")
                return

            await self._show_message("Current Task", f"📋 Maintenance Task #{current['id']}\n🆔 Equipment: {current['equipment_id']} ({current['type_name']})\n🔧 Type: {current['maintenance_type']}\n📊 Current Status: {current['status']}\n📅 Scheduled: {current['scheduled_date']}")

            # Status options
            status_options = [
                ("scheduled", "📅 Scheduled"),
                ("in_progress", "⚡ In Progress"),
                ("completed", "✅ Completed"),
                ("cancelled", "❌ Cancelled")
            ]

            new_status = await radiolist_dialog(
                title="🔄 Update Status",
                text=f"Current status: {current['status']}\nSelect new status:",
                values=status_options,
                default=current['status'],
                style=popup_style
            ).run_async()

            if not new_status:
                return

            completion_data = {}

            # Handle completion data for completed and cancelled statuses
            if new_status in ['completed', 'cancelled']:
                # Completion date
                date_input = await self._get_input("Completion Date", "Completion Date (YYYY-MM-DD) or 'today':", "today")
                
                if date_input.lower() == 'today' or date_input == '':
                    completion_date = datetime.now().date()
                else:
                    try:
                        completion_date = datetime.strptime(date_input, '%Y-%m-%d').date()
                    except ValueError:
                        await self._show_error("Invalid date format. Please use YYYY-MM-DD format.")
                        return
                
                completion_data['completed_date'] = completion_date

                # Actual cost
                cost_str = await self._get_input("Actual Cost", "Actual Cost (optional):")
                if cost_str:
                    try:
                        cost_value = float(cost_str)
                        if cost_value >= 0:
                            completion_data['actual_cost'] = cost_value
                        else:
                            await self._show_warning("Cost cannot be negative.")
                    except ValueError:
                        await self._show_warning("Invalid cost format.")

                # Downtime
                downtime_str = await self._get_input("Downtime", "Downtime in minutes (optional):")
                if downtime_str:
                    try:
                        downtime_value = int(float(downtime_str))
                        if downtime_value >= 0:
                            completion_data['downtime_minutes'] = downtime_value
                        else:
                            await self._show_warning("Downtime cannot be negative.")
                    except ValueError:
                        await self._show_warning("Invalid downtime format.")

                # Additional notes
                notes = await self._get_input("Notes", "Additional notes (optional):")
                if notes:
                    if current['description']:
                        completion_data['description'] = f"{current['description']}\nCompletion notes: {notes}"
                    else:
                        completion_data['description'] = f"Completion notes: {notes}"

            # Update status
            success = self.maintenance_scheduler.update_maintenance_status(
                maintenance_id, new_status, completion_data
            )
            
            if success:
                result_text = f"✅ Maintenance status updated successfully!\n\n"
                result_text += f"🆔 Task ID: {maintenance_id}\n"
                result_text += f"🔄 New Status: {new_status}\n"
                
                if new_status in ['completed', 'cancelled']:
                    result_text += f"📅 Completion Date: {completion_data.get('completed_date', 'N/A')}\n"
                    if 'actual_cost' in completion_data:
                        result_text += f"💰 Actual Cost: ${completion_data['actual_cost']:.2f}\n"
                    if 'downtime_minutes' in completion_data:
                        result_text += f"⏰ Downtime: {completion_data['downtime_minutes']} minutes\n"

                await message_dialog(
                    title="✅ Status Updated",
                    text=result_text,
                    style=popup_style
                ).run_async()
            else:
                await self._show_error("Failed to update maintenance status.")

        except Exception as e:
            await self._show_error(f"Error updating maintenance status: {str(e)}")

        await self._wait_for_continue()

    async def _maintenance_analytics_flow(self):
        """Maintenance analytics popup flow"""
        days_str = await self._get_input("Analytics Period", "Analysis period in days (default 90):", "90")
        days_back = int(days_str) if days_str.isdigit() else 90

        await self._show_message("Analytics", f"📊 Generating maintenance analytics for last {days_back} days...")

        try:
            analytics = self.maintenance_scheduler.get_maintenance_analytics(days_back)
            
            if not analytics:
                await self._show_warning("No analytics data available.")
                return

            # Format analytics
            analytics_text = f"📊 Maintenance Analytics - Last {days_back} Days\n\n"
            
            # Helper function to safely convert to float
            def safe_float(value, default=0.0):
                try:
                    if value is None:
                        return default
                    if hasattr(value, 'is_finite'):  # Decimal
                        return float(value)
                    return float(value) if value != 0 else default
                except:
                    return default
            
            # By status
            if analytics.get('by_status'):
                analytics_text += f"📈 By Status:\n"
                for item in analytics['by_status']:
                    avg_cost = safe_float(item.get('avg_cost'))
                    total_downtime = safe_float(item.get('total_downtime'))
                    downtime_hours = total_downtime / 60.0 if total_downtime > 0 else 0.0
                    
                    status_icons = {
                        'scheduled': '📅',
                        'in_progress': '⚡',
                        'completed': '✅',
                        'cancelled': '❌'
                    }
                    
                    status = item.get('status', 'unknown')
                    icon = status_icons.get(status, '⚪')
                    
                    analytics_text += f"  {icon} {status}: {item.get('count', 0)} tasks\n"
                    analytics_text += f"    💰 Avg Cost: ${avg_cost:.0f}\n"
                    analytics_text += f"    ⏰ Downtime: {downtime_hours:.1f} hrs\n"
                
                analytics_text += "\n"
            
            # By type
            if analytics.get('by_type'):
                analytics_text += f"🔧 By Maintenance Type:\n"
                for item in analytics['by_type']:
                    avg_cost = safe_float(item.get('avg_cost'))
                    avg_downtime = safe_float(item.get('avg_downtime'))
                    
                    type_icons = {
                        'preventive': '🛡️',
                        'corrective': '🔧',
                        'emergency': '🚨',
                        'scheduled': '📅'
                    }
                    
                    mtype = item.get('maintenance_type', 'unknown')
                    icon = type_icons.get(mtype, '🔧')
                    
                    analytics_text += f"  {icon} {mtype}: {item.get('count', 0)} tasks\n"
                    analytics_text += f"    💰 Avg Cost: ${avg_cost:.0f}\n"
                    analytics_text += f"    ⏰ Avg Downtime: {avg_downtime:.0f} min\n"
                
                analytics_text += "\n"
            
            # Summary
            if analytics.get('by_status'):
                total_maintenance = sum(item.get('count', 0) for item in analytics['by_status'])
                total_cost = sum(safe_float(item.get('avg_cost')) * item.get('count', 0) for item in analytics['by_status'])
                
                analytics_text += f"📊 Summary:\n"
                analytics_text += f"  📋 Total Tasks: {total_maintenance}\n"
                analytics_text += f"  💰 Total Cost: ${total_cost:.0f}\n"

            await message_dialog(
                title=f"📊 Maintenance Analytics - {days_back} Days",
                text=analytics_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error retrieving analytics: {str(e)}")

        await self._wait_for_continue()

    # Reports & Analytics Flow
    async def _reports_analytics_flow(self):
        """Reports and analytics popup flow"""
        while True:
            options = [
                ("1", "📋 Equipment Summary Report"),
                ("2", "❤️ Health Status Dashboard"),
                ("3", "⚠️ Failure Analysis Report"),
                ("4", "🔧 Maintenance Performance Report"),
                ("5", "🤖 Predictive Analytics Summary"),
                ("6", "💰 Cost Analysis Report"),
                ("0", "🔙 Back to Main Menu")
            ]

            choice = await radiolist_dialog(
                title="📊 Reports & Analytics",
                text="Select a report or analytics option:",
                values=options,
                style=popup_style
            ).run_async()

            if not choice or choice == "0":
                break

            if choice == "1":
                await self._equipment_summary_report_flow()
            elif choice == "2":
                await self._health_status_dashboard_flow()
            elif choice == "3":
                await self._failure_analysis_report_flow()
            elif choice == "4":
                await self._maintenance_performance_report_flow()
            elif choice == "5":
                await self._predictive_analytics_summary_flow()
            elif choice == "6":
                await self._cost_analysis_report_flow()

    async def _equipment_summary_report_flow(self):
        """Equipment summary report popup flow"""
        await self._show_message("Equipment Summary", "📊 Generating equipment summary report...")
        
        try:
            # Get comprehensive equipment data
            query = """
                SELECT 
                    et.type_name,
                    COUNT(e.id) as total_count,
                    COUNT(CASE WHEN e.status = 'active' THEN 1 END) as active_count,
                    COUNT(CASE WHEN e.status = 'maintenance' THEN 1 END) as maintenance_count,
                    COUNT(CASE WHEN e.status = 'failed' THEN 1 END) as failed_count,
                    AVG(DATEDIFF(CURDATE(), e.installation_date)) as avg_age_days
                FROM equipment_types et
                LEFT JOIN equipment e ON et.id = e.equipment_type_id
                GROUP BY et.id, et.type_name
                ORDER BY et.type_name
            """
            
            data = db_manager.execute_query(query)
            
            if not data:
                await self._show_warning("No equipment data available.")
                return

            # Format report
            report_text = f"📋 Equipment Summary Report\n"
            report_text += f"📅 Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            
            total_equipment = 0
            total_active = 0
            
            for item in data:
                total_equipment += item['total_count'] or 0
                total_active += item['active_count'] or 0
                
                report_text += f"📦 {item['type_name']}:\n"
                report_text += f"  📊 Total: {item['total_count'] or 0}\n"
                report_text += f"  ✅ Active: {item['active_count'] or 0}\n"
                report_text += f"  🔧 Maintenance: {item['maintenance_count'] or 0}\n"
                report_text += f"  ❌ Failed: {item['failed_count'] or 0}\n"
                if item['avg_age_days']:
                    report_text += f"  📅 Avg Age: {item['avg_age_days']:.0f} days\n"
                report_text += "\n"
            
            report_text += f"📊 Overall Summary:\n"
            report_text += f"  📋 Total Equipment: {total_equipment}\n"
            report_text += f"  ✅ Active Equipment: {total_active} ({(total_active/total_equipment*100) if total_equipment > 0 else 0:.1f}%)\n"

            await message_dialog(
                title="📋 Equipment Summary Report",
                text=report_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error generating equipment summary: {str(e)}")

        await self._wait_for_continue()

    async def _health_status_dashboard_flow(self):
        """Health status dashboard popup flow"""
        equipment_type_filter = await self._get_input("Health Dashboard", "Equipment type filter (leave empty for all):")
        
        await self._show_message("Health Dashboard", "❤️ Analyzing health data...")
        
        try:
            # Get health metrics summary
            base_query = """
                SELECT 
                    e.equipment_id,
                    et.type_name,
                    e.location,
                    hm.health_score,
                    hm.cpu_usage,
                    hm.memory_usage,
                    hm.temperature,
                    hm.timestamp,
                    CASE 
                        WHEN hm.health_score >= et.critical_threshold THEN 'CRITICAL'
                        WHEN hm.health_score >= et.warning_threshold THEN 'WARNING'
                        ELSE 'NORMAL'
                    END as health_status
                FROM equipment e
                JOIN equipment_types et ON e.equipment_type_id = et.id
                LEFT JOIN (
                    SELECT equipment_id, health_score, cpu_usage, memory_usage, temperature, timestamp,
                           ROW_NUMBER() OVER (PARTITION BY equipment_id ORDER BY timestamp DESC) as rn
                    FROM health_metrics
                ) hm ON e.id = hm.equipment_id AND hm.rn = 1
                WHERE e.status = 'active'
            """
            
            params = []
            if equipment_type_filter:
                base_query += " AND et.type_name = %s"
                params.append(equipment_type_filter)
            
            base_query += " ORDER BY hm.health_score DESC, e.equipment_id"
            
            data = db_manager.execute_query(base_query, tuple(params) if params else None)
            
            if not data:
                await self._show_warning("No health data available.")
                return

            # Categorize by health status
            critical_items = [item for item in data if item['health_status'] == 'CRITICAL']
            warning_items = [item for item in data if item['health_status'] == 'WARNING']
            normal_items = [item for item in data if item['health_status'] == 'NORMAL']

            # Format dashboard
            dashboard_text = f"❤️ Health Status Dashboard\n"
            dashboard_text += f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"

            # Critical items
            if critical_items:
                dashboard_text += f"🚨 CRITICAL HEALTH ({len(critical_items)} items):\n"
                for item in critical_items[:10]:  # Show first 10
                    dashboard_text += f"  • {item['equipment_id'][:15]} ({item['type_name'][:10]})\n"
                    dashboard_text += f"    📊 Health: {item['health_score']:.3f}\n"
                    if item['cpu_usage']:
                        dashboard_text += f"    💻 CPU: {item['cpu_usage']:.1f}%\n"
                    if item['temperature']:
                        dashboard_text += f"    🌡️ Temp: {item['temperature']:.1f}°C\n"
                    dashboard_text += "\n"
                
                if len(critical_items) > 10:
                    dashboard_text += f"  ... and {len(critical_items) - 10} more critical items\n\n"

            # Warning items
            if warning_items:
                dashboard_text += f"⚠️ WARNING HEALTH ({len(warning_items)} items):\n"
                for item in warning_items[:5]:  # Show first 5
                    dashboard_text += f"  • {item['equipment_id']} - Health: {item['health_score']:.3f}\n"
                if len(warning_items) > 5:
                    dashboard_text += f"  ... and {len(warning_items) - 5} more warning items\n"
                dashboard_text += "\n"

            # Summary
            total_items = len(data)
            dashboard_text += f"📊 Health Summary:\n"
            dashboard_text += f"  📋 Total Active Equipment: {total_items}\n"
            dashboard_text += f"  🚨 Critical: {len(critical_items)} ({len(critical_items)/total_items*100:.1f}%)\n"
            dashboard_text += f"  ⚠️ Warning: {len(warning_items)} ({len(warning_items)/total_items*100:.1f}%)\n"
            dashboard_text += f"  ✅ Normal: {len(normal_items)} ({len(normal_items)/total_items*100:.1f}%)\n"

            await message_dialog(
                title="❤️ Health Status Dashboard",
                text=dashboard_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error generating health dashboard: {str(e)}")

        await self._wait_for_continue()

    async def _failure_analysis_report_flow(self):
        """Failure analysis report popup flow"""
        days_str = await self._get_input("Failure Analysis", "Analysis period in days (default 90):", "90")
        days_back = int(days_str) if days_str.isdigit() else 90

        await self._show_message("Failure Analysis", f"⚠️ Analyzing failure patterns for last {days_back} days...")
        
        try:
            # Failure statistics
            failure_query = """
                SELECT 
                    et.type_name,
                    COUNT(fl.id) as failure_count,
                    AVG(fl.resolution_time_minutes) as avg_resolution_time,
                    COUNT(CASE WHEN fl.severity = 'critical' THEN 1 END) as critical_failures,
                    COUNT(CASE WHEN fl.severity = 'high' THEN 1 END) as high_failures
                FROM failure_logs fl
                JOIN equipment e ON fl.equipment_id = e.id
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE fl.failure_timestamp >= DATE_SUB(NOW(), INTERVAL %s DAY)
                GROUP BY et.id, et.type_name
                ORDER BY failure_count DESC
            """
            
            failure_data = db_manager.execute_query(failure_query, (days_back,))
            
            report_text = f"⚠️ Failure Analysis Report\n"
            report_text += f"📅 Period: Last {days_back} days\n\n"

            if failure_data:
                report_text += f"📊 Failures by Equipment Type:\n"
                
                total_failures = 0
                total_resolution_time = 0
                
                for item in failure_data:
                    total_failures += item['failure_count']
                    if item['avg_resolution_time']:
                        total_resolution_time += item['avg_resolution_time']
                    
                    report_text += f"📦 {item['type_name']}:\n"
                    report_text += f"  ❌ Failures: {item['failure_count']}\n"
                    report_text += f"  ⏱️ Avg Resolution: {item['avg_resolution_time']:.0f} min\n" if item['avg_resolution_time'] else "  ⏱️ Avg Resolution: N/A\n"
                    report_text += f"  🚨 Critical: {item['critical_failures']}\n"
                    report_text += f"  ⚠️ High: {item['high_failures']}\n\n"
                
                # Overall metrics
                if total_failures > 0:
                    avg_resolution = total_resolution_time / len(failure_data) if len(failure_data) > 0 else 0
                    report_text += f"📊 Overall Metrics:\n"
                    report_text += f"  📋 Total Failures: {total_failures}\n"
                    report_text += f"  ⏱️ Average Resolution Time: {avg_resolution:.0f} minutes\n"
                    
                    # Calculate MTTR (Mean Time To Repair)
                    report_text += f"  🔧 MTTR: {avg_resolution/60:.1f} hours\n"
            else:
                report_text += f"✅ No failures recorded in the specified period!\n"

            await message_dialog(
                title=f"⚠️ Failure Analysis - {days_back} Days",
                text=report_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error generating failure analysis: {str(e)}")

        await self._wait_for_continue()

    async def _maintenance_performance_report_flow(self):
        """Maintenance performance report popup flow"""
        days_str = await self._get_input("Performance Report", "Analysis period in days (default 180):", "180")
        days_back = int(days_str) if days_str.isdigit() else 180

        await self._show_message("Performance Report", f"🔧 Analyzing maintenance performance for last {days_back} days...")
        
        try:
            # Maintenance performance metrics
            performance_query = """
                SELECT 
                    et.type_name,
                    COUNT(mh.id) as total_maintenance,
                    COUNT(CASE WHEN mh.status = 'completed' THEN 1 END) as completed_maintenance,
                    AVG(mh.cost) as avg_cost,
                    SUM(mh.cost) as total_cost
                FROM maintenance_history mh
                JOIN equipment e ON mh.equipment_id = e.id
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE mh.scheduled_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
                GROUP BY et.id, et.type_name
                ORDER BY total_maintenance DESC
            """
            
            performance_data = db_manager.execute_query(performance_query, (days_back,))
            
            report_text = f"🔧 Maintenance Performance Report\n"
            report_text += f"📅 Period: Last {days_back} days\n\n"

            if performance_data:
                report_text += f"📊 Performance by Equipment Type:\n"
                
                grand_total_cost = 0
                overall_completion_rate = 0
                total_maintenance_all = 0
                completed_maintenance_all = 0
                
                for item in performance_data:
                    total_cost = item['total_cost'] or 0
                    grand_total_cost += total_cost
                    total_maintenance_all += item['total_maintenance']
                    completed_maintenance_all += item['completed_maintenance']
                    
                    completion_rate = (item['completed_maintenance'] / item['total_maintenance'] * 100) if item['total_maintenance'] > 0 else 0
                    
                    report_text += f"📦 {item['type_name']}:\n"
                    report_text += f"  📋 Total: {item['total_maintenance']}\n"
                    report_text += f"  ✅ Completed: {item['completed_maintenance']}\n"
                    report_text += f"  📊 Completion Rate: {completion_rate:.1f}%\n"
                    report_text += f"  💰 Avg Cost: ${item['avg_cost']:.0f}\n" if item['avg_cost'] else "  💰 Avg Cost: $0\n"
                    report_text += f"  💰 Total Cost: ${total_cost:.0f}\n\n"
                
                # Overall performance
                overall_completion_rate = (completed_maintenance_all / total_maintenance_all * 100) if total_maintenance_all > 0 else 0
                
                report_text += f"📊 Overall Performance:\n"
                report_text += f"  📋 Total Maintenance: {total_maintenance_all}\n"
                report_text += f"  ✅ Overall Completion Rate: {overall_completion_rate:.1f}%\n"
                report_text += f"  💰 Grand Total Cost: ${grand_total_cost:.0f}\n"
                
                # Performance indicators
                if overall_completion_rate >= 90:
                    report_text += f"  🎯 Performance: Excellent\n"
                elif overall_completion_rate >= 75:
                    report_text += f"  🎯 Performance: Good\n"
                elif overall_completion_rate >= 60:
                    report_text += f"  🎯 Performance: Needs Improvement\n"
                else:
                    report_text += f"  🎯 Performance: Poor\n"
            else:
                report_text += f"ℹ️ No maintenance data available for analysis.\n"

            await message_dialog(
                title=f"🔧 Maintenance Performance - {days_back} Days",
                text=report_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error generating maintenance performance report: {str(e)}")

        await self._wait_for_continue()

    async def _predictive_analytics_summary_flow(self):
        """Predictive analytics summary popup flow"""
        risk_threshold_input = await self._get_input("Predictive Analytics", "Risk threshold (low/medium/high/critical) [default: medium]:", "medium")
        risk_threshold = risk_threshold_input.lower() if risk_threshold_input else 'medium'
        
        threshold_values = {
            'low': 0.3,
            'medium': 0.5,
            'high': 0.7,
            'critical': 0.9
        }
        
        threshold_value = threshold_values.get(risk_threshold, 0.5)

        await self._show_message("Predictive Analytics", f"🤖 Analyzing prediction data with {risk_threshold.upper()} threshold ({threshold_value:.1f})...")
        
        try:
            # Recent predictions analysis
            predictions_query = """
                SELECT 
                    et.type_name,
                    COUNT(p.id) as total_predictions,
                    COUNT(CASE WHEN p.failure_probability >= %s THEN 1 END) as high_risk_predictions,
                    AVG(p.failure_probability) as avg_failure_probability,
                    MAX(p.failure_probability) as max_failure_probability,
                    COUNT(DISTINCT p.equipment_id) as equipment_analyzed
                FROM predictions p
                JOIN equipment e ON p.equipment_id = e.id
                JOIN equipment_types et ON e.equipment_type_id = et.id
                WHERE p.prediction_timestamp >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                GROUP BY et.id, et.type_name
                ORDER BY avg_failure_probability DESC
            """
            
            predictions_data = db_manager.execute_query(predictions_query, (threshold_value,))
            
            summary_text = f"🤖 Predictive Analytics Summary\n"
            summary_text += f"📅 Period: Last 7 days\n"
            summary_text += f"🎯 Risk Threshold: {risk_threshold.upper()} ({threshold_value:.1f})\n\n"

            if predictions_data:
                summary_text += f"📊 Predictions by Equipment Type:\n"
                
                total_predictions = 0
                total_high_risk = 0
                
                for item in predictions_data:
                    total_predictions += item['total_predictions']
                    total_high_risk += item['high_risk_predictions']
                    
                    summary_text += f"📦 {item['type_name']}:\n"
                    summary_text += f"  🔮 Total Predictions: {item['total_predictions']}\n"
                    summary_text += f"  ⚠️ High Risk: {item['high_risk_predictions']}\n"
                    summary_text += f"  📊 Avg Risk Score: {item['avg_failure_probability']:.3f}\n"
                    summary_text += f"  📈 Max Risk Score: {item['max_failure_probability']:.3f}\n"
                    summary_text += f"  📋 Equipment Analyzed: {item['equipment_analyzed']}\n\n"
                
                # Overall summary
                summary_text += f"📊 Overall Summary:\n"
                summary_text += f"  🔮 Total Predictions Made: {total_predictions}\n"
                if total_predictions > 0:
                    summary_text += f"  ⚠️ High Risk Predictions: {total_high_risk} ({total_high_risk/total_predictions*100:.1f}%)\n"
                    
                    # AI effectiveness indicators
                    if total_high_risk / total_predictions > 0.3:
                        summary_text += f"  🚨 Alert: High percentage of risky equipment detected!\n"
                    elif total_high_risk / total_predictions > 0.1:
                        summary_text += f"  ⚠️ Warning: Moderate risk level detected.\n"
                    else:
                        summary_text += f"  ✅ Good: Low overall risk level.\n"
                else:
                    summary_text += f"  ℹ️ No predictions available.\n"
            else:
                summary_text += f"ℹ️ No predictions found for the specified period.\n"
                summary_text += f"💡 Consider running AI predictions on your equipment.\n"

            await message_dialog(
                title="🤖 Predictive Analytics Summary",
                text=summary_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error generating predictive analytics summary: {str(e)}")

        await self._wait_for_continue()

    async def _cost_analysis_report_flow(self):
        """Cost analysis report popup flow"""
        days_str = await self._get_input("Cost Analysis", "Analysis period in days (default 365):", "365")
        days_back = int(days_str) if days_str.isdigit() else 365

        await self._show_message("Cost Analysis", f"💰 Analyzing cost data for last {days_back} days...")
        
        try:
            # Cost breakdown by equipment type
            cost_query = """
                SELECT 
                    et.type_name,
                    COUNT(DISTINCT e.id) as equipment_count,
                    COUNT(mh.id) as maintenance_events,
                    SUM(mh.cost) as total_maintenance_cost,
                    AVG(mh.cost) as avg_maintenance_cost,
                    SUM(CASE WHEN mh.maintenance_type = 'emergency' THEN mh.cost ELSE 0 END) as emergency_costs,
                    SUM(CASE WHEN mh.maintenance_type = 'preventive' THEN mh.cost ELSE 0 END) as preventive_costs
                FROM equipment_types et
                LEFT JOIN equipment e ON et.id = e.equipment_type_id
                LEFT JOIN maintenance_history mh ON e.id = mh.equipment_id 
                    AND mh.scheduled_date >= DATE_SUB(CURDATE(), INTERVAL %s DAY)
                    AND mh.status = 'completed'
                GROUP BY et.id, et.type_name
                ORDER BY total_maintenance_cost DESC
            """
            
            cost_data = db_manager.execute_query(cost_query, (days_back,))
            
            report_text = f"💰 Cost Analysis Report\n"
            report_text += f"📅 Period: Last {days_back} days\n\n"

            if cost_data:
                report_text += f"📊 Cost Analysis by Equipment Type:\n"
                
                grand_total = 0
                total_emergency = 0
                total_preventive = 0
                total_equipment = 0
                total_maintenance_events = 0
                
                for item in cost_data:
                    total_cost = item['total_maintenance_cost'] or 0
                    emergency_cost = item['emergency_costs'] or 0
                    preventive_cost = item['preventive_costs'] or 0
                    
                    grand_total += total_cost
                    total_emergency += emergency_cost
                    total_preventive += preventive_cost
                    total_equipment += item['equipment_count']
                    total_maintenance_events += item['maintenance_events'] or 0
                    
                    report_text += f"📦 {item['type_name']}:\n"
                    report_text += f"  📋 Equipment Count: {item['equipment_count']}\n"
                    report_text += f"  🔧 Maintenance Events: {item['maintenance_events'] or 0}\n"
                    report_text += f"  💰 Total Cost: ${total_cost:.0f}\n"
                    report_text += f"  📊 Avg Cost: ${item['avg_maintenance_cost']:.0f}\n" if item['avg_maintenance_cost'] else "  📊 Avg Cost: $0\n"
                    report_text += f"  🚨 Emergency Costs: ${emergency_cost:.0f}\n"
                    report_text += f"  🛡️ Preventive Costs: ${preventive_cost:.0f}\n\n"
                
                # Overall cost summary
                report_text += f"💰 Cost Summary:\n"
                report_text += f"  📋 Total Equipment: {total_equipment}\n"
                report_text += f"  🔧 Total Maintenance Events: {total_maintenance_events}\n"
                report_text += f"  💰 Grand Total: ${grand_total:.0f}\n"
                
                if grand_total > 0:
                    emergency_percentage = (total_emergency / grand_total * 100)
                    preventive_percentage = (total_preventive / grand_total * 100)
                    
                    report_text += f"  🚨 Emergency Costs: ${total_emergency:.0f} ({emergency_percentage:.1f}%)\n"
                    report_text += f"  🛡️ Preventive Costs: ${total_preventive:.0f} ({preventive_percentage:.1f}%)\n"
                    
                    # Cost efficiency analysis
                    if total_preventive > 0 and total_emergency > 0:
                        efficiency_ratio = total_preventive / total_emergency
                        report_text += f"  📊 Preventive/Emergency Ratio: {efficiency_ratio:.2f}\n"
                        
                        if efficiency_ratio < 1:
                            report_text += f"  💡 Recommendation: Increase preventive maintenance to reduce emergency costs.\n"
                        elif efficiency_ratio > 3:
                            report_text += f"  ✅ Good: Well-balanced maintenance strategy.\n"
                    
                    # Cost per equipment
                    if total_equipment > 0:
                        cost_per_equipment = grand_total / total_equipment
                        report_text += f"  📊 Cost per Equipment: ${cost_per_equipment:.0f}\n"
                        
                        if total_maintenance_events > 0:
                                                        cost_per_event = grand_total / total_maintenance_events
                                                        report_text += f"  📊 Cost per Event: ${cost_per_event:.0f}\n"
            else:
                report_text += f"ℹ️ No cost data available for analysis.\n"

            await message_dialog(
                title=f"💰 Cost Analysis - {days_back} Days",
                text=report_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error generating cost analysis: {str(e)}")

        await self._wait_for_continue()

    # System Management Flow
    async def _system_management_flow(self):
        """System management popup flow"""
        while True:
            options = [
                ("1", "📊 Database Status"),
                ("2", "🎲 Generate Training Data"),
                ("3", "⚙️ System Configuration"),
                ("4", "📤 Export Data"),
                ("5", "📋 System Logs"),
                ("0", "🔙 Back to Main Menu")
            ]

            choice = await radiolist_dialog(
                title="⚙️ System Management",
                text="Select a system management operation:",
                values=options,
                style=popup_style
            ).run_async()

            if not choice or choice == "0":
                break

            if choice == "1":
                await self._database_status_flow()
            elif choice == "2":
                await self._generate_training_data_flow()
            elif choice == "3":
                await self._system_configuration_flow()
            elif choice == "4":
                await self._export_data_flow()
            elif choice == "5":
                await self._system_logs_flow()

    async def _database_status_flow(self):
        """Database status popup flow"""
        await self._show_message("Database Status", "📊 Checking database connection and statistics...")
        
        try:
            # Test connection
            if db_manager.test_connection():
                connection_status = "✅ Active"
            else:
                await self._show_error("Database connection failed!")
                return

            # Get table statistics
            tables = [
                'equipment_types', 'equipment', 'health_metrics', 
                'maintenance_history', 'failure_logs', 'predictions'
            ]

            status_text = f"📊 Database Status Report\n"
            status_text += f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            status_text += f"🔗 Connection Status: {connection_status}\n"
            status_text += f"🗄️ Database: telecom_maintenance\n\n"
            status_text += f"📋 Table Statistics:\n"

            total_records = 0
            
            for table in tables:
                try:
                    result = db_manager.execute_query(f"SELECT COUNT(*) as count FROM {table}", fetch_one=True)
                    count = result['count'] if result else 0
                    total_records += count
                    
                    # Add emoji based on record count
                    if count > 1000:
                        emoji = "🚀"
                    elif count > 100:
                        emoji = "📈"
                    elif count > 0:
                        emoji = "✅"
                    else:
                        emoji = "⚪"
                    
                    status_text += f"  {emoji} {table}: {count:,} records\n"
                    
                except Exception as e:
                    status_text += f"  ❌ {table}: Error - {str(e)[:30]}...\n"
            
            status_text += f"\n📊 Total Records: {total_records:,}\n"
            status_text += f"⏰ Last Check: {datetime.now().strftime('%H:%M:%S')}\n"

            await message_dialog(
                title="📊 Database Status",
                text=status_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error checking database status: {str(e)}")

        await self._wait_for_continue()

    async def _generate_training_data_flow(self):
        """Generate training data popup flow"""
        confirm = await yes_no_dialog(
            title="🎲 Generate Training Data",
            text="⚠️ This will run the training data generator script.\nThis process will create synthetic equipment data and health metrics for AI model training.\n\nContinue?",
            style=popup_style
        ).run_async()

        if not confirm:
            await self._show_message("Cancelled", "Training data generation was cancelled.")
            return

        try:
            await self._show_message("Generating", "🚀 Starting training data generation...\nThis may take a few minutes.")

            import subprocess
            import sys
            
            # Run the training data generator
            result = subprocess.run([sys.executable, 'insert_training_data.py'], 
                                  capture_output=True, text=True, timeout=300)
            
            if result.returncode == 0:
                output_text = f"✅ Training data generation completed!\n\n"
                if result.stdout:
                    output_lines = result.stdout.strip().split('\n')[-10:]  # Last 10 lines
                    output_text += "📋 Output:\n" + '\n'.join(output_lines)
                
                await message_dialog(
                    title="✅ Generation Complete",
                    text=output_text,
                    style=popup_style
                ).run_async()
            else:
                error_text = f"❌ Training data generation failed!\n\n"
                if result.stderr:
                    error_lines = result.stderr.strip().split('\n')[-5:]  # Last 5 error lines
                    error_text += "❌ Error Details:\n" + '\n'.join(error_lines)
                
                await message_dialog(
                    title="❌ Generation Failed",
                    text=error_text,
                    style=popup_style
                ).run_async()
                
        except subprocess.TimeoutExpired:
            await self._show_error("Training data generation timed out after 5 minutes.")
        except Exception as e:
            await self._show_error(f"Error running training data generator: {str(e)}")
            await self._show_message("Manual Option", "💡 You can also run manually: python insert_training_data.py")

        await self._wait_for_continue()

    async def _system_configuration_flow(self):
        """System configuration popup flow"""
        await self._show_message("Configuration", "⚙️ Loading system configuration...")
        
        try:
            config_text = f"⚙️ System Configuration\n\n"
            
            # Database configuration
            config_text += f"🗄️ Database Configuration:\n"
            config_text += f"  🌐 Host: localhost\n"
            config_text += f"  📡 Port: 3306\n"
            config_text += f"  🗃️ Database: telecom_maintenance\n"
            config_text += f"  👤 User: root\n"
            config_text += f"  🔗 Pool Size: 10\n\n"
            
            # ML configuration
            config_text += f"🤖 ML Configuration:\n"
            config_text += f"  📁 Model Path: models/\n"
            config_text += f"  🎯 Features: 9 metrics\n"
            config_text += f"  📊 Test Size: 0.2\n"
            config_text += f"  🌳 RF Estimators: 100\n"
            config_text += f"  ⚠️ Failure Threshold: 0.3\n"
            config_text += f"  🚨 High Risk Threshold: 0.7\n"
            config_text += f"  🔴 Critical Risk Threshold: 0.9\n\n"
            
            # Feature columns
            feature_columns = [
                'cpu_usage', 'memory_usage', 'temperature', 
                'power_consumption', 'uptime_hours', 'packet_loss_rate',
                'error_count', 'bandwidth_utilization', 'signal_strength'
            ]
            
            config_text += f"📊 Feature Columns:\n"
            for i, feature in enumerate(feature_columns, 1):
                config_text += f"  {i:2d}. {feature}\n"

            await message_dialog(
                title="⚙️ System Configuration",
                text=config_text,
                style=popup_style
            ).run_async()

        except Exception as e:
            await self._show_error(f"Error displaying system configuration: {str(e)}")

        await self._wait_for_continue()

    async def _export_data_flow(self):
        """Export data popup flow"""
        export_options = [
            ("equipment", "📋 Equipment Data"),
            ("health", "❤️ Health Metrics (Last 30 Days)"),
            ("maintenance", "🔧 Maintenance History"),
            ("failures", "⚠️ Failure Logs"),
            ("all", "📦 All Data")
        ]

        export_choice = await radiolist_dialog(
            title="📤 Export Data",
            text="Select data to export:",
            values=export_options,
            style=popup_style
        ).run_async()

        if not export_choice:
            return

        try:
            await self._show_message("Exporting", f"📤 Exporting {export_choice} data...")

            date_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
            export_path = f"exports_{date_suffix}"
            
            # Create exports directory
            import os
            if not os.path.exists(export_path):
                os.makedirs(export_path)

            exports_completed = []
            
            if export_choice in ['equipment', 'all']:
                query = """
                    SELECT e.*, et.type_name, et.description as type_description
                    FROM equipment e
                    JOIN equipment_types et ON e.equipment_type_id = et.id
                    ORDER BY e.equipment_id
                """
                await self._export_to_csv(query, f"{export_path}/equipment_data.csv", "Equipment Data")
                exports_completed.append("Equipment Data")
            
            if export_choice in ['health', 'all']:
                query = """
                    SELECT hm.*, e.equipment_id, et.type_name
                    FROM health_metrics hm
                    JOIN equipment e ON hm.equipment_id = e.id
                    JOIN equipment_types et ON e.equipment_type_id = et.id
                    WHERE hm.timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                    ORDER BY hm.timestamp DESC
                """
                await self._export_to_csv(query, f"{export_path}/health_metrics.csv", "Health Metrics")
                exports_completed.append("Health Metrics")
            
            if export_choice in ['maintenance', 'all']:
                query = """
                    SELECT mh.*, e.equipment_id, et.type_name
                    FROM maintenance_history mh
                    JOIN equipment e ON mh.equipment_id = e.id
                    JOIN equipment_types et ON e.equipment_type_id = et.id
                    ORDER BY mh.scheduled_date DESC
                """
                await self._export_to_csv(query, f"{export_path}/maintenance_history.csv", "Maintenance History")
                exports_completed.append("Maintenance History")
            
            if export_choice in ['failures', 'all']:
                query = """
                    SELECT fl.*, e.equipment_id, et.type_name
                    FROM failure_logs fl
                    JOIN equipment e ON fl.equipment_id = e.id
                    JOIN equipment_types et ON e.equipment_type_id = et.id
                    ORDER BY fl.failure_timestamp DESC
                """
                await self._export_to_csv(query, f"{export_path}/failure_logs.csv", "Failure Logs")
                exports_completed.append("Failure Logs")

            if exports_completed:
                result_text = f"✅ Export completed successfully!\n\n"
                result_text += f"📄 Exported: {', '.join(exports_completed)}\n"
                result_text += f"📁 Location: {export_path}/\n"
                result_text += f"📅 Timestamp: {date_suffix}\n"
                
                await message_dialog(
                    title="✅ Export Complete",
                    text=result_text,
                    style=popup_style
                ).run_async()
            else:
                await self._show_warning("No exports completed.")

        except Exception as e:
            await self._show_error(f"Error exporting data: {str(e)}")

        await self._wait_for_continue()

    async def _export_to_csv(self, query: str, filename: str, description: str):
        """Export query results to CSV file"""
        try:
            import csv
            
            data = db_manager.execute_query(query)
            
            if data:
                with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                    if data:
                        fieldnames = data[0].keys()
                        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                        writer.writeheader()
                        writer.writerows(data)
                
                print(f"✅ {description}: {len(data)} records exported to {filename}")
            else:
                print(f"⚠️ {description}: No data found")
                
        except Exception as e:
            print(f"❌ {description}: Export failed - {e}")

    async def _system_logs_flow(self):
        """System logs popup flow"""
        log_file = 'telecom_maintenance.log'
        
        if not os.path.exists(log_file):
            await self._show_warning(f"Log file not found: {log_file}")
            return

        # Log filter options
        filter_options = [
            ("all", "📋 All Logs"),
            ("info", "ℹ️ INFO and above"),
            ("warning", "⚠️ WARNING and above"),
            ("error", "❌ ERROR only")
        ]

        filter_choice = await radiolist_dialog(
            title="📋 System Logs",
            text="Select log level filter:",
            values=filter_options,
            style=popup_style
        ).run_async()

        if not filter_choice:
            return

        num_lines_str = await self._get_input("Log Lines", "Number of recent lines to show (default 50):", "50")
        num_lines = int(num_lines_str) if num_lines_str.isdigit() else 50

        try:
            await self._show_message("Reading Logs", "📋 Reading log files...")

            # Read log file
            with open(log_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()

            # Apply filters
            filtered_lines = []
            for line in lines:
                if filter_choice == 'all':
                    filtered_lines.append(line)
                elif filter_choice == 'info' and ('INFO' in line or 'WARNING' in line or 'ERROR' in line):
                    filtered_lines.append(line)
                elif filter_choice == 'warning' and ('WARNING' in line or 'ERROR' in line):
                    filtered_lines.append(line)
                elif filter_choice == 'error' and 'ERROR' in line:
                    filtered_lines.append(line)

            # Show recent lines
            recent_lines = filtered_lines[-num_lines:] if filtered_lines else []

            if recent_lines:
                logs_text = f"📋 System Logs ({len(recent_lines)} lines)\n"
                logs_text += f"🔍 Filter: {filter_choice.upper()}\n"
                logs_text += f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
                
                for line in recent_lines[-20:]:  # Show last 20 for popup display
                    line = line.strip()
                    if 'ERROR' in line:
                        logs_text += f"❌ {line}\n"
                    elif 'WARNING' in line:
                        logs_text += f"⚠️ {line}\n"
                    elif 'INFO' in line:
                        logs_text += f"ℹ️ {line}\n"
                    else:
                        logs_text += f"📝 {line}\n"
                
                if len(recent_lines) > 20:
                    logs_text += f"\n... and {len(recent_lines) - 20} more log entries"

                await message_dialog(
                    title="📋 System Logs",
                    text=logs_text,
                    style=popup_style
                ).run_async()
            else:
                await self._show_warning("No log entries found matching criteria.")

        except Exception as e:
            await self._show_error(f"Error reading system logs: {str(e)}")

        await self._wait_for_continue()


def main():
    """Main entry point for popup CLI application"""
    try:
        print("🚀 Launching Telecom Equipment Maintenance Scheduler...")
        print("📱 Enhanced Popup CLI Interface")
        print("⏳ Initializing application...")
        
        # Initialize and run the popup application
        app = PopupTelecomMaintenanceApp()
        asyncio.run(app.run())
        
    except KeyboardInterrupt:
        print("\n⚠️ Application interrupted by user. Goodbye!")
    except Exception as e:
        print(f"💥 Fatal error: {e}")
        logger.error(f"Fatal error in popup CLI: {e}")


if __name__ == "__main__":
    main()

