"""Module to generate and insert synthetic training data for all equipment types."""
import random
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Any
import math
from utils.database_utils import db_manager
from modules.equipment_manager import EquipmentManager
from modules.health_monitor import HealthMonitor

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class TrainingDataGenerator:
    """Generates realistic synthetic training data for telecom equipment."""
    
    def __init__(self):
        self.db = db_manager
        self.equipment_manager = EquipmentManager()
        self.health_monitor = HealthMonitor()
        
        self.equipment_configs = {
            'Router': {
                'base_metrics': {
                    'cpu_usage': (30, 70, 85),
                    'memory_usage': (40, 75, 90),
                    'temperature': (35, 65, 80),
                    'power_consumption': (150, 300, 400),
                    'packet_loss_rate': (0.001, 0.01, 0.05),
                    'bandwidth_utilization': (45, 80, 95),
                    'signal_strength': (-45, -70, -85)
                },
                'failure_indicators': ['high_cpu', 'memory_leak', 'overheating', 'power_surge']
            },
            'Core_Switch': {
                'base_metrics': {
                    'cpu_usage': (25, 65, 80),
                    'memory_usage': (35, 70, 85),
                    'temperature': (30, 60, 75),
                    'power_consumption': (200, 400, 600),
                    'packet_loss_rate': (0.0005, 0.005, 0.02),
                    'bandwidth_utilization': (50, 85, 98),
                    'signal_strength': (-40, -65, -80)
                },
                'failure_indicators': ['port_failure', 'switching_delay', 'overheating', 'power_instability']
            },
            'Access_Switch': {
                'base_metrics': {
                    'cpu_usage': (20, 60, 75),
                    'memory_usage': (30, 65, 80),
                    'temperature': (28, 55, 70),
                    'power_consumption': (80, 150, 200),
                    'packet_loss_rate': (0.002, 0.015, 0.08),
                    'bandwidth_utilization': (35, 75, 90),
                    'signal_strength': (-50, -75, -90)
                },
                'failure_indicators': ['link_flapping', 'authentication_issues', 'overheating']
            },
            'Base_Station': {
                'base_metrics': {
                    'cpu_usage': (40, 75, 90),
                    'memory_usage': (45, 80, 95),
                    'temperature': (40, 70, 85),
                    'power_consumption': (500, 1000, 1500),
                    'packet_loss_rate': (0.003, 0.02, 0.1),
                    'bandwidth_utilization': (60, 90, 98),
                    'signal_strength': (-30, -60, -75)
                },
                'failure_indicators': ['rf_interference', 'antenna_misalignment', 'amplifier_failure']
            },
            'Optical_Transport': {
                'base_metrics': {
                    'cpu_usage': (15, 50, 65),
                    'memory_usage': (25, 60, 75),
                    'temperature': (25, 50, 65),
                    'power_consumption': (300, 600, 900),
                    'packet_loss_rate': (0.0001, 0.001, 0.01),
                    'bandwidth_utilization': (70, 95, 99),
                    'signal_strength': (-20, -40, -55)
                },
                'failure_indicators': ['fiber_degradation', 'optical_power_loss', 'laser_aging']
            }
        }
    
    def generate_complete_dataset(self, num_equipment_per_type: int = 20, 
                                days_of_data: int = 180, 
                                measurements_per_day: int = 24) -> bool:
        """Generate complete synthetic dataset for all equipment types."""
        try:
            logger.info("Starting complete dataset generation...")
            
            # Clear existing data (optional - remove for production)
            confirm_clear = input("Clear existing data? (y/N): ").strip().lower()
            if confirm_clear == 'y':
                self._clear_existing_data()
            
            # Generate equipment for each type
            equipment_ids = {}
            for equipment_type in self.equipment_configs.keys():
                logger.info(f"Generating equipment for {equipment_type}...")
                ids = self._generate_equipment(equipment_type, num_equipment_per_type)
                equipment_ids[equipment_type] = ids
            
            # Generate health metrics and failure data
            total_generated = 0
            for equipment_type, ids in equipment_ids.items():
                logger.info(f"Generating health data for {equipment_type}...")
                count = self._generate_health_metrics(
                    equipment_type, ids, days_of_data, measurements_per_day
                )
                total_generated += count
            
            logger.info(f"Dataset generation completed. Total records: {total_generated}")
            return True
            
        except Exception as e:
            logger.error(f"Error generating dataset: {e}")
            return False
    
    def _clear_existing_data(self):
        """Clear existing synthetic data (use with caution)."""
        try:
            logger.warning("Clearing existing data...")
            self.db.execute_update("DELETE FROM predictions", ())
            self.db.execute_update("DELETE FROM failure_logs", ())
            self.db.execute_update("DELETE FROM health_metrics", ())
            self.db.execute_update("DELETE FROM maintenance_history", ())
            self.db.execute_update("DELETE FROM equipment WHERE equipment_id LIKE '%-0%'", ())
            logger.info("Existing data cleared")
        except Exception as e:
            logger.error(f"Error clearing data: {e}")
    
    def _generate_equipment(self, equipment_type: str, count: int) -> List[int]:
        """Generate equipment entries for specific type."""
        equipment_ids = []
        
        type_query = "SELECT id FROM equipment_types WHERE type_name = %s"
        type_result = self.db.execute_query(type_query, (equipment_type,), fetch_one=True)
        
        if not type_result:
            logger.error(f"Equipment type {equipment_type} not found")
            return []
        
        type_id = type_result['id']
        
        for i in range(count):
            equipment_data = {
                'equipment_id': f"{equipment_type.upper()}-{i+1:03d}",
                'equipment_type_id': type_id,
                'location': self._generate_location(),
                'installation_date': self._generate_installation_date(),
                'manufacturer': self._generate_manufacturer(equipment_type),
                'model': self._generate_model(equipment_type),
                'firmware_version': self._generate_firmware_version(),
                'status': 'active'
            }
            
            equipment_id = self.equipment_manager.add_equipment(equipment_data)
            if equipment_id:
                equipment_ids.append(equipment_id)
        
        logger.info(f"Generated {len(equipment_ids)} {equipment_type} devices")
        return equipment_ids
    
    def _generate_health_metrics(self, equipment_type: str, equipment_ids: List[int], 
                               days: int, measurements_per_day: int) -> int:
        """Generate health metrics with realistic patterns and failures."""
        total_records = 0
        config = self.equipment_configs[equipment_type]
        
        for equipment_id in equipment_ids:
            # INCREASED failure probability to 30%
            failure_probability = 0.30
            will_fail = random.random() < failure_probability
            
            if will_fail:
                # Schedule 1-4 failure events (increased)
                failure_days = sorted(random.sample(range(days//3, days), random.randint(1, 4)))
            else:
                failure_days = []
            
            # Generate daily metrics
            equipment_condition = 'good'
            degradation_start = None
            
            for day in range(days):
                current_date = datetime.now() - timedelta(days=days-day)
                
                # Check if failure occurs on this day
                if day in failure_days:
                    self._create_failure_event(equipment_id, current_date, equipment_type)
                    equipment_condition = 'failing'
                
                # Start degradation 7-20 days before failure (increased window)
                if failure_days and not degradation_start:
                    next_failure = min([f for f in failure_days if f > day], default=None)
                    if next_failure and (next_failure - day) <= random.randint(7, 20):
                        equipment_condition = 'degrading'
                        degradation_start = day
                
                # Generate measurements for this day
                for hour in range(measurements_per_day):
                    timestamp = current_date + timedelta(hours=hour)
                    
                    metrics = self._generate_realistic_metrics(
                        config, equipment_condition, day, hour
                    )
                    
                    success = self.health_monitor.record_health_metrics(equipment_id, {
                        **metrics,
                        'timestamp': timestamp
                    })
                    
                    if success:
                        total_records += 1
                
                # Recovery after failure (maintenance simulation)
                if day in failure_days and day < days - 1:
                    equipment_condition = 'good'
                    self._create_maintenance_record(equipment_id, current_date)
        
        return total_records
    
    def _generate_realistic_metrics(self, config: Dict, condition: str, 
                                  day: int, hour: int) -> Dict[str, float]:
        """Generate realistic health metrics based on equipment condition."""
        metrics = {}
        base_metrics = config['base_metrics']
        
        # Time-based variations
        daily_cycle = math.sin(2 * math.pi * hour / 24)
        weekly_cycle = math.sin(2 * math.pi * day / 7)
        
        for metric, (normal, warning, critical) in base_metrics.items():
            base_value = normal
            
            # Apply condition-based modifications
            if condition == 'good':
                variation = random.gauss(0, normal * 0.1)
                if metric in ['cpu_usage', 'bandwidth_utilization']:
                    base_value += daily_cycle * normal * 0.2 + weekly_cycle * normal * 0.1
            
            elif condition == 'degrading':
                degradation_factor = 1 + random.uniform(0.1, 0.3)
                if metric in ['cpu_usage', 'memory_usage', 'temperature', 'error_count']:
                    base_value *= degradation_factor
                elif metric == 'packet_loss_rate':
                    base_value *= degradation_factor * 2
                
                variation = random.gauss(0, normal * 0.2)
            
            elif condition == 'failing':
                if metric in ['cpu_usage', 'memory_usage']:
                    base_value = random.uniform(warning, critical)
                elif metric == 'temperature':
                    base_value = random.uniform(warning * 0.9, critical)
                elif metric == 'packet_loss_rate':
                    base_value = random.uniform(warning, critical * 0.8)
                elif metric == 'error_count':
                    base_value = random.randint(50, 200)
                
                variation = random.gauss(0, normal * 0.3)
            
            # Calculate final value
            final_value = base_value + variation
            
            # Apply realistic bounds
            if metric in ['cpu_usage', 'memory_usage', 'bandwidth_utilization']:
                final_value = max(0, min(100, final_value))
            elif metric == 'temperature':
                final_value = max(15, min(120, final_value))
            elif metric == 'power_consumption':
                final_value = max(10, final_value)
            elif metric == 'packet_loss_rate':
                final_value = max(0, min(1.0, final_value))
            elif metric == 'error_count':
                final_value = max(0, int(final_value))
            elif metric == 'signal_strength':
                final_value = max(-100, min(-10, final_value))
            
            metrics[metric] = round(final_value, 4)
        
        # Add uptime hours (realistic values)
        metrics['uptime_hours'] = random.randint(1, 8760)  # Up to 1 year
        
        return metrics
    
    def _create_failure_event(self, equipment_id: int, timestamp: datetime, equipment_type: str):
        """Create a failure event in the database."""
        config = self.equipment_configs[equipment_type]
        failure_type = random.choice(config['failure_indicators'])
        
        severity_weights = {'low': 0.1, 'medium': 0.3, 'high': 0.4, 'critical': 0.2}
        severity = random.choices(
            list(severity_weights.keys()), 
            weights=list(severity_weights.values())
        )[0]
        
        # Resolution time based on severity
        resolution_times = {
            'low': random.randint(30, 120),
            'medium': random.randint(120, 360),
            'high': random.randint(360, 720),
            'critical': random.randint(720, 1440)
        }
        
        failure_data = {
            'equipment_id': equipment_id,
            'failure_timestamp': timestamp,
            'failure_type': failure_type,
            'severity': severity,
            'description': f"{failure_type.replace('_', ' ').title()} detected in {equipment_type}",
            'resolution_time_minutes': resolution_times[severity],
            'root_cause': self._generate_root_cause(failure_type),
            'resolved': True
        }
        
        try:
            query = """
                INSERT INTO failure_logs (
                    equipment_id, failure_timestamp, failure_type, severity,
                    description, resolution_time_minutes, root_cause, resolved
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            params = (
                failure_data['equipment_id'],
                failure_data['failure_timestamp'],
                failure_data['failure_type'],
                failure_data['severity'],
                failure_data['description'],
                failure_data['resolution_time_minutes'],
                failure_data['root_cause'],
                failure_data['resolved']
            )
            
            self.db.execute_insert(query, params)
            
        except Exception as e:
            logger.error(f"Error creating failure event: {e}")
    
    def _create_maintenance_record(self, equipment_id: int, timestamp: datetime):
        """Create a maintenance record after failure."""
        maintenance_types = ['corrective', 'emergency']
        maintenance_type = random.choice(maintenance_types)
        
        try:
            query = """
                INSERT INTO maintenance_history (
                    equipment_id, maintenance_type, scheduled_date, completed_date,
                    description, cost, status, priority, downtime_minutes
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            
            cost = random.uniform(200, 2000)
            downtime = random.randint(60, 300)
            
            params = (
                equipment_id,
                maintenance_type,
                timestamp.date(),
                timestamp.date(),
                f"Post-failure {maintenance_type} maintenance",
                cost,
                'completed',
                'high' if maintenance_type == 'emergency' else 'medium',
                downtime
            )
            
            self.db.execute_insert(query, params)
            
        except Exception as e:
            logger.error(f"Error creating maintenance record: {e}")
    
    def _generate_location(self) -> str:
        """Generate realistic equipment location."""
        cities = ['New York', 'Los Angeles', 'Chicago', 'Houston', 'Phoenix', 'Philadelphia']
        sites = ['Data Center', 'Cell Tower', 'Office Building', 'Hub Site', 'Remote Site']
        return f"{random.choice(cities)} - {random.choice(sites)} {random.randint(1, 50)}"
    
    def _generate_installation_date(self) -> datetime.date:
        """Generate realistic installation date."""
        days_ago = random.randint(30, 1825)  # 1 month to 5 years ago
        return (datetime.now() - timedelta(days=days_ago)).date()
    
    def _generate_manufacturer(self, equipment_type: str) -> str:
        """Generate realistic manufacturer based on equipment type."""
        manufacturers = {
            'Router': ['Cisco', 'Juniper', 'Huawei', 'Nokia'],
            'Core_Switch': ['Cisco', 'Arista', 'Juniper', 'HPE'],
            'Access_Switch': ['Cisco', 'HPE', 'Netgear', 'D-Link'],
            'Base_Station': ['Ericsson', 'Nokia', 'Huawei', 'Samsung'],
            'Optical_Transport': ['Ciena', 'Infinera', 'Nokia', 'Huawei']
        }
        return random.choice(manufacturers.get(equipment_type, ['Generic']))
    
    def _generate_model(self, equipment_type: str) -> str:
        """Generate realistic model number."""
        models = {
            'Router': ['ISR4431', 'ASR1001-X', 'MX480', 'NE40E-X8'],
            'Core_Switch': ['Catalyst 9500', 'Nexus 9000', 'EX4650', 'S12700'],
            'Access_Switch': ['Catalyst 2960', 'ProCurve 2920', 'GS308T', 'DGS-1100'],
            'Base_Station': ['AIR 6449', 'AAIU', 'BBU5900', 'Compact Macro'],
            'Optical_Transport': ['6500 Packet', 'FlexE', '1830 PSS', 'OptiX OSN']
        }
        return random.choice(models.get(equipment_type, ['Model-X']))
    
    def _generate_firmware_version(self) -> str:
        """Generate realistic firmware version."""
        major = random.randint(1, 5)
        minor = random.randint(0, 20)
        patch = random.randint(0, 50)
        return f"{major}.{minor}.{patch}"
    
    def _generate_root_cause(self, failure_type: str) -> str:
        """Generate realistic root cause based on failure type."""
        root_causes = {
            'high_cpu': 'Resource-intensive process consuming excessive CPU cycles',
            'memory_leak': 'Software bug causing gradual memory consumption increase',
            'overheating': 'Inadequate cooling or blocked ventilation',
            'power_surge': 'Electrical supply instability or voltage fluctuation',
            'port_failure': 'Physical port damage or connector wear',
            'switching_delay': 'Buffer overflow or processing bottleneck',
            'link_flapping': 'Intermittent cable connection or SFP module failure',
            'rf_interference': 'External signal interference or antenna misalignment',
            'fiber_degradation': 'Optical fiber bend loss or connector contamination',
            'laser_aging': 'Optical transmitter power degradation over time'
        }
        return root_causes.get(failure_type, 'Unknown root cause - investigation required')

def main():
    """Main function to run data generation."""
    try:
        generator = TrainingDataGenerator()
        
        print("=== Telecom Equipment Training Data Generator ===")
        print("This will generate synthetic training data for all equipment types.")
        
        # Get user input for generation parameters
        num_equipment = int(input("Number of equipment per type (default 10): ") or "10")
        days_of_data = int(input("Days of historical data (default 90): ") or "90")
        measurements_per_day = int(input("Measurements per day (default 24): ") or "24")
        
        confirm = input(f"Generate data for {num_equipment} devices per type, {days_of_data} days? (y/N): ")
        
        if confirm.lower() == 'y':
            success = generator.generate_complete_dataset(
                num_equipment_per_type=num_equipment,
                days_of_data=days_of_data,
                measurements_per_day=measurements_per_day
            )
            
            if success:
                print("✓ Training data generation completed successfully!")
                print(f"Generated data for {len(generator.equipment_configs)} equipment types")
                print(f"Total equipment: {num_equipment * len(generator.equipment_configs)}")
                print(f"Estimated health records: {num_equipment * len(generator.equipment_configs) * days_of_data * measurements_per_day}")
            else:
                print("✗ Data generation failed. Check logs for details.")
        else:
            print("Data generation cancelled.")
    
    except KeyboardInterrupt:
        print("\nData generation interrupted by user.")
    except Exception as e:
        logger.error(f"Error in main: {e}")
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
