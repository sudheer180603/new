import unittest
from modules.equipment_manager import EquipmentManager

class TestEquipmentManager(unittest.TestCase):
    def test_add_and_get_equipment(self):
        EquipmentManager.add_equipment('TEST12345', 1, 'Test Location', '2025-01-01', '2026-01-01', 'active')
        equipment = EquipmentManager.get_equipment_by_id(1)
        self.assertIsNotNone(equipment)
        self.assertEqual(equipment['serial_number'], 'TEST12345')

    def test_update_equipment(self):
        EquipmentManager.update_equipment(1, location='New Location', status='inactive')
        equipment = EquipmentManager.get_equipment_by_id(1)
        self.assertEqual(equipment['location'], 'New Location')
        self.assertEqual(equipment['status'], 'inactive')

    def test_delete_equipment(self):
        EquipmentManager.delete_equipment(1)
        equipment = EquipmentManager.get_equipment_by_id(1)
        self.assertIsNone(equipment)

if __name__ == '__main__':
    unittest.main()
