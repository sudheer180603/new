import unittest
from modules.health_monitor import HealthMonitor
from utils.database_utils import DatabaseUtils

class TestHealthMonitor(unittest.TestCase):
    def test_insert_and_get_metrics(self):
        # Add test data
        HealthMonitor.insert_metric(1, 'cpu_usage', 50.0, '%')
        metrics = HealthMonitor.get_latest_metrics(1)
        self.assertTrue(any(m['metric_name'] == 'cpu_usage' for m in metrics))

    def test_detect_anomalies(self):
        thresholds = {'cpu_usage': (10, 90)}
        anomalies = HealthMonitor.detect_anomalies(1, thresholds)
        # Anomalies will depend on data; test should pass if code runs without error
        self.assertIsInstance(anomalies, list)

if __name__ == '__main__':
    unittest.main()
