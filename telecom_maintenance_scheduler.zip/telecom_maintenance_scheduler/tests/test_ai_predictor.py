import unittest
from modules.ai_predictor import AIPredictor

class TestAIPredictor(unittest.TestCase):
    def test_train_and_predict(self):
        predictor = AIPredictor('models/Router_model.pkl')
        try:
            score = predictor.train_model('Router')
            self.assertIsInstance(score, float)
        except Exception:
            self.skipTest("Insufficient training data")

        predictor.load_model()
        try:
            pred = predictor.predict_failure('Router', {'cpu_usage': 50, 'memory_usage': 60, 'packet_loss': 2, 'temperature': 45})
            self.assertIn(pred, [0, 1])
        except Exception as e:
            self.fail(f"Prediction failed: {e}")

if __name__ == '__main__':
    unittest.main()
