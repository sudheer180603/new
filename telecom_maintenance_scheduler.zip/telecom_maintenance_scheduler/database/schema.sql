DROP DATABASE IF EXISTS telecom_maintenance;
CREATE DATABASE telecom_maintenance;
USE telecom_maintenance;

CREATE TABLE equipment_types (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    default_maintenance_interval_days INT DEFAULT 30,
    critical_threshold DECIMAL(5,2) DEFAULT 0.8,
    warning_threshold DECIMAL(5,2) DEFAULT 0.6,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE equipment (
    id INT AUTO_INCREMENT PRIMARY KEY,
    equipment_id VARCHAR(50) NOT NULL UNIQUE,
    equipment_type_id INT NOT NULL,
    location VARCHAR(255),
    installation_date DATE,
    last_maintenance_date DATE,
    status ENUM('active', 'inactive', 'maintenance', 'failed') DEFAULT 'active',
    manufacturer VARCHAR(100),
    model VARCHAR(100),
    firmware_version VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (equipment_type_id) REFERENCES equipment_types(id),
    INDEX idx_equipment_type (equipment_type_id),
    INDEX idx_status (status),
    INDEX idx_location (location)
);

CREATE TABLE health_metrics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    equipment_id INT NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    cpu_usage DECIMAL(5,2),
    memory_usage DECIMAL(5,2),
    temperature DECIMAL(5,2),
    power_consumption DECIMAL(8,2),
    uptime_hours INT,
    packet_loss_rate DECIMAL(5,4),
    error_count INT DEFAULT 0,
    bandwidth_utilization DECIMAL(5,2),
    signal_strength DECIMAL(5,2),
    health_score DECIMAL(5,2),
    FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE,
    INDEX idx_equipment_timestamp (equipment_id, timestamp),
    INDEX idx_health_score (health_score)
);

CREATE TABLE maintenance_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    equipment_id INT NOT NULL,
    maintenance_type ENUM('preventive', 'corrective', 'emergency', 'scheduled') NOT NULL,
    scheduled_date DATE NOT NULL,
    completed_date DATE,
    technician_id VARCHAR(50),
    description TEXT,
    cost DECIMAL(10,2),
    status ENUM('scheduled', 'in_progress', 'completed', 'cancelled') DEFAULT 'scheduled',
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    downtime_minutes INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE,
    INDEX idx_equipment_scheduled (equipment_id, scheduled_date),
    INDEX idx_status_priority (status, priority)
);

CREATE TABLE failure_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    equipment_id INT NOT NULL,
    failure_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    failure_type VARCHAR(100),
    severity ENUM('low', 'medium', 'high', 'critical') NOT NULL,
    description TEXT,
    resolution_time_minutes INT,
    root_cause TEXT,
    resolved BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE,
    INDEX idx_equipment_failure (equipment_id, failure_timestamp),
    INDEX idx_severity_resolved (severity, resolved)
);

CREATE TABLE predictions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    equipment_id INT NOT NULL,
    prediction_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    failure_probability DECIMAL(5,4) NOT NULL,
    predicted_failure_date DATE,
    model_version VARCHAR(20),
    confidence_score DECIMAL(5,4),
    recommended_action VARCHAR(255),
    FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE,
    INDEX idx_equipment_prediction (equipment_id, prediction_timestamp),
    INDEX idx_failure_probability (failure_probability DESC)
);

INSERT INTO equipment_types (type_name, description, default_maintenance_interval_days, critical_threshold, warning_threshold) VALUES
('Router', 'Network routing equipment for data packet forwarding', 30, 0.85, 0.65),
('Core_Switch', 'High-capacity network switches for core infrastructure', 45, 0.80, 0.60),
('Access_Switch', 'Edge network switches for end-user connectivity', 60, 0.75, 0.55),
('Base_Station', 'Cellular base station equipment for mobile communications', 21, 0.90, 0.70),
('Optical_Transport', 'Optical transmission equipment for long-distance communication', 90, 0.85, 0.65);
