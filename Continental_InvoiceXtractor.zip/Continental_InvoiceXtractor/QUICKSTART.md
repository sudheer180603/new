# Quick Start Guide

Get up and running with the SAP Invoice Processing System in 5 minutes.

## Prerequisites

- Python 3.8 or higher
- Azure OpenAI API access (configured in `.env`)
- AWS credentials (optional, for scanned PDF support)
- PDF invoices (text-based or scanned)

## Installation

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

This installs:
- **Core**: streamlit, pdfplumber, openai, pandas, openpyxl
- **Enhanced**: boto3, PyMuPDF, Pillow (for Textract fallback)
- **Utilities**: python-dotenv, pydantic

### Step 2: Verify Configuration

Your `.env` file contains:

```bash
# Azure OpenAI (Required)
AZURE_OPENAI_API_KEY=4DIsnzShsiv0nPASCDpn0VexIP9DZhIzf8okcZQKOVAhmP5nngmdJQQJ99BHACHYHv6XJ3w3AAABACOGKSS2
AZURE_OPENAI_API_VERSION=2024-12-01-preview
AZURE_OPENAI_ENDPOINT=https://prodpat-ai-agents.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=gpt-5-mini

# AWS Textract (Optional - for scanned PDFs)
AWS_ACCESS_KEY_ID=AKIASL2YHWSXWU632SUV
AWS_SECRET_ACCESS_KEY=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
AWS_REGION=us-east-1
```

### Step 3: Verify Installation

```bash
python verify_installation.py
```

Expected output:
```
✅ All dependencies installed
✅ Azure OpenAI configured
✅ AWS Textract available (optional)
✅ System ready!
```

## Usage Options

### Option 1: Web UI (Recommended)

```bash
streamlit run app.py
```

**Features:**
- Single or multiple PDF upload
- Real-time processing status
- Batch processing support
- Download all outputs
- Visual results display

**Steps:**
1. Open browser at `http://localhost:8501`
2. Choose "Single PDF" or "Multiple PDFs"
3. Upload PDF(s) (e.g., `POC_1.pdf`)
4. Configure base Excel path (optional)
5. Click "Process Invoice(s)"
6. View results and download outputs

### Option 2: Command Line

```bash
# Single PDF
python test_system.py

# Multiple PDFs
python test_multiple_pdf.py
```

**Features:**
- Terminal-based processing
- Batch processing support
- Progress indicators
- Detailed logging

### Option 3: Python Script

```python
from agents.orchestrator import OrchestratorAgent

orchestrator = OrchestratorAgent()

# Single PDF
result = orchestrator.execute({
    "pdf_path": "POC_1.pdf",
    "base_excel_path": "consolidated_acss_invoices_sample_output.xlsx",
    "output_dir": "output"
})

# Multiple PDFs
result = orchestrator.execute({
    "pdf_paths": ["POC_1.pdf", "POC_2.pdf", "POC_3.pdf"],
    "base_excel_path": "consolidated_acss_invoices_sample_output.xlsx",
    "output_dir": "output"
})

print(f"Status: {result['status']}")
print(f"Files processed: {result.get('processed_files', 1)}")
print(f"Rows added: {result['num_rows_added']}")
```

## Processing Pipeline

The system processes invoices through 5 specialized agents:

```
PDF Input → PDF Agent → LLM Agent → Validation Agent → Excel Agent → Output
```

### **1. PDF Agent**
- **Primary**: pdfplumber for text-based PDFs
- **Fallback**: AWS Textract for scanned PDFs
- **Output**: Raw text + tables + metadata

### **2. LLM Agent (3-Phase)**
- **Phase 1**: Detect number of invoices
- **Phase 2**: Extract to raw JSON (lossless)
- **Phase 3**: Normalize to SAP schema

### **3. Validation Agent**
- Validate required fields
- Calculate confidence score (0-1)
- Generate issues and warnings

### **4. Excel Agent**
- Map SAP JSON to Excel rows
- Update existing Excel or create new
- Create automatic backups

## Output Files

### Single PDF Processing
Check the `output/` directory for:
- `raw_invoice_TIMESTAMP.json` - Lossless extraction
- `sap_invoice_TIMESTAMP.json` - SAP-normalized data
- `invoice_output_TIMESTAMP.xlsx` - Final Excel file
- `confidence_report_TIMESTAMP.json` - Validation report

### Batch PDF Processing
Additional files for batch processing:
- `batch_raw_invoices_TIMESTAMP.json` - Combined raw data
- `batch_sap_invoices_TIMESTAMP.json` - Combined SAP data
- `batch_invoice_output_TIMESTAMP.xlsx` - Combined Excel
- `batch_processing_report_TIMESTAMP.json` - Batch statistics

### Excel Updates
When updating existing Excel files:
- `filename.backup_TIMESTAMP.xlsx` - Automatic backup

## Example Results

### Single PDF Processing
```
✅ Status: SUCCESS

📊 Processing Details:
  - Method: PDFPlumber (text-based PDF)
  - Confidence Score: 87.5%
  - Excel Operation: Updated existing file

📈 Statistics:
  - Invoices processed: 1
  - Line items extracted: 5
  - Rows added to Excel: 5
  - Total rows in Excel: 105 (100 existing + 5 new)

📁 Output Files:
  - Raw JSON: output/raw_invoice_20260203_143022.json
  - SAP JSON: output/sap_invoice_20260203_143022.json
  - Excel: consolidated_acss_invoices_sample_output.xlsx
  - Backup: consolidated_acss_invoices_sample_output.xlsx.backup_20260203_143022.xlsx
  - Report: output/confidence_report_20260203_143022.json
```

### Batch PDF Processing
```
✅ Status: SUCCESS

📊 Batch Processing Results:
  - Total files: 3
  - Successfully processed: 3
  - Failed files: 0
  - Processing method: Mixed (PDFPlumber + Textract)

📈 Combined Statistics:
  - Total invoices: 52
  - Total line items: 156
  - Rows added to Excel: 156
  - Excel operation: Updated existing file

📁 Batch Output Files:
  - Combined raw: output/batch_raw_invoices_20260203_143022.json
  - Combined SAP: output/batch_sap_invoices_20260203_143022.json
  - Combined Excel: consolidated_acss_invoices_sample_output.xlsx
  - Batch report: output/batch_processing_report_20260203_143022.json
```

## Testing with Sample PDFs

### Available Test Files
- **POC_1.pdf**: Single DHL invoice (17 pages, 69 tables)
- **POC_2.pdf**: American Express statement (61 pages, 50+ invoices)
- **POC_3.pdf**: Single DHL invoice (2 pages, 4 tables)
- **POC_4-6.pdf**: Various single invoice formats

### Quick Test Commands

```bash
# Test single PDF
python -c "
from agents.orchestrator import OrchestratorAgent
result = OrchestratorAgent().execute({'pdf_path': 'POC_1.pdf'})
print(f'Status: {result[\"status\"]}, Rows: {result.get(\"num_rows_added\", 0)}')
"

# Test batch processing
python test_multiple_pdf.py

# Test with scanned PDF (if available)
python -c "
from agents.pdf_agent import PDFAgent
result = PDFAgent().execute({'pdf_path': 'scanned_invoice.pdf'})
print(f'Method: {result[\"metadata\"].get(\"processing_method\", \"Unknown\")}')
"
```

## Understanding Results

### Confidence Scoring
- **90-100%**: Excellent - All required fields present
- **70-90%**: Good - Minor issues, ready to use
- **50-70%**: Fair - Some missing fields, review recommended
- **<50%**: Poor - Major issues, manual intervention needed

### Processing Methods
- **PDFPlumber**: Fast, for text-based PDFs
- **AWS Textract**: Slower, for scanned/image PDFs
- **Mixed**: Combination used in batch processing

### Excel Operations
- **Updated**: Existing file modified directly
- **Created**: New file created with timestamp
- **From Template**: New file created using existing as template

## Advanced Features

### Large Document Handling
The system automatically handles large documents:
- **Chunking**: Documents >50KB split automatically
- **Batch normalization**: 15 invoices per API call
- **Memory efficient**: Streaming processing

### Granular Line Item Extraction
- Each charge/fee/surcharge as separate line item
- No aggregation - preserves accounting detail
- Proper BSCHL codes (40 for items, 31 for totals)

### Error Recovery
- Graceful degradation when services fail
- Partial results saved even on errors
- Detailed error logging and reporting

## Troubleshooting

### Installation Issues
```bash
# Missing dependencies
pip install -r requirements.txt

# Python version check
python --version  # Should be 3.8+

# Verify installation
python verify_installation.py
```

### Processing Issues

**"PDF extraction failed"**
- For text-based PDFs: Check if PDF is corrupted
- For scanned PDFs: Verify AWS credentials in `.env`
- Try: `python -c "import pdfplumber; print('PDFPlumber OK')"`

**"Azure OpenAI error"**
- Check API key in `.env`
- Verify endpoint URL and deployment name
- Test: `python -c "from openai import AzureOpenAI; print('OpenAI OK')"`

**"Low confidence score"**
- Review `confidence_report_*.json` for specific issues
- Check if invoice has standard structure
- Verify required fields (BELNR, BLDAT, WAERS, WRBTR) are present

**"Textract fallback failed"**
- Check AWS credentials in `.env`
- Verify AWS region setting
- Test: `python -c "import boto3; print('Boto3 OK')"`

### Performance Issues

**"Processing too slow"**
- Large documents automatically use chunking
- Batch processing is more efficient for multiple files
- Check Azure OpenAI API rate limits

**"Memory issues"**
- System uses streaming for large files
- Temporary files cleaned automatically
- Check available disk space in `output/` and `temp/`

## Next Steps

### 1. Process Your Invoices
- Start with single PDF to test
- Use batch processing for multiple files
- Review confidence scores and validation reports

### 2. Customize the System
- **Schema**: Edit `config/sap_schema.py` for custom fields
- **Prompts**: Modify `agents/llm_agent.py` for extraction rules
- **Validation**: Update `agents/validation_agent.py` for custom rules
- **UI**: Customize `app.py` for different layouts

### 3. Integration
- Use programmatic API for custom workflows
- Add REST API wrapper for web services
- Integrate with existing SAP systems

### 4. Monitoring
- Review confidence reports regularly
- Monitor processing logs for issues
- Track batch processing statistics

## Quick Reference

### Essential Commands
```bash
# Install and verify
pip install -r requirements.txt
python verify_installation.py

# Run web UI
streamlit run app.py

# Test single PDF
python test_system.py

# Test batch processing
python test_multiple_pdf.py

# Check system status
python -c "from agents.orchestrator import OrchestratorAgent; print('System ready!')"
```

### Key Files
- **Configuration**: `.env` (credentials), `config/sap_schema.py` (schema)
- **Main app**: `app.py` (web UI), `agents/orchestrator.py` (core logic)
- **Documentation**: `docs/` (detailed guides), `README.md` (overview)
- **Outputs**: `output/` (results), `temp/` (temporary files)

### Success Checklist

- [ ] Dependencies installed (`pip install -r requirements.txt`)
- [ ] Configuration verified (`python verify_installation.py`)
- [ ] Web UI opens (`streamlit run app.py`)
- [ ] Sample PDF processes successfully
- [ ] Output files generated in `output/` directory
- [ ] Excel file opens and contains data
- [ ] Confidence score > 70%
- [ ] Batch processing works (optional)
- [ ] Textract fallback available (optional)

## Getting Help

- **Quick Issues**: Check troubleshooting section above
- **Architecture**: See `docs/ARCHITECTURE.md`
- **Detailed Usage**: See `docs/USAGE.md`
- **Customization**: See `docs/PROMPTS.md`
- **File Structure**: See `PROJECT_STRUCTURE.md`
- **Implementation**: See `IMPLEMENTATION_SUMMARY.md`

You're ready to process invoices at scale! 🚀

**System Status: ✅ Production Ready**
