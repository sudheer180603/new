# SAP Invoice Processing System

> **Multi-Agent System for Automated Invoice Processing**
> 
> Upload PDF invoices → Extract data → Normalize to SAP format → Generate Excel

[![Python](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/)
[![Streamlit](https://img.shields.io/badge/Streamlit-1.32+-red.svg)](https://streamlit.io/)
[![Azure OpenAI](https://img.shields.io/badge/Azure-OpenAI-green.svg)](https://azure.microsoft.com/en-us/products/ai-services/openai-service)

## 🎯 Overview

This system automatically processes text-based PDF invoices and converts them into SAP-formatted Excel files using a multi-agent architecture. Each agent specializes in a specific task, making the system modular, maintainable, and extensible.

### Key Features

✅ **Text-based PDF extraction** using pdfplumber  
✅ **AI-powered data extraction** with Azure OpenAI  
✅ **SAP schema normalization** with 35 standard fields  
✅ **Confidence scoring** and validation  
✅ **Multi-invoice support** in single PDF  
✅ **Audit trail** with raw and normalized JSON  
✅ **Web UI** with Streamlit  
✅ **No hardcoding** - works with any invoice format  

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Streamlit UI                            │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                   Orchestrator Agent                         │
│  Coordinates: PDF → LLM → Validation → Excel                │
└─────────────────────────────────────────────────────────────┘
                            │
        ┌───────────────────┼───────────────────┐
        ▼                   ▼                   ▼
┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│  PDF Agent   │   │  LLM Agent   │   │ Excel Agent  │
│              │   │              │   │              │
│ - Extract    │   │ - Detect     │   │ - Map JSON   │
│   text       │   │ - Extract    │   │ - Generate   │
│ - Parse      │   │ - Normalize  │   │   Excel      │
│   tables     │   │ - Validate   │   │ - Append     │
└──────────────┘   └──────────────┘   └──────────────┘
                            │
                            ▼
                    ┌──────────────┐
                    │ Validation   │
                    │ Agent        │
                    │              │
                    │ - Validate   │
                    │ - Score      │
                    │ - Report     │
                    └──────────────┘
```

## 🚀 Quick Start

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Run the Application

```bash
streamlit run app.py
```

### 3. Process an Invoice

1. Open browser at `http://localhost:8501`
2. Upload a PDF invoice
3. Click "Process Invoice"
4. Download results

**That's it!** See [QUICKSTART.md](QUICKSTART.md) for detailed instructions.

## 📊 Output

The system generates 4 outputs:

1. **Raw JSON** - Lossless extraction of all invoice data
2. **SAP JSON** - Normalized to SAP schema
3. **Excel File** - SAP-formatted rows ready for import
4. **Confidence Report** - Validation results and issues

### Example Output Structure

```
output/
├── raw_invoice_20260203_143022.json      # All extracted data
├── sap_invoice_20260203_143022.json      # SAP-normalized
├── invoice_output_20260203_143022.xlsx   # Final Excel
└── confidence_report_20260203_143022.json # Validation
```

## 🤖 Agents

| Agent | Responsibility | Technology |
|-------|---------------|------------|
| **PDF Agent** | Extract text and tables from PDF | pdfplumber |
| **LLM Agent** | Detect, extract, and normalize invoice data | Azure OpenAI |
| **Excel Agent** | Generate SAP-formatted Excel | pandas, openpyxl |
| **Validation Agent** | Validate data and calculate confidence | Python |
| **Orchestrator** | Coordinate all agents | Python |

## 📋 SAP Schema

The system supports 35 SAP fields including:

- **Document Info**: BELNR, BUDAT, BLDAT, BLART, BUKRS
- **Financial**: WAERS, WRBTR, Steuerbetrag, Betrag in HW
- **Line Items**: SGTXT, Artikel, MENGE, MEINS
- **Accounting**: HKONT, KOSTL, BSCHL, MWSKZ
- **Dates**: BZDAT, ZFBDT, Tage
- **Optional**: AUFNR, VBUND, Projekt-Nr, WERK, etc.

See [config/sap_schema.py](config/sap_schema.py) for complete schema.

## 📁 Project Structure

```
invoice-processing-system/
├── app.py                    # Streamlit UI
├── test_system.py            # Test script
├── requirements.txt          # Dependencies
├── .env                      # Azure OpenAI config
│
├── agents/                   # Agent implementations
│   ├── orchestrator.py       # Main coordinator
│   ├── pdf_agent.py          # PDF extraction
│   ├── llm_agent.py          # AI processing
│   ├── excel_agent.py        # Excel generation
│   └── validation_agent.py   # Validation
│
├── config/                   # Configuration
│   └── sap_schema.py         # SAP schema definition
│
├── utils/                    # Utilities
│   ├── date_utils.py         # Date handling
│   └── validation_utils.py   # Validation helpers
│
└── docs/                     # Documentation
    ├── ARCHITECTURE.md       # System design
    ├── USAGE.md              # Usage guide
    └── PROMPTS.md            # LLM prompts
```

See [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) for detailed structure.

## 🔧 Tech Stack

- **Python 3.8+** - Core language
- **Streamlit** - Web UI
- **pdfplumber** - PDF text extraction
- **Azure OpenAI** - AI-powered extraction
- **pandas** - Data manipulation
- **openpyxl** - Excel generation
- **pydantic** - Data validation

## 📖 Documentation

- [QUICKSTART.md](QUICKSTART.md) - Get started in 5 minutes
- [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) - System architecture
- [docs/USAGE.md](docs/USAGE.md) - Detailed usage guide
- [docs/PROMPTS.md](docs/PROMPTS.md) - LLM prompts
- [PROJECT_STRUCTURE.md](PROJECT_STRUCTURE.md) - File structure

## 🎯 Use Cases

- **Accounts Payable**: Automate invoice data entry
- **Expense Management**: Process employee expense reports
- **Vendor Management**: Extract vendor invoice data
- **Audit & Compliance**: Maintain audit trail with JSON outputs
- **ERP Integration**: Generate SAP-ready Excel files

## 🔒 Design Principles

1. **Agent-Based**: Modular, single-responsibility agents
2. **JSON as Truth**: All data flows through JSON
3. **No Hardcoding**: Schema-driven, not vendor-specific
4. **Deterministic**: LLM only for semantic tasks
5. **Audit Trail**: All intermediate outputs saved
6. **Graceful Degradation**: Agents handle errors independently

## 🧪 Testing

```bash
# Test with sample PDFs
python test_system.py

# Or use the UI
streamlit run app.py
```

Sample PDFs included: `POC_1.pdf` through `POC_6.pdf`

## 🛠️ Customization

### Add Custom SAP Fields

Edit `config/sap_schema.py`:
```python
SAP_COLUMNS.append("MY_CUSTOM_FIELD")
```

### Modify LLM Prompts

Edit `agents/llm_agent.py` - see [docs/PROMPTS.md](docs/PROMPTS.md)

### Change Default Values

Edit `config/sap_schema.py`:
```python
DEFAULT_VALUES["BLART"] = "MY_TYPE"
```

## 📊 Confidence Scoring

- **90-100%**: Excellent - All required fields present
- **70-90%**: Good - Minor issues
- **50-70%**: Fair - Some fields missing
- **<50%**: Poor - Manual review needed

## 🤝 Contributing

This is a POC system. To extend:

1. Add new agents in `agents/`
2. Update SAP schema in `config/`
3. Modify prompts in `agents/llm_agent.py`
4. Add validation rules in `agents/validation_agent.py`

## 📝 License

Internal use only - Client POC

## 🙋 Support

- Check [docs/USAGE.md](docs/USAGE.md) for troubleshooting
- Review [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for system design
- See [docs/PROMPTS.md](docs/PROMPTS.md) for LLM customization

---

**Built with ❤️ using Multi-Agent Architecture**
